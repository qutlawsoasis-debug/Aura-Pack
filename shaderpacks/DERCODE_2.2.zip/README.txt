


=============================================================================================================

All Rights Reserved

Copyright (C) 2025 Mizore

The DERCODE Project – a rework of DERIVATIVE MAIN (feel free to use the source however you want)

It has no relation to projects like Complementary or any others.

All source codes used in the project are, first and foremost, approved by the original owners (if they are not open-source).

The project was originally created as a fork of Bliss, but was later moved to DERIVATIVE because it is more stable and allows for more features to be implemented.

THE AUTHORS ARE NOT RESPONSIBLE IF YOUR GPU CATCHES FIRE xD

THE SHADER IS EXTREMELY UNOPTIMIZED FOR WEAK/OLD GPUS.




If you use the source code and publish a DERCODE fork publicly, please include [ DC FORK ] in the README or in the shader’s name, or leave a link to the original DERCODE.


Thank you for your attention.

=============================================================================================================






