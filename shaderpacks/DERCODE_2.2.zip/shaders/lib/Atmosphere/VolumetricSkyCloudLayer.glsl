
#define CUMULUS_STYLE 1 // [1 2 3 4 5 6]
#define CUMULUS_BOXY_RESOLUTION 0.1 // [0.05 0.075 0.1 0.125 0.15 0.175 0.2 0.25 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.5 1.7 1.8 2.0]
#define CUMULUS_GENERATION_MODE 1 // [1 2]
#define CUMULUS_TEXTURE_SCALE 0.00025 // [0.0001 0.00015 0.0002 0.00025 0.0003 0.0004 0.0005 0.00075 0.001]
#define CUMULUS_TEXTURE_CHANNEL 1 // [1 2 3 4 5]
#define CUMULUS_SHADING_TYPE 1 // [1 2 3 4 5 6]
#define CUMULUS_BLOOM_MULT            1.2 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define CUMULUS_BLOOM_MULT_NOSTALGIA  1.5 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define CUMULUS_BLOOM_MULT_DRAMATIC   0.9 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define CUMULUS_BLOOM_MULT_PEARLESCENT 1.4 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define CUMULUS_BLOOM_MULT_FLAT       1.1 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define CUMULUS_BLOOM_MULT_CINEMATIC  1.3 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define SKY_CLOUD_DISTANCE_CHUNKS 64 // [4 8 12 16 20 24 28 30 32 34 38 40 45 50 55 60 64 65 70 75 80 85 90 95 110 128 150 256 512 1024]
#define SKY_CLOUD_SUNLIGHT        1.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define SKY_CLOUD_SKYLIGHT        1.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define SKY_CLOUD_SAMPLES         24 // [4 6 8 10 12 16 18 20 24 28 32 38 42 46 48 50 60 70 80 90]
#define SKY_CLOUD_LIGHT_SAMPLES   4 // [4 6 8 10 12 16 18 20 24 28 32 38 42 46 48 50 60 70 80 90]
#define FOG_CLOUD_TYPE 3 // [0 1 2 3]
#define FOG_CLOUD_DENSITY 0.002 // [0.0001 0.0002 0.0005 0.001 0.002 0.003 0.005 0.007 0.01 0.02 0.05 0.1]
#define FOG_CLOUD_COVERAGE 0.55 // [0.0 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.0]
#define FOG_CLOUD_SAMPLES 32 // [6 8 10 12 16 20 24 28 32 40 50]
#define FOG_CLOUD_SUNLIGHT 1.0 // [0.1 0.2 0.3 0.5 0.7 1.0 1.5 2.0 3.0]
#define SKY_CLOUD_1_ENABLE   1   // [0 1]
#define SKY_CLOUD_1_ALTITUDE    128.0 // [64.0 80.0 96.0 112.0 128.0 144.0 160.0 176.0 192.0 208.0 224.0 240.0 256.0 280.0 300.0 320.0]
#define SKY_CLOUD_1_THICKNESS    64.0 // [8.0 16.0 24.0 32.0 40.0 48.0 56.0 64.0 80.0 96.0 112.0 128.0]
#define SKY_CLOUD_1_COVERAGE     0.55 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_CLOUD_1_DENSITY      0.6 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_CLOUD_1_OPACITY      0.85 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_CLOUD_1_OFFSET_X     0.0 // [-2000.0 -1000.0 -500.0 -250.0 -100.0 -50.0 0.0 50.0 100.0 250.0 500.0 1000.0 2000.0]
#define SKY_CLOUD_1_OFFSET_Z     0.0 // [-2000.0 -1000.0 -500.0 -250.0 -100.0 -50.0 0.0 50.0 100.0 250.0 500.0 1000.0 2000.0]
#define SKY_CLOUD_1_SHADOW   1   // [0 1]
#define SKY_CLOUD_2_ENABLE   0   // [0 1]
#define SKY_CLOUD_2_ALTITUDE    220.0 // [64.0 80.0 96.0 112.0 128.0 144.0 160.0 176.0 192.0 208.0 224.0 240.0 256.0 280.0 300.0 320.0]
#define SKY_CLOUD_2_THICKNESS    64.0 // [8.0 16.0 24.0 32.0 40.0 48.0 56.0 64.0 80.0 96.0 112.0 128.0]
#define SKY_CLOUD_2_COVERAGE     0.5 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_CLOUD_2_DENSITY      0.5 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_CLOUD_2_OPACITY      0.8 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_CLOUD_2_OFFSET_X     1.0 // [-2000.0 -1000.0 -500.0 -250.0 -100.0 -50.0 0.0 50.0 100.0 250.0 500.0 1000.0 2000.0]
#define SKY_CLOUD_2_OFFSET_Z     0.6 // [-2000.0 -1000.0 -500.0 -250.0 -100.0 -50.0 0.0 50.0 100.0 250.0 500.0 1000.0 2000.0]
#define SKY_CLOUD_2_SHADOW   1   // [0 1]
#define SKY_CLOUD_3_ENABLE   0   // [0 1]
#define SKY_CLOUD_3_ALTITUDE    300.0 // [64.0 80.0 96.0 112.0 128.0 144.0 160.0 176.0 192.0 208.0 224.0 240.0 256.0 280.0 300.0 320.0]
#define SKY_CLOUD_3_THICKNESS    32.0 // [8.0 16.0 24.0 32.0 40.0 48.0 56.0 64.0 80.0 96.0 112.0 128.0]
#define SKY_CLOUD_3_COVERAGE     0.3 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_CLOUD_3_DENSITY      0.3 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_CLOUD_3_OPACITY      0.7 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_CLOUD_3_OFFSET_X     0.0 // [-2000.0 -1000.0 -500.0 -250.0 -100.0 -50.0 0.0 50.0 100.0 250.0 500.0 1000.0 2000.0]
#define SKY_CLOUD_3_OFFSET_Z     0.0 // [-2000.0 -1000.0 -500.0 -250.0 -100.0 -50.0 0.0 50.0 100.0 250.0 500.0 1000.0 2000.0]
#define SKY_CLOUD_3_SHADOW   1   // [0 1]
#define BOXY_CUL 0    // [0 1]
#define CIRRUS_GENERATION_MODE    2 
#define CIRRUS_TEXTURE_SCALE      0.00025 // [0.0001 0.00015 0.0002 0.00025 0.0003 0.0004 0.0005 0.00075 0.001]
#define CIRRUS_TEXTURE_STYLE      2 // [1 2 3]
#define CIRRUS_SHADING_TYPE       2 // [1 2 3 4 5 6]
#define CIRRUS_BLOOM_MULT         1.1 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define CIRRUS_GRAY_FADING          1    // [0 1]
#define CIRRUS_GRAY_FADING_INVERT   0    // 0 = затенять низ, 1 = затенять верх // [0 1]
#define CIRRUS_GRAY_FADING_INTENSITY 0.4 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define CIRRUS_DIST_FADING          1    // [0 1]
#define CIRRUS_DIST_FADING_POWER    2.0 // [0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 5.0 6.0]
#define CIRRUS_DISTANCE_CHUNKS    96 // [4 8 12 16 20 24 28 30 32 34 38 40 45 50 55 60 65 70 75 80 85 90 95 110 128 150 248 512 1024]
#define CIRRUS_1_ENABLE   1   // [0 1]
#define CIRRUS_1_ALTITUDE  256.0 // [64.0 96.0 128.0 160.0 192.0 224.0 256.0 288.0 320.0 352.0 384.0 416.0 448.0]
#define CIRRUS_1_THICKNESS  16.0 // [4.0 8.0 12.0 16.0 20.0 24.0 28.0 32.0 40.0 48.0]
#define CIRRUS_1_COVERAGE   0.5 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define CIRRUS_1_OPACITY    0.45 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define CIRRUS_1_OFFSET_X   0.0 // [-2000.0 -1000.0 -500.0 -250.0 -100.0 -50.0 0.0 50.0 100.0 250.0 500.0 1000.0 2000.0]
#define CIRRUS_1_OFFSET_Z   0.0 // [-2000.0 -1000.0 -500.0 -250.0 -100.0 -50.0 0.0 50.0 100.0 250.0 500.0 1000.0 2000.0]
#define CIRRUS_1_SHADOW   0   // [0 1]
#define CIRRUS_2_ENABLE   0   // [0 1]
#define CIRRUS_2_ALTITUDE  320.0 // [64.0 96.0 128.0 160.0 192.0 224.0 256.0 288.0 320.0 352.0 384.0 416.0 448.0]
#define CIRRUS_2_THICKNESS  16.0 // [4.0 8.0 12.0 16.0 20.0 24.0 28.0 32.0 40.0 48.0]
#define CIRRUS_2_COVERAGE   0.4 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define CIRRUS_2_OPACITY    0.3 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define CIRRUS_2_OFFSET_X   0.0 // [-2000.0 -1000.0 -500.0 -250.0 -100.0 -50.0 0.0 50.0 100.0 250.0 500.0 1000.0 2000.0]
#define CIRRUS_2_OFFSET_Z   0.0 // [-2000.0 -1000.0 -500.0 -250.0 -100.0 -50.0 0.0 50.0 100.0 250.0 500.0 1000.0 2000.0]
#define CIRRUS_2_SHADOW   0   // [0 1]
#define CIRRUS_3_ENABLE   0   // [0 1]
#define CIRRUS_3_ALTITUDE  400.0 // [64.0 96.0 128.0 160.0 192.0 224.0 256.0 288.0 320.0 352.0 384.0 416.0 448.0]
#define CIRRUS_3_THICKNESS  16.0 // [4.0 8.0 12.0 16.0 20.0 24.0 28.0 32.0 40.0 48.0]
#define CIRRUS_3_COVERAGE   0.3 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define CIRRUS_3_OPACITY    0.2 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define CIRRUS_3_OFFSET_X   0.0 // [-2000.0 -1000.0 -500.0 -250.0 -100.0 -50.0 0.0 50.0 100.0 250.0 500.0 1000.0 2000.0]
#define CIRRUS_3_OFFSET_Z   0.0 // [-2000.0 -1000.0 -500.0 -250.0 -100.0 -50.0 0.0 50.0 100.0 250.0 500.0 1000.0 2000.0]
#define CIRRUS_3_SHADOW   0   // [0 1]
#define CLOUD_SHADOWS_ENABLE        1    // [0 1]
#define CLOUD_SHADOWS_CUMULUS_STRENGTH 1.8 // [0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.5 3.0]
#define CLOUD_SHADOWS_CIRRUS_STRENGTH  1.5 // [0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.5 3.0]
#if BOXY_CUL == 1 && CIRRUS_GENERATION_MODE == 2
    #if CIRRUS_TEXTURE_STYLE == 1
        uniform sampler2D colortex25;
        #define CIRRUS_SAMPLER colortex25
    #elif CIRRUS_TEXTURE_STYLE == 2
        uniform sampler2D colortex13;
        #define CIRRUS_SAMPLER colortex13
    #elif CIRRUS_TEXTURE_STYLE == 3
        uniform sampler2D colortex15;
        #define CIRRUS_SAMPLER colortex15
    #endif
#endif

#define SKY_CLOUD_MAX_XZ    (float(SKY_CLOUD_DISTANCE_CHUNKS) * 16.0)
#define CIRRUS_MAX_XZ       (float(CIRRUS_DISTANCE_CHUNKS) * 16.0)
#define SKY_CLOUD_MIN_TRANS  0.005

float CloudRayPlaneT(in vec3 origin, in vec3 dir, in float planeY) {
    if (abs(dir.y) < 1e-5) return -1.0;
    return (planeY - origin.y) / dir.y;
}

vec3 CloudLightColor() {
    return directIlluminance + moonIlluminance * timeMidnight * 4.0;
}


// ============================================================
//  forms
// ============================================================

float StratusHeightShape(float nh) {
    return saturate(nh * 12.0) * saturate((1.0 - nh) * 12.0);
}


// ============================================================
//  cul
// ============================================================

float GetCumulusDensityForLayer(vec3 worldPos, float alt, float thick, float cov, float densMult, float offX, float offZ) {
    float nh = saturate((worldPos.y - alt) / thick);
    
    float heightShape;
    #if CUMULUS_STYLE == 1
        heightShape = saturate(nh * 5.0) * saturate((1.0 - nh) * 2.5);
    #elif CUMULUS_STYLE == 2
        heightShape = saturate(nh * 5.0) * saturate((1.0 - nh) * 2.5);
    #elif CUMULUS_STYLE == 3
        heightShape = step(0.05, nh) * step(nh, 0.95);
    #elif CUMULUS_STYLE == 4
        heightShape = saturate(nh * 6.0) * pow(saturate(1.0 - nh), 1.5);
    #elif CUMULUS_STYLE == 5
        heightShape = StratusHeightShape(nh);
    #else
        heightShape = saturate(nh * 5.0) * saturate((1.0 - nh) * 2.5);
    #endif

    if (heightShape < 1e-4) return 0.0;

    vec3 samplePos = worldPos;
    samplePos.x += offX;
    samplePos.z += offZ;

    #if CUMULUS_STYLE == 2 || CUMULUS_STYLE == 3
        samplePos = floor(samplePos * CUMULUS_BOXY_RESOLUTION) / CUMULUS_BOXY_RESOLUTION;
    #endif

    vec3 windOff = vec3(2e-3, 2e-4, 1e-3) * worldTimeCounter * CLOUDS_SPEED;
    vec3 pos = samplePos * 0.0045 - windOff;

    float coverage = cov + wetness * 0.35;
    float noise = 0.0;

    #if CUMULUS_GENERATION_MODE == 1
        float w = 0.5;

        #if CUMULUS_STYLE == 3
            for (int i = 0; i < 3; ++i) {
                noise += w * Get3DNoiseSmooth(pos);
                pos    = pos * 2.5 - windOff;
                w     *= 0.5;
            }
            noise = step(1.0 - coverage, noise);

        #elif CUMULUS_STYLE == 4
            for (int i = 0; i < 4; ++i) {
                noise += w * abs(Get3DNoiseSmooth(pos) * 2.0 - 1.0);
                pos    = pos * 3.0 - windOff * 0.5;
                w     *= 0.5;
            }
            noise = 1.0 - noise;
            noise = saturate((noise - (1.0 - coverage)) / max(coverage, 0.001));

        #elif CUMULUS_STYLE == 5
            vec3 stratPos = pos * vec3(0.3, 2.0, 0.3);
            for (int i = 0; i < 4; ++i) {
                noise += w * Get3DNoiseSmooth(stratPos);
                stratPos = stratPos * vec3(3.0, 2.0, 3.0) - windOff;
                w *= 0.55;
            }
            noise = saturate((noise - (1.0 - coverage)) / max(coverage, 0.001));

        #else
            for (int i = 0; i < 5; ++i) {
                noise += w * Get3DNoiseSmooth(pos);
                pos    = pos * 3.0 - windOff;
                w     *= 0.5;
            }
            noise = saturate((noise - (1.0 - coverage)) / max(coverage, 0.001));
        #endif

    #elif CUMULUS_GENERATION_MODE == 2
        vec2 uv = (samplePos.xz - windOff.xz * 200.0) * CUMULUS_TEXTURE_SCALE;
        vec4 texColor = texture(colortex28, uv);
        float texNoise = 0.0;

        #if CUMULUS_TEXTURE_CHANNEL == 1
            texNoise = texColor.g;
        #elif CUMULUS_TEXTURE_CHANNEL == 2
            texNoise = (texColor.r + texColor.g) * 0.5;
        #elif CUMULUS_TEXTURE_CHANNEL == 3
            texNoise = (texColor.r + texColor.g + texColor.b) * 0.33333;
        #elif CUMULUS_TEXTURE_CHANNEL == 4
            texNoise = texColor.a;
        #elif CUMULUS_TEXTURE_CHANNEL == 5
            texNoise = (texColor.r + texColor.b) * 0.5;
        #endif

        #if CUMULUS_STYLE == 3
            noise = step(1.0 - coverage, texNoise);
        #else
            noise = saturate((texNoise - (1.0 - coverage)) / max(coverage, 0.001));
        #endif

        noise *= mix(0.7, 1.0, Get3DNoiseSmooth(pos * 1.5));
    #endif

    noise *= heightShape;

    #if CUMULUS_STYLE != 3
        noise -= 0.08 + nh * 0.15;
    #endif

    #if CUMULUS_STYLE == 3
        return step(0.01, noise) * densMult;
    #else
        return saturate(noise * 3.0 * densMult);
    #endif
}

float SkyCloudNoiseDensity(in vec3 worldPos) {
    float totalDensity = 0.0;
    #if SKY_CLOUD_1_ENABLE == 1
    if (worldPos.y >= SKY_CLOUD_1_ALTITUDE && worldPos.y <= SKY_CLOUD_1_ALTITUDE + SKY_CLOUD_1_THICKNESS)
        totalDensity += GetCumulusDensityForLayer(worldPos, SKY_CLOUD_1_ALTITUDE, SKY_CLOUD_1_THICKNESS, SKY_CLOUD_1_COVERAGE, SKY_CLOUD_1_DENSITY, SKY_CLOUD_1_OFFSET_X, SKY_CLOUD_1_OFFSET_Z);
    #endif
    #if SKY_CLOUD_2_ENABLE == 1
    if (worldPos.y >= SKY_CLOUD_2_ALTITUDE && worldPos.y <= SKY_CLOUD_2_ALTITUDE + SKY_CLOUD_2_THICKNESS)
        totalDensity += GetCumulusDensityForLayer(worldPos, SKY_CLOUD_2_ALTITUDE, SKY_CLOUD_2_THICKNESS, SKY_CLOUD_2_COVERAGE, SKY_CLOUD_2_DENSITY, SKY_CLOUD_2_OFFSET_X, SKY_CLOUD_2_OFFSET_Z);
    #endif
    #if SKY_CLOUD_3_ENABLE == 1
    if (worldPos.y >= SKY_CLOUD_3_ALTITUDE && worldPos.y <= SKY_CLOUD_3_ALTITUDE + SKY_CLOUD_3_THICKNESS)
        totalDensity += GetCumulusDensityForLayer(worldPos, SKY_CLOUD_3_ALTITUDE, SKY_CLOUD_3_THICKNESS, SKY_CLOUD_3_COVERAGE, SKY_CLOUD_3_DENSITY, SKY_CLOUD_3_OFFSET_X, SKY_CLOUD_3_OFFSET_Z);
    #endif
    return totalDensity;
}

float SkyCloudSunOD(in vec3 rayPos, in float lightNoise) {
    float stepSize = 32.0 * (0.25 / float(SKY_CLOUD_LIGHT_SAMPLES));
    vec3  st       = worldLightVector * stepSize;
    float od = 0.0;
    vec3  pos = rayPos;
    for (int i = 0; i < SKY_CLOUD_LIGHT_SAMPLES; ++i) {
        pos += st;
        st  *= 2.0;
        float d = SkyCloudNoiseDensity(pos + worldLightVector * stepSize * lightNoise);
        if (d < 1e-4) continue;
        od += d;
    }
    return od * stepSize * 0.12;
}





#if CUMULUS_STYLE == 6

// volFogWind 
#define FOG_CLOUD_WIND (vec3(2e-3, 2e-4, 1e-3) * worldTimeCounter * CLOUDS_SPEED)

float FogCloudCalculateDensity(in vec3 rayPosition, in float minY, in float maxY) {
    // heightMask
    float heightMask = smoothstep(minY,        minY + 8.0, rayPosition.y)
                     * smoothstep(maxY, maxY - 8.0, rayPosition.y);

    #if FOG_CLOUD_TYPE == 0
        // --- Low (FOG_TYPE 0) ---
        float fogDensity = exp2(min(((minY + maxY) * 0.5 + 32.0 - rayPosition.y) * rcp(12.0), 0.2));
        return fogDensity * 0.5 * heightMask;

    #elif FOG_CLOUD_TYPE == 1
        // --- Medium (FOG_TYPE 1) ---
        float fogDensity = exp2(min(((minY + maxY) * 0.5 + 28.0 - rayPosition.y) * 0.15, 0.2));

        vec3 rp = rayPosition * 0.07 + FOG_CLOUD_WIND;
        float noise = Get3DNoiseSmooth(rp) * 4.0;
        noise -= Get3DNoiseSmooth(rp * 4.0 + FOG_CLOUD_WIND);

        // FOG_CLOUD_COVERAGE
        float coverageShift = (FOG_CLOUD_COVERAGE - 0.5) * 4.0;
        fogDensity = saturate(noise * 4.0 * fogDensity - (5.0 - coverageShift)) * 1.4;

        #ifdef CLOUDS_WEATHER
            fogDensity = fogDensity * oneMinus(timeNoon) + timeNoon;
        #endif

        return fogDensity * heightMask;

    #elif FOG_CLOUD_TYPE == 2
        // --- High (FOG_TYPE 2) ---
        float seaLevel = (minY + maxY) * 0.5;
        float falloff = fastExp(-abs(rayPosition.y - seaLevel) * 0.01);

        vec3 rp = rayPosition * 0.04 + FOG_CLOUD_WIND;
        float noise  = Get3DNoiseSmooth(rp)         * 0.5;
              rp    += FOG_CLOUD_WIND;
              noise += Get3DNoiseSmooth(rp * 3.2)   * 0.25;
              rp    += FOG_CLOUD_WIND;
              noise += Get3DNoiseSmooth(rp * 9.6)   * 0.125;
              rp    += FOG_CLOUD_WIND;
              noise += Get3DNoiseSmooth(rp * 28.8)  * 0.0625;

        float coverageShift = (FOG_CLOUD_COVERAGE - 0.5) * 2.0;
        float fogDensity = saturate(noise * 12.0 * falloff - (4.5 - coverageShift));
        return fogDensity * 9.0 * heightMask;

    #else
        // --- Ultra (FOG_TYPE 3) ---
        float seaLevel = (minY + maxY) * 0.5;
        float falloff = exp2(-abs(rayPosition.y - seaLevel) * 0.01);
        vec3 rp = rayPosition + FOG_CLOUD_WIND;
        rp *= 0.013;
        float weight = 0.5;
        float noise = 0.0;
        for (uint i = 0u; i < 5u; i++, weight *= 0.5) {
            noise += weight * Get3DNoiseSmooth(rp);
            rp = (rp + FOG_CLOUD_WIND) * 4.0;
        }
        float coverageShift = (FOG_CLOUD_COVERAGE - 0.5) * 60.0;
        float fogDensity = saturate(falloff * noise * 4e2 - (1.7e2 - coverageShift));
        return fogDensity * 48.0 * heightMask;
    #endif
}


vec4 CalculateFogCloudLayer(in vec3 worldDir, in float dither) {
    vec3  camPos = gbufferModelViewInverse[3].xyz + cameraPosition;
    float eyeY   = camPos.y;

    float minAlt = 9999.0, maxAlt = -9999.0;
    #if SKY_CLOUD_1_ENABLE == 1
        minAlt = min(minAlt, SKY_CLOUD_1_ALTITUDE);
        maxAlt = max(maxAlt, SKY_CLOUD_1_ALTITUDE + SKY_CLOUD_1_THICKNESS);
    #endif
    #if SKY_CLOUD_2_ENABLE == 1
        minAlt = min(minAlt, SKY_CLOUD_2_ALTITUDE);
        maxAlt = max(maxAlt, SKY_CLOUD_2_ALTITUDE + SKY_CLOUD_2_THICKNESS);
    #endif
    #if SKY_CLOUD_3_ENABLE == 1
        minAlt = min(minAlt, SKY_CLOUD_3_ALTITUDE);
        maxAlt = max(maxAlt, SKY_CLOUD_3_ALTITUDE + SKY_CLOUD_3_THICKNESS);
    #endif
    if (minAlt > maxAlt) return vec4(0.0, 0.0, 0.0, 1.0);

    float tBottom = CloudRayPlaneT(camPos, worldDir, minAlt);
    float tTop    = CloudRayPlaneT(camPos, worldDir, maxAlt);
    float tStart, tEnd;
    if (eyeY < minAlt) {
      
        if (worldDir.y <= 1e-4) return vec4(0.0, 0.0, 0.0, 1.0);
        tStart = tBottom; tEnd = tTop;
    } else if (eyeY > maxAlt) {
      
        if (worldDir.y >= -1e-4) return vec4(0.0, 0.0, 0.0, 1.0);
       
        tStart = tTop;
        tEnd   = tBottom;
    } else {
       
        tStart = 0.0;
        tEnd   = (worldDir.y >= 0.0) ? tTop : tBottom;
    }
   
    if (tStart < 0.0 || tEnd < 0.0 || tEnd <= tStart) return vec4(0.0, 0.0, 0.0, 1.0);

    float maxXZ = SKY_CLOUD_MAX_XZ;
    if (length(worldDir.xz) > 1e-4) {
        float tMaxXZ = (maxXZ + length(camPos.xz)) / length(worldDir.xz);
        tEnd = min(tEnd, tMaxXZ);
    }
    if (tEnd <= tStart) return vec4(0.0, 0.0, 0.0, 1.0);

    // ──CalculateVolumetricFog ──────────────────────────
    uint  steps     = uint(FOG_CLOUD_SAMPLES);
    float rSteps    = 1.0 / float(steps);
    float rayLength = tEnd - tStart;
    float stepLength = rayLength * rSteps;

    float transmittance = 1.0;
    float LdotV   = dot(worldLightVector, worldDir);
    float LdotV01 = LdotV * 0.5 + 0.5;

    float mistDensity = FOG_CLOUD_DENSITY;


    #if FOG_CLOUD_TYPE > 0
        float phases1 = (HenyeyGreensteinPhase(LdotV, 0.6)        + HenyeyGreensteinPhase(LdotV, -0.3))        * 0.5;
        float phases2 = (HenyeyGreensteinPhase(LdotV * 0.5,  0.6) + HenyeyGreensteinPhase(LdotV * 0.5,  -0.3)) * 0.25;
        float phases3 = (HenyeyGreensteinPhase(LdotV * 0.25, 0.6) + HenyeyGreensteinPhase(LdotV * 0.25, -0.3)) * 0.125;
        float phases4 = (HenyeyGreensteinPhase(LdotV * 0.125, 0.6) + HenyeyGreensteinPhase(LdotV * 0.125, -0.3)) * 0.0625;
    #else

        mistDensity *= CornetteShanksPhase(LdotV, 0.7 - wetness * 0.3) * 0.45
                     + HenyeyGreensteinPhase(LdotV, -0.3) * 0.15
                     + 0.1;
    #endif

    vec3 rayStep     = worldDir * stepLength;
    vec3 rayPosition = camPos + worldDir * (tStart + stepLength * dither);

    float sunlightSample = 0.0;
    float skylightSample  = 0.0;

  
    uint i = 0u;
    while (++i < steps) {
        rayPosition += rayStep;

        if (rayPosition.y < minAlt || rayPosition.y > maxAlt) continue;
        if (dotSelf(rayPosition.xz - camPos.xz) > maxXZ * maxXZ)  continue;

        float fogDensity = FogCloudCalculateDensity(rayPosition, minAlt, maxAlt) * mistDensity;

        if (fogDensity < 1e-5) continue;
        fogDensity *= stepLength;

        // shadow = vec3(1.0)
        vec3 shadow = vec3(1.0);

    
        #if FOG_CLOUD_TYPE > 0
        {
            float density = FogCloudCalculateDensity(rayPosition, minAlt, maxAlt);
            if (density > 1e-5) {
                float stepSize = 5.0, sunlightOD = 0.0;
                vec3 checkPos = rayPosition;
                for (uint j = 0u; j < 4u; ++j, checkPos += worldLightVector * stepSize) {
                    float d = FogCloudCalculateDensity(checkPos, minAlt, maxAlt);
                    if (d < 1e-5) continue;
                    sunlightOD += d * stepSize;
                    stepSize   *= 1.5;
                }
                sunlightOD *= mistDensity;

             
                float scatteringSun = oneMinus(fastExp(-sunlightOD * 2.0)) * oneMinus(LdotV01) + LdotV01;
                scatteringSun *= fastExp(-sunlightOD * 2.4) * phases1
                               + fastExp(-sunlightOD * 1.2) * phases2
                               + fastExp(-sunlightOD * 0.6) * phases3
                               + fastExp(-sunlightOD * 0.3) * phases4;
                shadow *= (scatteringSun) * float(FOG_CLOUD_TYPE) * float(FOG_CLOUD_TYPE);
            }
        }
        #endif

        float stepTransmittance = fastExp(-fogDensity);

        float powder = 1.0 - fastExp(-fogDensity * 3.0);
        powder = powder * oneMinus(LdotV01) + LdotV01;
        float fogSample = powder * transmittance * oneMinus(stepTransmittance);

        sunlightSample += shadow.x * fogSample;
        skylightSample  += fogSample;

        transmittance *= stepTransmittance;

        if (transmittance < 1e-3) break;
    }

    if (transmittance > 1.0 - SKY_CLOUD_MIN_TRANS) return vec4(0.0, 0.0, 0.0, 1.0);


    vec3 fogSunColor = directIlluminance * sunlightSample * SUNLIGHT_INTENSITY * FOG_CLOUD_SUNLIGHT;
    vec3 fogSkyColor = skyIlluminance    * skylightSample;

    vec3 fogColor = fogSunColor * 20.0 + fogSkyColor * 2.0;

    if (isLightningFlashing > 1e-2) fogColor += sqr(skylightSample) * 2.0 * lightningColor;

   

    fogColor *= oneMinus(0.8 * wetness);

    float opacity = SKY_CLOUD_1_OPACITY;
    float viewAngleFactor = eyeY > maxAlt ? 1.0 : opacity;
    float finalTrans = mix(1.0, transmittance, viewAngleFactor);
    fogColor *= viewAngleFactor;

    vec3  entryPos = camPos + worldDir * tStart;
    float distFade = saturate(1.0 - dotSelf(entryPos.xz - camPos.xz) / (maxXZ * maxXZ * 0.5));
    fogColor   *= distFade;
    finalTrans  = mix(1.0, finalTrans, distFade);

    return vec4(fogColor, finalTrans);
}

#endif // CUMULUS_STYLE == 6



vec4 CalculateSkyCloudLayer(in vec3 worldDir, in float dither) {


    #if CUMULUS_STYLE == 6
        return CalculateFogCloudLayer(worldDir, dither);
    #endif
  

    vec3  camPos = gbufferModelViewInverse[3].xyz + cameraPosition;
    float eyeY   = camPos.y;

    float minAlt = 9999.0, maxAlt = -9999.0;
    #if SKY_CLOUD_1_ENABLE == 1
        minAlt = min(minAlt, SKY_CLOUD_1_ALTITUDE);
        maxAlt = max(maxAlt, SKY_CLOUD_1_ALTITUDE + SKY_CLOUD_1_THICKNESS);
    #endif
    #if SKY_CLOUD_2_ENABLE == 1
        minAlt = min(minAlt, SKY_CLOUD_2_ALTITUDE);
        maxAlt = max(maxAlt, SKY_CLOUD_2_ALTITUDE + SKY_CLOUD_2_THICKNESS);
    #endif
    #if SKY_CLOUD_3_ENABLE == 1
        minAlt = min(minAlt, SKY_CLOUD_3_ALTITUDE);
        maxAlt = max(maxAlt, SKY_CLOUD_3_ALTITUDE + SKY_CLOUD_3_THICKNESS);
    #endif
    if (minAlt > maxAlt) return vec4(0.0, 0.0, 0.0, 1.0);
    float tBottom = CloudRayPlaneT(camPos, worldDir, minAlt);
    float tTop    = CloudRayPlaneT(camPos, worldDir, maxAlt);
    float tStart, tEnd;
    if (eyeY < minAlt) {
        if (worldDir.y <= 1e-4) return vec4(0.0, 0.0, 0.0, 1.0);
        tStart = tBottom; tEnd = tTop;
    } else if (eyeY > maxAlt) {
        if (worldDir.y >= -1e-4) return vec4(0.0, 0.0, 0.0, 1.0);
        tStart = tTop; tEnd = tBottom;
    } else {
        tStart = 0.0;
        tEnd   = (worldDir.y >= 0.0) ? tTop : tBottom;
    }

    if (tStart < 0.0 || tEnd < 0.0 || tEnd <= tStart) return vec4(0.0, 0.0, 0.0, 1.0);
    float maxXZ = SKY_CLOUD_MAX_XZ;
    if (length(worldDir.xz) > 1e-4) {
        float tMaxXZ = (maxXZ + length(camPos.xz)) / length(worldDir.xz);
        tEnd = min(tEnd, tMaxXZ);
    }
    if (tEnd <= tStart) return vec4(0.0, 0.0, 0.0, 1.0);
    uint  steps   = uint(SKY_CLOUD_SAMPLES);
    float stepLen = (tEnd - tStart) / float(steps);
    vec3  rayStep = worldDir * stepLen;
    vec3  rayPos  = camPos + worldDir * (tStart + stepLen * dither);
    float LdotV   = dot(worldLightVector, worldDir);
    float LdotV01 = LdotV * 0.5 + 0.5;
    
    float ph1 = HenyeyGreensteinPhase(LdotV, 0.65 - wetness * 0.2) * 0.7 + HenyeyGreensteinPhase(LdotV, -0.35 + wetness * 0.1) * 0.3;
    float ph2 = (HenyeyGreensteinPhase(LdotV * 0.5, 0.6) + HenyeyGreensteinPhase(LdotV * 0.5, -0.3)) * 0.25;
    float ph3 = (HenyeyGreensteinPhase(LdotV * 0.25, 0.6) + HenyeyGreensteinPhase(LdotV * 0.25, -0.3)) * 0.125;
    float phNostalgia = HenyeyGreensteinPhase(LdotV, 0.8) * 0.85 + HenyeyGreensteinPhase(LdotV, -0.2) * 0.15;
    float phDramatic  = HenyeyGreensteinPhase(LdotV, 0.88) * 0.6 + HenyeyGreensteinPhase(LdotV, -0.5) * 0.4;
    float phPearl     = HenyeyGreensteinPhase(LdotV, 0.5) * 0.5 + HenyeyGreensteinPhase(LdotV, 0.1) * 0.5;
    float phCinematic = HenyeyGreensteinPhase(LdotV, 0.7) * 0.65 + HenyeyGreensteinPhase(LdotV, -0.2) * 0.35;
    
    float transmittance = 1.0;
    float scatterSun = 0.0, scatterSky = 0.0;
    vec3  scatterColor = vec3(0.0);
    
    for (uint i = 0u; i < steps; ++i, rayPos += rayStep) {
        if (transmittance < SKY_CLOUD_MIN_TRANS) break;
        if (rayPos.y < minAlt || rayPos.y > maxAlt) continue;
        if (dotSelf(rayPos.xz - camPos.xz) > maxXZ * maxXZ) continue;
        float density = SkyCloudNoiseDensity(rayPos);
        if (density < 1e-4) continue;

        float od    = density * stepLen;
        float sunOD = SkyCloudSunOD(rayPos, dither);

        float powder = 1.0 - fastExp(-density * 24.0);
        float pf     = powder * (1.0 - LdotV01) + LdotV01;

        float sunE, skyE;
        #if CUMULUS_SHADING_TYPE == 1
            sunE = (fastExp(-sunOD * 2.4) * ph1 + fastExp(-sunOD * 1.0) * ph2 + fastExp(-sunOD * 0.4) * ph3) * pf;
            float skyOD = density * 64.0 * 0.04;
            skyE = fastExp(-skyOD) + fastExp(-skyOD * 0.1) * 0.1;
        #elif CUMULUS_SHADING_TYPE == 2
            sunE = fastExp(-sunOD * 1.2) * phNostalgia * (0.5 + 0.5 * LdotV01);
            skyE = fastExp(-density * 0.5) * 0.8 + 0.2;
        #elif CUMULUS_SHADING_TYPE == 3
            float shadowTerm = fastExp(-sunOD * 4.5);
            sunE = (shadowTerm * phDramatic + fastExp(-sunOD * 0.8) * ph2 * 0.3) * pf;
            float skyOD = density * 80.0 * 0.04;
            skyE = fastExp(-skyOD) * 0.6 + fastExp(-skyOD * 0.05) * 0.1;
        #elif CUMULUS_SHADING_TYPE == 4
            float sunBase = fastExp(-sunOD * 1.8) * phPearl;
            float rimGlow = fastExp(-sunOD * 0.3) * (1.0 - fastExp(-sunOD * 0.8)) * 0.5;
            sunE = (sunBase + rimGlow) * pf;
            float skyOD = density * 48.0 * 0.04;
            skyE = fastExp(-skyOD) + fastExp(-skyOD * 0.15) * 0.15;
        #elif CUMULUS_SHADING_TYPE == 5
            float flatThresh = step(0.35, fastExp(-sunOD * 1.5));
            sunE = mix(0.05, 1.0, flatThresh) * pf;
            skyE = step(0.3, fastExp(-density * 0.5)) * 0.9 + 0.1;
        #elif CUMULUS_SHADING_TYPE == 6
            sunE = (fastExp(-sunOD * 2.0) * phCinematic * 0.8 + fastExp(-sunOD * 0.6) * ph2 * 0.4) * pf;
            float skyOD = density * 56.0 * 0.04;
            skyE = fastExp(-skyOD) * 0.9 + fastExp(-skyOD * 0.08) * 0.12;
        #else
            sunE = (fastExp(-sunOD * 2.4) * ph1 + fastExp(-sunOD * 1.0) * ph2 + fastExp(-sunOD * 0.4) * ph3) * pf;
            float skyOD = density * 64.0 * 0.04;
            skyE = fastExp(-skyOD) + fastExp(-skyOD * 0.1) * 0.1;
        #endif

        float stepTrans = fastExp(-od * 0.8);
        float samp      = pf * transmittance * (1.0 - stepTrans);

        scatterSun += sunE * samp;
        scatterSky += skyE * samp;
        transmittance *= stepTrans;
    }

    if (transmittance > 1.0 - SKY_CLOUD_MIN_TRANS) return vec4(0.0, 0.0, 0.0, 1.0);
    
    vec3 lightCol   = CloudLightColor();
    vec3 sunColor   = lightCol * scatterSun * SKY_CLOUD_SUNLIGHT * saturate(worldLightVector.y * 20.0 + 0.5);
    vec3 skyColor   = skyIlluminance * scatterSky * 0.15 * SKY_CLOUD_SKYLIGHT;
    vec3 moonDirect = moonIlluminance * scatterSun * timeMidnight * 6.0 * saturate(-worldSunVector.y * 20.0 + 0.5);
    
    vec3 color = sunColor * 48.0 + skyColor + moonDirect * 48.0;
    
    #if CUMULUS_SHADING_TYPE == 4
        float pearlHue = scatterSun * 0.3;
        color += vec3(pearlHue * 0.05, pearlHue * 0.02, pearlHue * 0.08) * lightCol * 12.0;
    #elif CUMULUS_SHADING_TYPE == 6
        vec3 shadowTint = vec3(1.05, 0.95, 0.85);
        vec3 lightTint  = vec3(0.95, 0.98, 1.05);
        color = mix(color * shadowTint, color * lightTint, saturate(scatterSun * 2.0));
    #endif

    if (isLightningFlashing > 1e-2) color += scatterSky * scatterSky * 0.15 * lightningColor;
    color *= 1.0 - wetness * 0.5;

    #if CUMULUS_SHADING_TYPE == 1
        color *= CUMULUS_BLOOM_MULT;
    #elif CUMULUS_SHADING_TYPE == 2
        color *= CUMULUS_BLOOM_MULT_NOSTALGIA;
    #elif CUMULUS_SHADING_TYPE == 3
        color *= CUMULUS_BLOOM_MULT_DRAMATIC;
    #elif CUMULUS_SHADING_TYPE == 4
        color *= CUMULUS_BLOOM_MULT_PEARLESCENT;
    #elif CUMULUS_SHADING_TYPE == 5
        color *= CUMULUS_BLOOM_MULT_FLAT;
    #elif CUMULUS_SHADING_TYPE == 6
        color *= CUMULUS_BLOOM_MULT_CINEMATIC;
    #else
        color *= CUMULUS_BLOOM_MULT;
    #endif

    float finalTrans = mix(1.0, transmittance, SKY_CLOUD_1_OPACITY);
    color *= SKY_CLOUD_1_OPACITY;
    
    vec3  entryPos = camPos + worldDir * tStart;
    float distFade = saturate(1.0 - dotSelf(entryPos.xz - camPos.xz) / (maxXZ * maxXZ * 0.5));
    color     *= distFade;
    finalTrans = mix(1.0, finalTrans, distFade);

    return vec4(color, finalTrans);
}



#if BOXY_CUL == 1

#if CIRRUS_GENERATION_MODE == 1
float FiberNoise(vec2 worldXZ, vec2 fiberDir) {
    vec2 perp = vec2(-fiberDir.y, fiberDir.x);
    float along  = dot(worldXZ, fiberDir);
    float across = dot(worldXZ, perp);
    vec2 uv = vec2(along * 0.00002, across * 0.0016);
    float n = 0.0;
    n += Get3DNoiseSmooth(vec3(uv,               0.1)) * 0.25;
    n += Get3DNoiseSmooth(vec3(uv * 2.8  + 0.17, 0.2)) * 0.45;
    n += Get3DNoiseSmooth(vec3(uv * 6.0  + 0.53, 0.4)) * 0.20;
    n += Get3DNoiseSmooth(vec3(uv * 12.0 + 0.91, 0.7)) * 0.10;
    return n;
}
#endif

float GetCirrusDensityForLayer(vec3 worldPos, float alt, float thick, float cov, float offX, float offZ) {
    float nh = saturate((worldPos.y - alt) / thick);
    float heightShape = exp(-sqr((nh - 0.5) * 6.0));
    if (heightShape < 0.01) return 0.0;
    
    vec2 wind2D = vec2(3.5e-3, 1.0e-3) * worldTimeCounter * CLOUDS_SPEED;
    vec2 pos2D  = worldPos.xz - wind2D * 800.0;
    pos2D.x += offX;
    pos2D.y += offZ;

    #if CIRRUS_GENERATION_MODE == 1
        vec2 baseDir = normalize(vec2(-1.0, -0.6));
        float curl = Get3DNoiseSmooth(vec3(pos2D * 0.00012, 0.3)) * 2.0 - 1.0;
        float angle = curl * 0.3;
        float ca = cos(angle), sa = sin(angle);
        vec2 fiberDir = normalize(vec2(baseDir.x * ca - baseDir.y * sa, baseDir.x * sa + baseDir.y * ca));
        
        float fiber1 = FiberNoise(pos2D, fiberDir);
        vec2 fiberDir2 = normalize(fiberDir + vec2(-fiberDir.y, fiberDir.x) * 0.3);
        float fiber2   = FiberNoise(pos2D * 1.4 + 200.0, fiberDir2) * 0.35;
        
        float noise = fiber1 * 0.75 + fiber2;
        float coverage = cov + wetness * 0.2;
        float mask = Get3DNoiseSmooth(vec3(pos2D * 0.00025, 0.5));
        mask = saturate((mask - (1.0 - coverage * 1.2)) * 2.0);
        
        if (mask < 1e-4) return 0.0;

        noise = smoothstep(0.33, 0.48, noise);
        noise *= mask * heightShape;
        return saturate(noise);
        
    #elif CIRRUS_GENERATION_MODE == 2
        vec2 uv = pos2D * CIRRUS_TEXTURE_SCALE;
        float noise = texture(CIRRUS_SAMPLER, uv).r;
        noise = smoothstep(1.0 - cov, 1.1 - cov, noise);
        noise *= heightShape;
        return saturate(noise);
    #endif

    return 0.0;
}

float CirrusNoiseDensity(in vec3 worldPos) {
    float total = 0.0;
    #if CIRRUS_1_ENABLE == 1
        if (worldPos.y >= CIRRUS_1_ALTITUDE && worldPos.y <= CIRRUS_1_ALTITUDE + CIRRUS_1_THICKNESS)
            total += GetCirrusDensityForLayer(worldPos, CIRRUS_1_ALTITUDE, CIRRUS_1_THICKNESS, CIRRUS_1_COVERAGE, CIRRUS_1_OFFSET_X, CIRRUS_1_OFFSET_Z);
    #endif
    #if CIRRUS_2_ENABLE == 1
        if (worldPos.y >= CIRRUS_2_ALTITUDE && worldPos.y <= CIRRUS_2_ALTITUDE + CIRRUS_2_THICKNESS)
            total += GetCirrusDensityForLayer(worldPos, CIRRUS_2_ALTITUDE, CIRRUS_2_THICKNESS, CIRRUS_2_COVERAGE, CIRRUS_2_OFFSET_X, CIRRUS_2_OFFSET_Z);
    #endif
    #if CIRRUS_3_ENABLE == 1
        if (worldPos.y >= CIRRUS_3_ALTITUDE && worldPos.y <= CIRRUS_3_ALTITUDE + CIRRUS_3_THICKNESS)
            total += GetCirrusDensityForLayer(worldPos, CIRRUS_3_ALTITUDE, CIRRUS_3_THICKNESS, CIRRUS_3_COVERAGE, CIRRUS_3_OFFSET_X, CIRRUS_3_OFFSET_Z);
    #endif
    return saturate(total);
}

vec4 CalculateCirrusLayer(in vec3 worldDir, in float dither) {
    vec3  camPos = gbufferModelViewInverse[3].xyz + cameraPosition;
    float eyeY   = camPos.y;

    float minAlt = 9999.0, maxAlt = -9999.0;
    #if CIRRUS_1_ENABLE == 1
        minAlt = min(minAlt, CIRRUS_1_ALTITUDE);
        maxAlt = max(maxAlt, CIRRUS_1_ALTITUDE + CIRRUS_1_THICKNESS);
    #endif
    #if CIRRUS_2_ENABLE == 1
        minAlt = min(minAlt, CIRRUS_2_ALTITUDE);
        maxAlt = max(maxAlt, CIRRUS_2_ALTITUDE + CIRRUS_2_THICKNESS);
    #endif
    #if CIRRUS_3_ENABLE == 1
        minAlt = min(minAlt, CIRRUS_3_ALTITUDE);
        maxAlt = max(maxAlt, CIRRUS_3_ALTITUDE + CIRRUS_3_THICKNESS);
    #endif
    if (minAlt > maxAlt) return vec4(0.0, 0.0, 0.0, 1.0);
    
    float tBottom = CloudRayPlaneT(camPos, worldDir, minAlt);
    float tTop    = CloudRayPlaneT(camPos, worldDir, maxAlt);
    float tStart, tEnd;
    
    if (eyeY < minAlt) {
        tStart = (tBottom > 0.0) ? tBottom : 0.0;
        tEnd   = (tTop    > 0.0) ? tTop    : tStart;
    } else if (eyeY > maxAlt) {
        tStart = (tTop    > 0.0) ? tTop    : 0.0;
        tEnd   = (tBottom > 0.0) ? tBottom : tStart;
    } else {
        tStart = 0.0;
        tEnd   = (worldDir.y >= 0.0) ? tTop : tBottom;
        if (tEnd < 0.0) tEnd = 0.0;
    }

    if (tEnd <= tStart) return vec4(0.0, 0.0, 0.0, 1.0);

    float maxXZ = CIRRUS_MAX_XZ;
    if (length(worldDir.xz) > 1e-4) {
        float tMaxXZ = maxXZ / length(worldDir.xz);
        if (tStart > tMaxXZ) return vec4(0.0, 0.0, 0.0, 1.0);
        tEnd = min(tEnd, tMaxXZ);
    }

    const int CIRRUS_STEPS = 12;
    float stepLen = (tEnd - tStart) / float(CIRRUS_STEPS);
    if (stepLen < 0.001) stepLen = 1.0;

    float LdotV   = dot(worldLightVector, worldDir);
    float LdotV01 = LdotV * 0.5 + 0.5;

    #if CIRRUS_SHADING_TYPE == 1
        float phaseForward = HenyeyGreensteinPhase(LdotV, 0.9);
        float phaseAvg     = HenyeyGreensteinPhase(LdotV, 0.3);
        float phase        = phaseForward * 0.8 + phaseAvg * 0.2;
    #elif CIRRUS_SHADING_TYPE == 2
        float ph1 = HenyeyGreensteinPhase(LdotV, 0.65 - wetness * 0.2) * 0.7 + HenyeyGreensteinPhase(LdotV, -0.35 + wetness * 0.1) * 0.3;
        float ph2 = (HenyeyGreensteinPhase(LdotV * 0.5, 0.6) + HenyeyGreensteinPhase(LdotV * 0.5, -0.3)) * 0.25;
        float ph3 = (HenyeyGreensteinPhase(LdotV * 0.25, 0.6) + HenyeyGreensteinPhase(LdotV * 0.25, -0.3)) * 0.125;
    #elif CIRRUS_SHADING_TYPE == 3
        float phNostalgia = HenyeyGreensteinPhase(LdotV, 0.8) * 0.85 + HenyeyGreensteinPhase(LdotV, -0.2) * 0.15;
    #elif CIRRUS_SHADING_TYPE == 4
        float phIriMain = HenyeyGreensteinPhase(LdotV, 0.92);
        float phIriSide = HenyeyGreensteinPhase(LdotV * 0.3, 0.4);
        float phIri     = phIriMain * 0.7 + phIriSide * 0.3;
    #elif CIRRUS_SHADING_TYPE == 5
        float phGhost = HenyeyGreensteinPhase(LdotV, -0.3) * 0.4 + HenyeyGreensteinPhase(LdotV, 0.5) * 0.6;
    #elif CIRRUS_SHADING_TYPE == 6
        float phBeam = HenyeyGreensteinPhase(LdotV, 0.97) * 0.9 + HenyeyGreensteinPhase(LdotV, 0.2) * 0.1;
    #endif

    float accumDensity = 0.0, scatterSun = 0.0, scatterSky = 0.0;
    
    for (int i = 0; i < CIRRUS_STEPS; ++i) {
        float t = tStart + (float(i) + dither) * stepLen;
        vec3 rPos = camPos + worldDir * t;

        if (dotSelf(rPos.xz - camPos.xz) > maxXZ * maxXZ) continue;
        float d = CirrusNoiseDensity(rPos);
        if (d < 1e-4) continue;

        float nh = saturate((rPos.y - minAlt) / (maxAlt - minAlt));
        float grayFade = 1.0;
        
        #if CIRRUS_GRAY_FADING == 1
            #if CIRRUS_GRAY_FADING_INVERT == 0
                grayFade = mix(1.0 - CIRRUS_GRAY_FADING_INTENSITY, 1.0, nh);
            #else
                grayFade = mix(1.0 - CIRRUS_GRAY_FADING_INTENSITY, 1.0, 1.0 - nh);
            #endif
        #endif

        #if CIRRUS_SHADING_TYPE == 1
            accumDensity += d * stepLen;
            scatterSun   += d * phase * stepLen * grayFade;
            scatterSky   += d * stepLen * grayFade;
        #elif CIRRUS_SHADING_TYPE == 2
            float od     = d * stepLen;
            accumDensity += od;
            float powder = 1.0 - fastExp(-d * 24.0);
            float pf     = powder * (1.0 - LdotV01) + LdotV01;
            float lightSymmetry = worldLightVector.y >= 0.0 ? (1.0 - nh) : nh;
            float approxSunOD = lightSymmetry * d * 4.0;
            float sunE = (fastExp(-approxSunOD * 2.4) * ph1 + fastExp(-approxSunOD * 1.0) * ph2 + fastExp(-approxSunOD * 0.4) * ph3) * pf;
            float skyOD = d * 16.0 * 0.04;
            float skyE  = fastExp(-skyOD) + fastExp(-skyOD * 0.1) * 0.1;
            scatterSun += sunE * d * stepLen * grayFade;
            scatterSky += skyE * d * stepLen * grayFade;
        #elif CIRRUS_SHADING_TYPE == 3
            accumDensity += d * stepLen;
            float sunE = fastExp(-d * 1.2) * phNostalgia * (0.5 + 0.5 * LdotV01);
            float skyE = fastExp(-d * 0.5) * 0.8 + 0.2;
            scatterSun += sunE * d * stepLen * grayFade;
            scatterSky += skyE * d * stepLen * grayFade;
        #elif CIRRUS_SHADING_TYPE == 4
            accumDensity += d * stepLen;
            float sunE = fastExp(-d * 1.0) * phIri * (0.6 + 0.4 * LdotV01);
            float skyE = fastExp(-d * 0.3) * 0.9 + 0.15;
            scatterSun += sunE * d * stepLen * grayFade;
            scatterSky += skyE * d * stepLen * grayFade;
        #elif CIRRUS_SHADING_TYPE == 5
            accumDensity += d * stepLen;
            float sunE = fastExp(-d * 0.4) * phGhost * (0.3 + 0.7 * (1.0 - LdotV01));
            float skyE = fastExp(-d * 0.15) * 0.95 + 0.05;
            scatterSun += sunE * d * stepLen * grayFade;
            scatterSky += skyE * d * stepLen * grayFade;
        #elif CIRRUS_SHADING_TYPE == 6
            accumDensity += d * stepLen;
            float sunE = fastExp(-d * 2.5) * phBeam;
            float skyE = fastExp(-d * 0.8) * 0.7 + 0.1;
            scatterSun += sunE * d * stepLen * grayFade;
            scatterSky += skyE * d * stepLen * grayFade;
        #endif
    }

    if (accumDensity < 1e-5) return vec4(0.0, 0.0, 0.0, 1.0);
    
    float cirrusTrans = fastExp(-accumDensity * 4.0);
    vec3 lightCol = CloudLightColor();
    vec3 color    = vec3(0.0);
    
    #if CIRRUS_SHADING_TYPE == 1
        float sunAngle  = saturate(worldLightVector.y * 10.0 + 0.3);
        vec3 sunColor   = lightCol * scatterSun * 32.0 * sunAngle;
        vec3 skyColor   = skyIlluminance * scatterSky * 0.4;
        vec3 moonDirect = moonIlluminance * scatterSun * timeMidnight * 5.0 * saturate(-worldSunVector.y * 10.0 + 0.3);
        color = sunColor + skyColor + moonDirect * 32.0;
    #elif CIRRUS_SHADING_TYPE == 2 || CIRRUS_SHADING_TYPE == 3
        vec3 sunColor   = lightCol * scatterSun * saturate(worldLightVector.y * 20.0 + 0.5);
        vec3 skyColor   = skyIlluminance * scatterSky * 0.15;
        vec3 moonDirect = moonIlluminance * scatterSun * timeMidnight * 6.0 * saturate(-worldSunVector.y * 20.0 + 0.5);
        color = sunColor * 48.0 + skyColor + moonDirect * 48.0;
    #elif CIRRUS_SHADING_TYPE == 4
        vec3 sunColor = lightCol * scatterSun * saturate(worldLightVector.y * 20.0 + 0.5);
        vec3 skyColor = skyIlluminance * scatterSky * 0.2;
        vec3 moonDirect = moonIlluminance * scatterSun * timeMidnight * 6.0 * saturate(-worldSunVector.y * 20.0 + 0.5);
        color = sunColor * 48.0 + skyColor + moonDirect * 48.0;
        float iriAngle = LdotV01;
        vec3 iriColor = vec3(
            sin(iriAngle * 6.28 + 0.0) * 0.5 + 0.5,
            sin(iriAngle * 6.28 + 2.09) * 0.5 + 0.5,
            sin(iriAngle * 6.28 + 4.19) * 0.5 + 0.5
        );
        color += iriColor * scatterSun * lightCol * 4.0 * saturate(worldLightVector.y * 5.0 + 0.2);
    #elif CIRRUS_SHADING_TYPE == 5
        vec3 sunColor = lightCol * scatterSun * saturate(worldLightVector.y * 15.0 + 0.3) * 0.5;
        vec3 skyColor = skyIlluminance * scatterSky * 0.35;
        vec3 moonDirect = moonIlluminance * scatterSun * timeMidnight * 8.0 * saturate(-worldSunVector.y * 15.0 + 0.3);
        color = sunColor * 24.0 + skyColor + moonDirect * 24.0;
        color *= vec3(0.88, 0.93, 1.08);
    #elif CIRRUS_SHADING_TYPE == 6
        float beamBoost = saturate(1.0 - abs(worldLightVector.y) * 3.0) * 3.0 + 1.0;
        vec3 sunColor = lightCol * scatterSun * saturate(worldLightVector.y * 20.0 + 0.5) * beamBoost;
        vec3 skyColor = skyIlluminance * scatterSky * 0.1;
        vec3 moonDirect = moonIlluminance * scatterSun * timeMidnight * 6.0 * saturate(-worldSunVector.y * 20.0 + 0.5);
        color = sunColor * 64.0 + skyColor + moonDirect * 64.0;
    #endif

    color = mix(color, color * vec3(0.95, 0.97, 1.0), 0.3);
    color *= 1.0 - wetness * 0.3;
    color *= CIRRUS_BLOOM_MULT;

    float finalTrans = mix(1.0, cirrusTrans, CIRRUS_1_OPACITY);
    color *= CIRRUS_1_OPACITY;
    
    vec3  entryPos = camPos + worldDir * tStart;
    float distFade = saturate(1.0 - dotSelf(entryPos.xz - camPos.xz) / (maxXZ * maxXZ * 0.6));
    
    #if CIRRUS_DIST_FADING == 1
        distFade = pow(distFade, 1.0 / CIRRUS_DIST_FADING_POWER);
    #else
        distFade = sqrt(distFade);
    #endif

    color     *= distFade;
    finalTrans = mix(1.0, finalTrans, distFade);

    return vec4(color, finalTrans);
}

#endif // BOXY_CUL == 1


#if CLOUD_SHADOWS_ENABLE == 1

float GetCloudShadowMask(vec3 worldPos) {
    if (worldLightVector.y < 0.02) return 1.0;
    float shadowMask = 1.0;

    #if SKY_CLOUD_1_ENABLE == 1 && SKY_CLOUD_1_SHADOW == 1
    {
        float tCloud = (SKY_CLOUD_1_ALTITUDE - worldPos.y) / worldLightVector.y;
        if (tCloud > 0.0) {
            #if CUMULUS_STYLE == 6
                // Fog Cloud: сэмплируем туман в середине слоя
                vec3 samplePos = worldPos + worldLightVector * (tCloud + SKY_CLOUD_1_THICKNESS * 0.5);
                samplePos.x += SKY_CLOUD_1_OFFSET_X;
                samplePos.z += SKY_CLOUD_1_OFFSET_Z;
                float d = FogCloudCalculateDensity(samplePos, SKY_CLOUD_1_ALTITUDE, SKY_CLOUD_1_ALTITUDE + SKY_CLOUD_1_THICKNESS)
                        * FOG_CLOUD_DENSITY * SKY_CLOUD_1_THICKNESS;
                shadowMask *= exp(-d * CLOUD_SHADOWS_CUMULUS_STRENGTH);
            #else
                float stepSize = SKY_CLOUD_1_THICKNESS / 6.0;
                vec3 st = worldLightVector * stepSize;
                vec3 samplePos = worldPos + worldLightVector * tCloud;
                samplePos.x += SKY_CLOUD_1_OFFSET_X;
                samplePos.z += SKY_CLOUD_1_OFFSET_Z;
                float od = 0.0;
                for (int i = 0; i < 6; i++) {
                    od += SkyCloudNoiseDensity(samplePos) * stepSize;
                    samplePos += st;
                }
                shadowMask *= exp(-od * CLOUD_SHADOWS_CUMULUS_STRENGTH);
            #endif
        }
    }
    #endif

    #if SKY_CLOUD_2_ENABLE == 1 && SKY_CLOUD_2_SHADOW == 1
    {
        float tCloud = (SKY_CLOUD_2_ALTITUDE - worldPos.y) / worldLightVector.y;
        if (tCloud > 0.0) {
            #if CUMULUS_STYLE == 6
                vec3 samplePos = worldPos + worldLightVector * (tCloud + SKY_CLOUD_2_THICKNESS * 0.5);
                samplePos.x += SKY_CLOUD_2_OFFSET_X;
                samplePos.z += SKY_CLOUD_2_OFFSET_Z;
                float d = FogCloudCalculateDensity(samplePos, SKY_CLOUD_2_ALTITUDE, SKY_CLOUD_2_ALTITUDE + SKY_CLOUD_2_THICKNESS)
                        * FOG_CLOUD_DENSITY * SKY_CLOUD_2_THICKNESS;
                shadowMask *= exp(-d * CLOUD_SHADOWS_CUMULUS_STRENGTH);
            #else
                float stepSize = SKY_CLOUD_2_THICKNESS / 6.0;
                vec3 st = worldLightVector * stepSize;
                vec3 samplePos = worldPos + worldLightVector * tCloud;
                samplePos.x += SKY_CLOUD_2_OFFSET_X;
                samplePos.z += SKY_CLOUD_2_OFFSET_Z;
                float od = 0.0;
                for (int i = 0; i < 6; i++) {
                    od += SkyCloudNoiseDensity(samplePos) * stepSize;
                    samplePos += st;
                }
                shadowMask *= exp(-od * CLOUD_SHADOWS_CUMULUS_STRENGTH);
            #endif
        }
    }
    #endif

    #if SKY_CLOUD_3_ENABLE == 1 && SKY_CLOUD_3_SHADOW == 1
    {
        float tCloud = (SKY_CLOUD_3_ALTITUDE - worldPos.y) / worldLightVector.y;
        if (tCloud > 0.0) {
            #if CUMULUS_STYLE == 6
                vec3 samplePos = worldPos + worldLightVector * (tCloud + SKY_CLOUD_3_THICKNESS * 0.5);
                samplePos.x += SKY_CLOUD_3_OFFSET_X;
                samplePos.z += SKY_CLOUD_3_OFFSET_Z;
                float d = FogCloudCalculateDensity(samplePos, SKY_CLOUD_3_ALTITUDE, SKY_CLOUD_3_ALTITUDE + SKY_CLOUD_3_THICKNESS)
                        * FOG_CLOUD_DENSITY * SKY_CLOUD_3_THICKNESS;
                shadowMask *= exp(-d * CLOUD_SHADOWS_CUMULUS_STRENGTH);
            #else
                float stepSize = SKY_CLOUD_3_THICKNESS / 6.0;
                vec3 st = worldLightVector * stepSize;
                vec3 samplePos = worldPos + worldLightVector * tCloud;
                samplePos.x += SKY_CLOUD_3_OFFSET_X;
                samplePos.z += SKY_CLOUD_3_OFFSET_Z;
                float od = 0.0;
                for (int i = 0; i < 6; i++) {
                    od += SkyCloudNoiseDensity(samplePos) * stepSize;
                    samplePos += st;
                }
                shadowMask *= exp(-od * CLOUD_SHADOWS_CUMULUS_STRENGTH);
            #endif
        }
    }
    #endif

    #if BOXY_CUL == 1

    #if CIRRUS_1_ENABLE == 1 && CIRRUS_1_SHADOW == 1
    {
        float tCirrus = (CIRRUS_1_ALTITUDE - worldPos.y) / worldLightVector.y;
        if (tCirrus > 0.0) {
            vec3 cirrusPos = worldPos + worldLightVector * (tCirrus + CIRRUS_1_THICKNESS * 0.5);
            cirrusPos.x += CIRRUS_1_OFFSET_X;
            cirrusPos.z += CIRRUS_1_OFFSET_Z;
            float d = CirrusNoiseDensity(cirrusPos);
            shadowMask *= exp(-d * CLOUD_SHADOWS_CIRRUS_STRENGTH);
        }
    }
    #endif

    #if CIRRUS_2_ENABLE == 1 && CIRRUS_2_SHADOW == 1
    {
        float tCirrus = (CIRRUS_2_ALTITUDE - worldPos.y) / worldLightVector.y;
        if (tCirrus > 0.0) {
            vec3 cirrusPos = worldPos + worldLightVector * (tCirrus + CIRRUS_2_THICKNESS * 0.5);
            cirrusPos.x += CIRRUS_2_OFFSET_X;
            cirrusPos.z += CIRRUS_2_OFFSET_Z;
            float d = CirrusNoiseDensity(cirrusPos);
            shadowMask *= exp(-d * CLOUD_SHADOWS_CIRRUS_STRENGTH);
        }
    }
    #endif

    #if CIRRUS_3_ENABLE == 1 && CIRRUS_3_SHADOW == 1
    {
        float tCirrus = (CIRRUS_3_ALTITUDE - worldPos.y) / worldLightVector.y;
        if (tCirrus > 0.0) {
            vec3 cirrusPos = worldPos + worldLightVector * (tCirrus + CIRRUS_3_THICKNESS * 0.5);
            cirrusPos.x += CIRRUS_3_OFFSET_X;
            cirrusPos.z += CIRRUS_3_OFFSET_Z;
            float d = CirrusNoiseDensity(cirrusPos);
            shadowMask *= exp(-d * CLOUD_SHADOWS_CIRRUS_STRENGTH);
        }
    }
    #endif

    #endif // BOXY_CUL == 1

    return max(shadowMask, 0.05);
}

#endif // CLOUD_SHADOWS_ENABLE == 1
