#include "/lib/Head/BiomeWeather.inc"

// Единая функция маски
float _BiomeMaskAtRayPoint(float biomeFactor, vec2 rayXZ, vec2 camXZ, float maxDist) {
    if (biomeFactor < 0.01) return 0.0;
    float distXZ = length(rayXZ - camXZ);
    float currentRadius = maxDist * biomeFactor; 
    float fade = 1.0 - smoothstep(currentRadius * 0.3, currentRadius, distXZ);
    return fade * smoothstep(0.0, 1.0, biomeFactor);
}

// ─────────────────────────────────────────────────────────────────────────────
//  ШУМОВЫЕ ФУНКЦИИ (Только для песка)
// ─────────────────────────────────────────────────────────────────────────────

float _SandstormNoise(in vec3 worldPos) {
    vec2  windDir2 = normalize(vec2(SANDSTORM_WIND_DIR_X, SANDSTORM_WIND_DIR_Z));
    float t = frameTimeCounter * SANDSTORM_WIND_SPEED * 0.0015;
    vec3  windOffset = vec3(windDir2.x, 0.008, windDir2.y) * t;
    
    vec3 pos = worldPos * SANDSTORM_NOISE_SCALE + windOffset;

    float coarse = Get3DNoiseSmooth(pos);
    float detail = Get3DNoiseSmooth(pos * 2.8 + windOffset * 0.4) * SANDSTORM_NOISE_DETAIL;
    float swirl  = Get3DNoiseSmooth(pos * 1.2 + vec3(5.1, 0.2, 3.7)) * 0.08;
    
    pos.xz += swirl * 1.2;
    float noise = coarse * 0.70 + detail + swirl * 0.5;
    return clamp(noise * 2.4 - 0.92, 0.0, 1.0);
}

// Шум для адских биомных туманов (Basalt / Crimson)
float _NetherBiomeFogNoise(in vec3 worldPos, float noiseScale, vec3 windOffset) {
    vec3 pos = worldPos * noiseScale + windOffset;
    float coarse = Get3DNoiseSmooth(pos);
    float detail = Get3DNoiseSmooth(pos * 2.5 + windOffset * 0.3) * 0.25;
    float noise = coarse * 0.75 + detail;
    return clamp(noise * 1.8 - 0.5, 0.0, 1.0);
}

// ─────────────────────────────────────────────────────────────────────────────
//  ПЛОТНОСТЬ В ТОЧКЕ
// ─────────────────────────────────────────────────────────────────────────────

float _SandstormDensity(in vec3 rayPos, in float biomeMask) {
    if (biomeMask < 1e-4) return 0.0;
    float heightMask = smoothstep(SANDSTORM_MIN_HEIGHT, SANDSTORM_MIN_HEIGHT + SANDSTORM_HEIGHT_FADE, rayPos.y)
                     * smoothstep(SANDSTORM_MAX_HEIGHT, SANDSTORM_MAX_HEIGHT - SANDSTORM_HEIGHT_FADE, rayPos.y);
    if (heightMask < 1e-4) return 0.0;
    float noise = _SandstormNoise(rayPos);
    return noise * SANDSTORM_DENSITY * biomeMask * rainStrength * SANDSTORM_STORM_INTENSITY * heightMask;
}

float _GroundFogDensity(in vec3 rayPos, in float density) {
    float groundH = SEA_LEVEL;
    float topEdge = groundH + GROUND_FOG_MAX_HEIGHT_ABOVE;
    float heightMask = smoothstep(groundH - 0.5, groundH, rayPos.y)
                     * smoothstep(topEdge + GROUND_FOG_FADE, topEdge, rayPos.y);
    return density * heightMask;
}

// Плотность адского биомного тумана в точке
float _NetherFogDensity(in vec3 rayPos, in float biomeFactor,
                         float fogDensity, float minH, float maxH, float fade,
                         float noiseScale, vec3 windOffset) {
    if (biomeFactor < 1e-4) return 0.0;
    float heightMask = smoothstep(minH, minH + fade, rayPos.y)
                     * smoothstep(maxH, maxH - fade, rayPos.y);
    if (heightMask < 1e-4) return 0.0;
    float noise = _NetherBiomeFogNoise(rayPos, noiseScale, windOffset);
    return noise * fogDensity * biomeFactor * heightMask;
}

// ─────────────────────────────────────────────────────────────────────────────
//  ГЛАВНАЯ ФУНКЦИЯ — ОВЕРВОРЛД (без метели)
// ─────────────────────────────────────────────────────────────────────────────

#ifdef BIOME_WEATHER_ENABLED
vec4 CalculateBiomeWeatherFog(in vec3 worldPos, in vec3 worldDir, in float dither) {

    float desertFactor  = weatherDesertSmooth;
    float savannaFactor = weatherSavannaSmooth;
    float snowFactor    = weatherSnowySmooth;

    bool hasSandstorm = desertFactor > 0.01 && rainStrength > 0.01;
    bool hasGroundFog = (snowFactor + desertFactor + savannaFactor) > 0.01 && rainStrength > 0.01;
                      
    #ifndef SANDSTORM_ENABLED
        hasSandstorm = false;
    #endif
    #ifndef GROUND_FOG_ENABLED
        hasGroundFog = false;
    #endif

    if (!hasSandstorm && !hasGroundFog) return vec4(0.0, 0.0, 0.0, 1.0);
        
    vec2 camXZ = cameraPosition.xz;
    float maxDist = 0.0;
    if (hasSandstorm) maxDist = max(maxDist, SANDSTORM_MAX_DIST);
    if (hasGroundFog) maxDist = max(maxDist, GROUND_FOG_MAX_DIST);

    float rayLength  = min(maxDist, length(worldPos));
    uint  steps      = 0u;
    
    if (hasSandstorm) steps = max(steps, uint(SANDSTORM_SAMPLES));
    if (hasGroundFog) steps = max(steps, uint(GROUND_FOG_SAMPLES));
    
    if (steps == 0u) return vec4(0.0, 0.0, 0.0, 1.0);

    float stepLength = rayLength / float(steps);
    float LdotV = dot(worldLightVector, worldDir);
                         
    float phaseSand   = HenyeyGreensteinPhase(LdotV,  0.4) * 0.55 + HenyeyGreensteinPhase(LdotV, -0.15) * 0.35 + 0.10;
    float phaseGround = HenyeyGreensteinPhase(LdotV,  0.3) * 0.5  + HenyeyGreensteinPhase(LdotV, -0.1)  * 0.3  + 0.20;
                         
    vec3 colorSandstorm = vec3(SANDSTORM_COLOR_R, SANDSTORM_COLOR_G, SANDSTORM_COLOR_B);
    
    float gfWeight = snowFactor + desertFactor + savannaFactor;
    vec3 colorGround = vec3(0.0);
    if (gfWeight > 1e-5) {
        colorGround = (vec3(GROUND_FOG_COLOR_SNOW_R,    GROUND_FOG_COLOR_SNOW_G,    GROUND_FOG_COLOR_SNOW_B)    * snowFactor
                    +  vec3(GROUND_FOG_COLOR_DESERT_R,  GROUND_FOG_COLOR_DESERT_G,  GROUND_FOG_COLOR_DESERT_B)  * desertFactor
                    +  vec3(GROUND_FOG_COLOR_SAVANNA_R, GROUND_FOG_COLOR_SAVANNA_G, GROUND_FOG_COLOR_SAVANNA_B) * savannaFactor)
                      / gfWeight;
    }
    float groundDensityVal = GROUND_FOG_DENSITY_SNOW * snowFactor + GROUND_FOG_DENSITY_DESERT * desertFactor + GROUND_FOG_DENSITY_SAVANNA * savannaFactor;
                           
    vec3 rayStep     = worldDir * stepLength;
    vec3 rayPosition = rayStep * dither + gbufferModelViewInverse[3].xyz + cameraPosition;

    vec3  scatSand    = vec3(0.0);
    vec3  scatGround  = vec3(0.0);
    float transSand   = 1.0;
    float transGround = 1.0;

    vec3 baseLight = skyIlluminance * 0.8 + directIlluminance * 0.2;
    
    for (uint i = 0u; i < steps; ++i, rayPosition += rayStep) {
        vec2 rayXZ = rayPosition.xz;
        
        #ifdef SANDSTORM_ENABLED
        if (hasSandstorm && transSand > 1e-3) {
            float biomeMask = _BiomeMaskAtRayPoint(desertFactor, rayXZ, camXZ, SANDSTORM_MAX_DIST);
            float dens = _SandstormDensity(rayPosition, biomeMask);
            
            if (dens > 1e-5) {
                float sd      = dens * stepLength;
                float stepTr  = exp2(-sd * (SANDSTORM_SCATTER + SANDSTORM_ABSORPTION) * 1.4427);
                float fogSamp = transSand * (1.0 - stepTr);
                
                vec3 light = baseLight * SANDSTORM_SCATTER * phaseSand;
                if (isLightningFlashing > 1e-2) light += lightningColor * isLightningFlashing * SANDSTORM_LIGHTNING_BOOST;
                    
                scatSand  += light * fogSamp * colorSandstorm;
                transSand *= stepTr;
            }
        }
        #endif

        #ifdef GROUND_FOG_ENABLED
        if (hasGroundFog && transGround > 1e-3) {
            float gfBiomeMask = _BiomeMaskAtRayPoint(clamp(gfWeight, 0.0, 1.0), rayXZ, camXZ, GROUND_FOG_MAX_DIST);
            float savannaMask = _BiomeMaskAtRayPoint(savannaFactor, rayXZ, camXZ, GROUND_FOG_MAX_DIST);
            float totalGfMask = clamp(gfBiomeMask + savannaMask, 0.0, 1.0);

            float dens = _GroundFogDensity(rayPosition, groundDensityVal * totalGfMask);
            if (dens > 1e-5) {
                float sd      = dens * stepLength * rainStrength;
                float stepTr  = exp2(-sd * 2.0 * 1.4427);
                float fogSamp = transGround * (1.0 - stepTr);
                
                vec3 light = baseLight * phaseGround;
                scatGround  += light * fogSamp * colorGround;
                transGround *= stepTr;
            }
        }
        #endif
    }

    scatSand   *= mix(0.40, 1.0, eyeSkylightFix);
    scatGround *= mix(0.25, 1.0, eyeSkylightFix);

    vec3  totalScatter       = scatSand + scatGround;
    float totalTransmittance = transSand * transGround;

    return vec4(totalScatter, totalTransmittance);
}
#else
vec4 CalculateBiomeWeatherFog(in vec3 worldPos, in vec3 worldDir, in float dither) {
    return vec4(0.0, 0.0, 0.0, 1.0);
}
#endif


// ═══════════════════════════════════════════════════════════════════════════
//  ТУМАН АДА — Basalt Deltas + Crimson Forest
//  Вызывай отдельно в нефернском пасе (IS_NETHER).
// ═══════════════════════════════════════════════════════════════════════════

#if defined IS_NETHER && defined NETHER_BIOME_FOG_ENABLED

uniform float BiomeBasaltDeltasSmooth;
uniform float BiomeCrimsonForestSmooth;

// Применяет дополнительный объёмный туман для двух биомов ада поверх NetherFog.
// color — текущий цвет пикселя (inout).
// dist  — глубина в блоках.
void ApplyNetherBiomeFog(inout vec3 color, in vec3 worldPos, in vec3 worldDir, in float dither) {

    float basaltFactor  = BiomeBasaltDeltasSmooth;
    float crimsonFactor = BiomeCrimsonForestSmooth;

    if (basaltFactor + crimsonFactor < 0.01) return;

    // Параметры рейкаста — используем умеренное число шагов
    const uint STEPS = 12u;
    float rayLength  = min(96.0, length(worldPos));
    float stepLength = rayLength / float(STEPS);

    float LdotV = dot(worldLightVector, worldDir);
    float phase  = HenyeyGreensteinPhase(LdotV, 0.25) * 0.6 + 0.4;

    // Времена-ветер для каждого биома
    float tBasalt  = frameTimeCounter * BASALT_FOG_SPEED  * 0.001;
    float tCrimson = frameTimeCounter * CRIMSON_FOG_SPEED * 0.001;

    vec3 windBasalt  = vec3(BASALT_FOG_WIND_X,  0.002, BASALT_FOG_WIND_Z)  * tBasalt;
    vec3 windCrimson = vec3(CRIMSON_FOG_WIND_X, 0.003, CRIMSON_FOG_WIND_Z) * tCrimson;

    vec3 colorBasalt  = vec3(BASALT_FOG_COLOR_R,  BASALT_FOG_COLOR_G,  BASALT_FOG_COLOR_B);
    vec3 colorCrimson = vec3(CRIMSON_FOG_COLOR_R, CRIMSON_FOG_COLOR_G, CRIMSON_FOG_COLOR_B);

    // Базовый свет ада (нет прямого солнца, только ambient)
    vec3 baseLight = skyIlluminance * 0.9 + directIlluminance * 0.1;

    vec3 rayStep     = worldDir * stepLength;
    vec3 rayPosition = rayStep * dither + gbufferModelViewInverse[3].xyz + cameraPosition;

    vec3  scatBasalt  = vec3(0.0);
    vec3  scatCrimson = vec3(0.0);
    float transBasalt  = 1.0;
    float transCrimson = 1.0;

    const float noiseScaleBasalt  = 0.009;
    const float noiseScaleCrimson = 0.011;

    for (uint i = 0u; i < STEPS; ++i, rayPosition += rayStep) {

        if (basaltFactor > 0.01 && transBasalt > 1e-3) {
            float dens = _NetherFogDensity(rayPosition, basaltFactor,
                                            BASALT_FOG_DENSITY,
                                            BASALT_FOG_MIN_H, BASALT_FOG_MAX_H, BASALT_FOG_FADE,
                                            noiseScaleBasalt, windBasalt);
            if (dens > 1e-5) {
                float sd     = dens * stepLength;
                float stepTr = exp2(-sd * 2.0 * 1.4427);
                scatBasalt  += baseLight * phase * transBasalt * (1.0 - stepTr) * colorBasalt;
                transBasalt *= stepTr;
            }
        }

        if (crimsonFactor > 0.01 && transCrimson > 1e-3) {
            float dens = _NetherFogDensity(rayPosition, crimsonFactor,
                                            CRIMSON_FOG_DENSITY,
                                            CRIMSON_FOG_MIN_H, CRIMSON_FOG_MAX_H, CRIMSON_FOG_FADE,
                                            noiseScaleCrimson, windCrimson);
            if (dens > 1e-5) {
                float sd     = dens * stepLength;
                float stepTr = exp2(-sd * 2.0 * 1.4427);
                scatCrimson  += baseLight * phase * transCrimson * (1.0 - stepTr) * colorCrimson;
                transCrimson *= stepTr;
            }
        }
    }

    float totalTrans = transBasalt * transCrimson;
    vec3  totalScat  = scatBasalt + scatCrimson;

    color = color * totalTrans + totalScat;
}

#else
// Заглушка если не в аду или не включено
void ApplyNetherBiomeFog(inout vec3 color, in vec3 worldPos, in vec3 worldDir, in float dither) {}
#endif
