//----// SKY BIRDS (летающие птицы) //--------------------------------------------------------------//
// Переписано: вместо движения по фиксированному кольцу птицы теперь летят
// небольшой СТАЕЙ (флоком) — общий центр + индивидуальные офсеты для каждой
// птицы. Стая имеет жизненный цикл:
//   1) плавно появляется (fade-in) в случайном месте неба;
//   2) летит некоторое время по дуге;
//   3) плавно исчезает (fade-out), "улетая далеко";
//   4) после паузы появляется заново в ДРУГОМ случайном месте неба.
//
// Также сохранена зависимость размера/яркости от "дистанции до камеры":
// ближе -> крупнее и ярче, дальше -> мельче и бледнее.

#ifndef NUMBER_OF_BIRDS
	#define NUMBER_OF_BIRDS 2 // [1 2 3]
#endif
#ifndef BIRD_LINE_THICKNESS
	#define BIRD_LINE_THICKNESS 0.003 // [0.001 0.0015 0.002 0.003 0.004 0.005 0.008]
#endif
#ifndef BIRDS_HEIGHT
	#define BIRDS_HEIGHT 0.15 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.4]
#endif
#ifndef BIRDS_AMPLITUDE
	#define BIRDS_AMPLITUDE 0.05 // [0.0 0.02 0.05 0.08 0.1 0.15 0.2]
#endif

// Сколько птиц в одной стае (на каждый вызов drawBirdGroup).
#ifndef FLOCK_SIZE
	#define FLOCK_SIZE 2 // [2 3 4 5 6 8]
#endif

// Длительность полёта стаи (сек), пауза перед новым появлением,
// и длительность fade-in/fade-out.
#ifndef BIRD_LIFETIME
	#define BIRD_LIFETIME 35.0 // [15.0 20.0 25.0 30.0 35.0 40.0 50.0 60.0 80.0]
#endif
#ifndef BIRD_RESPAWN_DELAY
	#define BIRD_RESPAWN_DELAY 10.0 // [2.0 4.0 6.0 8.0 10.0 15.0 20.0 30.0]
#endif
#ifndef BIRD_FADE_TIME
	#define BIRD_FADE_TIME 4.0 // [1.0 2.0 3.0 4.0 5.0 6.0 8.0 10.0]
#endif

// Разброс позиций птиц внутри стаи (по углу/высоте) — насколько "кучно" летят.
#ifndef FLOCK_SPREAD
	#define FLOCK_SPREAD 0.16 // [0.02 0.04 0.06 0.08 0.1 0.15 0.16 0.20 0.25 0.30]
#endif

// Скорость движения центра стаи по небу.
#ifndef FLOCK_SPEED
	#define FLOCK_SPEED 0.05 // [0.01 0.02 0.03 0.05 0.08 0.1 0.15]
#endif

// Диапазон "расстояния от камеры" для масштабирования размера/яркости.
// 1.0 = базовый размер, <1.0 = ближе (крупнее/ярче), >1.0 = дальше (мельче/бледнее).
#ifndef BIRD_DIST_NEAR
	#define BIRD_DIST_NEAR 0.6 // [0.3 0.4 0.5 0.6 0.7 0.8]
#endif
#ifndef BIRD_DIST_FAR
	#define BIRD_DIST_FAR 1.8 // [1.2 1.4 1.6 1.8 2.0 2.5 3.0]
#endif

// Простой хэш для "случайных" чисел по сиду (без текстур).
float birdHash(float n) {
	return fract(sin(n * 127.1 + 311.7) * 43758.5453123);
}

vec3 drawBirdLine(vec3 color, vec3 worldPos, vec3 v1, vec3 v2, float size, float alpha) {
	float l1 = length(v1 - worldPos);
	float l2 = length(v2 - worldPos);
	float l3 = length(v1 - v2);
	if (l3 < BIRD_LINE_THICKNESS * size) {
		l3 = BIRD_LINE_THICKNESS * size;
	}

	vec3 ss3 = normalize(cross(v1, v2));
	float dist = abs(dot(worldPos, ss3));

	if ((dist < BIRD_LINE_THICKNESS * size && l3 > l1 && l3 > l2)) {
		color = mix(color, vec3(0.0), alpha);
	}
	return color;
}

vec3 drawBird(vec3 color, vec3 worldPos, vec3 birdPos, float dir, float wingdecal, float size, float alpha) {
	vec3 birdColor = color;
	vec3 nWorldPos = normalize(worldPos);
	vec3 nBirdPos = normalize(birdPos);
	vec3 VcrossB = cross(nWorldPos, nBirdPos);

	float cosb = dot(nWorldPos, nBirdPos);
	float sinb = length(VcrossB);

	if (sinb < 0.018 && cosb > 0.0 && alpha > 0.001) {

		float decal = sin((frameTimeCounter + wingdecal) * 4.0) * size;

		vec3 BcrossU = cross(nBirdPos, vec3(0.0, 1.0, 0.0));
		vec3 midPos = normalize(nBirdPos + vec3(0.0, 0.005, 0.0) * decal);
		vec3 leftPos = normalize(nBirdPos + normalize(BcrossU) * 0.0125 * dir * size - vec3(0.0, 0.005, 0.0) * decal);
		vec3 rightPos = normalize(nBirdPos - normalize(BcrossU) * 0.0075 * dir * size - vec3(0.0, 0.005, 0.0) * decal);

		float cosm = dot(nWorldPos, midPos);
		float sinm = length(cross(nWorldPos, midPos));

		float cosl = dot(nWorldPos, leftPos);
		float sinl = length(cross(nWorldPos, leftPos));

		float cosr = dot(nWorldPos, rightPos);
		float sinr = length(cross(nWorldPos, rightPos));

		if (sinm < BIRD_LINE_THICKNESS * size && cosm > 0.0) birdColor = mix(birdColor, vec3(0.0), alpha);
		if (sinl < BIRD_LINE_THICKNESS * size && cosl > 0.0) birdColor = mix(birdColor, vec3(0.0), alpha);
		if (sinr < BIRD_LINE_THICKNESS * size && cosr > 0.0) birdColor = mix(birdColor, vec3(0.0), alpha);

		birdColor = drawBirdLine(birdColor, nWorldPos, leftPos, midPos, size, alpha);
		birdColor = drawBirdLine(birdColor, nWorldPos, rightPos, midPos, size, alpha);
	}

	return birdColor;
}

// Параметры текущего цикла жизни стаи:
//  alpha        — общая прозрачность стаи (fade-in/out + затухание по дистанции);
//  sizeMul      — множитель размера/яркости от "дистанции до камеры";
//  centerAzimuth, centerElevation — стартовое направление центра стаи (азимут/высота);
//  flightDir    — направление полёта (влево/вправо), влияет на взмах крыльев.
void getFlockLifecycle(float seed, out float alpha, out float sizeMul, out float centerAzimuth, out float centerElevation, out float flightDir) {
	float cycleLen = BIRD_LIFETIME + BIRD_RESPAWN_DELAY;

	float shiftedTime = frameTimeCounter + seed * 1000.0;
	float t = mod(shiftedTime, cycleLen);

	float cycleIndex = floor(shiftedTime / cycleLen);
	float cycleSeed = seed * 991.7 + cycleIndex * 137.31;

	// Случайная стартовая точка на небе — "появилась в другой части".
	centerAzimuth = birdHash(cycleSeed) * TAU;
	// Высота центра стаи: немного варьируется вокруг BIRDS_HEIGHT.
	centerElevation = BIRDS_HEIGHT + (birdHash(cycleSeed + 5.17) - 0.5) * BIRDS_AMPLITUDE * 1.5;

	// Случайное направление полёта (влево/вправо вдоль горизонта).
	flightDir = (birdHash(cycleSeed + 2.31) > 0.5) ? 1.0 : -1.0;

	// Случайная "дистанция до камеры" на этот цикл.
	float distFactor = mix(BIRD_DIST_NEAR, BIRD_DIST_FAR, birdHash(cycleSeed + 9.81));
	sizeMul = 1.0 / distFactor;

	// alpha: 0 во время паузы между появлениями, плавно нарастает в начале
	// жизни и убывает в конце (стая "улетает далеко" и растворяется).
	if (t >= BIRD_LIFETIME) {
		alpha = 0.0;
	} else {
		float fadeIn = clamp(t / BIRD_FADE_TIME, 0.0, 1.0);
		float fadeOut = clamp((BIRD_LIFETIME - t) / BIRD_FADE_TIME, 0.0, 1.0);
		alpha = min(fadeIn, fadeOut);
	}

	// Дальние стаи дополнительно бледнее.
	alpha *= clamp(1.0 / distFactor, 0.0, 1.0);
}

// Рисует одну стаю птиц (флок). decal — уникальный сид стаи, size — базовый
// размер (масштабируется по дистанции внутри).
vec3 drawBirdGroup(vec3 color, vec3 worldPos, float dir, float decal, float size) {
	float alpha, sizeMul, centerAzimuth, centerElevation, flightDir;
	getFlockLifecycle(decal, alpha, sizeMul, centerAzimuth, centerElevation, flightDir);

	if (alpha <= 0.001) {
		return color;
	}

	float effDir = dir * flightDir;
	float effSize = size * sizeMul;

	// Время полёта внутри текущего цикла жизни (для движения центра стаи).
	float shiftedTime = frameTimeCounter + decal * 1000.0;
	float t = mod(shiftedTime, BIRD_LIFETIME + BIRD_RESPAWN_DELAY);

	// Центр стаи плавно перемещается по азимуту в течение жизни.
	float azimuth = centerAzimuth + t * FLOCK_SPEED * effDir;

	for (int i = 0; i < FLOCK_SIZE; i++) {
		float idx = float(i);
		float birdSeed = decal * 53.7 + idx * 17.123;

		// Индивидуальный офсет птицы внутри стаи (азимут/высота),
		// чуть подрагивающий со временем для живости.
		float offAz = (birdHash(birdSeed) - 0.5) * FLOCK_SPREAD * 2.0;
		float offEl = (birdHash(birdSeed + 3.3) - 0.5) * FLOCK_SPREAD;

		float wobble = sin(frameTimeCounter * 0.6 + birdSeed * 6.0) * FLOCK_SPREAD * 0.15;

		float birdAzimuth = azimuth + offAz + wobble;
		float birdElevation = centerElevation + offEl;

		vec3 birdPos = normalize(vec3(cos(birdAzimuth), birdElevation, sin(birdAzimuth)));

		float wingdecal = birdSeed;
		color.rgb = drawBird(color.rgb, worldPos, birdPos, effDir, wingdecal, effSize, alpha);
	}

	return color;
}
