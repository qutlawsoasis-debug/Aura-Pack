
#ifndef TAU
	#define TAU 6.28318530717959
#endif

#define starsSunVisibility  clamp((worldSunVector.y + 0.0625) * 8.0, 0.0, 1.0)
#define starsMoonVisibility clamp((-worldSunVector.y + 0.0625) * 8.0, 0.0, 1.0)
#define starsRainFactor     wetness
#define starsRainStrength   wetness
#define starsDayFactor      starsSunVisibility
