#include "/lib/Head/BiomeWeather.inc"

// Единая функция маски для всех погодных явлений. 
// Делает очень плавный переход и не дает метели "вылезать" резкой стеной в другие биомы.
float _BiomeMaskAtRayPoint(float biomeFactor, vec2 rayXZ, vec2 camXZ, float maxDist) {
    if (biomeFactor < 0.01) return 0.0;

    float distXZ = length(rayXZ - camXZ);
    
    // Чем меньше фактор биома (мы на границе), тем меньше радиус метели/бури
    float currentRadius = maxDist * biomeFactor; 
    
    // Очень плавное затухание от 30% радиуса до самого края. 
    // Это убирает эффект "стены тумана", которая лезет в другой биом.
    float fade = 1.0 - smoothstep(currentRadius * 0.3, currentRadius, distXZ);
    
    // Дополнительно глушим общую плотность на границах биома
    return fade * smoothstep(0.0, 1.0, biomeFactor);
}

// ─────────────────────────────────────────────────────────────────────────────
//  ШУМОВЫЕ ФУНКЦИИ
// ─────────────────────────────────────────────────────────────────────────────

float _BlizzardNoise(in vec3 worldPos) {
    vec2  windDir2 = normalize(vec2(BLIZZARD_WIND_DIR_X, BLIZZARD_WIND_DIR_Z));
    
    // ФИКС СКОРОСТИ: уменьшен базовый множитель времени с 0.012 на 0.0015.
    // Теперь настройка BLIZZARD_WIND_SPEED будет работать адекватно и плавно.
    float t = frameTimeCounter * BLIZZARD_WIND_SPEED * 0.0015;
    vec3  windOffset = vec3(windDir2.x, 0.025, windDir2.y) * t;

    vec3 pos = worldPos * BLIZZARD_NOISE_SCALE + windOffset;

    float coarse = Get3DNoiseSmooth(pos);
    float detail = Get3DNoiseSmooth(pos * 3.2 + windOffset * 0.5) * BLIZZARD_NOISE_DETAIL;
    float swirl  = Get3DNoiseSmooth(pos * 1.6 + vec3(0.3, 0.7, 0.1)) * 0.06;
    
    pos.xz += swirl;
    float noise = coarse * 0.74 + detail + swirl * 0.4;
    return clamp(noise * 2.6 - 1.0, 0.0, 1.0);
}

float _SandstormNoise(in vec3 worldPos) {
    vec2  windDir2 = normalize(vec2(SANDSTORM_WIND_DIR_X, SANDSTORM_WIND_DIR_Z));
    
    // ФИКС СКОРОСТИ
    float t = frameTimeCounter * SANDSTORM_WIND_SPEED * 0.0015;
    vec3  windOffset = vec3(windDir2.x, 0.008, windDir2.y) * t;
    
    vec3 pos = worldPos * SANDSTORM_NOISE_SCALE + windOffset;

    float coarse = Get3DNoiseSmooth(pos);
    float detail = Get3DNoiseSmooth(pos * 2.8 + windOffset * 0.4) * SANDSTORM_NOISE_DETAIL;
    float swirl  = Get3DNoiseSmooth(pos * 1.2 + vec3(5.1, 0.2, 3.7)) * 0.08;
    
    pos.xz += swirl * 1.2;
    float noise = coarse * 0.70 + detail + swirl * 0.5;
    return clamp(noise * 2.4 - 0.92, 0.0, 1.0);
}

// ─────────────────────────────────────────────────────────────────────────────
//  ПЛОТНОСТЬ В ТОЧКЕ
// ─────────────────────────────────────────────────────────────────────────────

float _BlizzardDensity(in vec3 rayPos, in float biomeMask) {
    if (biomeMask < 1e-4) return 0.0;
    
    float heightMask = smoothstep(BLIZZARD_MIN_HEIGHT,
                                  BLIZZARD_MIN_HEIGHT + BLIZZARD_HEIGHT_FADE, rayPos.y)
                     * smoothstep(BLIZZARD_MAX_HEIGHT,
                                  BLIZZARD_MAX_HEIGHT - BLIZZARD_HEIGHT_FADE, rayPos.y);
                                  
    if (heightMask < 1e-4) return 0.0;

    float noise = _BlizzardNoise(rayPos);
    return noise * BLIZZARD_DENSITY * biomeMask * rainStrength
         * BLIZZARD_STORM_INTENSITY * heightMask;
}

float _SandstormDensity(in vec3 rayPos, in float biomeMask) {
    if (biomeMask < 1e-4) return 0.0;
    
    float heightMask = smoothstep(SANDSTORM_MIN_HEIGHT,
                                  SANDSTORM_MIN_HEIGHT + SANDSTORM_HEIGHT_FADE, rayPos.y)
                     * smoothstep(SANDSTORM_MAX_HEIGHT,
                                  SANDSTORM_MAX_HEIGHT - SANDSTORM_HEIGHT_FADE, rayPos.y);
                                  
    if (heightMask < 1e-4) return 0.0;

    float noise = _SandstormNoise(rayPos);
    return noise * SANDSTORM_DENSITY * biomeMask * rainStrength
         * SANDSTORM_STORM_INTENSITY * heightMask;
}

float _GroundFogDensity(in vec3 rayPos, in float density) {
    float groundH = SEA_LEVEL;
    float topEdge = groundH + GROUND_FOG_MAX_HEIGHT_ABOVE;
    float heightMask = smoothstep(groundH - 0.5, groundH, rayPos.y)
                     * smoothstep(topEdge + GROUND_FOG_FADE, topEdge, rayPos.y);
    return density * heightMask;
}

// ─────────────────────────────────────────────────────────────────────────────
//  ГЛАВНАЯ ФУНКЦИЯ
// ─────────────────────────────────────────────────────────────────────────────

#ifdef BIOME_WEATHER_ENABLED
vec4 CalculateBiomeWeatherFog(in vec3 worldPos, in vec3 worldDir, in float dither) {

    float snowFactor    = weatherSnowySmooth;
    float desertFactor  = weatherDesertSmooth;
    float savannaFactor = weatherSavannaSmooth;

    bool hasBlizzard  = snowFactor   > 0.01 && rainStrength > 0.01;
    bool hasSandstorm = desertFactor > 0.01 && rainStrength > 0.01;
    bool hasGroundFog = (snowFactor + desertFactor + savannaFactor) > 0.01
                      && rainStrength > 0.01;
                      
    #ifndef BLIZZARD_ENABLED
        hasBlizzard = false;
    #endif
    #ifndef SANDSTORM_ENABLED
        hasSandstorm = false;
    #endif
    #ifndef GROUND_FOG_ENABLED
        hasGroundFog = false;
    #endif

    if (!hasBlizzard && !hasSandstorm && !hasGroundFog)
        return vec4(0.0, 0.0, 0.0, 1.0);
        
    // XZ позиция камеры в мировых координатах
    vec2 camXZ = cameraPosition.xz;
    
    // Параметры рейкаста
    float maxDist = 0.0;
    if (hasBlizzard)  maxDist = max(maxDist, BLIZZARD_MAX_DIST);
    if (hasSandstorm) maxDist = max(maxDist, SANDSTORM_MAX_DIST);
    if (hasGroundFog) maxDist = max(maxDist, GROUND_FOG_MAX_DIST);

    float rayLength  = min(maxDist, length(worldPos));
    uint  steps      = 0u;
    
    if (hasBlizzard)  steps = max(steps, uint(BLIZZARD_SAMPLES));
    if (hasSandstorm) steps = max(steps, uint(SANDSTORM_SAMPLES));
    if (hasGroundFog) steps = max(steps, uint(GROUND_FOG_SAMPLES));
    
    if (steps == 0u) return vec4(0.0, 0.0, 0.0, 1.0);

    float stepLength = rayLength / float(steps);
    float LdotV = dot(worldLightVector, worldDir);
    
    // Фазовые функции
    float phaseBlizzard  = HenyeyGreensteinPhase(LdotV,  0.5) * 0.6
                         + HenyeyGreensteinPhase(LdotV, -0.2) * 0.4;
                         
    float phaseSand      = HenyeyGreensteinPhase(LdotV,  0.4) * 0.55
                         + HenyeyGreensteinPhase(LdotV, -0.15) * 0.35
                         + 0.10;
                         
    float phaseGround    = HenyeyGreensteinPhase(LdotV,  0.3) * 0.5
                         + HenyeyGreensteinPhase(LdotV, -0.1) * 0.3
                         + 0.20;
                         
    vec3 colorBlizzard  = vec3(BLIZZARD_COLOR_R,  BLIZZARD_COLOR_G,  BLIZZARD_COLOR_B);
    vec3 colorSandstorm = vec3(SANDSTORM_COLOR_R, SANDSTORM_COLOR_G, SANDSTORM_COLOR_B);
    
    // Цвет наземного тумана — взвешенное смешение биомов
    float gfWeight = snowFactor + desertFactor + savannaFactor;
    vec3 colorGround = vec3(0.0);
    if (gfWeight > 1e-5) {
        colorGround = (vec3(GROUND_FOG_COLOR_SNOW_R,    GROUND_FOG_COLOR_SNOW_G,    GROUND_FOG_COLOR_SNOW_B)    * snowFactor
                    +  vec3(GROUND_FOG_COLOR_DESERT_R,  GROUND_FOG_COLOR_DESERT_G,  GROUND_FOG_COLOR_DESERT_B)  * desertFactor
                    +  vec3(GROUND_FOG_COLOR_SAVANNA_R, GROUND_FOG_COLOR_SAVANNA_G, GROUND_FOG_COLOR_SAVANNA_B) * savannaFactor)
                      / gfWeight;
    }
    float groundDensityVal = GROUND_FOG_DENSITY_SNOW    * snowFactor
                           + GROUND_FOG_DENSITY_DESERT  * desertFactor
                           + GROUND_FOG_DENSITY_SAVANNA * savannaFactor;
                           
    // Рейкаст
    vec3 rayStep     = worldDir * stepLength;
    vec3 rayPosition = rayStep * dither + gbufferModelViewInverse[3].xyz + cameraPosition;

    vec3  scatBlizzard  = vec3(0.0);
    vec3  scatSand      = vec3(0.0);
    vec3  scatGround    = vec3(0.0);
    
    float transBlizzard  = 1.0;
    float transSand      = 1.0;
    float transGround    = 1.0;

    vec3 baseLight = skyIlluminance * 0.8 + directIlluminance * 0.2;
    
    for (uint i = 0u; i < steps; ++i, rayPosition += rayStep) {

        // XZ позиция точки рейкаста
        vec2 rayXZ = rayPosition.xz;
        
        // ── Метель ──────────────────────────
        #ifdef BLIZZARD_ENABLED
        if (hasBlizzard && transBlizzard > 1e-3) {
            float biomeMask = _BiomeMaskAtRayPoint(snowFactor, rayXZ, camXZ, BLIZZARD_MAX_DIST);
            float dens = _BlizzardDensity(rayPosition, biomeMask);
            
            if (dens > 1e-5) {
                float sd      = dens * stepLength;
                float stepTr  = exp2(-sd * (BLIZZARD_SCATTER + BLIZZARD_ABSORPTION) * 1.4427);
                float fogSamp = transBlizzard * (1.0 - stepTr);
                
                vec3 light = baseLight * BLIZZARD_SCATTER * phaseBlizzard;
                if (isLightningFlashing > 1e-2)
                    light += lightningColor * isLightningFlashing * BLIZZARD_LIGHTNING_BOOST;
                    
                scatBlizzard  += light * fogSamp * colorBlizzard;
                transBlizzard *= stepTr;
            }
        }
        #endif

        // ── Песчаная буря ─────────────────────────────────────────────────────
        #ifdef SANDSTORM_ENABLED
        if (hasSandstorm && transSand > 1e-3) {
            float biomeMask = _BiomeMaskAtRayPoint(desertFactor, rayXZ, camXZ, SANDSTORM_MAX_DIST);
            float dens = _SandstormDensity(rayPosition, biomeMask);
            
            if (dens > 1e-5) {
                float sd      = dens * stepLength;
                float stepTr  = exp2(-sd * (SANDSTORM_SCATTER + SANDSTORM_ABSORPTION) * 1.4427);
                float fogSamp = transSand * (1.0 - stepTr);
                
                vec3 light = baseLight * SANDSTORM_SCATTER * phaseSand;
                if (isLightningFlashing > 1e-2)
                    light += lightningColor * isLightningFlashing * SANDSTORM_LIGHTNING_BOOST;
                    
                scatSand  += light * fogSamp * colorSandstorm;
                transSand *= stepTr;
            }
        }
        #endif

        // ── Наземный туман ────────────────────────────────────────────────────
        #ifdef GROUND_FOG_ENABLED
        if (hasGroundFog && transGround > 1e-3) {
            // Для наземного тумана комбинируем маски нужных биомов
            float gfBiomeMask = _BiomeMaskAtRayPoint(clamp(gfWeight, 0.0, 1.0), rayXZ, camXZ, GROUND_FOG_MAX_DIST);
            float savannaMask = _BiomeMaskAtRayPoint(savannaFactor, rayXZ, camXZ, GROUND_FOG_MAX_DIST);
            float totalGfMask = clamp(gfBiomeMask + savannaMask, 0.0, 1.0);

            float dens = _GroundFogDensity(rayPosition, groundDensityVal * totalGfMask);
            if (dens > 1e-5) {
                float sd      = dens * stepLength * rainStrength;
                float stepTr  = exp2(-sd * 2.0 * 1.4427);
                float fogSamp = transGround * (1.0 - stepTr);
                
                vec3 light = baseLight * phaseGround;
                scatGround    += light * fogSamp * colorGround;
                transGround   *= stepTr;
            }
        }
        #endif
    }

    // Ночное затухание
    float nightFade = mix(0.30, 1.0, eyeSkylightFix);
    scatBlizzard *= nightFade;
    scatSand     *= mix(0.40, 1.0, eyeSkylightFix);
    scatGround   *= mix(0.25, 1.0, eyeSkylightFix);
    
    vec3  totalScatter       = scatBlizzard + scatSand + scatGround;
    float totalTransmittance = transBlizzard * transSand * transGround;

    return vec4(totalScatter, totalTransmittance);
}
#else
vec4 CalculateBiomeWeatherFog(in vec3 worldPos, in vec3 worldDir, in float dither) {
    return vec4(0.0, 0.0, 0.0, 1.0);
}
#endif