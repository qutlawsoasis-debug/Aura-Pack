//----// STAR SETTINGS //------------------------------------------------------------------------//
#ifndef STAR_STYLE
	#define STAR_STYLE 0 // [0 1 2 3]
#endif
#ifndef STARS_COVERAGE
	#define STARS_COVERAGE 1.0 // [0.0 0.3 0.5 0.7 1.0 1.3 1.6 2.0]
#endif
#ifndef STARS_INTENSITY
	#define STARS_INTENSITY 1.0 // [0.0 0.3 0.5 0.7 1.0 1.3 1.6 2.0]
#endif

#ifndef PLANETS_IN_REFLECTIONS
	#define PLANETS_IN_REFLECTIONS 1 // [0 1]
#endif
#define PLANET1_ENABLED 0 // [0 1]
#define PLANET1_ROTX 0 // [0.0 0.5 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0]
#define PLANET1_ROTY 0 // [0.0 0.5 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0]
#define PLANET1_ROTZ 0 // [0.0 0.5 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0]
#define PLANET1_SIZE 1.0 // [-0.3 -0.2 -0.z1 0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0 21.0 22.0 23.0 24.0 25.0 26.0 27.0 28.0 29.0 30.0]
#define PLANET1_BRIGHTNESS 1.0 // [0 0.5 1 1.5 2 2.5 3 3.5 4 4.5 5 5.5 6 6.5 7 7,5 8 8.5 9 9.5 10 10.5 11 11.5 12 12.5 13 13.5 14 14.5 15 15.5 16 16.5 17 17.5 18 18.5 19 19.5 20]
#define PLANET2_ENABLED 0 // [0 1]  
#define PLANET2_ROTX 0 // [0.0 0.5 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0]
#define PLANET2_ROTY 0 // [0.0 0.5 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0]
#define PLANET2_ROTZ 0 // [0.0 0.5 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0]
#define PLANET2_SIZE 1.0 // [-0.3 -0.2 -0.z1 0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0 21.0 22.0 23.0 24.0 25.0 26.0 27.0 28.0 29.0 30.0]
#define PLANET2_BRIGHTNESS 1.0 // [0 0.5 1 1.5 2 2.5 3 3.5 4 4.5 5 5.5 6 6.5 7 7,5 8 8.5 9 9.5 10 10.5 11 11.5 12 12.5 13 13.5 14 14.5 15 15.5 16 16.5 17 17.5 18 18.5 19 19.5 20]
#define PLANET3_ENABLED 0 // [0 1]
#define PLANET3_ROTX 0 // [0.0 0.5 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0]
#define PLANET3_ROTY 0 // [0.0 0.5 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0]
#define PLANET3_ROTZ 0 // [0.0 0.5 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0]
#define PLANET3_SIZE 1.0 // [-0.3 -0.2 -0.z1 0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0 21.0 22.0 23.0 24.0 25.0 26.0 27.0 28.0 29.0 30.0]
#define PLANET3_BRIGHTNESS 1.0 // [0 0.5 1 1.5 2 2.5 3 3.5 4 4.5 5 5.5 6 6.5 7 7,5 8 8.5 9 9.5 10 10.5 11 11.5 12 12.5 13 13.5 14 14.5 15 15.5 16 16.5 17 17.5 18 18.5 19 19.5 20]
#define PLANET4_ENABLED 0 // [0 1]
#define PLANET4_ROTX 0 // [0.0 0.5 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0]
#define PLANET4_ROTY 0 // [0.0 0.5 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0]
#define PLANET4_ROTZ 0 // [0.0 0.5 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0]
#define PLANET4_SIZE 1.0 // [-0.3 -0.2 -0.z1 0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0 21.0 22.0 23.0 24.0 25.0 26.0 27.0 28.0 29.0 30.0]
#define PLANET4_BRIGHTNESS 1.0 // [0 0.5 1 1.5 2 2.5 3 3.5 4 4.5 5 5.5 6 6.5 7 7,5 8 8.5 9 9.5 10 10.5 11 11.5 12 12.5 13 13.5 14 14.5 15 15.5 16 16.5 17 17.5 18 18.5 19 19.5 20]

//----// STARMAP SETTINGS //---------------------------------------------------------------------//
// Use PNG starmap texture instead of (or on top of) procedural stars
#ifndef STARMAP_ENABLED
	#define STARMAP_ENABLED 0 // [0 1]
#endif

#ifndef STARMAP_MODE
	#define STARMAP_MODE 0 // [0 1]
#endif
#ifndef STARMAP_BRIGHTNESS
	#define STARMAP_BRIGHTNESS 1.0 // [0.1 0.2 0.3 0.5 0.7 1.0 1.2 1.5 2.0 3.0 5.0]
#endif

#ifndef STARMAP_ROTATION
	#define STARMAP_ROTATION 0.0 // [0.0 15.0 30.0 45.0 60.0 90.0 120.0 135.0 150.0 180.0 210.0 225.0 240.0 270.0 300.0 315.0 330.0]
#endif

//----// SKYBOX STYLE SETTINGS //---------------------------------------------------------------//
#ifndef SKYBOX_STYLE
    #define SKYBOX_STYLE 0 // [0 1 2 3 4 5 6 7 8 9 10 11 12]
#endif

#ifndef SKYBOX_CUBEMAP_BRIGHTNESS
    #define SKYBOX_CUBEMAP_BRIGHTNESS 1.0 // [0.1 0.2 0.3 0.5 0.7 1.0 1.2 1.5 2.0 3.0]
#endif
// Blend cubemap 
#ifndef SKYBOX_CUBEMAP_BLEND
    #define SKYBOX_CUBEMAP_BLEND 0 // [0 1]
#endif
// UE haze
#ifndef SKYBOX_UE_HAZE
    #define SKYBOX_UE_HAZE 1.0 // [0.0 0.3 0.5 0.7 1.0 1.3 1.5 2.0]
#endif
// UE zen
#ifndef SKYBOX_UE_ZENITH_DEPTH
    #define SKYBOX_UE_ZENITH_DEPTH 1.0 // [0.0 0.3 0.5 0.7 1.0 1.3 1.5 2.0]
#endif

#ifndef SKYBOX_BRIGHTNESS
    #define SKYBOX_BRIGHTNESS 1.0
#endif

//----// CUSTOM SKY COLORS //-------------------------------------------------------------------//
#ifndef CUSTOM_SKY_COLORS
    #define CUSTOM_SKY_COLORS 1 // [0 1]
#endif

// Day
#ifndef SKY_COLOR_DAY_R
    #define SKY_COLOR_DAY_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef SKY_COLOR_DAY_G
    #define SKY_COLOR_DAY_G 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef SKY_COLOR_DAY_B
    #define SKY_COLOR_DAY_B 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif

// Noon (зенит, sunY -> 1.0). Применяется как доп. блент НАД Day, когда солнце высоко.
#ifndef SKY_COLOR_NOON_R
    #define SKY_COLOR_NOON_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef SKY_COLOR_NOON_G
    #define SKY_COLOR_NOON_G 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef SKY_COLOR_NOON_B
    #define SKY_COLOR_NOON_B 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
// На какой высоте солнца (0.1..1.0) цвет полностью переходит в NOON
#ifndef SKY_COLOR_NOON_HEIGHT
    #define SKY_COLOR_NOON_HEIGHT 0.7 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 0.95]
#endif

// Sunrise
#ifndef SKY_COLOR_SUNRISE_R
    #define SKY_COLOR_SUNRISE_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef SKY_COLOR_SUNRISE_G
    #define SKY_COLOR_SUNRISE_G 0.85 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.85 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef SKY_COLOR_SUNRISE_B
    #define SKY_COLOR_SUNRISE_B 0.7 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif

// Sunset
#ifndef SKY_COLOR_SUNSET_R
    #define SKY_COLOR_SUNSET_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef SKY_COLOR_SUNSET_G
    #define SKY_COLOR_SUNSET_G 0.75 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef SKY_COLOR_SUNSET_B
    #define SKY_COLOR_SUNSET_B 0.65 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.65 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif

// Night
#ifndef SKY_COLOR_NIGHT_R
    #define SKY_COLOR_NIGHT_R 0.5 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef SKY_COLOR_NIGHT_G
    #define SKY_COLOR_NIGHT_G 0.65 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.65 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef SKY_COLOR_NIGHT_B
    #define SKY_COLOR_NIGHT_B 0.8 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif

// Cubemap tint
#ifndef CUBEMAP_COLOR_TINT
    #define CUBEMAP_COLOR_TINT 1 // [0 1]
#endif

// Cubemap Day
#ifndef CUBEMAP_COLOR_DAY_R
    #define CUBEMAP_COLOR_DAY_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef CUBEMAP_COLOR_DAY_G
    #define CUBEMAP_COLOR_DAY_G 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef CUBEMAP_COLOR_DAY_B
    #define CUBEMAP_COLOR_DAY_B 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif

// Cubemap Noon (зенит)
#ifndef CUBEMAP_COLOR_NOON_R
    #define CUBEMAP_COLOR_NOON_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef CUBEMAP_COLOR_NOON_G
    #define CUBEMAP_COLOR_NOON_G 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef CUBEMAP_COLOR_NOON_B
    #define CUBEMAP_COLOR_NOON_B 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif

// Cubemap Sunrise
#ifndef CUBEMAP_COLOR_SUNRISE_R
    #define CUBEMAP_COLOR_SUNRISE_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef CUBEMAP_COLOR_SUNRISE_G
    #define CUBEMAP_COLOR_SUNRISE_G 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef CUBEMAP_COLOR_SUNRISE_B
    #define CUBEMAP_COLOR_SUNRISE_B 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif

// Cubemap Sunset
#ifndef CUBEMAP_COLOR_SUNSET_R
    #define CUBEMAP_COLOR_SUNSET_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef CUBEMAP_COLOR_SUNSET_G
    #define CUBEMAP_COLOR_SUNSET_G 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef CUBEMAP_COLOR_SUNSET_B
    #define CUBEMAP_COLOR_SUNSET_B 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif

// Cubemap Night
#ifndef CUBEMAP_COLOR_NIGHT_R
    #define CUBEMAP_COLOR_NIGHT_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef CUBEMAP_COLOR_NIGHT_G
    #define CUBEMAP_COLOR_NIGHT_G 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
#ifndef CUBEMAP_COLOR_NIGHT_B
    #define CUBEMAP_COLOR_NIGHT_B 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0]
#endif
//----------------------------------------------------------------------------------------------//

//----// CLOUD MAP SETTINGS //-------------------------------------------------------------------//

#ifndef CLOUDMAP_ENABLED
    #define CLOUDMAP_ENABLED 0 // [0 1]
#endif
#ifndef CLOUDMAP_INDEPENDENT
    #define CLOUDMAP_INDEPENDENT 1 // [0 1]
#endif
#ifndef CLOUDMAP_BRIGHTNESS
    #define CLOUDMAP_BRIGHTNESS 1.0 // [0.1 0.3 0.5 0.7 1.0 1.2 1.5 2.0 3.0]
#endif
#ifndef CLOUDMAP_LAYERS
    #define CLOUDMAP_LAYERS 16 // [1 2 3 4 5 6 8]
#endif
#ifndef CLOUDMAP_PARALLAX_DEPTH
    #define CLOUDMAP_PARALLAX_DEPTH 1.04 // [0.0 0.01 0.02 0.04 0.06 0.08 0.10 0.15 0.20]
#endif
#ifndef CLOUDMAP_ALTITUDE
    #define CLOUDMAP_ALTITUDE 192.0 // [100.0 128.0 160.0 192.0 256.0 320.0 384.0 512.0]
#endif
#ifndef CLOUDMAP_SPEED
    #define CLOUDMAP_SPEED 1.0 // [0.0 0.1 0.2 0.5 1.0 1.5 2.0 3.0 5.0]
#endif
#ifndef CLOUDMAP_DENSITY
    #define CLOUDMAP_DENSITY 1.0 // [0.1 0.2 0.3 0.5 0.7 1.0 1.2 1.5 2.0]
#endif
// Размер одного облачного блока в мировых единицах (ванила = 12)
#ifndef CLOUDMAP_BLOCK_SIZE
    #define CLOUDMAP_BLOCK_SIZE 24.0 // [4.0 6.0 8.0 10.0 12.0 16.0 20.0 24.0 32.0]
#endif
// Максимальная дистанция отрисовки облаков в блоках
#ifndef CLOUDMAP_RENDER_DISTANCE
    #define CLOUDMAP_RENDER_DISTANCE 128.0 // [64.0 128.0 192.0 256.0 384.0 512.0 768.0 1024.0]
#endif
#define CLOUDMAP_SUNLIGHT_SAMPLES 4

#define CLOUDMAP_SKYLIGHT_SAMPLES 4

#define CLOUDMAP_SCALE 40.0

#define CLOUDMAP_VERTICAL_SHADING 1

//----------------------------------------------------------------------------------------------//

// Поддержка ванильных текстур солнца/луны
#ifndef USE_VANILLA_TEXTURES
    #define USE_VANILLA_TEXTURES 0 // [0 1]
#endif


// Cubemap skybox textures
#if SKYBOX_STYLE == 2
    uniform sampler2D shadowcolor0;
#elif SKYBOX_STYLE == 3
    uniform sampler2D colortex27;
#endif

#if USE_VANILLA_TEXTURES == 1
    uniform sampler2D gtexture;
#endif

uniform float worldTimeCounter;
vec3 MoonFlux = vec3(abs(moonPhase - 4.0) * 0.25 + 0.2) * (NIGHT_BRIGHTNESS + nightVision * 0.02);
vec3 lightningColor = isLightningFlashing * vec3(0.45, 0.43, 1.0) * 0.03;

#ifdef AURORA
	float auroraAmount = smoothstep(0.0, 0.2, -worldSunVector.y) * AURORA_STRENGTH;
#endif

vec4 ToSH(float value, vec3 dir) {
	const vec2 foo = vec2(0.5 * PI * sqrt(rPI), 0.3849 * PI * sqrt(0.75 * rPI));
    return vec4(foo.x, foo.y * dir.yzx) * value;
}

vec3 FromSH(vec4 cR, vec4 cG, vec4 cB, vec3 lightDir) {
	const vec2 foo = vec2(0.5 * sqrt(rPI), sqrt(0.75 * rPI));
    vec4 sh = vec4(foo.x, foo.y * lightDir.yzx);
    return vec3(dot(sh, cR), dot(sh, cG), dot(sh, cB));
}

float RayleighPhase(in float cosTheta) {
	const float c = 3.0 / 16.0 * rPI;
    return cosTheta * cosTheta * c + c;
}

float HenyeyGreensteinPhase(in float cosTheta, in const float g) {
	const float gg = g * g;
    float phase = 1.0 + gg - 2.0 * g * cosTheta;
    return oneMinus(gg) / (4.0 * PI * phase * sqrt(phase));
}

float CornetteShanksPhase(in float cosTheta, in const float g) {
	const float gg = g * g;
    float a = oneMinus(gg) * rcp(2.0 + gg) * 3.0 * rPI;
    float b = (1.0 + sqr(cosTheta)) * pow((1.0 + gg - 2.0 * g * cosTheta), -1.5);
    return a * b * 0.125;
}

float MiePhaseClouds(in float cosTheta, in const vec3 g, in const vec3 w) {
	const vec3 gg = g * g;
    vec3 a = (0.75 * oneMinus(gg)) * rcp(2.0 + gg)/* * rTAU*/;
    vec3 b = (1.0 + sqr(cosTheta)) * pow(1.0 + gg - 2.0 * g * cosTheta, vec3(-1.5));
    return dot(a * b, w) / (w.x + w.y + w.z);
}

vec3 DoNightEye(in vec3 color) {
	float luminance = GetLuminance(color);
    float rodFactor = exp2(-luminance * 6e2);
	return mix(color, luminance * vec3(0.72, 0.95, 1.2), rodFactor);
}

float fastAcos(in float x) {
    float a = abs(x);
	float r = 1.570796 - 0.175394 * a;
    r *= sqrt(1.0 - a);
	return x < 0.0 ? PI - r : r;
}

vec2 ProjectSky(in vec3 direction) {
	vec2 coord = vec2(atan(-direction.x, -direction.z) * rTAU + 0.5, fastAcos(direction.y) * rPI);
    coord.x = coord.x * oneMinus(4.0 / skyCaptureRes.x) + 2.0 / skyCaptureRes.x;
	return saturate(coord * skyCaptureRes * screenPixelSize);
}

vec3 UnprojectSky(in vec2 coord) {
	coord.x *= 256.0 / 255.0;
    coord.x = fract((coord.x - 2.0 / skyCaptureRes.x) * rcp(oneMinus(4.0 / skyCaptureRes.x)));
    coord *= vec2(TAU, PI);
	return vec3(sincos(coord.x) * sin(coord.y), cos(coord.y)).xzy;
}

vec2 RaySphereIntersection(in vec3 pos, in vec3 dir, in float rad) {
	float PdotD = dot(pos, dir);
    float delta = sqr(PdotD) + sqr(rad) - dotSelf(pos);
	if (delta < 0.0) return vec2(-1.0);
	delta = sqrt(delta);
    return vec2(-delta, delta) - PdotD;
}

//----------------------------------------------------------------------------//

const float planetRadius = 6371e3;
// ==== НАСТРОЙКИ СОЛНЦА ===================================================
// 1 = дефолт: простой круглый диск
// 2 = кубический: тот же диск, но форма квадратная вместо круглой
#define SUN_STYLE 2 // [1 2]

#define SUN_SIZE 0.012          // угловой радиус диска солнца (стиль 1, круглое), [1] задаёт его "круглость"
#define SUN_SIZE_SQUARE 0.012   // угловой радиус диска солнца (стиль 2, кубическое)

// ==== НАСТРОЙКИ ЛУНЫ ======================================================
// Все стили полностью процедурные, без текстур (colortex16 больше не используется).
// 1 = дефолт: простой круглый диск (старая версия)
// 2 = кубическая: тот же диск, но форма квадратная вместо круглой
// 3 = дефолт с фазами: круглый диск + процедурный терминатор по moonPhase
// 4 = кубическая с фазами: квадратный диск + процедурный терминатор по moonPhase
#define MOON_STYLE 4 // [1 2 3 4]

#define MOON_SIZE 5e-3            // угловой размер диска луны (стили 1 и 3, круглые)
#define MOON_SIZE_SQUARE 45e-3     // угловой размер диска луны (стили 2 и 4, квадратные)
#define MOON_BRIGHTNESS 4.0       // общая яркость луны
#define MOON_PHASE_SOFTNESS 0.03  // мягкость края терминатора (0 = жёсткая граница фазы)

// ==== НАСТРОЙКИ БЛИКОВ (ГАЛО ВОКРУГ СОЛНЦА) ==============================
// Это мягкое яркое гало вокруг диска (шире и мягче самого диска) — то, что
// раньше называлось "лизами"/бликами.
#define SUN_GLARE_ENABLED 1     // [0 1]
#define SUN_GLARE_SIZE 0.05     // угловой радиус гало вокруг солнца (рад)
#define SUN_GLARE_BRIGHTNESS 2e3 // яркость гало солнца

const float sun_angular_radius = SUN_SIZE;
// Unphysical
const float mie_phase_g = 0.77;

#if defined PRECOMPUTED_ATMOSPHERIC_SCATTERING

#define TRANSMITTANCE_TEXTURE_WIDTH     256.0
#define TRANSMITTANCE_TEXTURE_HEIGHT    64.0

#define SCATTERING_TEXTURE_R_SIZE       32.0
#define SCATTERING_TEXTURE_MU_SIZE      128.0
#define SCATTERING_TEXTURE_MU_S_SIZE    32.0
#define SCATTERING_TEXTURE_NU_SIZE      8.0

#define IRRADIANCE_TEXTURE_WIDTH        64.0
#define IRRADIANCE_TEXTURE_HEIGHT       16.0

#define ATMOSPHERE_STYLE 1

struct AtmosphereParameters {
    vec3 solar_irradiance;
    vec3 rayleigh_scattering;
    vec3 mie_scattering;
    vec3 ground_albedo;
};

AtmosphereParameters atmosphereModel = AtmosphereParameters(

#if ATMOSPHERE_STYLE == 1
    // --- DEFAULT ---
    vec3(1.474000, 1.850400, 1.911980),
    vec3(0.005802, 0.013558, 0.033100),
    vec3(0.003996),
    vec3(0.100)

#elif ATMOSPHERE_STYLE == 2
    // --- SEUS PTGI ---
    // Чистая атмосфера с немного теплым солнцем
    vec3(1.62, 1.74, 1.78),
    vec3(0.00560, 0.01320, 0.03190),
    vec3(0.00460),
    vec3(0.130)

#elif ATMOSPHERE_STYLE == 3
    // --- CHOCAPIC13 ---
    // Более плотная атмосфера и насыщенное синее небо
    vec3(1.58, 1.72, 1.82),
    vec3(0.00660, 0.01510, 0.03580),
    vec3(0.00620),
    vec3(0.110)

#elif ATMOSPHERE_STYLE == 4
    // --- BLISS ---
    // Очень чистый воздух и мягкое освещение
    vec3(1.52, 1.67, 1.74),
    vec3(0.00530, 0.01270, 0.02980),
    vec3(0.00260),
    vec3(0.180)

#elif ATMOSPHERE_STYLE == 5
    // --- REALISTIC EARTH ---
    // Практически физически корректные значения
    vec3(1.4740, 1.8504, 1.91198),
    vec3(0.005802, 0.013558, 0.033100),
    vec3(0.003996),
    vec3(0.100)

#elif ATMOSPHERE_STYLE == 6
    // --- ITERATION T ---
    // Значения из IterationT
    vec3(1.68194, 1.85149, 1.91198),
    vec3(0.008396, 0.014590, 0.033100),
    vec3(0.003996),
    vec3(0.100)

#endif
);
#define ATMOSPHERE_BOTTOM_ALTITUDE  1000.0 // [0.0 500.0 1000.0 2000.0 3000.0 4000.0 5000.0 6000.0 7000.0 8000.0 9000.0 10000.0 11000.0 12000.0 13000.0 14000.0 15000.0 16000.0]
#define ATMOSPHERE_TOP_ALTITUDE     100000.0 // [0.0 5000.0 10000.0 20000.0 30000.0 40000.0 50000.0 60000.0 70000.0 80000.0 90000.0 100000.0 110000.0 120000.0 130000.0 140000.0 150000.0 160000.0]

const float atmosphere_bottom_radius = planetRadius - ATMOSPHERE_BOTTOM_ALTITUDE;
const float atmosphere_top_radius = planetRadius + ATMOSPHERE_TOP_ALTITUDE;

const float atmosphere_bottom_radius_sq = atmosphere_bottom_radius * atmosphere_bottom_radius;
const float atmosphere_top_radius_sq = atmosphere_top_radius * atmosphere_top_radius;

const float mu_s_min = -0.2;
//--// Utility functions //---------------------------------------------------//

float ClampCosine(float mu) { return clamp(mu, -1.0, 1.0); }
float ClampRadius(float r) { return clamp(r, atmosphere_bottom_radius, atmosphere_top_radius);
}
float SafeSqrt(float a) { return sqrt(max0(a)); }

//--// Intersections //-------------------------------------------------------//

float DistanceToTopAtmosphereBoundary(float r, float mu) {
    float discriminant = r * r * (mu * mu - 1.0) + atmosphere_top_radius_sq;
    return max0(-r * mu + SafeSqrt(discriminant));
}

float DistanceToBottomAtmosphereBoundary(float r, float mu) {
    float discriminant = r * r * (mu * mu - 1.0) + atmosphere_bottom_radius_sq;
    return max0(-r * mu - SafeSqrt(discriminant));
}

bool RayIntersectsGround(float r, float mu) {
    return mu < 0.0 && r * r * (mu * mu - 1.0) + atmosphere_bottom_radius_sq >= 0.0;
}

//--// Coord Transforms //----------------------------------------------------//

float GetTextureCoordFromUnitRange(float x, float texture_size) {
    return 0.5 / texture_size + x * oneMinus(1.0 / texture_size);
}

//--// Transmittance Lookup //------------------------------------------------//

vec2 GetTransmittanceTextureUvFromRMu(float r, float mu) {
    const float H = sqrt(atmosphere_top_radius_sq - atmosphere_bottom_radius_sq);
    float rho = SafeSqrt(r * r - atmosphere_bottom_radius_sq);
    float d = DistanceToTopAtmosphereBoundary(r, mu);
    float d_min = atmosphere_top_radius - r;
    float d_max = rho + H;
    return vec2(GetTextureCoordFromUnitRange((d - d_min) / (d_max - d_min), TRANSMITTANCE_TEXTURE_WIDTH),
                GetTextureCoordFromUnitRange(rho / H, TRANSMITTANCE_TEXTURE_HEIGHT));
}

vec3 GetTransmittanceToTopAtmosphereBoundary(float r, float mu) {
    vec2 uv = GetTransmittanceTextureUvFromRMu(r, mu);
    uv = clamp(uv, vec2(0.5 / 256.0, 0.5 / 64.0), vec2(255.5 / 256.0, 63.5 / 64.0));
    return vec3(texture(colortex4, vec3(uv * vec2(1.0, 0.5), 32.5 / 33.0)));
}

vec3 GetTransmittance(float r, float mu, float d, bool ray_r_mu_intersects_ground) {
    float r_d = ClampRadius(sqrt(d * d + 2.0 * r * mu * d + r * r));
    float mu_d = ClampCosine((r * mu + d) / r_d);
    if (ray_r_mu_intersects_ground) {
        return min(
            GetTransmittanceToTopAtmosphereBoundary(r_d, -mu_d) /
            GetTransmittanceToTopAtmosphereBoundary(r, -mu),
        vec3(1.0));
    } else {
        return min(
            GetTransmittanceToTopAtmosphereBoundary(r, mu) /
            GetTransmittanceToTopAtmosphereBoundary(r_d, mu_d),
        vec3(1.0));
    }
}

vec3 GetTransmittance(vec3 view_ray) {
	vec3 camera = vec3(0.0, planetRadius + eyeAltitude, 0.0);
    float r = length(camera);
    float rmu = dot(camera, view_ray);
    float distance_to_top_atmosphere_boundary = -rmu - sqrt(rmu * rmu - r * r + atmosphere_top_radius_sq);
    if (distance_to_top_atmosphere_boundary > 0.0) {
        camera += view_ray * distance_to_top_atmosphere_boundary;
        r = atmosphere_top_radius;
        rmu += distance_to_top_atmosphere_boundary;
    } else if (r > atmosphere_top_radius) {
        return vec3(1.0);
    }
    float mu = rmu / r;
	return GetTransmittanceToTopAtmosphereBoundary(r, mu);
}

vec3 GetTransmittanceToSun(float r, float mu_s) {
    float sin_theta_h = atmosphere_bottom_radius / r;
    float cos_theta_h = -sqrt(max0(1.0 - sin_theta_h * sin_theta_h));
    return GetTransmittanceToTopAtmosphereBoundary(r, mu_s) *
        smoothstep(-sin_theta_h * sun_angular_radius,
                    sin_theta_h * sun_angular_radius,
                    mu_s - cos_theta_h);
}

//--// Scattering Lookup //---------------------------------------------------//

vec4 GetScatteringTextureUvwzFromRMuMuSNu(float r, float mu, float mu_s, float nu, bool ray_r_mu_intersects_ground) {
    float H = sqrt(atmosphere_top_radius_sq - atmosphere_bottom_radius_sq);
    float rho = SafeSqrt(r * r - atmosphere_bottom_radius_sq);
    float u_r = GetTextureCoordFromUnitRange(rho / H, SCATTERING_TEXTURE_R_SIZE);
    float r_mu = r * mu;
    float discriminant = r_mu * r_mu - r * r + atmosphere_bottom_radius_sq;
    float u_mu;
    if (ray_r_mu_intersects_ground) {
        float d = -r_mu - SafeSqrt(discriminant);
        float d_min = r - atmosphere_bottom_radius;
        float d_max = rho;
        u_mu = 0.5 - 0.5 * GetTextureCoordFromUnitRange(d_max == d_min ? 0.0 : (d - d_min) / (d_max - d_min), SCATTERING_TEXTURE_MU_SIZE * 0.5);
    } else {
        float d = -r_mu + SafeSqrt(discriminant + H * H);
        float d_min = atmosphere_top_radius - r;
        float d_max = rho + H;
        u_mu = 0.5 + 0.5 * GetTextureCoordFromUnitRange((d - d_min) / (d_max - d_min), SCATTERING_TEXTURE_MU_SIZE * 0.5);
    }

    float d = DistanceToTopAtmosphereBoundary(atmosphere_bottom_radius, mu_s);
    float d_min = atmosphere_top_radius - atmosphere_bottom_radius;
    float d_max = H;
    float a = (d - d_min) / (d_max - d_min);
    float D = DistanceToTopAtmosphereBoundary(atmosphere_bottom_radius, mu_s_min);
    float A = (D - d_min) / (d_max - d_min);
    float u_mu_s = GetTextureCoordFromUnitRange(max0(1.0 - a / A) / (1.0 + a), SCATTERING_TEXTURE_MU_S_SIZE);
    float u_nu = nu * 0.5 + 0.5;
    return vec4(u_nu, u_mu_s, u_mu, u_r);
}

vec3 GetExtrapolatedSingleMieScattering(AtmosphereParameters atmosphere, vec4 scattering) {
    if (scattering.r <= 0.0) {
        return vec3(0.0);
    }
    return scattering.rgb * scattering.a / scattering.r *
        (atmosphere.rayleigh_scattering.r / atmosphere.mie_scattering.r) *
        (atmosphere.mie_scattering / atmosphere.rayleigh_scattering);
}

vec3 GetCombinedScattering(AtmosphereParameters atmosphere, float r, float mu, float mu_s, float nu,
    bool ray_r_mu_intersects_ground, out vec3 single_mie_scattering) {
    vec4 uvwz = GetScatteringTextureUvwzFromRMuMuSNu(r, mu, mu_s, nu, ray_r_mu_intersects_ground);
    float tex_coord_x = uvwz.x * (SCATTERING_TEXTURE_NU_SIZE - 1.0);
    float tex_x = floor(tex_coord_x);
    float lerp = tex_coord_x - tex_x;
    vec3 uvw0 = vec3((tex_x + uvwz.y) / SCATTERING_TEXTURE_NU_SIZE, uvwz.z, uvwz.w);
    vec3 uvw1 = vec3((tex_x + 1.0 + uvwz.y) / SCATTERING_TEXTURE_NU_SIZE, uvwz.z, uvwz.w);
    vec4 combined_scattering = texture(colortex4, uvw0) * oneMinus(lerp) + texture(colortex4, uvw1) * lerp;

    vec3 scattering = vec3(combined_scattering);
    single_mie_scattering = GetExtrapolatedSingleMieScattering(atmosphere, combined_scattering);
    return scattering;
}

//--// Irradiance Lookup //---------------------------------------------------//

vec3 GetIrradiance(float r, float mu_s) {
    float x_r = (r - atmosphere_bottom_radius) / (atmosphere_top_radius - atmosphere_bottom_radius);
    float x_mu_s = mu_s * 0.5 + 0.5;
    vec2 uv = vec2(GetTextureCoordFromUnitRange(x_mu_s, IRRADIANCE_TEXTURE_WIDTH),
                   GetTextureCoordFromUnitRange(x_r, IRRADIANCE_TEXTURE_HEIGHT));
    uv = clamp(uv, vec2(0.5 / 64.0, 0.5 / 16.0), vec2(63.5 / 64.0, 15.5 / 16.0));
    return vec3(texture(colortex4, vec3(uv * vec2(0.25, 0.125) + vec2(0.0, 0.5), 32.5 / 33.0)));
}

//--// Rendering //-----------------------------------------------------------//

vec3 GetSkyRadiance(AtmosphereParameters atmosphere, vec3 view_ray, vec3 sun_direction, out vec3 transmittance) {
		vec3 camera = vec3(0.0, planetRadius + eyeAltitude, 0.0);
        float r = length(camera);
        float rmu = dot(camera, view_ray);
        float distance_to_top_atmosphere_boundary = -rmu - sqrt(rmu * rmu - r * r + atmosphere_top_radius_sq);
        if (distance_to_top_atmosphere_boundary > 0.0) {
            camera += view_ray * distance_to_top_atmosphere_boundary;
            r = atmosphere_top_radius;
            rmu += distance_to_top_atmosphere_boundary;
        } else if (r > atmosphere_top_radius) {
            transmittance = vec3(1.0);
            return vec3(0.0);
        }

        float mu = rmu / r;
        float mu_s = dot(camera, sun_direction) / r;
        float nu = dot(view_ray, sun_direction);

        bool ray_r_mu_intersects_ground = RayIntersectsGround(r, mu);
        transmittance = ray_r_mu_intersects_ground ? vec3(0.0) : GetTransmittanceToTopAtmosphereBoundary(r, mu);

        vec3 sun_single_mie_scattering;
        vec3 sun_scattering;

        vec3 moon_single_mie_scattering;
        vec3 moon_scattering;

        vec3 groundDiffuse = vec3(0.0);
        #ifdef SKY_GROUND
            if (ray_r_mu_intersects_ground) {
                vec3 planet_surface = camera + view_ray * DistanceToBottomAtmosphereBoundary(r, mu);
                float r = length(planet_surface);
                float mu_s = dot(planet_surface, sun_direction) / r;
                vec3 sky_irradiance = GetIrradiance(r, mu_s);
                sky_irradiance += GetIrradiance(r, -mu_s) * MoonFlux;
                vec3 sun_irradiance = atmosphere.solar_irradiance * GetTransmittanceToSun(r, mu_s);
                float d = distance(camera, planet_surface);
                vec3 surface_transmittance = GetTransmittance(r, mu, d, ray_r_mu_intersects_ground);
                groundDiffuse = mix(sky_irradiance * 0.1, sun_irradiance * 0.01, wetness * 0.7) * surface_transmittance;
            }
        #else
            ray_r_mu_intersects_ground = false;
        #endif

        sun_scattering = GetCombinedScattering(atmosphere, r, mu, mu_s, nu, ray_r_mu_intersects_ground, sun_single_mie_scattering);
        moon_scattering = GetCombinedScattering(atmosphere, r, mu, -mu_s, -nu, ray_r_mu_intersects_ground, moon_single_mie_scattering);

        vec3 rayleigh = sun_scattering * RayleighPhase(nu)
                     + moon_scattering * RayleighPhase(-nu) * MoonFlux;
        vec3 mie = sun_single_mie_scattering * HenyeyGreensteinPhase(nu, mie_phase_g)
                + moon_single_mie_scattering * HenyeyGreensteinPhase(-nu, mie_phase_g) * MoonFlux;
        rayleigh = mix(rayleigh, GetLuminance(rayleigh) * vec3(1.026186824, 0.9881671071, 1.015787125), wetness * 0.7);
        return (rayleigh + mie + groundDiffuse) * oneMinus(wetness * 0.6);
}

vec3 GetSkyRadianceToPoint(AtmosphereParameters atmosphere, vec3 point, vec3 sun_direction, out vec3 transmittance) {
		vec3 camera = vec3(0.0, planetRadius + eyeAltitude, 0.0);
        vec3 view_ray = normalize(point);
        float r = length(camera);
        float rmu = dot(camera, view_ray);
        float distance_to_top_atmosphere_boundary = -rmu - sqrt(rmu * rmu - r * r + atmosphere_top_radius_sq);
        if (distance_to_top_atmosphere_boundary > 0.0) {
            camera += view_ray * distance_to_top_atmosphere_boundary;
            r = atmosphere_top_radius;
            rmu += distance_to_top_atmosphere_boundary;
        }

        float mu = rmu / r;
        float mu_s = dot(camera, sun_direction) / r;
        float nu = dot(view_ray, sun_direction);
        float d = length(point);
        bool ray_r_mu_intersects_ground = RayIntersectsGround(r, mu);

        transmittance = GetTransmittance(r, mu, d, ray_r_mu_intersects_ground);

        vec3 sun_single_mie_scattering;
        vec3 sun_scattering = GetCombinedScattering(atmosphere, r, mu, mu_s, nu, ray_r_mu_intersects_ground, sun_single_mie_scattering);
        vec3 moon_single_mie_scattering;
        vec3 moon_scattering = GetCombinedScattering(atmosphere, r, mu, -mu_s, -nu, ray_r_mu_intersects_ground, moon_single_mie_scattering);
        float r_p = ClampRadius(sqrt(d * d + 2.0 * r * mu * d + r * r));
        float mu_p = (r * mu + d) / r_p;
        float mu_s_p = (r * mu_s + d * nu) / r_p;
        float mu_s_p_m = (r * -mu_s + d * -nu) / r_p;

        vec3 sun_single_mie_scattering_p;
        vec3 sun_scattering_p = GetCombinedScattering(atmosphere, r_p, mu_p, mu_s_p, nu, ray_r_mu_intersects_ground, sun_single_mie_scattering_p);
        vec3 moon_single_mie_scattering_p;
        vec3 moon_scattering_p = GetCombinedScattering(atmosphere, r_p, mu_p, mu_s_p_m, -nu, ray_r_mu_intersects_ground, moon_single_mie_scattering_p);

        sun_scattering -= transmittance * sun_scattering_p;
        sun_single_mie_scattering -= transmittance * sun_single_mie_scattering_p;
        moon_scattering = moon_scattering - transmittance * moon_scattering_p;
        moon_single_mie_scattering -= transmittance * moon_single_mie_scattering_p;

        sun_single_mie_scattering *= smoothstep(0.0, 0.01, mu_s);
        moon_single_mie_scattering *= smoothstep(0.0, 0.01, -mu_s);

        vec3 rayleigh = sun_scattering * RayleighPhase(nu)
                     + moon_scattering * RayleighPhase(-nu) * MoonFlux;
        vec3 mie = sun_single_mie_scattering * HenyeyGreensteinPhase(nu, mie_phase_g)
                + moon_single_mie_scattering * HenyeyGreensteinPhase(-nu, mie_phase_g) * MoonFlux;
        rayleigh = mix(rayleigh, GetLuminance(rayleigh) * vec3(1.026186824, 0.9881671071, 1.015787125), wetness * 0.7);

        return (rayleigh + mie) * oneMinus(wetness * 0.6);
}

vec3 GetSunAndSkyIrradiance(AtmosphereParameters atmosphere, vec3 point, vec3 sun_direction,
    out vec3 sun_irradiance, out vec3 moon_irradiance) {
    float r = length(point);
    float mu_s = dot(point, sun_direction) / r;

    sun_irradiance = atmosphere.solar_irradiance * GetTransmittanceToSun(r, mu_s);
    moon_irradiance = atmosphere.solar_irradiance * DoNightEye(GetTransmittanceToSun(r, -mu_s) * MoonFlux);

    vec3 sky_irradiance = GetIrradiance(r, mu_s) + GetIrradiance(r, -mu_s) * MoonFlux;
    sky_irradiance *= 1.0 + point.y / r;

    return sky_irradiance;
}

#endif

#define coneAngleToSolidAngle(x) (TAU * oneMinus(cos(x)))


//============================================================================//
// SKYBOX PRESET SYSTEM
//============================================================================//

// ---- Vertical-cross cubemap sampler ----------------------------------------
#if SKYBOX_STYLE == 2 || SKYBOX_STYLE == 3

vec3 _SampleCubemapCross(in sampler2D tex, in vec3 dir) {
    vec3 absDir = abs(dir);
    vec2 faceUV;
    int  face;

    if (absDir.x >= absDir.y && absDir.x >= absDir.z) {
        if (dir.x > 0.0) { face = 0;
            faceUV = vec2(-dir.z, -dir.y) / absDir.x; }
        else             { face = 1;
            faceUV = vec2( dir.z, -dir.y) / absDir.x; }
    } else if (absDir.y >= absDir.x && absDir.y >= absDir.z) {
        if (dir.y > 0.0) { face = 2;
            faceUV = vec2( dir.x,  dir.z) / absDir.y; }
        else             { face = 3;
            faceUV = vec2( dir.x, -dir.z) / absDir.y; }
    } else {
        if (dir.z > 0.0) { face = 4;
            faceUV = vec2( dir.x, -dir.y) / absDir.z; }
        else             { face = 5;
            faceUV = vec2(-dir.x, -dir.y) / absDir.z; }
    }

    faceUV = faceUV * 0.5 + 0.5;
    const float fw = 1.0 / 4.0;
    const float fh = 1.0 / 3.0;

    vec2 origin;
    if      (face == 2) origin = vec2(1.0 * fw, 0.0 * fh);
    else if (face == 5) origin = vec2(0.0 * fw, 1.0 * fh);
    else if (face == 1) origin = vec2(1.0 * fw, 1.0 * fh);
    else if (face == 4) origin = vec2(2.0 * fw, 1.0 * fh);
    else if (face == 0) origin = vec2(3.0 * fw, 1.0 * fh);
    else                origin = vec2(1.0 * fw, 2.0 * fh);
    vec2 uv = origin + faceUV * vec2(fw, fh);


    vec3 color = textureLod(tex, uv, 0.0).rgb;
    return pow(color, vec3(2.2)) * SKYBOX_CUBEMAP_BRIGHTNESS;
}

#endif // SKYBOX_STYLE 2/3

#if SKYBOX_STYLE == 4
vec3 _ApplySEUSStyle(in vec3 skyRadiance, in vec3 worldDir, in vec3 sunVector) {
    float sunY    = sunVector.y;
    float upness  = max0(worldDir.y);
    float horizon = 1.0 - abs(worldDir.y);

    vec3 dayZenith    = vec3(0.18, 0.42, 0.90);
    vec3 dayHorizon   = vec3(0.62, 0.78, 1.00);
    vec3 sunriseColor = vec3(1.00, 0.55, 0.18);
    vec3 sunsetColor  = vec3(1.00, 0.42, 0.14);
    vec3 nightZenith  = vec3(0.04, 0.06, 0.16);
    vec3 nightHorizon = vec3(0.10, 0.13, 0.25);
    vec3 dayColor = mix(dayHorizon, dayZenith, upness * upness);

    bool isSunrise  = (sunVector.x > 0.0);
    vec3 twilight   = isSunrise ? sunriseColor : sunsetColor;
    float sunDot    = saturate(dot(worldDir, vec3(sunVector.x, 0.0, sunVector.z)));
    float glowAmt   = sqr(horizon) * pow(sunDot, 3.0) * 1.4;
    vec3 nightColor = mix(nightHorizon, nightZenith, upness);

    vec3 tint;
    if (sunY > 0.15) {
        tint = dayColor;
    } else if (sunY > -0.06) {
        float t = smoothstep(-0.06, 0.15, sunY);
        vec3 twilightSky = mix(dayHorizon * 0.6, dayColor, upness) + twilight * glowAmt;
        tint = mix(twilightSky, dayColor, t);
    } else {
        float t = smoothstep(-0.25, -0.06, sunY);
        tint = mix(nightColor, mix(dayHorizon * 0.4, dayColor * 0.5, upness) + twilight * glowAmt * t, t);
    }

    float sunGlow  = sqr(sqr(horizon)) * saturate(dot(worldDir, sunVector) * 0.5 + 0.5);
    vec3 glowColor = mix(sunsetColor, vec3(1.0, 0.85, 0.55), saturate(sunY * 3.0));
    vec3 result    = skyRadiance * tint;
    result += glowColor * sunGlow * 0.18 * saturate(1.0 - abs(sunY) * 4.0);
    return result;
}
#endif


// ---- Style 5: BSL-style ----------------------------------------------------
#if SKYBOX_STYLE == 5
vec3 _ApplyBSLStyle(in vec3 skyRadiance, in vec3 worldDir, in vec3 sunVector) {
    float sunY    = sunVector.y;
    float upness  = max0(worldDir.y);
    float horizon = 1.0 - abs(worldDir.y);

    vec3 dayZenith    = vec3(0.38, 0.55, 0.82);
    vec3 dayHorizon   = vec3(0.74, 0.82, 0.93);
    vec3 sunriseColor = vec3(0.92, 0.68, 0.48);
    vec3 sunsetColor  = vec3(0.88, 0.60, 0.40);
    vec3 nightZenith  = vec3(0.06, 0.08, 0.18);
    vec3 nightHorizon = vec3(0.14, 0.17, 0.28);
    vec3 dayColor = mix(dayHorizon, dayZenith, pow(upness, 0.7));

    bool isSunrise  = (sunVector.x > 0.0);
    vec3 twilight   = isSunrise ? sunriseColor : sunsetColor;
    float sunDot    = saturate(dot(worldDir, vec3(sunVector.x, 0.0, sunVector.z)));
    float glowAmt   = sqr(horizon) * pow(sunDot, 4.0) * 0.9;
    vec3 nightColor = mix(nightHorizon, nightZenith, upness);

    vec3 tint;
    if (sunY > 0.15) {
        tint = dayColor;
    } else if (sunY > -0.06) {
        float t = smoothstep(-0.06, 0.15, sunY);
        vec3 twilightSky = mix(dayHorizon * 0.65, dayColor, upness) + twilight * glowAmt;
        tint = mix(twilightSky, dayColor, t);
    } else {
        float t = smoothstep(-0.22, -0.06, sunY);
        tint = mix(nightColor, mix(dayHorizon * 0.45, dayColor * 0.55, upness) + twilight * glowAmt * t, t);
    }

    float lum       = dot(skyRadiance, vec3(0.2126, 0.7152, 0.0722));
    vec3 desat      = mix(skyRadiance, vec3(lum), 0.22);
    float milkiness = sqr(horizon) * 0.28;
    vec3 milky      = vec3(0.88, 0.90, 0.95) * milkiness * saturate(sunY + 0.5);
    return desat * tint + milky;
}
#endif



#if SKYBOX_STYLE == 6
vec3 _ApplyHosekWilkieStyle(in vec3 skyRadiance, in vec3 worldDir, in vec3 sunVector) {
    float sunY     = max(sunVector.y, 0.0);
    float cosTheta = max(worldDir.y, 0.001);
    float cosGamma = clamp(dot(worldDir, sunVector), -1.0, 1.0);
    float gamma_a  = acos(cosGamma);
    const vec3 A = vec3(-1.071, -1.104, -1.139);
    const vec3 B = vec3(-0.123, -0.125, -0.127);
    const vec3 C = vec3( 0.605,  0.631,  0.661);
    const vec3 D = vec3(-0.082, -0.084, -0.086);
    const vec3 E = vec3( 0.044,  0.047,  0.052);
    const vec3 F = vec3( 0.294,  0.318,  0.347);
    const vec3 G = vec3( 0.021,  0.024,  0.028);
    const vec3 H = vec3( 0.815,  0.832,  0.852);
    const vec3 I = vec3( 0.242,  0.253,  0.265);

    float cosGammaSq = cosGamma * cosGamma;
    vec3 term1 = vec3(1.0) + A * exp(B / max(cosTheta, 0.01));
    vec3 term2 = vec3(1.0) + C * exp(D * gamma_a) + E * cosGammaSq;
    vec3 f     = (term1 * term2) * (G * exp(H * gamma_a) + F * cosGammaSq + I);
    vec3 hw    = clamp(f * 0.012, vec3(0.0), vec3(4.0));

    float dayMask = saturate(sunY * 8.0);
    vec3 result   = mix(skyRadiance * vec3(0.12, 0.15, 0.26), skyRadiance * hw, dayMask);
    float hazeAmt = sqr(1.0 - abs(worldDir.y)) * sunY * 0.6;
    vec3 hazeCol  = mix(vec3(1.0, 0.85, 0.65), vec3(0.8, 0.90, 1.0), saturate(sunY * 2.0));
    result += hazeCol * hazeAmt * 0.15;
    return result;
}
#endif



#if SKYBOX_STYLE == 7
vec3 _ApplyStormyStyle(in vec3 skyRadiance, in vec3 worldDir, in vec3 sunVector) {
    float sunY   = sunVector.y;
    float upness = max0(worldDir.y);

    vec3 stormZenith  = vec3(0.06, 0.07, 0.09);
    vec3 stormHorizon = vec3(0.14, 0.18, 0.12);
    vec3 stormMid     = vec3(0.10, 0.12, 0.10);
    vec3 breakColor   = vec3(0.55, 0.52, 0.38);
    float sunDot   = saturate(dot(worldDir, sunVector));
    float breakAmt = pow(sunDot, 6.0) * saturate(sunY * 3.0) * 0.5;
    vec3 stormColor = mix(stormHorizon, stormZenith, pow(upness, 0.5));
    stormColor = mix(stormColor, stormMid, 0.4);

    float nightMask = saturate(-sunY * 4.0);
    stormColor *= mix(1.0, 0.35, nightMask);

    vec3 result = skyRadiance * stormColor + breakColor * breakAmt * 0.12;
    float lum   = dot(result, vec3(0.2126, 0.7152, 0.0722));
    result = mix(result, vec3(lum) * 0.8, 0.45);
    result *= 0.7;
    return result;
}
#endif



#if SKYBOX_STYLE == 8
vec3 _ApplyAlienStyle(in vec3 skyRadiance, in vec3 worldDir, in vec3 sunVector) {
    float sunY    = sunVector.y;
    float upness  = max0(worldDir.y);
    float horizon = 1.0 - abs(worldDir.y);

    vec3 dayZenith   = vec3(0.10, 0.02, 0.28);
    vec3 dayMid      = vec3(0.30, 0.03, 0.18);
    vec3 dayHorizon  = vec3(0.72, 0.10, 0.06);
    vec3 nightZenith = vec3(0.03, 0.00, 0.10);
    vec3 nightHoriz  = vec3(0.14, 0.01, 0.10);
    vec3 sun2Dir   = normalize(vec3(-sunVector.x, sunVector.y * 0.5, -sunVector.z));
    float sun2DirDot  = saturate(dot(worldDir, sun2Dir));
    float sun2Glow = pow(sun2DirDot, 8.0) * sqr(horizon) * 0.5;

    vec3 dayColor = mix(dayHorizon, dayMid, upness);
    dayColor      = mix(dayColor, dayZenith, upness * upness);

    float sunDot  = saturate(dot(worldDir, vec3(sunVector.x, 0.0, sunVector.z)));
    float sunGlow = sqr(horizon) * pow(sunDot, 4.0) * 0.8;

    vec3 tint;
    if (sunY > 0.0) {
        tint = dayColor;
    } else {
        float t = smoothstep(-0.3, 0.0, sunY);
        vec3 nightColor = mix(nightHoriz, nightZenith, upness);
        tint = mix(nightColor, dayColor, t);
    }

    vec3 result = skyRadiance * tint;
    result += vec3(0.80, 0.08, 0.02) * sunGlow * 0.20 * saturate(sunY + 0.3);
    result += vec3(0.10, 0.15, 0.70) * sun2Glow * 0.10;
    return result;
}
#endif


#if SKYBOX_STYLE == 9
vec3 _ApplyOvercastStyle(in vec3 skyRadiance, in vec3 worldDir, in vec3 sunVector) {
    float sunY_oc    = sunVector.y;
    float upness_oc  = max0(worldDir.y);

    vec3 ocDay   = vec3(0.72, 0.76, 0.80);
    vec3 ocHoriz = vec3(0.62, 0.65, 0.68);
    vec3 ocNight = vec3(0.06, 0.07, 0.10);
    vec3 ocSun   = vec3(0.85, 0.84, 0.80);
    float patchDot = saturate(dot(worldDir, sunVector) * 0.5 + 0.5);
    float patchAmt = pow(patchDot, 8.0) * saturate(sunY_oc * 4.0) * 0.3;
    vec3 dayColor_oc = mix(ocHoriz, ocDay, upness_oc * 0.8 + 0.2);
    dayColor_oc      = mix(dayColor_oc, ocSun, patchAmt);
    float nightMask_oc = saturate(-sunY_oc * 5.0);
    vec3 tint_oc = mix(dayColor_oc, ocNight, nightMask_oc * nightMask_oc);
    float lum_oc  = dot(skyRadiance, vec3(0.2126, 0.7152, 0.0722));
    vec3 desat_oc = mix(skyRadiance, vec3(lum_oc), 0.75);
    return desat_oc * tint_oc * 1.1;
}
#endif


#if SKYBOX_STYLE == 10
vec3 _ApplyRetroChocapicStyle(in vec3 skyRadiance, in vec3 worldDir, in vec3 sunVector) {
    float sunY    = sunVector.y;
    float upness  = max0(worldDir.y);
    float horizon = 1.0 - abs(worldDir.y);

    vec3 dayZenith   = vec3(0.12, 0.35, 0.88);
    vec3 dayHorizon  = vec3(0.88, 0.68, 0.38);
    vec3 sunriseCol  = vec3(1.00, 0.45, 0.10);
    vec3 sunsetCol   = vec3(1.00, 0.38, 0.08);
    vec3 nightZenith = vec3(0.02, 0.04, 0.14);
    vec3 nightHoriz  = vec3(0.06, 0.08, 0.22);

    bool isSunrise = (sunVector.x > 0.0);
    vec3 twilight  = isSunrise ?
        sunriseCol : sunsetCol;
    float sunDot   = saturate(dot(worldDir, vec3(sunVector.x, 0.0, sunVector.z)));
    float glowAmt  = pow(horizon, 1.5) * pow(sunDot, 2.5) * 1.8;
    vec3 dayColor  = mix(dayHorizon, dayZenith, pow(upness, 1.2));
    vec3 tint;
    if (sunY > 0.1) {
        tint = dayColor;
    } else if (sunY > -0.08) {
        float t = smoothstep(-0.08, 0.1, sunY);
        vec3 twilightSky = mix(dayHorizon * 0.7, dayColor * 0.5, upness) + twilight * glowAmt;
        tint = mix(twilightSky, dayColor, t);
    } else {
        float t = smoothstep(-0.28, -0.08, sunY);
        vec3 nightColor = mix(nightHoriz, nightZenith, upness);
        tint = mix(nightColor, mix(dayHorizon * 0.5, dayColor * 0.5, upness) + twilight * glowAmt * t, t);
    }

    vec3 result   = skyRadiance * tint;
    float bigGlow = sqr(horizon) * saturate(dot(worldDir, sunVector) * 0.5 + 0.5);
    result += twilight * bigGlow * 0.25 * saturate(1.0 - abs(sunY) * 3.0);
    float lum = dot(result, vec3(0.2126, 0.7152, 0.0722));
    result    = mix(vec3(lum), result, 1.18);
    return result;
}
#endif



#if SKYBOX_STYLE == 11
vec3 _ApplyHillaireStyle(in vec3 skyRadiance, in vec3 worldDir, in vec3 sunVector) {
    float sunY     = sunVector.y;
    float cosV     = clamp(worldDir.y, -1.0, 1.0);
    float cosG     = clamp(dot(worldDir, sunVector), -1.0, 1.0);

    
    const vec3  betaR = vec3(5.8e-3, 13.5e-3, 33.1e-3);
    // Rayleigh (RGB)
    const float betaM = 21.0e-3;
    // Mie
    const float gMie  = 0.76;
    // Mie asymmetry

  
    float airMass = clamp(1.0 / (0.0001 + abs(cosV) + sqrt(max(0.0, 1.0 - cosV * cosV)) * 0.04),
                          1.0, 40.0);
    vec3  tauR      = betaR * airMass * 8.0;
    float tauM_val  = betaM * airMass * 1.2;
    vec3  transm    = exp(-(tauR + tauM_val));
    float phaseR = 0.75 * (1.0 + cosG * cosG);

    float gg     = gMie * gMie;
    float phaseM = (1.0 - gg) /
                   (4.0 * PI * pow(max(1e-6, 1.0 + gg - 2.0 * gMie * cosG), 1.5));
    float sunMask  = saturate(sunY * 6.0 + 0.5);
    vec3  sunColor = mix(vec3(1.0, 0.50, 0.20),
                         vec3(1.0, 0.97, 0.90),
                         saturate(sunY * 3.0));
    float sunIrr   = sunMask * 20.0;

  
    vec3 scatterR = betaR * phaseR * sunIrr * sunColor;
    vec3 scatterM = vec3(betaM) * phaseM * sunIrr * sunColor * 0.02;
    vec3 ambient = vec3(0.05, 0.10, 0.20) * (0.5 + 0.5 * cosV) * sunMask;
    vec3 inScatter = (scatterR + scatterM + ambient) * transm;
    float hz     = exp(-max(0.0, cosV) * 8.0) * sunMask;
    vec3 hzColor = mix(vec3(0.7, 0.6, 0.5),
                       vec3(0.9, 0.85, 0.75),
                       saturate(sunY)) * hz * 0.6;
    vec3 nightSky = vec3(0.005, 0.008, 0.020) * saturate(-sunY * 3.0);

    return skyRadiance * inScatter + hzColor + nightSky;
}
#endif



#if SKYBOX_STYLE == 12
vec3 _ApplyGreenSkyboxStyle(in vec3 skyRadiance, in vec3 worldDir, in vec3 sunVector) {
    float sunY    = sunVector.y;
    float upness  = max0(worldDir.y);
    float horizon = 1.0 - abs(worldDir.y);

    vec3 gZenith  = vec3(0.00, 0.80, 0.00);
    vec3 gMid     = vec3(0.00, 0.80, 0.00);
    vec3 gHorizon = vec3(0.00, 0.80, 0.00);
    vec3 greenColor = mix(gHorizon, gMid, upness);
    greenColor      = mix(greenColor, gZenith, upness * upness);
    vec3 nightGreen = vec3(0.00, 0.80, 0.00);
    float nightMask = saturate(-sunY * 4.0);
    greenColor      = mix(greenColor, nightGreen, nightMask);

    float sunDot = saturate(dot(worldDir, sunVector) * 0.5 + 0.5);
    float glow   = sqr(horizon) * pow(sunDot, 5.0) * 0.5 * saturate(sunY * 3.0);
    vec3 glowCol = vec3(0.0, 1.0, 0.0);

    return skyRadiance * greenColor + glowCol * glow * 0.15;
}
#endif

// ---- Custom Sky Colors Applier ---------------------------------------------
vec3 ApplyCustomSkyColors(in vec3 skyRadiance, in vec3 sunVector) {
    #if CUSTOM_SKY_COLORS == 1
        float sunY = sunVector.y;
        vec3 tintColor;

        if (sunY > 0.1) {
            // Блент Day -> Noon по мере подъёма солнца к зениту
            float noonBlend = smoothstep(0.1, SKY_COLOR_NOON_HEIGHT, sunY);
            tintColor = mix(
                vec3(SKY_COLOR_DAY_R, SKY_COLOR_DAY_G, SKY_COLOR_DAY_B),
                vec3(SKY_COLOR_NOON_R, SKY_COLOR_NOON_G, SKY_COLOR_NOON_B),
                noonBlend
            );
        } else if (sunY > -0.05) {
            bool isSunrise = (sunVector.x > 0.0);
            vec3 twilightColor = isSunrise
                ?
                vec3(SKY_COLOR_SUNRISE_R, SKY_COLOR_SUNRISE_G, SKY_COLOR_SUNRISE_B)
                : vec3(SKY_COLOR_SUNSET_R,  SKY_COLOR_SUNSET_G,  SKY_COLOR_SUNSET_B);
            float blend = smoothstep(-0.05, 0.1, sunY);
            tintColor = mix(twilightColor, vec3(SKY_COLOR_DAY_R, SKY_COLOR_DAY_G, SKY_COLOR_DAY_B), blend);
        } else {
            bool isSunrise = (sunVector.x > 0.0);
            vec3 twilightColor = isSunrise
                ?
                vec3(SKY_COLOR_SUNRISE_R, SKY_COLOR_SUNRISE_G, SKY_COLOR_SUNRISE_B)
                : vec3(SKY_COLOR_SUNSET_R,  SKY_COLOR_SUNSET_G,  SKY_COLOR_SUNSET_B);
            float blend = smoothstep(-0.2, -0.05, sunY);
            tintColor = mix(vec3(SKY_COLOR_NIGHT_R, SKY_COLOR_NIGHT_G, SKY_COLOR_NIGHT_B), twilightColor, blend);
        }

        return skyRadiance * tintColor;
    #else
        return skyRadiance;
    #endif
}
vec3 _ApplyCubemapColors(in vec3 color, in vec3 sunVector) {
    #if CUBEMAP_COLOR_TINT == 1
        float sunY = sunVector.y;
        vec3 tintColor;

        if (sunY > 0.1) {
            float noonBlend = smoothstep(0.1, SKY_COLOR_NOON_HEIGHT, sunY);
            tintColor = mix(
                vec3(CUBEMAP_COLOR_DAY_R, CUBEMAP_COLOR_DAY_G, CUBEMAP_COLOR_DAY_B),
                vec3(CUBEMAP_COLOR_NOON_R, CUBEMAP_COLOR_NOON_G, CUBEMAP_COLOR_NOON_B),
                noonBlend
            );
        } else if (sunY > -0.05) {
            bool isSunrise = (sunVector.x > 0.0);
            vec3 twilightColor = isSunrise
                ?
                vec3(CUBEMAP_COLOR_SUNRISE_R, CUBEMAP_COLOR_SUNRISE_G, CUBEMAP_COLOR_SUNRISE_B)
                : vec3(CUBEMAP_COLOR_SUNSET_R,  CUBEMAP_COLOR_SUNSET_G,  CUBEMAP_COLOR_SUNSET_B);
            float blend = smoothstep(-0.05, 0.1, sunY);
            tintColor = mix(twilightColor, vec3(CUBEMAP_COLOR_DAY_R, CUBEMAP_COLOR_DAY_G, CUBEMAP_COLOR_DAY_B), blend);
        } else {
            bool isSunrise = (sunVector.x > 0.0);
            vec3 twilightColor = isSunrise
                ?
                vec3(CUBEMAP_COLOR_SUNRISE_R, CUBEMAP_COLOR_SUNRISE_G, CUBEMAP_COLOR_SUNRISE_B)
                : vec3(CUBEMAP_COLOR_SUNSET_R,  CUBEMAP_COLOR_SUNSET_G,  CUBEMAP_COLOR_SUNSET_B);
            float blend = smoothstep(-0.2, -0.05, sunY);
            tintColor = mix(vec3(CUBEMAP_COLOR_NIGHT_R, CUBEMAP_COLOR_NIGHT_G, CUBEMAP_COLOR_NIGHT_B), twilightColor, blend);
        }

        return color * tintColor;
    #else
        return color;
    #endif
}

// ---- Unreal Engine-style procedural sky modifier ---------------------------
#if SKYBOX_STYLE == 1
vec3 _ApplyUESkyStyle(in vec3 skyRadiance, in vec3 worldDir, in vec3 sunVector) {
    float horizon = 1.0 - abs(worldDir.y);
    float zenith  = max0(worldDir.y);

    float zenithFactor = 1.0 - zenith * 0.35 * SKYBOX_UE_ZENITH_DEPTH;
    vec3  zenithTint   = vec3(zenithFactor * 0.88, zenithFactor * 0.94, 1.0);

    float hazeWidth   = 0.18;
    float hazeStrength = saturate(1.0 - abs(worldDir.y) / hazeWidth);
    hazeStrength = sqr(hazeStrength);

    bool  moonlit   = sunVector.y < -0.04;
    vec3  sunColor  = moonlit ? vec3(0.55, 0.65, 0.9) : mix(vec3(1.0, 0.72, 0.45), vec3(0.85, 0.92, 1.0), saturate(sunVector.y * 2.5));
    vec3  hazeTint  = sunColor * hazeStrength * SKYBOX_UE_HAZE * 0.6;
    float sunSide   = saturate(dot(worldDir, vec3(sunVector.x, 0.0, sunVector.z)) * 0.5 + 0.5);
    float sunGlow   = sqr(hazeStrength) * sunSide * 1.2 * SKYBOX_UE_HAZE;
    vec3  glowColor = moonlit ?
        vec3(0.3, 0.4, 0.7) : vec3(1.0, 0.6, 0.25);

    vec3 result = skyRadiance * zenithTint;
    result     += hazeTint  * GetLuminance(skyRadiance + vec3(0.01));
    result     += glowColor * sunGlow * 0.08;

    float lum    = GetLuminance(result);
    result       = mix(result, vec3(lum), 0.12);
    result      *= 1.0 + 0.15 * zenith;

    return result;
}
#endif // SKYBOX_STYLE == 1


vec3 ApplySkyboxPreset(in vec3 skyRadiance, in vec3 worldDir, in vec3 sunVector) {
    // Стили 0-3: используют CUSTOM_SKY_COLORS / CUBEMAP_COLOR_TINT
    // Стили 4-12: независимые встроенные палитры, игнорируют те дефайны

#if SKYBOX_STYLE == 0
    return ApplyCustomSkyColors(skyRadiance, sunVector);
#elif SKYBOX_STYLE == 1
    return _ApplyUESkyStyle(ApplyCustomSkyColors(skyRadiance, sunVector), worldDir, sunVector);
#elif SKYBOX_STYLE == 2
    vec3 c2 = _ApplyCubemapColors(_SampleCubemapCross(shadowcolor0, worldDir), sunVector);
    #if SKYBOX_CUBEMAP_BLEND == 1
        return ApplyCustomSkyColors(skyRadiance, sunVector) + c2;
    #else
        return c2;
    #endif

#elif SKYBOX_STYLE == 3
    vec3 c3 = _ApplyCubemapColors(_SampleCubemapCross(colortex27, worldDir), sunVector);
    #if SKYBOX_CUBEMAP_BLEND == 1
        return ApplyCustomSkyColors(skyRadiance, sunVector) + c3;
    #else
        return c3;
    #endif

#elif SKYBOX_STYLE == 4
    return _ApplySEUSStyle(skyRadiance, worldDir, sunVector);
#elif SKYBOX_STYLE == 5
    return _ApplyBSLStyle(skyRadiance, worldDir, sunVector);
#elif SKYBOX_STYLE == 6
    return _ApplyHosekWilkieStyle(skyRadiance, worldDir, sunVector);
#elif SKYBOX_STYLE == 7
    return _ApplyStormyStyle(skyRadiance, worldDir, sunVector);
#elif SKYBOX_STYLE == 8
    return _ApplyAlienStyle(skyRadiance, worldDir, sunVector);
#elif SKYBOX_STYLE == 9
    return _ApplyOvercastStyle(skyRadiance, worldDir, sunVector);
#elif SKYBOX_STYLE == 10
    return _ApplyRetroChocapicStyle(skyRadiance, worldDir, sunVector);
#elif SKYBOX_STYLE == 11
    return _ApplyHillaireStyle(skyRadiance, worldDir, sunVector);
#elif SKYBOX_STYLE == 12
    return _ApplyGreenSkyboxStyle(skyRadiance, worldDir, sunVector);

#else
    return skyRadiance;
#endif
}


//============================================================================//

// Локальный базис диска солнца, смотрящего на игрока (нужен только для
// кубического стиля SUN_STYLE == 2, чтобы получить квадратную форму вместо
// круглой — по аналогии с луной).
void _SunLocalBasis(in vec3 sunVector, out vec3 forward, out vec3 right, out vec3 up2) {
	forward = sunVector;
	vec3 upHint = (abs(forward.y) > 0.98) ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
	right = normalize(cross(upHint, forward));
	up2   = cross(forward, right);
}

// [1] === КРУГЛОЕ СОЛНЦЕ (SUN_STYLE == 1) ====================================
// Диск солнца строится через угловой радиус (SUN_SIZE): для каждого
// направления взгляда (worldDir) считаем угол до центра солнца (cosTheta / fastAcos),
// и если этот угол больше SUN_SIZE — пиксель вне диска, возвращаем 0.
// centerToEdge (0 в центре, 1 на краю) используется дальше для лимбового затемнения (limb darkening).
vec3 _RenderSunRound(in vec3 worldDir, in vec3 sunVector, in vec3 sunIlluminance) {
    float cosTheta = dot(worldDir, sunVector);
    float centerToEdge = saturate(fastAcos(cosTheta) / SUN_SIZE);
    if (cosTheta < cos(SUN_SIZE)) return vec3(0.0);
    // <-- эта строка "вырезает" круг солнца

	const vec3 alpha = vec3(0.429, 0.522, 0.614);
    vec3 factor = pow(vec3(1.0 - centerToEdge * centerToEdge), alpha * 0.5);
    // затемнение к краю диска
    vec3 finalLuminance = sunIlluminance / coneAngleToSolidAngle(SUN_SIZE) * factor;
    return min(finalLuminance, 1e4);
}

// [2] === КУБИЧЕСКОЕ СОЛНЦЕ (SUN_STYLE == 2) =================================
// Тот же диск, но форма квадратная вместо круглой: проекция worldDir на
// локальный billboard-базис солнца, отсечка по max(|x|,|y|), угловой размер
// задаётся отдельным дефайном SUN_SIZE_SQUARE.
vec3 _RenderSunSquare(in vec3 worldDir, in vec3 sunVector, in vec3 sunIlluminance) {
	vec3 forward, right, up2;
	_SunLocalBasis(sunVector, forward, right, up2);
	float z = dot(worldDir, forward);
	if (z <= 0.0) return vec3(0.0);

	vec2 tc = vec2(dot(worldDir, right), dot(worldDir, up2)) / z;
	float halfSize = tan(SUN_SIZE_SQUARE);
	if (abs(tc.x) > halfSize || abs(tc.y) > halfSize) return vec3(0.0);
    // псевдо centerToEdge (по max(|x|,|y|)) для сохранения лимбового затемнения на квадрате
	vec2 edge = abs(tc) / halfSize;
	float centerToEdgeScalar = max(edge.x, edge.y);
	const vec3 alpha = vec3(0.429, 0.522, 0.614);
	vec3 factor = pow(vec3(1.0 - centerToEdgeScalar * centerToEdgeScalar), alpha * 0.5);
	vec3 finalLuminance = sunIlluminance / coneAngleToSolidAngle(SUN_SIZE_SQUARE) * factor;
    return min(finalLuminance, 1e4);
}

vec3 RenderSun(in vec3 worldDir, in vec3 sunVector) {
	const vec3 sunIlluminance = vec3(1.474000,1.850400,1.911980) * 126.6e3;
    
    #if USE_VANILLA_TEXTURES == 1
        vec3 forward, right, up2;
        _SunLocalBasis(sunVector, forward, right, up2);
        float z = dot(worldDir, forward);
        if (z > 0.0) {
            vec2 tc = vec2(dot(worldDir, right), dot(worldDir, up2)) / z;
            float halfSize = tan(SUN_SIZE_SQUARE);
            if (abs(tc.x) <= halfSize && abs(tc.y) <= halfSize) {
                vec2 screenUV = gl_FragCoord.xy * screenPixelSize;
                vec4 texColor = texture(gtexture, screenUV);
                return texColor.rgb;
            }
        }
        return vec3(0.0);
    #else
        #if SUN_STYLE == 2
            return _RenderSunSquare(worldDir, sunVector, sunIlluminance);
        #else
            return _RenderSunRound(worldDir, sunVector, sunIlluminance);
        #endif
    #endif
}

// [5] === БЛИК (БЛЕСК) ОТ СОЛНЦА ============================================
// Это и есть тот самый "лик"/блик от солнца, который ты искал: увеличенный,
// более мягкий диск солнца (радиус 0.05 рад вместо sun_angular_radius),
// используется как специальный блик/солнечный блеск (например, на воде/льду
// в отражениях), а НЕ настоящий экранный lens flare (лучи, кольца, "зайчики"
// по диагонали экрана).
// Такого классического lens-flare-эффекта (со стрик-лучами
// и ghost-артефактами) в загруженных файлах нет — судя по всему, он либо
// отсутствует в шейдерпаке, либо реализован в файле composite/final, который
// не был загружен.
// Если он тебе нужен — его надо делать отдельно, как
// пост-эффект в composite-проходе поверх готовой картинки.
// [5] === БЛИК (ГАЛО) ВОКРУГ СОЛНЦА =========================================
// Мягкий увеличенный ореол вокруг солнечного диска. Управляется SUN_GLARE_*.
vec3 RenderSunReflection(in vec3 worldDir, in vec3 sunVector) {
	#if SUN_GLARE_ENABLED == 0 || SUN_STYLE == 2
		return vec3(0.0);
	#endif
	const vec3 sunIlluminance = vec3(1.474000,1.850400,1.911980) * 126.6e3;
    float cosTheta = dot(worldDir, sunVector);
    float centerToEdge = saturate(fastAcos(cosTheta) / SUN_GLARE_SIZE);
    if (cosTheta < cos(SUN_GLARE_SIZE)) return vec3(0.0);
    const vec3 alpha = vec3(0.429, 0.522, 0.614);

    vec3 factor = pow(vec3(1.0 - centerToEdge * centerToEdge), alpha * 0.5);
    vec3 finalLuminance = sunIlluminance / coneAngleToSolidAngle(SUN_GLARE_SIZE) * factor;

    return min(finalLuminance, SUN_GLARE_BRIGHTNESS);
}

// === ЛУНА (полностью процедурная, стили 1-4) ================================
// Никаких текстур/colortex — форма и фаза считаются напрямую по геометрии.
//
// Локальный базис диска луны, смотрящего на игрока (нужен только стилям
// 2-4 для квадратной формы и для терминатора; стиль 1 — как и раньше, без
// базиса, поэтому не может стать некруглым ни при каком направлении взгляда).
void _MoonLocalBasis(in vec3 sunVector, out vec3 forward, out vec3 right, out vec3 up2) {
	forward = -sunVector;
    // луна всегда строго напротив солнца
	vec3 upHint = (abs(forward.y) > 0.98) ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
	right = normalize(cross(upHint, forward));
	up2   = cross(forward, right);
}

// Круглая маска диска (стили 1 и 3), без изменений от старого стиля 0.
float _MoonDiscRound(in vec3 worldDir, in vec3 moonVector) {
	float cosTheta = dot(worldDir, moonVector);
	float hardness = 2e2;
	return sqr(curve(saturate((cosTheta - 1.0 + MOON_SIZE) * hardness)));
}

// Квадратная маска диска (стили 2 и 4): проекция worldDir на локальный
// billboard-базис луны, отсечка по max(|x|,|y|) вместо длины вектора —
// даёт ровный квадрат вместо круга, тем же угловым размером MOON_SIZE_SQUARE.
float _MoonDiscSquare(in vec3 worldDir, in vec3 forward, in vec3 right, in vec3 up2) {
	float z = dot(worldDir, forward);
    if (z <= 0.0) return 0.0;

	vec2 tc = vec2(dot(worldDir, right), dot(worldDir, up2)) / z;
	float halfSize = tan(MOON_SIZE_SQUARE);
    vec2 edge = 1.0 - abs(tc) / halfSize;
	float hardness = 2e2;
	return sqr(curve(saturate(min(edge.x, edge.y) * hardness)));
}

// Процедурный терминатор (стили 3 и 4): отсекает часть диска в UV-плоскости
// луны по moonPhase, как настоящая фаза — 0 = полнолуние, 4 = новолуние,
// 1/3 = растущая/убывающая четверть, 2 = полумесяцы.
// Форма терминатора —
// эллипс (косинус), сдвигающийся и переворачивающийся по фазе, как у
// реального серпа луны.
float _MoonPhaseMask(in vec2 tc) {
    // Сдвиг на +4 исправляет инверсию фаз в формуле (теперь 0 = полнолуние, 4 = новолуние)
    float phase01 = fract(float(moonPhase + 4) / 8.0);
    float t = phase01 * TAU;
    float k = cos(t);
    float side = sign(sin(t) + 1e-6);
    float y2 = clamp(tc.y * tc.y, 0.0, 1.0);
    float limbX = sqrt(max(1.0 - y2, 0.0));
    float termX = k * limbX;
    float lit = tc.x * side - termX;
    return smoothstep(-MOON_PHASE_SOFTNESS, MOON_PHASE_SOFTNESS, lit);
}

vec3 RenderMoonReflection(in vec3 worldDir, in vec3 sunVector) {
	vec3 forward, right, up2;
	_MoonLocalBasis(sunVector, forward, right, up2);
    
    #if USE_VANILLA_TEXTURES == 1
        float z = dot(worldDir, forward);
        if (z > 0.0) {
            vec2 tc = vec2(dot(worldDir, right), dot(worldDir, up2)) / z;
            float halfSize = tan(MOON_SIZE_SQUARE);
            if (abs(tc.x) <= halfSize && abs(tc.y) <= halfSize) {
                vec2 screenUV = gl_FragCoord.xy * screenPixelSize;
                vec4 texColor = texture(gtexture, screenUV);
                return texColor.rgb;
            }
        }
        return vec3(0.0);
    #else
        #if MOON_STYLE == 1
            float disc = _MoonDiscRound(worldDir, forward);
        #elif MOON_STYLE == 2
            float disc = _MoonDiscSquare(worldDir, forward, right, up2);
        #elif MOON_STYLE == 3
            float disc = _MoonDiscRound(worldDir, forward);
        #else // MOON_STYLE == 4
            float disc = _MoonDiscSquare(worldDir, forward, right, up2);
        #endif

        if (disc <= 0.0) return vec3(0.0);

        #if MOON_STYLE == 3 || MOON_STYLE == 4
            float z_face = dot(worldDir, forward);
            float dist = 0.0;
            #if MOON_STYLE == 4
                vec2 tc = vec2(dot(worldDir, right), dot(worldDir, up2)) / max(z_face, 1e-6) / tan(MOON_SIZE_SQUARE);
                vec2 pixelatedTc = floor(tc * 4.0) / 4.0 + 0.125;
                float mask = _MoonPhaseMask(pixelatedTc);
                dist = max(abs(tc.x), abs(tc.y));
            #else
                vec2 tc = vec2(dot(worldDir, right), dot(worldDir, up2)) / max(z_face, 1e-6) / tan(MOON_SIZE);
                float mask = _MoonPhaseMask(tc);
                dist = length(tc);
            #endif

            // Плавный ореол на краях луны при затенении
            float corona = smoothstep(0.7, 1.0, dist) * 0.6;
            disc *= mix(corona, 1.0, mask);
        #endif

        return vec3(disc) * MOON_BRIGHTNESS;
    #endif
}

// Маска диска луны — 1 внутри диска, 0 снаружи.
// Нужна, чтобы гасить
// звёзды/starmap там, где уже нарисована луна (фаза здесь не учитывается
// специально: тёмная сторона луны всё равно должна закрывать звёзды).
float GetMoonDiscMask(in vec3 worldDir, in vec3 sunVector) {
	vec3 moonVector = -sunVector;

	#if MOON_STYLE == 1 || MOON_STYLE == 3
		float cosTheta = dot(worldDir, moonVector);
		return step(1.0 - MOON_SIZE, cosTheta);
	#else // MOON_STYLE == 2 || MOON_STYLE == 4
		vec3 forward, right, up2;
		_MoonLocalBasis(sunVector, forward, right, up2);
		float z = dot(worldDir, forward);
        if (z <= 0.0) return 0.0;
		vec2 tc = vec2(dot(worldDir, right), dot(worldDir, up2)) / z;
		float halfSize = tan(MOON_SIZE_SQUARE);
        return step(max(abs(tc.x), abs(tc.y)), halfSize);
	#endif
}

//============================================================================//
// STARMAP PNG 
//============================================================================//

#if STARMAP_ENABLED == 1
vec3 SampleStarmap(in vec3 dir) {
	float angle = radians(STARMAP_ROTATION);
    float cosA  = cos(angle), sinA = sin(angle);
	vec3  rd    = vec3(dir.x * cosA + dir.z * sinA, dir.y, -dir.x * sinA + dir.z * cosA);
    vec2 uv;
	uv.x = atan(-rd.x, -rd.z) * rTAU + 0.5;
	uv.y = fastAcos(rd.y) * rPI;

	float star = texture(colortex25, uv).g;
    return star * vec3(0.85, 0.92, 1.0) * STARMAP_BRIGHTNESS;
}
#endif

vec3 RenderStars(in vec3 worldDir) {
	float userCoverage  = STARS_COVERAGE;
    float userIntensity = STARS_INTENSITY;
	float horizonFade = oneMinus(exp2(-max0(worldDir.y) * 3.0));

	#if STARMAP_ENABLED == 1
		#if STARMAP_MODE == 0
			return SampleStarmap(worldDir) * horizonFade;
        #endif
	#endif

	float cosine = worldSunVector.z;
	vec3 axis = cross(worldSunVector, vec3(0.0, 0.0, 1.0));
	float cosecantSquared = rcp(dotSelf(axis));
    vec3 dir = cosine * worldDir + cross(axis, worldDir) + cosecantSquared * oneMinus(cosine) * dot(axis, worldDir) * axis;
    vec3 proceduralStars = vec3(0.0);

	#if STAR_STYLE == 1
		const float scale    = 350.0;
        const float coverage = 0.045 * userCoverage;
		const float maxLum   = 0.55  * userIntensity;
        vec3  p  = dir * scale;
		ivec3 i  = ivec3(floor(p));
        vec3  f  = p - i;
		float r  = dotSelf(f - 0.5);
        vec3 i3 = fract(i * vec3(443.897, 441.423, 437.195));
		i3 += dot(i3, i3.yzx + 19.19);
        vec2 hash = fract((i3.xx + i3.yz) * i3.zy);

		float cov  = step(oneMinus(coverage), hash.x);
		float disc = smoothstep(0.22, 0.10, r);
        proceduralStars = vec3(maxLum * disc * cov * horizonFade);

	#elif STAR_STYLE == 2
		const float scale          = 256.0;
        const float coverage       = 0.1  * userCoverage;
        const float maxLum         = 0.6  * userIntensity;
        const float bloomRadius    = 0.40;
		const float bloomStrength  = 0.35 * userIntensity;
        const float minTemperature = 4000.0;
		const float maxTemperature = 8000.0;

		vec3  p  = dir * scale;
        ivec3 i  = ivec3(floor(p));
		vec3  f  = p - i;
		float r  = dotSelf(f - 0.5);
        vec3 i3 = fract(i * vec3(443.897, 441.423, 437.195));
		i3 += dot(i3, i3.yzx + 19.19);
        vec2 hash = fract((i3.xx + i3.yz) * i3.zy);
		hash.y = 2.0 * hash.y - 4.0 * hash.y * hash.y + 3.0 * hash.y * hash.y * hash.y;
        float cov   = remap(oneMinus(coverage), 1.0, hash.x);
		float disc  = remap(0.25, 0.0, r);
        float bloom = smoothstep(bloomRadius, 0.0, sqrt(r)) * bloomStrength * cov * cov;
		vec3  color = Blackbody(mix(minTemperature, maxTemperature, hash.y));
        vec3  star  = maxLum * disc * cov * cov * color;
        vec3  halo  = bloom * vec3(1.0);
		proceduralStars = (star + halo) * horizonFade;
    #elif STAR_STYLE == 3
		const float scale          = 180.0;
        const float coverage       = 0.07  * userCoverage;
        const float maxLum         = 1.8   * userIntensity;
        const float haloStrength   = 0.6   * userIntensity;
		const float minTemperature = 5000.0;
        const float maxTemperature = 9000.0;

		vec3  p  = dir * scale;
		ivec3 i  = ivec3(floor(p));
        vec3  f  = p - i;
		float r  = dotSelf(f - 0.5);
		float d  = sqrt(r);
        vec3 i3 = fract(i * vec3(443.897, 441.423, 437.195));
		i3 += dot(i3, i3.yzx + 19.19);
        vec2 hash = fract((i3.xx + i3.yz) * i3.zy);
		hash.y = 2.0 * hash.y - 4.0 * hash.y * hash.y + 3.0 * hash.y * hash.y * hash.y;
        float cov   = remap(oneMinus(coverage), 1.0, hash.x);
		float disc  = remap(0.28, 0.0, r) * cov * cov;
        float halo  = smoothstep(0.60, 0.0, d) * haloStrength * cov;
		vec3  color = mix(Blackbody(mix(minTemperature, maxTemperature, hash.y)), vec3(1.0), 0.3);
        proceduralStars = (disc * maxLum * color + halo * vec3(0.8, 0.85, 1.0)) * horizonFade;
    #else
		const float scale          = 256.0;
        const float coverage       = 0.1  * userCoverage;
        const float maxLum         = 0.6  * userIntensity;
        const float minTemperature = 4000.0;
		const float maxTemperature = 8000.0;

		vec3  p  = dir * scale;
        ivec3 i  = ivec3(floor(p));
		vec3  f  = p - i;
		float r  = dotSelf(f - 0.5);
        vec3 i3 = fract(i * vec3(443.897, 441.423, 437.195));
		i3 += dot(i3, i3.yzx + 19.19);
        vec2 hash = fract((i3.xx + i3.yz) * i3.zy);
		hash.y = 2.0 * hash.y - 4.0 * hash.y * hash.y + 3.0 * hash.y * hash.y * hash.y;
        float cov = remap(oneMinus(coverage), 1.0, hash.x);
		proceduralStars = maxLum * remap(0.25, 0.0, r) * cov * cov * Blackbody(mix(minTemperature, maxTemperature, hash.y)) * horizonFade;
    #endif

	#if STARMAP_ENABLED == 1 && STARMAP_MODE == 1
		proceduralStars += SampleStarmap(worldDir) * horizonFade;
	#endif

	return proceduralStars;
}

vec3 wind2 = vec3(2e-3, 2e-4, 1e-3) * worldTimeCounter * CLOUDMAP_SPEED;
#if CLOUDMAP_ENABLED == 1

// Интегрированный фейдинг по краям слоев как в Complementary
float _CloudMapDensity(vec2 worldXZ, vec2 scroll, float uvScale, float height) {
    vec2 uv = (worldXZ + scroll) * uvScale;
    float rawLuma = GetLuminance(texture(noise, uv).rgb);
    // Плавное затухание по высоте для мягких краев объема
    float profile = sin(height * 3.14159);
    return smoothstep(0.3, 0.7, rawLuma) * profile;
}

float _CloudMapSunlightOD(vec2 cloudPos, vec2 scroll, float uvScale, float stepSize, float startHeight) {
    float od = 0.0;
    vec2  pos = cloudPos;

    for (int s = 0; s < CLOUDMAP_SUNLIGHT_SAMPLES; ++s) {
        float dist = stepSize * float(s + 1) * (1.0 + float(s) * 0.5);
        vec2  samplePos = pos + worldLightVector.xz * dist;
        float h = clamp(startHeight + float(s) * 0.25, 0.0, 1.0);
        od += _CloudMapDensity(samplePos, scroll, uvScale, h);
    }
    return od / float(CLOUDMAP_SUNLIGHT_SAMPLES);
}

float _CloudMapSkylightOD(vec2 cloudPos, vec2 scroll, float uvScale, float stepSize, float startHeight) {
    float od = 0.0;
    vec2  pos = cloudPos;

    for (int s = 0; s < CLOUDMAP_SKYLIGHT_SAMPLES; ++s) {
        float dist = stepSize * float(s + 1) * (1.0 + float(s));
        vec2 samplePos = pos + vec2(dist * 0.3, dist * 0.15);
        float h = clamp(startHeight + float(s) * 0.2, 0.0, 1.0);
        od += _CloudMapDensity(samplePos, scroll, uvScale, h);
}
    return od / float(CLOUDMAP_SKYLIGHT_SAMPLES);
}

vec4 RenderCloudMap(in vec3 worldDir) {
    if (worldDir.y <= 0.005) return vec4(0.0, 0.0, 0.0, 1.0);
    float cloudDist = (CLOUDMAP_ALTITUDE - eyeAltitude) / max(worldDir.y, 0.005);
    float maxDist   = CLOUDMAP_RENDER_DISTANCE / max(worldDir.y, 0.005);
    if (cloudDist > maxDist || cloudDist <= 0.0) return vec4(0.0, 0.0, 0.0, 1.0);
    vec2 cloudPos = worldDir.xz * cloudDist + cameraPosition.xz;
    vec2 scroll   = vec2(wind2.x * 0.6, wind2.z * 0.1);
    float horizonFade = saturate(worldDir.y * 10.0);
    float distFade    = saturate(1.0 - cloudDist / maxDist);
    horizonFade *= distFade;
    bool  moonlit    = worldSunVector.y < -0.04;
    float sunHeight  = saturate(worldSunVector.y * 2.0 + 0.3);
    float sunFade    = saturate(worldLightVector.y * 40.0);
    float LdotV      = dot(worldDir, worldLightVector);
    float cloudForwardG_cm  = 0.6 - wetness * 0.2;
    float cloudBackwardG_cm = -0.4 + wetness * 0.2;
    float cloudPeakWeight_cm = 0.1 + 0.7 * wetness;

    vec4 phases;
    phases.x = HenyeyGreensteinPhase(LdotV, cloudForwardG_cm)         * 0.70
             + HenyeyGreensteinPhase(LdotV, cloudBackwardG_cm)         * 0.25
             + CornetteShanksPhase  (LdotV, 0.9) * cloudPeakWeight_cm;
    phases.y = HenyeyGreensteinPhase(LdotV, cloudForwardG_cm  * 0.7)  * 0.35
             + HenyeyGreensteinPhase(LdotV, cloudBackwardG_cm * 0.7)   * 0.15
             + CornetteShanksPhase  (LdotV, 0.6) * cloudPeakWeight_cm  * 0.5;
    phases.z = HenyeyGreensteinPhase(LdotV, cloudForwardG_cm  * 0.5)  * 0.17
             + HenyeyGreensteinPhase(LdotV, cloudBackwardG_cm * 0.5)   * 0.075
             + CornetteShanksPhase  (LdotV, 0.4) * cloudPeakWeight_cm  * 0.2;
    phases.w = HenyeyGreensteinPhase(LdotV, cloudForwardG_cm  * 0.3)  * 0.08
             + HenyeyGreensteinPhase(LdotV, cloudBackwardG_cm * 0.3)   * 0.05
             + CornetteShanksPhase  (LdotV, 0.2) * cloudPeakWeight_cm  * 0.1;
    vec3 sunTint  = mix(vec3(1.0, 0.55, 0.2), vec3(1.0, 0.98, 0.95), sunHeight);
    vec3 moonTint = vec3(0.22, 0.25, 0.35);
    vec3 litColor = moonlit ? moonTint : sunTint;

    vec3 baseIlluminance = moonlit ? moonIlluminance : (vec3(1.474, 1.8504, 1.91198) * 18.0);
    vec3 localSkyColor   = vec3(0.55, 0.72, 1.0) * 0.28 * skyIlluminance * 0.015;
    float uvScale = 1.0 / (CLOUDMAP_SCALE * 32.0);
    float sunStepSize = CLOUDMAP_SCALE * 3.0;
    float skyStepSize = CLOUDMAP_SCALE * 2.0;
    vec4 result = vec4(0.0, 0.0, 0.0, 1.0);
    
    // Синхронизированный параллакс по слоям вместо семплов
    for (int l = 0; l < CLOUDMAP_LAYERS; ++l) {
        float t = float(l) / max(float(CLOUDMAP_LAYERS - 1), 1.0);
        vec2 parallaxOffset = worldDir.xz * (t * CLOUDMAP_PARALLAX_DEPTH) / max(worldDir.y, 0.05);
        // Используем новую функцию плотности с фейдингом
        float density = _CloudMapDensity(cloudPos + parallaxOffset, scroll, uvScale, t) * CLOUDMAP_DENSITY;
        if (density < 1e-4) continue;
        
        vec2 layerPos = cloudPos + parallaxOffset;
        float sunlightOD = _CloudMapSunlightOD(layerPos, scroll, uvScale, sunStepSize, t);
        float sunlightEnergy  = fastExp(-sunlightOD * 2.0) * phases.x;
        sunlightEnergy       += fastExp(-sunlightOD * 0.8) * phases.y;
        sunlightEnergy       += fastExp(-sunlightOD * 0.3) * phases.z;
        sunlightEnergy       += fastExp(-sunlightOD * 0.1) * phases.w;
        float skylightOD = _CloudMapSkylightOD(layerPos, scroll, uvScale, skyStepSize, t);
        float skylightEnergy = fastExp(-skylightOD) + fastExp(-skylightOD * 0.1) * 0.1;
        float powder = oneMinus(fastExp(-density * 32.0)) * 0.82;
        powder /= max(1.0 - powder, 1e-4);
        float verticalShading = mix(1.0, 0.45, t * CLOUDMAP_VERTICAL_SHADING);
        vec3 layerColor  = baseIlluminance * sunlightEnergy * litColor * sunFade * 22.0;
        layerColor      *= CLOUDMAP_BRIGHTNESS;

        if (moonlit) layerColor = DoNightEye(layerColor * MoonFlux);
        layerColor += skylightEnergy * localSkyColor;
        if (isLightningFlashing > 1e-2)
            layerColor += skylightEnergy * skylightEnergy * lightningColor * 0.1;
        layerColor *= verticalShading;
        layerColor = min(layerColor, vec3(8.0));

        float alpha = saturate(powder * density) * horizonFade;
        result.rgb += layerColor * alpha * result.a;
        result.a   *= oneMinus(alpha);
        if (result.a < 0.01) {
            result.a = 0.0;
            break;
        }
    }

    result.rgb = min(result.rgb, vec3(8.0));
    return vec4(result.rgb, result.a);
}

#endif // CLOUDMAP_ENABLED

vec3 RenderCustomSkybox(vec3 dir) {
    #if SKYBOX_STYLE == 2
        return _SampleCubemapCross(shadowcolor0, dir);
    #elif SKYBOX_STYLE == 3
        return _SampleCubemapCross(colortex27, dir);
    #else
        return vec3(0.0);
    #endif
}

//============================================================================//
// PLANET SYSTEM — 4 PLANETS on colortex 14, 16, 17, 18
//============================================================================//

#define PLANETS_ALL_OFF    0     // [0 1]

vec3 _RenderPlanetGeneric(in vec3 worldDir, in vec3 sunVector,
    sampler2D tex, float rotX, float rotY, float rotZ,
    float size, float bright) {

	#if PLANETS_IN_REFLECTIONS == 0 && defined(UNDER_REFLECTION_PASS)
		return vec3(0.0);
    #endif

    mat3 rot = _rotPlanet(rotX, rotY, rotZ);
    vec3 rDir = rot * worldDir;
    if (rDir.z <= 0.0) return vec3(0.0);

    vec2 tc = (rDir.xy / rDir.z) / vec2(size, size);
    if (tc.x < -1.0 || tc.x > 1.0 || tc.y < -1.0 || tc.y > 1.0) return vec3(0.0);
    vec2 uv = vec2(0.5) + tc * 0.5;
    vec4 planet = texture(tex, uv);

    if (planet.a < 0.01) return vec3(0.0);
    vec3 finalPlanet = planet.rgb * bright;

    return finalPlanet * planet.a;
}

vec3 RenderPlanet1(in vec3 worldDir, in vec3 sunVector) {
    #if PLANETS_ALL_OFF == 1
        return vec3(0.0);
    #endif
    #if PLANET1_ENABLED == 1
        return _RenderPlanetGeneric(worldDir, sunVector,
            colortex14, PLANET1_ROTX, PLANET1_ROTY, PLANET1_ROTZ,
            PLANET1_SIZE, PLANET1_BRIGHTNESS);
    #else
        return vec3(0.0);
    #endif
}

vec3 RenderPlanet2Sky(in vec3 worldDir, in vec3 sunVector) {
    #if PLANETS_ALL_OFF == 1
        return vec3(0.0);
    #endif
    #if PLANET2_ENABLED == 1
        return _RenderPlanetGeneric(worldDir, sunVector,
            colortex16, PLANET2_ROTX, PLANET2_ROTY, PLANET2_ROTZ,
            PLANET2_SIZE, PLANET2_BRIGHTNESS);
    #else
        return vec3(0.0);
    #endif
}

vec3 RenderPlanet3(in vec3 worldDir, in vec3 sunVector) {
    #if PLANETS_ALL_OFF == 1
        return vec3(0.0);
    #endif
    #if PLANET3_ENABLED == 1
        return _RenderPlanetGeneric(worldDir, sunVector,
            colortex17, PLANET3_ROTX, PLANET3_ROTY, PLANET3_ROTZ,
            PLANET3_SIZE, PLANET3_BRIGHTNESS);
    #else
        return vec3(0.0);
    #endif
}

vec3 RenderPlanet4(in vec3 worldDir, in vec3 sunVector) {
    #if PLANETS_ALL_OFF == 1
        return vec3(0.0);
    #endif
    #if PLANET4_ENABLED == 1
        return _RenderPlanetGeneric(worldDir, sunVector,
            colortex18, PLANET4_ROTX, PLANET4_ROTY, PLANET4_ROTZ,
            PLANET4_SIZE, PLANET4_BRIGHTNESS);
    #else
        return vec3(0.0);
    #endif
}