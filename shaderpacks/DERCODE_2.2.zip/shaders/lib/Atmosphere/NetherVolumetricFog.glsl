
#define NETHER_VOL_FOG_SAMPLES   32     // [8 16 24 32 48 64] Шагов рейкаста
#define NETHER_VOL_FOG_MAX_DIST  96.0   // [32.0 48.0 64.0 96.0 128.0 160.0] Дальность


#define NETHER_CLOUD_DENSITY     2.5    // [0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0] 
#define NETHER_CLOUD_CUTOFF      0.30   // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45] 
#define NETHER_CLOUD_OPACITY     1.0    // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] 
#define NETHER_CLOUD_SCATTER     2.0    // [0.5 1.0 1.5 2.0 2.5 3.0 4.0] 


#define NETHER_RISE_SPEED        0.04   // [0.0 0.01 0.02 0.03 0.04 0.05 0.07 0.10] 



#define NETHER_SWAY_SPEED        0.18   // [0.0 0.05 0.10 0.15 0.18 0.20 0.25 0.30] 
#define NETHER_SWAY_AMOUNT       0.80   // [0.0 0.2 0.4 0.6 0.8 1.0 1.5 2.0]


#define NETHER_TURB_SPEED        0.22   // [0.0 0.05 0.10 0.15 0.20 0.22 0.25 0.30 0.40] 
#define NETHER_TURB_SCALE        0.55   // [0.1 0.2 0.3 0.4 0.5 0.55 0.6 0.7 0.8 1.0]


#define NETHER_DRIFT_SPEED       0.03   // [0.0 0.01 0.02 0.03 0.05 0.07 0.10] 
#define NETHER_DRIFT_DIR_X       1.0    // [-2.0 -1.0 -0.5 0.0 0.5 1.0 2.0] 
#define NETHER_DRIFT_DIR_Z       0.3    // [-2.0 -1.0 -0.5 0.0 0.5 1.0 2.0] 


#define NETHER_BORDER_FOG        1      // [0 1] 
#define NETHER_BORDER_FOG_START  0.55   // [0.3 0.4 0.5 0.55 0.6 0.65 0.7 0.75 0.8] 
#define NETHER_BORDER_FOG_END    0.95   // [0.7 0.75 0.8 0.85 0.90 0.95 1.0]
#define NETHER_BORDER_FOG_VERT   0.35   // [0.0 0.1 0.2 0.3 0.35 0.4 0.5] 


#define NW_FOG_DENSITY   0.030 // [0.005 0.010 0.015 0.020 0.025 0.030 0.035 0.040 0.050 0.060 0.080 0.100]
#define NW_FOG_SPEED     1.00 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0]
#define NW_FOG_MIN_H    15.0 // [0.0 5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0]
#define NW_FOG_MAX_H   115.0 // [60.0 70.0 80.0 90.0 100.0 110.0 115.0 120.0 130.0 140.0 150.0]
#define NW_FOG_COLOR_R   0.095 // [0.0 0.05 0.095 0.1 0.15 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define NW_FOG_COLOR_G   0.022 // [0.0 0.022 0.05 0.1 0.15 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define NW_FOG_COLOR_B   0.03 // [0.0 0.03 0.05 0.1 0.15 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// --- Warped Forest ---
#define WF_FOG_DENSITY   0.040 // [0.005 0.010 0.015 0.020 0.025 0.030 0.035 0.040 0.050 0.060 0.080 0.100]
#define WF_FOG_SPEED     0.75 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0]
#define WF_FOG_MIN_H    20.0 // [0.0 5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0]
#define WF_FOG_MAX_H   110.0 // [60.0 70.0 80.0 90.0 100.0 110.0 115.0 120.0 130.0 140.0 150.0]
#define WF_FOG_COLOR_R   0.04 // [0.0 0.04 0.05 0.1 0.15 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define WF_FOG_COLOR_G   0.55 // [0.0 0.1 0.2 0.3 0.4 0.5 0.55 0.6 0.7 0.8 0.9 1.0]
#define WF_FOG_COLOR_B   0.72 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.72 0.8 0.9 1.0]

// --- Crimson Forest ---
#define CF_FOG_DENSITY   0.045 // [0.005 0.010 0.015 0.020 0.025 0.030 0.035 0.040 0.045 0.050 0.060 0.080 0.100]
#define CF_FOG_SPEED     1.25 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0]
#define CF_FOG_MIN_H    20.0 // [0.0 5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0]
#define CF_FOG_MAX_H   105.0 // [60.0 70.0 80.0 90.0 100.0 105.0 110.0 120.0 130.0 140.0 150.0]
#define CF_FOG_COLOR_R   0.90 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define CF_FOG_COLOR_G   0.10 // [0.0 0.05 0.10 0.15 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define CF_FOG_COLOR_B   0.05 // [0.0 0.05 0.1 0.15 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// --- Soul Sand Valley ---
#define SS_FOG_DENSITY   0.035 // [0.005 0.010 0.015 0.020 0.025 0.030 0.035 0.040 0.050 0.060 0.080 0.100]
#define SS_FOG_SPEED     0.85 // [0.0 0.25 0.5 0.75 0.85 1.0 1.25 1.5 1.75 2.0 2.5 3.0]
#define SS_FOG_MIN_H    10.0 // [0.0 5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0]
#define SS_FOG_MAX_H   100.0 // [60.0 70.0 80.0 90.0 100.0 110.0 120.0 130.0 140.0 150.0]
#define SS_FOG_COLOR_R   0.05 // [0.0 0.05 0.1 0.15 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define SS_FOG_COLOR_G   0.20 // [0.0 0.1 0.15 0.20 0.25 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define SS_FOG_COLOR_B   0.70 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.70 0.8 0.9 1.0]

// --- Basalt Deltas ---
#define BD_FOG_DENSITY   0.032 // [0.005 0.010 0.015 0.020 0.025 0.030 0.032 0.040 0.050 0.060 0.080 0.100]
#define BD_FOG_SPEED     1.10 // [0.0 0.25 0.5 0.75 1.0 1.10 1.25 1.5 1.75 2.0 2.5 3.0]
#define BD_FOG_MIN_H    25.0 // [0.0 5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0]
#define BD_FOG_MAX_H   115.0 // [60.0 70.0 80.0 90.0 100.0 110.0 115.0 120.0 130.0 140.0 150.0]
#define BD_FOG_COLOR_R   0.32 // [0.0 0.1 0.2 0.3 0.32 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BD_FOG_COLOR_G   0.28 // [0.0 0.1 0.2 0.28 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BD_FOG_COLOR_B   0.35 // [0.0 0.1 0.2 0.3 0.35 0.4 0.5 0.6 0.7 0.8 0.9 1.0]



float _NetherNoise3D(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    vec2 uv1 = i.xz + f.xz + vec2(37.0, 17.0) *  i.y;
    vec2 uv2 = i.xz + f.xz + vec2(37.0, 17.0) * (i.y + 1.0);
    return mix(texture(noisetex, (uv1 + 0.5) / 256.0).a,
               texture(noisetex, (uv2 + 0.5) / 256.0).a, f.y);
}


float _NetherCloudNoise(vec3 absWorldPos, float speedMult) {
    float t = frameTimeCounter;

  
    vec3 rise = vec3(0.0, -t * NETHER_RISE_SPEED * speedMult, 0.0);


    float swayPhase = t * NETHER_SWAY_SPEED * speedMult;
    vec3 sway = vec3(sin(swayPhase) * NETHER_SWAY_AMOUNT,
                     0.0,
                     cos(swayPhase * 0.7) * NETHER_SWAY_AMOUNT * 0.4);


    vec3 drift = vec3(NETHER_DRIFT_DIR_X, 0.0, NETHER_DRIFT_DIR_Z)
               * t * NETHER_DRIFT_SPEED * speedMult;


    vec3 p0 = absWorldPos * 0.030 + rise + drift + sway * 0.5;

    vec3 p1 = absWorldPos * 0.065 + rise * 1.4 + drift * 1.2
            + sway * vec3(0.8, 0.3, 0.6);


    vec3 turbOffset = vec3(
        sin(t * NETHER_TURB_SPEED * speedMult * 1.3) * 0.5,
        cos(t * NETHER_TURB_SPEED * speedMult * 0.9) * 0.5,
        sin(t * NETHER_TURB_SPEED * speedMult * 1.7 + 1.2) * 0.5
    );
    vec3 p2 = absWorldPos * (0.12 * NETHER_TURB_SCALE)
            + rise * 1.8 + drift * 0.6
            + turbOffset * NETHER_SWAY_AMOUNT * 0.3;

    return _NetherNoise3D(p0) * 0.55
         + _NetherNoise3D(p1) * 0.30
         + _NetherNoise3D(p2) * 0.15;
}


float _NetherCloudDensity(vec3 absWorldPos, float speedMult, float minH, float maxH) {
    float hm = smoothstep(minH, minH + 12.0, absWorldPos.y)
             * smoothstep(maxH, maxH - 12.0, absWorldPos.y);
    if (hm < 1e-4) return 0.0;

    float noise = _NetherCloudNoise(absWorldPos, speedMult);
    float raw   = saturate((noise - NETHER_CLOUD_CUTOFF) * NETHER_CLOUD_DENSITY);

    return raw * hm * NETHER_CLOUD_OPACITY;
}

#if defined IS_NETHER

vec4 CalculateNetherVolumetricFog(in vec3 worldPos, in vec3 worldDir, in float dither) {
    float nwF = BiomeNetherWastesSmooth;
    float wfF = BiomeWarpedForestSmooth;
    float cfF = BiomeCrimsonForestSmooth;
    float ssF = BiomeSoulSandValleySmooth;
    float bdF = BiomeBasaltDeltasSmooth;

    if (nwF + wfF + cfF + ssF + bdF < 0.01) return vec4(0.0, 0.0, 0.0, 1.0);

    float maxDist    = min(NETHER_VOL_FOG_MAX_DIST, length(worldPos));
    uint  steps      = uint(NETHER_VOL_FOG_SAMPLES);
    float stepLength = maxDist / float(steps);

    float LdotV = dot(worldLightVector, worldDir);
    float phase  = HenyeyGreensteinPhase(LdotV, 0.15) * 0.5 + 0.5;

    vec3 colNW = vec3(NW_FOG_COLOR_R, NW_FOG_COLOR_G, NW_FOG_COLOR_B);
    vec3 colWF = vec3(WF_FOG_COLOR_R, WF_FOG_COLOR_G, WF_FOG_COLOR_B);
    vec3 colCF = vec3(CF_FOG_COLOR_R, CF_FOG_COLOR_G, CF_FOG_COLOR_B);
    vec3 colSS = vec3(SS_FOG_COLOR_R, SS_FOG_COLOR_G, SS_FOG_COLOR_B);
    vec3 colBD = vec3(BD_FOG_COLOR_R, BD_FOG_COLOR_G, BD_FOG_COLOR_B);

    vec3 baseLight = ambientColor * 1.8 + blocklightColor * 0.2;

    vec3 rayStep = worldDir * stepLength;
    vec3 rayPos  = cameraPosition + rayStep * dither;

    vec3  totalScatter  = vec3(0.0);
    float transmittance = 1.0;

    for (uint i = 0u; i < steps; ++i, rayPos += rayStep) {
        if (transmittance < 1e-3) break;

        float dens = 0.0;
        vec3  wCol = vec3(0.0);
        float wSum = 0.0;

        #define ADD_BIOME(factor, speedMult, minH, maxH, density, col) \
            if ((factor) > 0.01) { \
                float _d = _NetherCloudDensity(rayPos, speedMult, minH, maxH) * (density) * (factor); \
                dens += _d; wCol += (col) * _d; wSum += _d; \
            }

        ADD_BIOME(nwF, NW_FOG_SPEED, NW_FOG_MIN_H, NW_FOG_MAX_H, NW_FOG_DENSITY, colNW)
        ADD_BIOME(wfF, WF_FOG_SPEED, WF_FOG_MIN_H, WF_FOG_MAX_H, WF_FOG_DENSITY, colWF)
        ADD_BIOME(cfF, CF_FOG_SPEED, CF_FOG_MIN_H, CF_FOG_MAX_H, CF_FOG_DENSITY, colCF)
        ADD_BIOME(ssF, SS_FOG_SPEED, SS_FOG_MIN_H, SS_FOG_MAX_H, SS_FOG_DENSITY, colSS)
        ADD_BIOME(bdF, BD_FOG_SPEED, BD_FOG_MIN_H, BD_FOG_MAX_H, BD_FOG_DENSITY, colBD)

        #undef ADD_BIOME

        if (dens < 1e-5) continue;

        vec3  fogColor = (wSum > 1e-5) ? (wCol / wSum) : vec3(0.5);
        float sd       = dens * stepLength;
        float stepTr   = fastExp(-sd * NETHER_CLOUD_SCATTER);
        float fogSamp  = transmittance * (1.0 - stepTr);

        totalScatter  += baseLight * phase * fogSamp * fogColor;
        transmittance *= stepTr;
    }

    return vec4(totalScatter, transmittance);
}

// ── Border fog ───────────────────────────────────────────────────────────────
#if NETHER_BORDER_FOG == 1
void ApplyNetherBorderFog(inout vec3 color, in vec3 worldPos, in vec3 worldDir) {
    vec3 fogCol = vec3(0.99, 0.23, 0.03)   * BiomeNetherWastesSmooth
                + vec3(0.04, 0.24, 0.20)   * BiomeWarpedForestSmooth
                + vec3(0.30, 0.03, 0.01)   * BiomeCrimsonForestSmooth
                + vec3(0.012, 0.055, 0.06) * BiomeSoulSandValleySmooth
                + vec3(0.50, 0.50, 0.50)   * BiomeBasaltDeltasSmooth;
    fogCol = mix(fogCol, vec3(0.5, 0.1, 0.02), 0.3);

    float horizDist = length(worldPos.xz);
    float distNorm  = horizDist / far;

    float horizFog  = smoothstep(NETHER_BORDER_FOG_START, NETHER_BORDER_FOG_END, distNorm);

    float vertMask  = oneMinus(saturate(abs(worldDir.y) * (1.0 / NETHER_BORDER_FOG_VERT)));
    vertMask = vertMask * vertMask;

    float density = horizFog * (0.6 + vertMask * 0.4);

    vec3 scatterColor = fogCol * (oneMinus(exp2(-NetherFogColor() * 4.0)) * 0.6 + 0.4);
    color = mix(color, scatterColor, density);
}
#endif

#else
vec4 CalculateNetherVolumetricFog(in vec3 worldPos, in vec3 worldDir, in float dither) {
    return vec4(0.0, 0.0, 0.0, 1.0);
}
#if NETHER_BORDER_FOG == 1
void ApplyNetherBorderFog(inout vec3 color, in vec3 worldPos, in vec3 worldDir) {}
#endif
#endif
