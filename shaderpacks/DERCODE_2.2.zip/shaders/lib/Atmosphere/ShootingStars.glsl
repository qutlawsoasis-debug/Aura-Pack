//----// SHOOTING STARS (падающие звёзды) //--------------------------------------------------------//
// Портировано из исходного шейдера. Оригинал работал с viewPos, здесь используется
// уже посчитанное направление worldDir (нормализованный мировой вектор взгляда).

#ifndef NUM_SHOOTING_STARS
	#define NUM_SHOOTING_STARS 5 // [1 2 3 4 5]
#endif
#ifndef SPEED_SHOOTING
	#define SPEED_SHOOTING 8.0 // [2.0 3.0 4.0 5.0 6.0 8.0 10.0 15.0 20.0 30.0]
#endif
#ifndef SHOW_DELAY
	#define SHOW_DELAY 0.05 // [0.01 0.02 0.03 0.05 0.07 0.1 0.15 0.2 0.3]
#endif
#ifndef STAR_THICKNESS
	#define STAR_THICKNESS 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#endif
#ifndef SHOOTING_STARS_FADE
	#define SHOOTING_STARS_FADE 3.0 // [1.0 2.0 3.0 4.0 5.0 6.0 8.0 10.0]
#endif
#ifndef SHOOTING_INTENSITY
	#define SHOOTING_INTENSITY 1.0 // [0.2 0.5 1.0 1.5 2.0 3.0 5.0]
#endif

vec3 DrawShootingStar(vec3 color, vec3 worldDir, float variation, float dither) {
	float frameShootingStar = frameTimeCounter / SPEED_SHOOTING;

	float visibility = starsMoonVisibility * (1.0 - starsRainFactor);

	// ИСПРАВЛЕНО: visibility == 0 днём — звёзд тогда быть не должно, но если
	// видимость нулевая, выходим сразу, чтобы не тратить выборки текстур.
	if (visibility <= 0.0) {
		return color;
	}

	float sectorTime = mod(frameShootingStar, 1.0);

	float limit1 = 49.0 * variation;
	float limit2 = 69.0 * variation;

	// ИСПРАВЛЕНО: индекс кадра берём от целой части времени конкретного "слота",
	// раньше floor(frameShootingStar) почти не менялся в пределах слота —
	// из-за этого время1/время2 обновлялись слишком редко и условие
	// "isShooting < SHOW_DELAY" почти никогда не выполнялось.
	float seedIndex = floor(frameShootingStar);

	float time1 = mod(seedIndex, limit1) / limit1;
	float time2 = mod(seedIndex, limit2) / limit2;

	vec3 worldPos = normalize(worldDir);

	vec3 starPos1Start = texture(noisetex, vec2(time1, time2)).rgb;
	starPos1Start.xz = (starPos1Start.xz * 2.0) - 1.0;
	starPos1Start.y = (starPos1Start.y * 0.9) + 0.1;

	vec3 starPos2Start = texture(noisetex, vec2(1.0 - time1, 1.0 - time2)).rgb;
	starPos2Start.xz = (starPos2Start.xz * 2.0) - 1.0;
	starPos2Start.y = (starPos2Start.y * 0.9) + 0.1;

	// ИСПРАВЛЕНО: координаты выборки для "флага запуска звезды" теперь зависят
	// от seedIndex, а не от time1/time2 (которые при старой схеме почти
	// не менялись), иначе isShooting "застывает" и звезда либо всегда есть,
	// либо никогда не появляется.
	float isShooting = texture(noisetex, vec2(fract(seedIndex * 0.013), fract(seedIndex * 0.071))).r;

	starPos1Start = normalize(starPos1Start);
	starPos2Start = normalize(starPos2Start);

	if (length(starPos1Start - starPos2Start) > 0.7 && isShooting < SHOW_DELAY) {
		vec3 starPos1;
		vec3 starPos2;

		if (sectorTime < 0.5) {
			starPos1 = mix(starPos2Start, starPos1Start, sectorTime * 2.0);
			starPos2 = starPos2Start;
		} else {
			starPos1 = starPos1Start;
			starPos2 = mix(starPos1Start, starPos2Start, (1.0 - sectorTime) * 2.0);
		}

		starPos1 = normalize(starPos1);
		starPos2 = normalize(starPos2);

		float starThickness = STAR_THICKNESS * 0.01;

		float length1 = length(starPos1 - worldPos);
		float length2 = length(starPos2 - worldPos);
		float length3 = length(starPos1 - starPos2);

		if (length3 < starThickness) {
			length3 = starThickness;
		}

		vec3 crossProduct = normalize(cross(starPos1, starPos2));
		float dist = abs(dot(worldPos, crossProduct));

		if ((dist < starThickness && length3 > length1 && length3 > length2) || length1 < starThickness) {
			float t1 = 1.0 - (dist / starThickness);
			float t2 = 1.0 - (length1 / length3);
			t2 = pow(clamp(t2, 0.0, 1.0), SHOOTING_STARS_FADE);
			float t = t1 * t2 * dither;

			float fade = clamp((1.0 - sectorTime), 0.0, 1.0);
			fade = clamp(pow(fade, 30.0) * 700.0, 0.0, 1.0);

			color = clamp(mix(color, vec3(SHOOTING_INTENSITY) * 30.0 * visibility, t * fade), 0.0, 1.0);
		}
	}

	return color;
}
