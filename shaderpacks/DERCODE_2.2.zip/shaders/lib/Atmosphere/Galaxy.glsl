// ============================================================
//NO WORK
// ============================================================

#ifndef GALAXY_GLSL
#define GALAXY_GLSL

// ===== GALAXY SETTINGS =====
#define GALAXY_ENABLED 1             // [0 1]
#define GALAXY_MODE    1             // [0 1]   0=procedural  1=texture

// Яркость и цвет
#define GALAXY_BRIGHTNESS    1.0     // [0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define GALAXY_COLOR_R       0.55    // [0.0 0.1 0.2 0.3 0.4 0.5 0.55 0.6 0.7 0.8 0.9 1.0]
#define GALAXY_COLOR_G       0.65    // [0.0 0.1 0.2 0.3 0.4 0.5 0.55 0.6 0.7 0.8 0.9 1.0]
#define GALAXY_COLOR_B       1.0     // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Форма рукавов
#define GALAXY_ARM_COUNT     2.0     // [1.0 2.0 3.0 4.0 5.0 6.0]
#define GALAXY_ARM_TWIST     2.8     // [0.5 1.0 1.5 2.0 2.5 2.8 3.0 4.0 5.0]
#define GALAXY_ARM_WIDTH     0.18    // [0.05 0.08 0.1 0.12 0.15 0.18 0.2 0.25 0.3]
#define GALAXY_CORE_SIZE     0.18    // [0.05 0.08 0.1 0.12 0.15 0.18 0.2 0.25 0.3]
#define GALAXY_DISC_RADIUS   0.42    // [0.1 0.2 0.25 0.3 0.35 0.4 0.42 0.45 0.5 0.6]

// Наклон и ориентация галактики в небе (градусы)
#define GALAXY_ROTX  28.0   // [0 10 15 20 25 28 30 35 40 45 60 75 90 120 150 180]
#define GALAXY_ROTY   0.0   // [0 10 15 20 25 30 35 40 45 60 75 90 120 150 180]
#define GALAXY_ROTZ  70.0   // [0 10 15 20 25 30 35 40 45 60 75 90 120 150 180]

// Плоскость диска (толщина — чем меньше, тем тоньше полоса)
#define GALAXY_DISC_THICKNESS 0.06   // [0.02 0.04 0.06 0.08 0.1 0.12 0.15 0.2]

// Детальность шума (только GALAXY_MODE 0)
#define GALAXY_NOISE_SCALE   4.2     // [1.0 2.0 3.0 4.0 4.2 5.0 6.0 8.0]
#define GALAXY_NOISE_OCTAVES 3       // [1 2 3 4]

// Скорость медленного вращения (анимация)
#define GALAXY_ROTATION_SPEED 0.002  // [0.0 0.001 0.002 0.005 0.01]

// Пыльные тёмные полосы
#define GALAXY_DUST_STRENGTH  0.45   // [0.0 0.1 0.2 0.3 0.4 0.45 0.5 0.6 0.8]

// ============================================================

const vec3 GALAXY_BaseColor = vec3(GALAXY_COLOR_R, GALAXY_COLOR_G, GALAXY_COLOR_B);

// ------ shared helpers --------------------------------------

mat3 GAL_RotMat(vec3 deg) {
    vec3 a = radians(deg);
    float cx = cos(a.x), sx = sin(a.x);
    float cy = cos(a.y), sy = sin(a.y);
    float cz = cos(a.z), sz = sin(a.z);
    mat3 Rx = mat3(1,0,0, 0,cx,-sx, 0,sx,cx);
    mat3 Ry = mat3(cy,0,sy, 0,1,0,-sy,0,cy);
    mat3 Rz = mat3(cz,-sz,0, sz,cz,0, 0,0,1);
    return Rz * Ry * Rx;
}

// Быстрый hash для звёзд галактики
float GAL_hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

// Базовая fbm (шум) через noisetex — тот же подход что BH_noise
float GAL_noise(vec3 p) {
    vec3 fl = floor(p), fr = fract(p);
    fr = fr * fr * (3.0 - 2.0 * fr);
    vec2 uv = (fl.xy + vec2(37.0, 17.0) * fl.z) + fr.xy;
    vec2 rg = textureLod(noisetex, (uv + 0.5) / 256.0, 0.0).yx;
    return mix(rg.x, rg.y, fr.z);
}

float GAL_fbm(vec3 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < GALAXY_NOISE_OCTAVES; i++) {
        v += a * GAL_noise(p);
        p  = p * 2.1 + vec3(5.3, 1.7, 2.9);
        a *= 0.5;
    }
    return v;
}

// Форма рукава: возвращает [0..1] плотность рукавов
float GAL_ArmDensity(vec2 uv, float r) {
    float phi   = atan(uv.y, uv.x);
    float twist = GALAXY_ARM_TWIST * (1.0 - r);             // рукава скручиваются к центру
    float arms  = cos(phi * GALAXY_ARM_COUNT - twist) * 0.5 + 0.5;
    float radialFade = smoothstep(GALAXY_DISC_RADIUS, 0.0, r)
                     * smoothstep(0.0, 0.04, r);             // исчезает в центре и у края
    return pow(arms, 3.0) * radialFade;
}

// ------ MODE 0: Процедурная галактика ----------------------

vec3 GAL_Procedural(vec3 dir) {
    // dir уже в локальном пространстве галактики
    // Плоскость галактики — XZ, dir.y = расстояние над/под диском
    float discFade = exp(-abs(dir.y) / GALAXY_DISC_THICKNESS);
    if (discFade < 0.001) return vec3(0.0);

    vec2 uv = dir.xz;                        // проекция на плоскость диска
    float r  = length(uv);

    if (r > GALAXY_DISC_RADIUS + 0.05) return vec3(0.0);

    // Медленное вращение
    float angle = frameTimeCounter * GALAXY_ROTATION_SPEED;
    float ca = cos(angle), sa = sin(angle);
    uv = vec2(ca * uv.x - sa * uv.y,
              sa * uv.x + ca * uv.y);

    // Шум для структуры облаков
    vec3 noisePos = vec3(uv * GALAXY_NOISE_SCALE, frameTimeCounter * 0.001);
    float noise   = GAL_fbm(noisePos);

    // Рукава
    float arms    = GAL_ArmDensity(uv, r);

    // Ядро — яркое пятно в центре
    float core    = exp(-r * r / (GALAXY_CORE_SIZE * GALAXY_CORE_SIZE)) * 2.5;

    // Пыльные тёмные полосы (второй слой шума, противофаза)
    float dust    = GAL_fbm(noisePos * 1.7 + 3.0) * GALAXY_DUST_STRENGTH;

    float density = (arms * (noise * 0.6 + 0.4) + core) * discFade;
    density       = saturate(density - dust * (1.0 - core));

    // Цвет: ядро горячее (белый-оранжевый), рукава синеватые
    vec3 coreColor = vec3(1.6, 1.2, 0.9);
    vec3 armColor  = GALAXY_BaseColor * 1.4;
    vec3 color     = mix(armColor, coreColor, saturate(core * 0.5)) * density;

    return color * GALAXY_BRIGHTNESS;
}

// ------ MODE 1: Текстурная галактика -----------------------
//
// colortex25 = texture/bhnoise2.png
// Ожидается: серая текстура шума, которую мы интерпретируем
// как облачность галактики в сферических координатах.
// Это позволяет использовать ручную нарисованную текстуру
// вместо полностью процедурного шума.



vec3 GAL_Texture(vec3 dir) {
#if GALAXY_MODE == 1
    float discFade = exp(-abs(dir.y) / GALAXY_DISC_THICKNESS);
    if (discFade < 0.001) return vec3(0.0);

    vec2 uv = dir.xz;
    float r  = length(uv);
    if (r > GALAXY_DISC_RADIUS + 0.05) return vec3(0.0);

    // Сферические UV для текстуры
    float phi   = atan(dir.z, dir.x) / (2.0 * PI) + 0.5;
    float theta = acos(clamp(dir.y, -1.0, 1.0)) / PI;

    // Медленное вращение текстуры
    float rot = frameTimeCounter * GALAXY_ROTATION_SPEED;
    phi = fract(phi + rot);

    // Два слоя текстуры с разным масштабом — даёт ощущение глубины
    vec2 uvA = vec2(phi, theta);
    vec2 uvB = vec2(phi * 2.0 + 0.13, theta * 1.8 + 0.07);

    float sampleA = textureLod(colortex25, uvA, 0.0).r;
    float sampleB = textureLod(colortex25, uvB, 1.0).r * 0.5;

    float texDensity = saturate(sampleA * 0.7 + sampleB * 0.3);

    // Форма рукавов поверх текстуры
    float arms = GAL_ArmDensity(uv, r);
    float core = exp(-r * r / (GALAXY_CORE_SIZE * GALAXY_CORE_SIZE)) * 2.5;

    // Пыльные тёмные полосы из того же noisetex
    vec3 noisePos = vec3(uv * 3.0, 0.0);
    float dust    = GAL_noise(noisePos) * GALAXY_DUST_STRENGTH;

    float density = (texDensity * arms + core) * discFade;
    density       = saturate(density - dust * (1.0 - core));

    // Цвет аналогичен процедурному
    vec3 coreColor = vec3(1.6, 1.2, 0.9);
    vec3 armColor  = GALAXY_BaseColor * 1.4;
    vec3 color     = mix(armColor, coreColor, saturate(core * 0.5)) * density;

    return color * GALAXY_BRIGHTNESS;
#else
    return vec3(0.0); // unused branch when MODE 0
#endif
}

// ------ Public entry point ----------------------------------

vec3 RenderGalaxy(in vec3 worldDir) {
#if GALAXY_ENABLED == 0
    return vec3(0.0);
#endif

    // Поворот направления взгляда в локальное пространство галактики
    mat3 rotMat = GAL_RotMat(vec3(GALAXY_ROTX, GALAXY_ROTY, GALAXY_ROTZ));
    vec3 dir    = rotMat * worldDir;

    // Отображаем только небо (ниже горизонта галактика не видна)
    // Но для полного контроля можно убрать это ограничение
    // if (dir.y > 0.0) dir.y = -dir.y; // зеркалим — видно с обеих сторон

#if GALAXY_MODE == 0
    return GAL_Procedural(dir);
#else
    return GAL_Texture(dir);
#endif
}

#endif // GALAXY_GLSL
