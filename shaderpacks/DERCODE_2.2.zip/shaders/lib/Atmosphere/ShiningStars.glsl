//----// SHINING STARS / CONSTELLATIONS (мерцающие звёзды и созвездия) //---------------------------//
// Портировано из исходного шейдера. Таблицы координат звёзд/созвездий лежат в StarData.glsl.
// Используется направление worldDir вместо wpos исходного шейдера (без поворота лунной фазы).

#ifndef NUMBER_SHININGSTARS
	#define NUMBER_SHININGSTARS 2 // [1 2 3 4]
#endif

#ifndef SIZESTARS
	#define SIZESTARS 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#endif
#ifndef THICKSTARS
	#define THICKSTARS 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#endif
#ifndef S_SSTARS_INTENSITY
	#define S_SSTARS_INTENSITY 1.0 // [0.2 0.5 1.0 1.5 2.0 3.0 5.0]
#endif
#ifndef SHININGSTARS_JITTER_SPEED
	#define SHININGSTARS_JITTER_SPEED 1.0 // [0.25 0.5 1.0 1.5 2.0 3.0]
#endif

#ifndef LINE_THICKNESS
	#define LINE_THICKNESS 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#endif
#ifndef LINE_TRANSPARENCY
	#define LINE_TRANSPARENCY 1.0 // [0.0 0.2 0.5 1.0 1.5 2.0 3.0]
#endif

#ifndef R_SSTARS
	#define R_SSTARS 0.8 // [0.0 0.2 0.4 0.6 0.8 1.0]
#endif
#ifndef G_SSTARS
	#define G_SSTARS 0.9 // [0.0 0.2 0.4 0.6 0.8 1.0]
#endif
#ifndef B_SSTARS
	#define B_SSTARS 1.0 // [0.0 0.2 0.4 0.6 0.8 1.0]
#endif

#ifndef R_LINE
	#define R_LINE 0.5 // [0.0 0.2 0.4 0.6 0.8 1.0]
#endif
#ifndef G_LINE
	#define G_LINE 0.6 // [0.0 0.2 0.4 0.6 0.8 1.0]
#endif
#ifndef B_LINE
	#define B_LINE 1.0 // [0.0 0.2 0.4 0.6 0.8 1.0]
#endif

#include "/lib/Atmosphere/StarData.glsl"

const vec3 shiningStarsColSqrt = vec3(sqrt(R_SSTARS), sqrt(G_SSTARS), sqrt(B_SSTARS));
const vec3 lineColSqrt         = vec3(sqrt(R_LINE),   sqrt(G_LINE),   sqrt(B_LINE));

vec3 polarSS(vec3 cart) {
	vec3 p = vec3(0.0);
	p.x = length(cart);
	p.y = acos(cart.y / p.x);
	p.z = atan(cart.z, cart.x);
	return p;
}

vec3 DrawShiningStar(vec3 color, vec3 wpos, vec3 starPos, float dither, float ssIntensityMult) {
	vec3 clr = color;
	vec3 polwpos = polarSS(wpos);
	vec3 polspos = polarSS(starPos);

	vec3 poldiff = polwpos - polspos;

	vec3 diff = starPos - wpos;

	float starJitter = 1.0;

	#ifdef SHININGSTARS_JITTER
		float jitterSpeed = mix(3.0, 9.0, abs(starPos.x + starPos.z) / 2.0);
		starJitter = sin(frameTimeCounter * jitterSpeed * SHININGSTARS_JITTER_SPEED) * 0.5 + 0.6;
	#endif

	float thicknessStars = THICKSTARS * 0.001;
	float s0 = max(0.0, (0.007 * SIZESTARS) - length(diff)) * 100.0;
	float s1 = max(0.0, thicknessStars - abs(poldiff.z)) * 100.0;
	float s2 = max(0.0, thicknessStars - abs(poldiff.y)) * 100.0;
	float s = max(s1, s2) * s0 * S_SSTARS_INTENSITY * ssIntensityMult * starJitter * dither;

	float s0d = max(0.0, (0.004 * SIZESTARS) - length(diff)) * 100.0;
	float s1d = max(0.0, thicknessStars - abs(poldiff.z - poldiff.y)) * 100.0;
	float s2d = max(0.0, thicknessStars - abs(poldiff.z + poldiff.y)) * 100.0;
	float sd = max(s1d, s2d) * s0d * S_SSTARS_INTENSITY * ssIntensityMult * starJitter * dither;

	clr = max(max(s, sd) * shiningStarsColSqrt, clr);
	return mix(color, clr, pow(starsMoonVisibility, 2.0));
}

vec3 DrawLine(vec3 color, vec3 v1, vec3 v2, vec3 wpos) {
	vec3 clr = color;
	float lineThickness = LINE_THICKNESS * 0.001;
	float l1 = length(v1 - wpos);
	float l2 = length(v2 - wpos);
	float l3 = length(v1 - v2);
	if (l3 < lineThickness) {
		l3 = lineThickness;
	}

	vec3 ss3 = normalize(cross(v1, v2));
	float dist = abs(dot(wpos, ss3));

	if ((dist < lineThickness && l3 > l1 && l3 > l2)) {
		clr = mix(clr, lineColSqrt, LINE_TRANSPARENCY * 0.1);
	}
	return mix(color, clr, starsMoonVisibility);
}

ivec2 getConstellSS(vec3 viewPos) {
	int minindex1 = 0;
	int minindex2 = 0;
	float minl1 = length(viewPos - centers[0]);
	float minl2 = length(viewPos - centers[0]);
	for (int i = 1; i < numconstell; i++) {
		float l = length(viewPos - centers[i]);
		if (l < minl1) {
			minl2 = minl1;
			minl1 = l;
			minindex2 = minindex1;
			minindex1 = i;
		} else if (l < minl2) {
			minl2 = l;
			minindex2 = i;
		}
	}
	ivec2 indexes = ivec2(minindex1, -1);
	if (minl2 - minl1 < 0.02) {
		indexes.y = minindex2;
	}
	return indexes;
}

vec3 DrawConstellations(vec3 albedo, vec3 wpos, float dither, float ssIntensityMult) {
	if (starsMoonVisibility > 0.0) {
		ivec2 constell = getConstellSS(wpos.xyz);

		int linestart = 0;
		int starstart1 = 0;
		int starstart2 = 0;

		if (constell.x == 0) {
			linestart = starstart1 = 0;
		} else {
			linestart = constellations[constell.x - 1].y;
			starstart1 = constellations[constell.x - 1].x;
		}
		int lineend = constellations[constell.x].y;
		int starend1 = constellations[constell.x].x;
		int starend2 = 0;
		if (constell.y >= 0) {
			if (constell.y == 0) {
				starstart2 = 0;
			} else {
				starstart2 = constellations[constell.y - 1].x;
			}
			starend2 = constellations[constell.y].x;
		}

		#ifdef CONSTELLATIONS
			for (int i = linestart; i < lineend; i++) {
				albedo.rgb = DrawLine(albedo.rgb, stars[lines[i].x], stars[lines[i].y], wpos.xyz);
			}
		#endif

		for (int i = starstart1; i < starend1; i++) {
			albedo.rgb = DrawShiningStar(albedo.rgb, wpos.xyz, stars[i], dither, ssIntensityMult);
		}
		if (constell.y >= 0) {
			for (int i = starstart2; i < starend2; i++) {
				albedo.rgb = DrawShiningStar(albedo.rgb, wpos.xyz, stars[i], dither, ssIntensityMult);
			}
		}
	}

	return albedo.rgb;
}
