// Black Hole based on https://www.shadertoy.com/view/lstSRS


#ifndef BLACK_HOLE_GLSL
#define BLACK_HOLE_GLSL

// ===== BLACK HOLE SETTINGS =====
#define BLACKHOLE_ENABLED 0 // [0 1]
#define BLACKHOLE_ITERATIONS 100 // [50 75 100 125 150 175 200]
#define BLACKHOLE_BRIGHTNESS 200.0 // [50 75 100 125 150 175 200 225 250 275 300 350 400 450 500]

#define BLACKHOLE_CORE_SIZE 1.0 // [0.3 0.5 0.7 0.9 1.0 1.2 1.5 1.8 2.0 2.5 3.0]
#define BLACKHOLE_DISC_RADIUS 3.2 // [1.0 1.5 2.0 2.5 3.0 3.2 3.5 4.0 4.5 5.0]
#define BLACKHOLE_DISC_WIDTH 5.3 // [2.0 3.0 4.0 5.0 5.3 6.0 7.0 8.0 9.0 10.0]
#define BLACKHOLE_WARP_STRENGTH 7.0 // [0.5 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0]

#define BLACKHOLE_DUST_RING_WIDTH 0.8 // [0.3 0.5 0.8 1.0 1.5 2.0 2.5 3.0 4.0 5.0]
#define BLACKHOLE_DUST_RING_LENGTH 2.0 // [0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0]

// Наклон диска в ГРАДУСАХ. 0 = диск горизонтальный (не видно текстуру).
// 25-35 = как у Gargantua из Interstellar (видно текстуру сверху).
// 90 = диск стоит вертикально (видно ребро).
#define BLACKHOLE_DISC_TILT -27.0 // [0.0 5.0 10.0 15.0 20.0 25.0 27.0 30.0 35.0 40.0 45.0 60.0 75.0 90.0 -5.0 -10.0 -15.0 -20.0 -25.0 -27.0 -30.0 -35.0 -40.0 -45.0 -60.0 -75.0 -90.0]

// Поворот диска вокруг вертикальной оси (ориентация "лица" диска)
#define BLACKHOLE_DISC_AZIMUTH -20.0 // [-90.0 -75.0 -60.0 -45.0 -30.0 -20.0 -15.0 -10.0 0.0 10.0 15.0 20.0 30.0 45.0 60.0 75.0 90.0]

#define BLACKHOLE_BLOOM_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 4.0 5.0]
#define BLACKHOLE_HAZE_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 4.0 5.0]

// Угол доплеровского эффекта — сдвигает яркую сторону диска
#define BLACKHOLE_DOPPLER_ANGLE 1.07 // [0.0 0.5 1.0 1.07 1.5 2.0 2.5 3.0 3.14]
// Сила доплеровского эффекта (0 = выкл, 1 = реалистично, 2 = очень сильно)
#define BLACKHOLE_DOPPLER_STRENGTH 0.75 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0]

// Позиция/ориентация чёрной дыры в небе
#define BLACKHOLE_POSITION_ROTX 90.0 // [0.0 15.0 30.0 45.0 60.0 75.0 90.0 105.0 120.0 135.0 150.0 165.0 180.0]
#define BLACKHOLE_POSITION_ROTY 90.0 // [0.0 15.0 30.0 45.0 60.0 75.0 90.0 105.0 120.0 135.0 150.0 165.0 180.0]
#define BLACKHOLE_POSITION_ROTZ 90.0 // [0.0 15.0 30.0 45.0 60.0 75.0 90.0 105.0 120.0 135.0 150.0 165.0 180.0]

#define BLACKHOLE_COLOR_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BLACKHOLE_COLOR_G 0.8 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BLACKHOLE_COLOR_B 0.4 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// ===== PROTOPLANETARY DISK =====
#define PROTO_DISK_ENABLED 0 // [0 1]
#define PROTO_DISK_ITERATIONS 56 // [30 40 50 56 70 80 100]
#define PROTO_DISK_BRIGHTNESS 2.0 // [0.1 0.25 0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0 4.0 5.0]
#define PROTO_DISK_RADIUS 2.0 // [0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 5.0]
#define PROTO_DISK_THICKNESS 1.0 // [0.3 0.5 0.7 1.0 1.2 1.5 2.0 2.5 3.0]
#define PROTO_DISK_HEIGHT 0.05 // [0.01 0.03 0.05 0.07 0.1 0.15 0.2]
#define PROTO_RING_RADIUS 4.3 // [1.0 1.5 2.0 2.3 2.5 3.0 3.5 4.0]
#define PROTO_RING_THICKNESS 0.01 // [0.005 0.01 0.02 0.03 0.05 0.1]
#define PROTO_DISK_POSITION_ROTX 0.0 // [0.0 45.0 90.0 135.0 180.0 225.0 270.0 315.0 360.0]
#define PROTO_DISK_POSITION_ROTY 0.0 // [0.0 45.0 90.0 135.0 180.0 225.0 270.0 315.0 360.0]
#define PROTO_DISK_POSITION_ROTZ 10.0 // [0.0 45.0 90.0 135.0 180.0 225.0 270.0 315.0 360.0]
#define PROTO_DISK_COLOR_R 0.72 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define PROTO_DISK_COLOR_G 0.62 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define PROTO_DISK_COLOR_B 0.44 // [0.0 0.05 0.1 0.15 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define PROTO_CENTER_COLOR_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define PROTO_CENTER_COLOR_G 0.8 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define PROTO_CENTER_COLOR_B 0.4 // [0.0 0.1 0.2 0.25 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define PROTO_DISK_ROTATION_SPEED 0.51 // [0.0 0.1 0.3 0.5 0.7 1.0 1.5 2.0 3.0]

// ===== PLANET SETTINGS =====
#define PLANET_ENABLED 0 // [0 1]
#define PLANET_ITERATIONS 56 // [20 30 40 50 60 80 100]
#define PLANET_BRIGHTNESS 2.0 // [0.1 0.3 0.5 0.8 1.0 1.5 2.0 3.0 5.0 10.0]
#define PLANET_SIZE 0.55 // [0.3 0.5 0.7 0.8 0.9 0.95 1.0 1.2 1.5 2.0]
#define PLANET_POSITION_ROTX 80.0 // [0.0 45.0 90.0 135.0 180.0 225.0 270.0 315.0 360.0]
#define PLANET_POSITION_ROTY 0.0 // [0.0 45.0 90.0 135.0 180.0 225.0 270.0 315.0 360.0]
#define PLANET_POSITION_ROTZ 80.0 // [0.0 45.0 90.0 135.0 180.0 225.0 270.0 315.0 360.0]
#define PLANET_OFFSET_X 180.0 // [-5.0 -4.0 -3.0 -2.0 -1.0 0.0 1.0 2.0 3.0 4.0 5.0]
#define PLANET_OFFSET_Y 0.0 // [-5.0 -4.0 -3.0 -2.0 -1.0 0.0 1.0 2.0 3.0 4.0 5.0]
#define PLANET_OFFSET_Z 180.0 // [-10.0 -8.0 -6.0 -5.0 -4.0 -3.0 -2.0 -1.0 0.0 1.0 2.0 3.0]
#define PLANET_ROTATION_SPEED 0.1 // [0.0 0.05 0.1 0.2 0.5 1.0]
#define PLANET_ATMOS_STRENGTH 1.0 // [0.0 0.3 0.5 0.7 1.0 1.5 2.0]

const vec3 BH_MainColor = vec3(BLACKHOLE_COLOR_R, BLACKHOLE_COLOR_G, BLACKHOLE_COLOR_B);
const vec3 colDust = vec3(1.0, 0.9, 0.75);

// ===== ROTATION MATRIX =====
mat3 BH_RotationMatrix(vec3 angles) {
    angles = radians(angles);
    float cx = cos(angles.x); float sx = sin(angles.x);
    float cy = cos(angles.y); float sy = sin(angles.y);
    float cz = cos(angles.z); float sz = sin(angles.z);
    mat3 rotX = mat3(1.0,0.0,0.0, 0.0,cx,-sx, 0.0,sx,cx);
    mat3 rotY = mat3(cy,0.0,sy, 0.0,1.0,0.0, -sy,0.0,cy);
    mat3 rotZ = mat3(cz,-sz,0.0, sz,cz,0.0, 0.0,0.0,1.0);
    return rotZ * rotY * rotX;
}

// Строит матрицу поворота, выравнивающую локальную ось +Z чёрной дыры
// по заданному мировому направлению (используется, чтобы дыра светила
// как солнце Энда — то есть совпадала с worldLightVector/worldSunVector).
mat3 BH_AlignToDirection(vec3 dir) {
    vec3 forward = normalize(dir);
    vec3 upHint  = abs(forward.y) > 0.999 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
    vec3 right   = normalize(cross(upHint, forward));
    vec3 up      = cross(forward, right);
    return mat3(right, up, forward);
}

// ===== BLACK HOLE FUNCTIONS =====
float BH_noise(in vec3 x) {
    vec3 p = floor(x);
    vec3 f = fract(x);
    f = f*f*(3.0-2.0*f);
    vec2 uv = (p.xy+vec2(37.0,17.0)*p.z) + f.xy;
    vec2 rg = textureLod(noisetex, (uv+0.5)/256.0, 0.0).yx;
    return -1.0+2.0*mix(rg.x, rg.y, f.z);
}

float BH_pcurve(float x, float a, float b) {
    float k = pow(a+b,a+b) / (pow(a,a)*pow(b,b));
    return k * pow(x,a) * pow(1.0-x,b);
}

float BH_sdTorus(vec3 p, vec2 t) {
    vec2 q = vec2(length(p.xz)-t.x, p.y);
    return length(q)-t.y;
}

// Haze — световое кольцо вокруг горизонта событий (photon sphere)
void BH_Haze(inout vec3 color, vec3 pos, float alpha) {
    vec2 t = vec2(1.0, 0.01) * BLACKHOLE_CORE_SIZE;
    float torusDist = length(BH_sdTorus(pos + vec3(0.0, 0.05, 0.0), t));
    float bloomDisc = 1.0 / (pow(torusDist, 2.0) + 0.001);
    bloomDisc *= length(pos) < 0.5 ? 0.0 : 1.0;
    // Фотонное кольцо всегда горячее — белый+голубой
    vec3 photonColor = mix(BH_MainColor * 2.0, vec3(1.5, 1.8, 2.5), 0.4);
    color += photonColor * bloomDisc * (2.9/float(BLACKHOLE_ITERATIONS)) * (1.0-alpha) * BLACKHOLE_HAZE_STRENGTH;
}

void BH_GasDisc(inout vec3 color, inout float alpha, vec3 pos) {
    // ==========================================
    // Наклон диска: строим матрицу через tilt и azimuth
    // Это заменяет старый discTiltMat с TILT_X/Y/Z в градусах,
    // который при 180/0/180 давал почти identity → плоский диск
    // ==========================================
    float tiltRad    = radians(BLACKHOLE_DISC_TILT);
    float azimuthRad = radians(BLACKHOLE_DISC_AZIMUTH);

    // Шаг 1: поворот вокруг Y на azimuth (ориентация диска в горизонтальной плоскости)
    float ca = cos(azimuthRad); float sa = sin(azimuthRad);
    mat3 rotAzimuth = mat3(ca,0.0,sa, 0.0,1.0,0.0, -sa,0.0,ca);

    // Шаг 2: наклон диска вокруг локальной оси X на tilt
    // tilt=0   → нормаль диска = (0,1,0) → смотрим на ребро, текстуры не видно
    // tilt=27° → нормаль диска наклонена → видно поверхность диска как у Gargantua
    // tilt=90° → нормаль диска = (0,0,1) → диск стоит вертикально
    float ct = cos(tiltRad); float st = sin(tiltRad);
    mat3 rotTilt = mat3(1.0,0.0,0.0, 0.0,ct,-st, 0.0,st,ct);

    mat3 discMat = rotTilt * rotAzimuth;
    vec3 discPos = discMat * pos;

    float discRadius = BLACKHOLE_DISC_RADIUS * BLACKHOLE_CORE_SIZE;
    float discWidth  = BLACKHOLE_DISC_WIDTH  * BLACKHOLE_CORE_SIZE * BLACKHOLE_DUST_RING_WIDTH;
    float discInner  = discRadius - discWidth * 0.5;

    // discPos.xz — плоскость диска, discPos.y — высота над/под диском
    float distFromCenter = length(discPos.xz);  // радиус в плоскости диска
    float h = discPos.y;                         // высота (0 = середина диска)

    float radialGradient = 1.0 - saturate((distFromCenter - discInner) / discWidth * 0.5);
    float discThickness  = 0.45 * BLACKHOLE_CORE_SIZE * radialGradient;

    // Базовая плотность по форме диска (pcurve даёт красивый горб)
    float coverage = BH_pcurve(radialGradient, 4.0, 0.9);
    coverage *= saturate(1.0 - abs(h) / discThickness);

    // Bloom — светящийся ореол вокруг диска
    float fade = pow((abs(distFromCenter - discInner) + 0.4), 4.0) * 0.04;
    float bloomFactor = 1.0 / (h*h*40.0 + fade + 0.00002);
    vec3 bloomColor = BH_MainColor * pow(bloomFactor, 1.5) * BLACKHOLE_BLOOM_STRENGTH;
    // Цветовой градиент bloom: горячий (оранжево-белый) у центра → синеватый у края
    bloomColor *= mix(vec3(1.7,1.1,1.0), vec3(0.5,0.6,1.0), vec3(pow(radialGradient,2.0)));
    bloomColor *= mix(vec3(1.7,0.5,0.1), vec3(1.0),          vec3(pow(radialGradient,0.5)));

    // Температурный гlow — чем ближе к центру, тем ярче и горячее
    float gr = 1.0 - radialGradient; gr = gr * gr;
    float glowStrength = 1.0 / (gr*gr*290.0 + 0.002);
    vec3 dustColor = BH_MainColor * glowStrength * 8.2;

    coverage = saturate(coverage * 0.7);
    dustColor = mix(dustColor, bloomColor * 150.0, saturate(1.0 - coverage));
    coverage  = saturate(coverage + bloomFactor*bloomFactor*0.1);

    if (coverage < 0.01) return;

    // Координаты для шума: x=радиус, y=азимут (угол), z=высота
    // Это даёт закрученные потоки ВДОЛЬ диска а не поперёк
    vec3 radialCoords;
    radialCoords.x = distFromCenter * 1.5 + 0.55;
    radialCoords.y = atan(-discPos.x, -discPos.z) * 1.5 * BLACKHOLE_DUST_RING_LENGTH;
    radialCoords.z = h * 1.5;
    radialCoords *= 0.95;

    float speed = 0.06;

    // noise1 — крупный шум (общая форма облаков)
    float noise1 = 1.0;
    vec3 rc = radialCoords;
    rc.y += frameTimeCounter * speed;  noise1 *= BH_noise(rc * 3.0)  * 0.5 + 0.5;
    rc.y -= frameTimeCounter * speed;  noise1 *= BH_noise(rc * 6.0)  * 0.5 + 0.5;
    rc.y += frameTimeCounter * speed;  noise1 *= BH_noise(rc * 12.0) * 0.5 + 0.5;
    rc.y -= frameTimeCounter * speed;  noise1 *= BH_noise(rc * 24.0) * 0.5 + 0.5;

    // noise2 — мелкий шум (детали, волокна)
    float noise2 = 2.0;
    rc = radialCoords + 30.0;
    rc.y += frameTimeCounter * speed;  noise2 *= BH_noise(rc * 3.0)  * 0.5 + 0.5;
    rc.y -= frameTimeCounter * speed;  noise2 *= BH_noise(rc * 6.0)  * 0.5 + 0.5;
    rc.y += frameTimeCounter * speed;  noise2 *= BH_noise(rc * 12.0) * 0.5 + 0.5;
    rc.y -= frameTimeCounter * speed;  noise2 *= BH_noise(rc * 24.0) * 0.5 + 0.5;
    rc.y += frameTimeCounter * speed;  noise2 *= BH_noise(rc * 48.0) * 0.5 + 0.5;
    rc.y -= frameTimeCounter * speed;  noise2 *= BH_noise(rc * 92.0) * 0.5 + 0.5;

    // Доплеровский эффект: одна сторона диска летит к нам → ярче и голубее,
    // другая удаляется → тусклее и краснее
    float azimuthAngle = atan(-discPos.x, -discPos.z);
    float doppler = sin(azimuthAngle - BLACKHOLE_DOPPLER_ANGLE) * BLACKHOLE_DOPPLER_STRENGTH + 1.0;
    dustColor *= doppler;
    // Цветовой сдвиг от доплера: синяя (приближающаяся) сторона ↔ красная (удаляющаяся)
    vec3 dopplerShift = mix(vec3(1.0, 0.55, 0.25), vec3(0.75, 0.9, 1.5), saturate(doppler * 0.5));
    dustColor *= dopplerShift;

    dustColor *= noise1 * 0.998 + 0.002;
    coverage  *= noise2;

    coverage  = saturate(coverage * 1200.0 / float(BLACKHOLE_ITERATIONS));
    dustColor = max(vec3(0.0), dustColor);
    coverage  *= BH_pcurve(radialGradient, 4.0, 0.9);

    color = (1.0 - alpha) * dustColor * coverage + color;
    alpha = (1.0 - alpha) * coverage + alpha;
}

void BH_WarpSpace(inout vec3 eyevec, inout vec3 raypos) {
    vec3 origin = vec3(0.0);
    float singularityDist = distance(raypos, origin);
    float warpFactor = 1.0 / (pow(singularityDist, 2.0) + 0.000001);
    vec3 singularityVector = normalize(origin - raypos);
    float warpAmount = BLACKHOLE_WARP_STRENGTH / BLACKHOLE_CORE_SIZE;
    eyevec = normalize(eyevec + singularityVector * warpFactor * warpAmount / float(BLACKHOLE_ITERATIONS));
}

vec3 RenderBlackHole(in vec3 worldDir, in vec3 cameraPos) {
    #if BLACKHOLE_ENABLED == 0
        return vec3(0.0);
    #endif

    mat3 posRotMat = BH_RotationMatrix(vec3(BLACKHOLE_POSITION_ROTX, BLACKHOLE_POSITION_ROTY, BLACKHOLE_POSITION_ROTZ));
    vec3 bhDir = posRotMat * worldDir;

    vec3 eyepos = vec3(0.0, 0.0, -10.0 * BLACKHOLE_CORE_SIZE);
    vec3 eyevec = bhDir;
    float far = 15.0 * BLACKHOLE_CORE_SIZE;

    vec3 color = vec3(0.0);
    float dither = fract(sin(dot(worldDir.xy + frameTimeCounter, vec2(12.9898, 78.223))) * 43758.5453) * 2.0;

    float alpha = 0.0;
    vec3 raypos = eyepos + eyevec * dither * far / float(BLACKHOLE_ITERATIONS);

    for (int i = 0; i < BLACKHOLE_ITERATIONS; i++) {
        BH_WarpSpace(eyevec, raypos);
        raypos += eyevec * far / float(BLACKHOLE_ITERATIONS);
        BH_GasDisc(color, alpha, raypos);
        BH_Haze(color, raypos, alpha);
    }

    color *= 0.0001 * BLACKHOLE_BRIGHTNESS;
    return saturate(color);
}

// Версия чёрной дыры, ориентированная по заданному мировому направлению
// (используем worldLightVector/worldSunVector, чтобы дыра была "солнцем" Энда:
// освещение, тени и specular из остального пайплайна будут идти именно от неё).
vec3 RenderBlackHole(in vec3 worldDir, in vec3 cameraPos, in vec3 lightDir) {
    #if BLACKHOLE_ENABLED == 0
        return vec3(0.0);
    #endif

    mat3 posRotMat = BH_AlignToDirection(lightDir);
    vec3 bhDir = posRotMat * worldDir;

    vec3 eyepos = vec3(0.0, 0.0, -10.0 * BLACKHOLE_CORE_SIZE);
    vec3 eyevec = bhDir;
    float far = 15.0 * BLACKHOLE_CORE_SIZE;

    vec3 color = vec3(0.0);
    float dither = fract(sin(dot(worldDir.xy + frameTimeCounter, vec2(12.9898, 78.223))) * 43758.5453) * 2.0;

    float alpha = 0.0;
    vec3 raypos = eyepos + eyevec * dither * far / float(BLACKHOLE_ITERATIONS);

    for (int i = 0; i < BLACKHOLE_ITERATIONS; i++) {
        BH_WarpSpace(eyevec, raypos);
        raypos += eyevec * far / float(BLACKHOLE_ITERATIONS);
        BH_GasDisc(color, alpha, raypos);
        BH_Haze(color, raypos, alpha);
    }

    color *= 0.0001 * BLACKHOLE_BRIGHTNESS;
    return saturate(color);
}

// ===== END SKY STARS (портировано из EndSky.glsl) =====
// Звёзды для неба Энда. worldSunVector тут используется только как
// произвольная стабильная ось для медленного вращения звёздного поля,
// сама чёрная дыра как источник света не влияет на их позиции.
vec3 BH_CalculateEndStars(vec3 worldDir) {
    float angleY = frameTimeCounter * 0.001;
    mat3 eyeRoataionMatrixY = mat3(cos(angleY), 0, sin(angleY), 0, 1, 0, -sin(angleY), 0, cos(angleY));

    worldDir = eyeRoataionMatrixY * worldDir;

    const float scale = 384.0;
    const float coverage = 0.007;
    const float maxLuminance = 0.04;
    const float minTemperature = 4000.0;
    const float maxTemperature = 8000.0;

    float cosine = dot(worldSunVector, vec3(0, 0, 1));
    vec3 axis = cross(worldSunVector, vec3(0, 0, 1));
    float cosecantSquared = 1.0 / dot(axis, axis);
    worldDir = cosine * worldDir + cross(axis, worldDir) + (cosecantSquared - cosecantSquared * cosine) * dot(axis, worldDir) * axis;

    vec3  p = worldDir * scale;
    ivec3 i = ivec3(floor(p));
    vec3  f = p - i;
    float r = dot(f - 0.5, f - 0.5);

    vec3 i3 = fract(i * vec3(443.897, 441.423, 437.195));
    i3 += dot(i3, i3.yzx + 19.19);
    vec2 hash = fract((i3.xx + i3.yz) * i3.zy);
    hash.y = 2.0 * hash.y - 4.0 * hash.y * hash.y + 3.0 * hash.y * hash.y * hash.y;

    float c = remap(1.0 - coverage, 1.0, hash.x);
    return (maxLuminance * remap(0.25, 0.0, r) * c * c) * Blackbody(mix(minTemperature, maxTemperature, hash.y));
}

// Упрощённый туман к горизонту для неба Энда (без планеты с кольцами).
// Привязан к worldLightVector — сгущается со стороны чёрной дыры.
vec3 BH_EndHorizonFog(vec3 worldDir, vec3 lightDir) {
    float VdotL = dot(lightDir, worldDir);

    // Чем ближе к горизонту, тем гуще туман
    float horizon = exp2(-abs(worldDir.y) * 6.0);

    // Подсветка со стороны источника света (чёрной дыры)
    // HenyeyGreensteinPhase должна быть определена выше по includes (см. deferred5.fsh)
    float mie = HenyeyGreensteinPhase(VdotL, 0.7);

    float density = horizon * (0.3 + mie * 1.5);

    vec3 fogColor = mix(vec3(0.05, 0.04, 0.07), vec3(1.0, 0.85, 0.55), saturate(mie));

    return fogColor * density * 0.05;
}

// ===== PROTOPLANETARY DISK FUNCTIONS =====
mat2 PD_Spin(float angle) {
    return mat2(cos(angle),-sin(angle),sin(angle),cos(angle));
}

float PD_noise(in vec3 x) {
    vec3 p = floor(x); vec3 f = fract(x);
    f = f*f*(3.0-2.0*f);
    vec2 uv = (p.xy+vec2(37.0,17.0)*p.z)+f.xy;
    vec2 rg = textureLod(noisetex,(uv+0.5)/256.0,0.0).yx;
    return -1.0+2.4*mix(rg.x,rg.y,f.z);
}

float PD_fpn(vec3 p) {
    return PD_noise(p*.06125)*.5 + PD_noise(p*.125)*.25 + PD_noise(p*.25)*.125;
}

float PD_rand(vec2 co) {
    return fract(sin(dot(co*0.123,vec2(12.9898,78.233)))*43758.5453);
}

float PD_length2(vec2 p) { return sqrt(p.x*p.x+p.y*p.y); }

float PD_length8(vec2 p) {
    p=p*p; p=p*p; p=p*p;
    return pow(p.x+p.y,1.0/8.0);
}

float PD_Ring(vec3 p) {
    vec2 q = vec2(length(p.xy)-PROTO_RING_RADIUS, p.z);
    return length(q)-PROTO_RING_THICKNESS;
}

float PD_Disk(vec3 p, vec3 t) {
    vec2 q = vec2(PD_length2(p.xy)-t.x, p.z*0.5);
    return max(PD_length8(q)-t.y, abs(p.z)-t.z);
}

float PD_smin(float a, float b, float k) {
    float h = clamp(0.5+0.5*(b-a)/k, 0.0,1.0);
    return mix(b,a,h)-k*h*(1.0-h);
}

float PD_map(vec3 p) {
    float t = PROTO_DISK_ROTATION_SPEED * frameTimeCounter;
    float d1 = PD_Disk(p,vec3(PROTO_DISK_RADIUS,PROTO_DISK_THICKNESS,PROTO_DISK_HEIGHT)) +
               PD_fpn(vec3(PD_Spin(t*0.25+p.z*.10)*p.xy*20.,p.z*20.-t)*5.0)*0.545;
    float d2 = PD_Ring(p);
    return PD_smin(d1,d2,1.0);
}

vec3 PD_computeColor(float density, float radius) {
    vec3 result = mix(1.1*vec3(1.0,0.9,0.8),vec3(PROTO_DISK_COLOR_R,PROTO_DISK_COLOR_G,PROTO_DISK_COLOR_B),density);
    vec3 colCenter = 6.0*vec3(PROTO_CENTER_COLOR_R,PROTO_CENTER_COLOR_G,PROTO_CENTER_COLOR_B);
    vec3 colEdge   = 2.0*vec3(PROTO_DISK_COLOR_R*0.6,PROTO_DISK_COLOR_G*0.6,PROTO_DISK_COLOR_B*0.5);
    result *= mix(colCenter,colEdge,min((radius+.5)/2.0,1.15));
    return result;
}

bool PD_Raycylinderintersect(vec3 org, vec3 dir, out float near, out float far) {
    float a = dot(dir.xy,dir.xy);
    float b = dot(org.xy,dir.xy);
    float c = dot(org.xy,org.xy)-12.0;
    float delta = b*b-a*c;
    if(delta<0.0) return false;
    float deltasqrt = sqrt(delta);
    float arcp = 1.0/a;
    near = (-b-deltasqrt)*arcp;
    far  = (-b+deltasqrt)*arcp;
    float temp=min(far,near); far=max(far,near); near=temp;
    float znear=org.z+near*dir.z; float zfar=org.z+far*dir.z;
    vec2 zcap=vec2(1.85,-1.85); vec2 cap=(zcap-org.z)/dir.z;
    if(znear<zcap.y) near=cap.y; else if(znear>zcap.x) near=cap.x;
    if(zfar <zcap.y) far =cap.y; else if(zfar >zcap.x) far =cap.x;
    return far>0.0 && far>near;
}

vec3 RenderProtoDisk(in vec3 worldDir, in vec3 cameraPos) {
    #if PROTO_DISK_ENABLED == 0
        return vec3(0.0);
    #endif

    mat3 posRotMat = BH_RotationMatrix(vec3(PROTO_DISK_POSITION_ROTX,PROTO_DISK_POSITION_ROTY,PROTO_DISK_POSITION_ROTZ));
    vec3 rd = posRotMat * worldDir;
    vec3 ro = vec3(0.0,0.0,-6.0);

    mat3 R_yz = mat3(1.0,0.0,0.0,0.0,cos(-PI*3.65),-sin(-PI*3.65),0.0,sin(-PI*3.65),cos(-PI*3.65));
    mat3 R_xz = mat3(cos(PI*3.2),0.0,sin(PI*3.2),0.0,1.0,0.0,-sin(PI*3.2),0.0,cos(PI*3.2));
    rd = R_xz*R_yz*rd; ro = R_xz*R_yz*ro;

    vec2 seed = worldDir.xy+fract(frameTimeCounter);
    float ld=0.0,td=0.0,w=0.0,d=1.0,t=0.0;
    vec4 sum = vec4(0.0);
    float min_dist=0.0,max_dist=0.0;

    if(PD_Raycylinderintersect(ro,rd,min_dist,max_dist)) {
        t = min_dist*step(t,min_dist);
        for(int i=0; i<PROTO_DISK_ITERATIONS; i++) {
            vec3 pos = ro+t*rd;
            if(td>(1.0-1.0/80.0)||d<0.008*t||t>10.0||sum.a>0.99||t>max_dist) break;
            d = PD_map(pos);
            vec3 stardir = normalize(vec3(0.0)-pos);
            d = max(d,0.08);
            if(d<0.1) {
                ld = 0.1-d;
                float fld = clamp((ld-PD_map(pos+0.2*stardir))/0.4,0.0,1.0);
                ld += fld; w=(1.0-td)*ld; td+=w+1.0/200.0;
                float radiusFromCenter = length(pos);
                vec4 col = vec4(PD_computeColor(td,radiusFromCenter),td);
                col.a *= 0.2; col.rgb *= col.a/0.8;
                sum = sum+col*(1.0-sum.a);
            }
            td += 1.0/70.0;
            vec3 ldst = vec3(0.0)-pos;
            float lDist = max(length(ldst),0.001);
            vec3 lightColor = vec3(PROTO_CENTER_COLOR_R,PROTO_CENTER_COLOR_G,PROTO_CENTER_COLOR_B);
            sum.rgb += lightColor/(lDist*lDist*lDist*7.0);
            d = max(d,0.04);
            d = abs(d)*(1.0+0.28*PD_rand(seed*vec2(i)));
            t += max(d*0.3,0.02);
        }
        sum = clamp(sum,0.0,1.0);
        sum.xyz = sum.xyz*sum.xyz*(3.0-2.0*sum.xyz);
    }
    return sum.xyz*PROTO_DISK_BRIGHTNESS;
}

// ===== PLANET FUNCTIONS =====
float PLANET_noise3d(vec3 x) {
    vec3 p=floor(x); vec3 f=fract(x);
    f=f*f*(3.0-2.0*f);
    vec2 uv=(p.xy+vec2(37.0,17.0)*p.z)+f.xy;
    vec2 rg=textureLod(noisetex,(uv+0.5)/256.0,0.0).yx;
    return mix(rg.x,rg.y,f.z);
}

float PLANET_getHeight(vec2 uv) { return PLANET_noise3d(vec3(uv*4.0,0.0)); }

vec4 PLANET_bumpFromDepth(vec2 uv) {
    float scale=0.001;
    float height=PLANET_getHeight(uv);
    vec2 dxy=height-vec2(PLANET_getHeight(uv+vec2(scale,0.0)),PLANET_getHeight(uv+vec2(0.0,scale)));
    return vec4(normalize(vec3(dxy*1.0/scale,1.0)),height);
}

vec3 PLANET_normalMap(vec2 uv) { return PLANET_bumpFromDepth(uv).rgb*0.5+0.5; }

vec3 RenderPlaneta(in vec3 worldDir, in vec3 cameraPos) {
    #if PLANET_ENABLED == 0
        return vec3(0.0);
    #endif

    mat3 posRotMat = BH_RotationMatrix(vec3(PLANET_POSITION_ROTX,PLANET_POSITION_ROTY,PLANET_POSITION_ROTZ));
    vec3 rd = normalize(posRotMat*worldDir);
    vec3 ro = vec3(0.0);
    vec3 planetCenter = vec3(PLANET_OFFSET_X,PLANET_OFFSET_Y,PLANET_OFFSET_Z);
    float planetRadius = PLANET_SIZE;

    vec3 oc = ro-planetCenter;
    float b=dot(oc,rd), c=dot(oc,oc)-planetRadius*planetRadius;
    float disc=b*b-c;
    if(disc<0.0) return vec3(0.0);
    float sqrtDisc=sqrt(disc);
    float t1=-b-sqrtDisc, t2=-b+sqrtDisc;
    if(t2<0.0) return vec3(0.0);
    float t=t1>0.0?t1:t2;

    vec3 hitPos=ro+rd*t;
    vec3 normal=normalize(hitPos-planetCenter);
    float time=frameTimeCounter*PLANET_ROTATION_SPEED;
    float angle=time*0.1;
    mat3 rotY=mat3(cos(angle),0.0,sin(angle),0.0,1.0,0.0,-sin(angle),0.0,cos(angle));
    vec3 rotatedNormal=rotY*normal;

    float theta=acos(clamp(rotatedNormal.y,-1.0,1.0));
    float phi=atan(rotatedNormal.z,rotatedNormal.x);
    vec2 uv=vec2(phi/(2.0*PI)+0.5,theta/PI);

    vec3 lightDir=normalize(vec3(cos(time*0.25),0.5,sin(time*0.25)));
    vec3 ntex=PLANET_normalMap(uv);
    float tex1=PLANET_noise3d(vec3(uv*2.0,0.0));
    float tex2=PLANET_noise3d(vec3(uv*4.0,1.0));
    float tex=tex1*0.6+tex2*0.4;

    vec3 bumpNormal=normalize(normal+(ntex-0.5)*0.3);
    float diffuse=max(0.0,dot(bumpNormal,lightDir));
    vec3 color=vec3(0.8,1.0,0.8)*tex*diffuse;
    vec3 viewDir=-rd;
    vec3 reflectDir=reflect(-lightDir,bumpNormal);
    color+=vec3(pow(max(0.0,dot(viewDir,reflectDir)),16.0)*0.5);
    float rim=pow(1.0-abs(dot(normal,viewDir)),3.0);
    color+=vec3(0.5,0.8,0.5)*rim*0.3*PLANET_ATMOS_STRENGTH;

    vec2 npos=normal.xy;
    vec2 sd=npos-lightDir.xy;
    float sm=pow(abs(cos(time*0.25)),32.0);
    float lndist=length(sd);
    float tn=PLANET_noise3d(vec3(sm,0.0,0.0))*0.1;
    float lm=0.25+tn;
    if(lndist<lm) color+=vec3((lm-lndist)/lm)*sm;
    if(abs(sd.y)<tn) color+=vec3(tn-abs(sd.y))*sm;

    return saturate(color*PLANET_BRIGHTNESS);
}

#endif // BLACK_HOLE_GLSL
