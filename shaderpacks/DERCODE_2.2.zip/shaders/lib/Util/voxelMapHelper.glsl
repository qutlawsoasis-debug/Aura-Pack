#ifndef INCLUDE_VOXEL_MAP_HELPER
#define INCLUDE_VOXEL_MAP_HELPER

#ifdef MCBL_HALF_HEIGHT
	vec3 voxelMapSize = vec3(float(MCBL_DISTANCE), float(min(MCBL_DISTANCE / 2, 256)), float(MCBL_DISTANCE));
#else
	vec3 voxelMapSize = vec3(float(MCBL_DISTANCE), float(min(MCBL_DISTANCE, 256)), float(MCBL_DISTANCE));
#endif

// worldPos — абсолютная мировая позиция.
// Центрируем воксельную карту вокруг камеры.
vec3 WorldToVoxel(in vec3 worldPos) {
	return worldPos - cameraPosition + voxelMapSize * 0.5;
}

bool IsInVoxelMapVolume(in vec3 voxelPos) {
	return all(greaterThanEqual(voxelPos, vec3(0.0))) &&
	       all(lessThan(voxelPos, voxelMapSize));
}

float GetVoxelMapSoftBounds(in vec3 voxelPos) {
	const float borderSize = 8.0;
	vec3 halfSize  = voxelMapSize * 0.5;
	vec3 absCenter = abs(voxelPos - halfSize);
	vec3 fade3D    = (absCenter - (halfSize - vec3(borderSize))) / borderSize;
	float fade     = max(max(fade3D.x, fade3D.y), fade3D.z);
	return 1.0 - clamp(fade, 0.0, 1.0);
}

#endif
