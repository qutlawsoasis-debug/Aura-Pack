// ============================================================
//  WaterRipple.glsl  —  Player-driven circular ripple waves
//
//  Supports two event types passed as uniforms from CPU side:
//    1. Walk ripples   — player moving on water surface
//    2. Splash ripples — player jumping INTO water
//
//  Up to MAX_RIPPLES simultaneous sources are tracked.
//  Each source is encoded as vec4(worldX, worldZ, startTime, strength).
//
//  Because GLSL shaders have no persistent state, the ripple
//  sources must be sent every frame as uniform arrays.
//  Add to shaders.properties / your uniform declarations:
//
//    uniform vec4  u_rippleSources[MAX_RIPPLES];  // xz pos, startTime, strength
//    uniform int   u_rippleCount;
//    uniform float u_rippleWalkStrength;   // 0..1 from player velocity
//    uniform vec2  u_playerFootXZ;         // current player foot world XZ
//    uniform float u_playerSplashTime;     // frameTimeCounter at last splash, -1 if none
//    uniform float u_playerSplashStrength; // 0..1
//
//  NOTE: If your shader pipeline does not support custom uniforms
//  you can approximate player position with cameraPosition.xz and
//  detect water entry by watching isEyeInWater transitions.
//  A ready-to-use fallback using only built-in uniforms is provided
//  below via #define RIPPLE_BUILTIN_ONLY.
// ============================================================

#define MAX_RIPPLES 8

// Ripple visual parameters
#define RIPPLE_SPEED          2.4      // How fast ring expands (blocks/sec)
#define RIPPLE_WAVELENGTH     0.55     // Spacing between ring crests
#define RIPPLE_DECAY_DIST     7.0      // Rings fade after this many blocks
#define RIPPLE_DECAY_TIME     3.2      // Rings fade after this many seconds
#define RIPPLE_WALK_STRENGTH  0.018    // Height amplitude for walk ripples
#define RIPPLE_SPLASH_STRENGTH 0.055   // Height amplitude for splash
#define RIPPLE_NORMAL_SCALE   2.8      // How much ripples tilt normals

// ---- Single circular ripple contribution -------------------
//  source  : vec4(worldX, worldZ, startTime, strength 0..1)
//  p       : current world XZ position being shaded
//  t       : frameTimeCounter
float RippleHeight(vec4 source, vec2 p, float t) {
    vec2  delta   = p - source.xy;
    float dist    = length(delta);
    float age     = t - source.z;

    if (age < 0.0 || age > RIPPLE_DECAY_TIME) return 0.0;

    // Expanding ring front: only show wave where ring has arrived
    float front   = age * RIPPLE_SPEED;
    if (dist > front + RIPPLE_WAVELENGTH * 2.0) return 0.0;

    // Spatial envelope: gaussian centred at ring front
    float ringDist = dist - front;
    float spatial  = exp(-ringDist * ringDist * 8.0);

    // Temporal decay: fade as ring expands and ages
    float timeFade = 1.0 - smoothstep(0.0, RIPPLE_DECAY_TIME, age);
    float distFade = 1.0 - smoothstep(0.0, RIPPLE_DECAY_DIST, dist);

    // Oscillation along the ring radius
    float wave = sin((dist - front) * (6.28318 / RIPPLE_WAVELENGTH));

    return wave * spatial * timeFade * distFade * source.w;
}

// ---- Sum all active sources --------------------------------
float GetRippleSumHeight(vec2 p, float t,
                         vec4 sources[MAX_RIPPLES], int count) {
    float h = 0.0;
    for (int i = 0; i < MAX_RIPPLES; i++) {
        if (i >= count) break;
        h += RippleHeight(sources[i], p, t);
    }
    return h;
}

// ---- Normal perturbation from ripples ----------------------
//  Returns XZ gradient used to tilt the water normal.
vec2 GetRippleNormal(vec2 p, float t,
                     vec4 sources[MAX_RIPPLES], int count) {
    const float d = 0.04;
    float h0 = GetRippleSumHeight(p,              t, sources, count);
    float hx = GetRippleSumHeight(p + vec2(d,0.), t, sources, count);
    float hz = GetRippleSumHeight(p + vec2(0.,d), t, sources, count);
    return vec2(h0 - hx, h0 - hz) * (RIPPLE_NORMAL_SCALE / d);
}

// ============================================================
//  FALLBACK — builtin uniforms only
//
//  Uses cameraPosition.xz as the ripple origin.
//  Detects "splash" by isEyeInWater becoming 1 (camera submerged).
//  Detects "walk on water" by small horizontal camera movement
//  when not submerged and camera Y is near water surface.
//
//  Because we have no persistent CPU state in pure GLSL we fake
//  multiple ripple pulses by offsetting time with small constants.
// ============================================================
#ifdef RIPPLE_BUILTIN_ONLY
uniform int isEyeInWater;
uniform float frameTimeCounter;


// Returns combined ripple height using only built-in uniforms.
// Call this instead of GetRippleSumHeight when custom uniforms
// are unavailable.
//
// cameraPos  : cameraPosition (world space)
// t          : frameTimeCounter
float GetRippleHeightBuiltin(vec2 worldXZ, vec3 cameraPos, float t) {
    float h = 0.0;

    // Determine if camera is at water level (Y fractional part ≈ 0)
    float camYfrac = fract(cameraPos.y);
    bool  onWater  = (isEyeInWater == 0) &&
                     (camYfrac > 0.55 && camYfrac < 0.75);

    vec2  origin   = cameraPos.xz;

    if (isEyeInWater == 1) {
        // Underwater → player just splashed in; strong slow pulse
        vec4 src = vec4(origin, 0.0, RIPPLE_SPLASH_STRENGTH);
        // Generate 3 offset pulses to simulate sustained splash
        h += RippleHeight(src,                                  worldXZ, t);
        h += RippleHeight(vec4(origin, -0.25, RIPPLE_SPLASH_STRENGTH * 0.6), worldXZ, t);
        h += RippleHeight(vec4(origin, -0.55, RIPPLE_SPLASH_STRENGTH * 0.3), worldXZ, t);
    } else if (onWater) {
        // Walking on water surface → gentle walk ripple
        vec4 src = vec4(origin, fract(t * 0.7) < 0.5 ? 0.0 : -0.45,
                        RIPPLE_WALK_STRENGTH);
        h += RippleHeight(src, worldXZ, t);
    }

    return h;
}

vec2 GetRippleNormalBuiltin(vec2 worldXZ, vec3 cameraPos, float t) {
    const float d = 0.04;
    float h0 = GetRippleHeightBuiltin(worldXZ,              cameraPos, t);
    float hx = GetRippleHeightBuiltin(worldXZ + vec2(d,0.), cameraPos, t);
    float hz = GetRippleHeightBuiltin(worldXZ + vec2(0.,d), cameraPos, t);
    return vec2(h0 - hx, h0 - hz) * (RIPPLE_NORMAL_SCALE / d);
}

#endif // RIPPLE_BUILTIN_ONLY
