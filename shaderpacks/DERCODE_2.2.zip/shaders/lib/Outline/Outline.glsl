/*
--------------------------------------------------------------------------------
	Custom Block Selection Outline
	Styles (set OUTLINE_STYLE in Settings.glsl):
		0 = OFF
		1 = BLACK   - thin solid black outline (classic)
		2 = GLOW    - soft colored glow around the block
		3 = RGB     - animated rainbow outline
		4 = CUSTOM  - solid user-defined color (OUTLINE_CUSTOM_COLOR)
--------------------------------------------------------------------------------
*/

#ifndef OUTLINE_STYLE
	#define OUTLINE_STYLE 0 // [0 1 2 3 4]
#endif

#ifndef OUTLINE_WIDTH
	#define OUTLINE_WIDTH 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]
#endif

#ifndef OUTLINE_GLOW_STRENGTH
	#define OUTLINE_GLOW_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#endif

#ifndef OUTLINE_CUSTOM_COLOR
	#define OUTLINE_CUSTOM_COLOR vec3(1.0, 0.85, 0.2) // R G B, 0.0-1.0
#endif

#ifndef OUTLINE_RGB_SPEED
	#define OUTLINE_RGB_SPEED 0.5 // [0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#endif

#include "/lib/outline/OutlineOffsets.glsl"

// Simple HSV -> RGB for the rainbow style
vec3 OutlineHueShift(in float hue) {
	vec3 rgb = clamp(abs(mod(hue * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0);
	return rgb;
}

// Returns the outline mask (0 = no edge, 1 = full edge) by comparing the
// "selection box" depth (depthtex0) against the world depth without it (depthtex1).
// Where the selection box is closer to the camera than the world behind it,
// and a neighboring pixel is NOT part of the box, we are on an edge.
float GetOutlineEdgeMask(in vec2 coord, in vec2 pixelSize) {
	float centerSelected = step(texture(depthtex0, coord).x, texture(depthtex1, coord).x - 1e-6);

	float edge = 0.0;

	for (int i = 0; i < 12; i++) {
		vec2 sampleCoord = coord + outlineOffsets[i] * pixelSize * OUTLINE_WIDTH;

		float sampleSelected = step(texture(depthtex0, sampleCoord).x, texture(depthtex1, sampleCoord).x - 1e-6);

		edge += abs(centerSelected - sampleSelected);
	}

	return saturate(edge);
}

// Wider mask used for the glow style — samples a larger ring so the glow
// can extend further than the hard 1px outline.
float GetOutlineGlowMask(in vec2 coord, in vec2 pixelSize) {
	float glow = 0.0;

	for (int i = 0; i < 12; i++) {
		vec2 sampleCoord = coord + outlineOffsets[i] * pixelSize * (OUTLINE_WIDTH * 2.0);

		float sampleSelected = step(texture(depthtex0, sampleCoord).x, texture(depthtex1, sampleCoord).x - 1e-6);

		glow += sampleSelected;
	}

	return saturate(glow * (1.0 / 12.0) * 2.0);
}

// Applies the configured outline style on top of `color`.
// `coord` is the current pixel's screen coordinate in [0,1].
void ApplyBlockOutline(inout vec3 color, in vec2 coord) {
	#if OUTLINE_STYLE == 0
		return;
	#else
		vec2 pixelSize = screenPixelSize;

		float edge = GetOutlineEdgeMask(coord, pixelSize);

		#if OUTLINE_STYLE == 1
			// BLACK - classic thin dark outline
			color = mix(color, vec3(0.0), edge);

		#elif OUTLINE_STYLE == 2
			// GLOW - soft colored glow + thin bright edge
			float glow = GetOutlineGlowMask(coord, pixelSize);
			vec3 glowColor = vec3(1.0, 0.95, 0.75);

			color += glowColor * glow * glow * OUTLINE_GLOW_STRENGTH * 0.5;
			color = mix(color, glowColor, edge * OUTLINE_GLOW_STRENGTH);

		#elif OUTLINE_STYLE == 3
			// RGB - animated rainbow outline
			float hue = fract(frameTimeCounter * OUTLINE_RGB_SPEED * 0.1 + (coord.x + coord.y) * 0.25);
			vec3 rainbow = OutlineHueShift(hue);

			float glow = GetOutlineGlowMask(coord, pixelSize);

			color += rainbow * glow * glow * OUTLINE_GLOW_STRENGTH * 0.5;
			color = mix(color, rainbow, edge);

		#elif OUTLINE_STYLE == 4
			// CUSTOM - solid user color with light glow
			float glow = GetOutlineGlowMask(coord, pixelSize);

			color += OUTLINE_CUSTOM_COLOR * glow * glow * OUTLINE_GLOW_STRENGTH * 0.5;
			color = mix(color, OUTLINE_CUSTOM_COLOR, edge);
		#endif
	#endif
}
