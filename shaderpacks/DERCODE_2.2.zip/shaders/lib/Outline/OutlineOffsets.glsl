// Sampling offsets used for edge detection around the selected block.
// 12 directions covering a 2px radius ring (enough for thin, clean outlines).
const vec2 outlineOffsets[12] = vec2[12](
    vec2( 0.0,  1.0),
    vec2( 1.0,  0.0),
    vec2( 0.0, -1.0),
    vec2(-1.0,  0.0),
    vec2( 1.0,  1.0),
    vec2( 1.0, -1.0),
    vec2(-1.0,  1.0),
    vec2(-1.0, -1.0),
    vec2( 2.0,  0.0),
    vec2(-2.0,  0.0),
    vec2( 0.0,  2.0),
    vec2( 0.0, -2.0)
);
