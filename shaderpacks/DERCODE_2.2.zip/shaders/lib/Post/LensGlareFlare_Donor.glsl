// ============================================================
// LENS GLARE / FLARE (перенесено из донора)
// Источник: https://www.shadertoy.com/view/MdGSWy
//
// Адаптация под наш пайплайн:
//  - sunCoord (донор считал его в вершинном шейдере с occlusion-тестом по
//    depthtex) заменён на проекцию sunPosition прямо во фрагментном шейдере,
//    тем же способом, что уже используется в нашем Final.glsl::LensFlare;
//  - texCoord -> screenCoord (наш аналог);
//  - colorSunlight / VFOG_DENSITY / MAIN_OUTPUT_FACTOR у нас не объявлены —
//    эти члены убраны, тонировку/туман при желании можно добавить позже;
//  - LinearToCurve убран: Grade.glsl всё ещё работает в линейном HDR,
//    финальная кривая применяется позже в Final.glsl (sRGB_EncodeSafe);
//  - atan2(v) заменён на встроенный atan(v.y, v.x) (то же самое).
// ============================================================

#ifndef LENS_GLARE
    #define LENS_GLARE
#endif
#ifndef LENS_FLARE_ORB
    #define LENS_FLARE_ORB
#endif

#ifndef GLARE_BRIGHTNESS
    #define GLARE_BRIGHTNESS 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0]
#endif
#ifndef FLARE_BRIGHTNESS
    #define FLARE_BRIGHTNESS 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0]
#endif

#if defined LENS_GLARE || defined LENS_FLARE_ORB

uniform vec3 sunPosition;
uniform float sunVisibility;

#define ORB_FLARE_COUNT          6.0
#define DONOR_FLARE_DISTORTION   1.0

vec2 DonorFlareDistOffset(vec2 uv, vec2 pxoffset) {
    vec2 tocenter = uv.xy;
    vec3 prep = normalize(vec3(tocenter.y, -tocenter.x, 0.0));

    float angle = length(tocenter.xy) * 2.221 * DONOR_FLARE_DISTORTION;
    vec3 oldoffset = vec3(pxoffset, 0.0);

    vec3 rotated = oldoffset * cos(angle) + cross(prep, oldoffset) * sin(angle)
                 + prep * dot(prep, oldoffset) * (1.0 - cos(angle));

    return rotated.xy;
}

vec3 DonorFlare(vec2 uv, vec2 pos, float dist, float chromaOffset, float size) {
    pos = DonorFlareDistOffset(uv, pos);

    float r = max(0.01 - pow(length(uv + (dist - chromaOffset) * pos), 2.4) * (1.0 / (size * 2.0)), 0.0) * 0.85;
    float g = max(0.01 - pow(length(uv +  dist                 * pos), 2.4) * (1.0 / (size * 2.0)), 0.0) * 1.0;
    float b = max(0.01 - pow(length(uv + (dist + chromaOffset) * pos), 2.4) * (1.0 / (size * 2.0)), 0.0) * 1.5;

    return vec3(r, g, b);
}

vec3 DonorOrb(vec2 uv, vec2 pos, float dist, float size) {
    vec3 c = vec3(0.0);

    for (float i = 0.0; i < ORB_FLARE_COUNT; i++) {
        float j = i + 1.0;
        float offset = j / (j + 0.1);
        float colOffset = j / ORB_FLARE_COUNT * 0.5;

        float ss = size / (j + 1.0);

        c += DonorFlare(uv, pos, dist + offset, ss * 2.0, ss) * vec3(1.0 - colOffset, 1.0, 0.5 + colOffset) * j;
    }

    c += DonorFlare(uv, pos, dist + 0.8, 0.05, 3.0 * size) * 0.5;

    return c;
}

vec3 DonorRing(vec2 uv, vec2 pos, float dist, float chromaOffset, float blur) {
    vec2 uvd = uv * length(uv);

    float r = max(1.0 / (1.0 + 250.0 * pow(length(uvd + (dist - chromaOffset) * pos), blur)), 0.0) * 0.8;
    float g = max(1.0 / (1.0 + 250.0 * pow(length(uvd +  dist                 * pos), blur)), 0.0) * 1.0;
    float b = max(1.0 / (1.0 + 250.0 * pow(length(uvd + (dist + chromaOffset) * pos), blur)), 0.0) * 1.5;

    return vec3(r, g, b);
}

vec3 DonorLensGlareFlare(vec2 texcoord) {
    vec3 lf = vec3(0.0);

    // Проекция солнца в экранные координаты — так же, как уже сделано
    // в нашем Final.glsl перед вызовом LensFlare().
    vec4 sunClipPos = gbufferProjection * vec4(sunPosition, 1.0);
    vec2 sunScreenPos = (sunClipPos.xy / sunClipPos.w) * 0.5 + 0.5;

    if (sunVisibility <= 0.0 || sunClipPos.w <= 0.0
        || sunScreenPos.x < -0.5 || sunScreenPos.x > 1.5
        || sunScreenPos.y < -0.5 || sunScreenPos.y > 1.5) {
        return lf;
    }

    vec2 coord = texcoord - 0.5;
    vec2 sunPos = sunScreenPos - 0.5;
    coord.x  *= aspectRatio;
    sunPos.x *= aspectRatio;

    float fovFactor = max(gbufferProjection[1][1], 2.0);

    #ifdef LENS_GLARE
        vec2 v = coord - sunPos;
        float dist = length(v);
        float gDist = dist * 13.0 / fovFactor;
        float phase = atan(v.y, v.x) + 0.131;

        float gl = 2.0 - saturate(gDist) + sin(phase * 12.0) * saturate(gDist * 2.5 - 0.2);
        gl = gl * gl;
        gDist = gDist * gDist;
        gl *= 8e-5 / (gDist * gDist);
        gl = min(gl, 200.0);

        lf += vec3(gl * GLARE_BRIGHTNESS);
    #endif

    #ifdef LENS_FLARE_ORB
        float size = 0.5 * fovFactor;
        vec3 fl = vec3(0.0);

        fl += DonorOrb(coord, sunPos, 0.0, size * 0.01) * 0.1;
        fl += DonorRing(coord, sunPos,  1.0, 0.02, 1.4) * 0.01;
        fl += DonorRing(coord, sunPos, -1.0, 0.02, 1.4) * 0.01;

        fl += DonorFlare(coord, sunPos, -2.00, 0.05, size * 0.05) * 0.5;
        fl += DonorFlare(coord, sunPos, -0.90, 0.02, size * 0.03) * 0.3;
        fl += DonorFlare(coord, sunPos, -0.70, 0.01, size * 0.06) * 0.5;
        fl += DonorFlare(coord, sunPos, -0.55, 0.02, size * 0.02) * 0.2;
        fl += DonorFlare(coord, sunPos, -0.35, 0.02, size * 0.04) * 0.7;
        fl += DonorFlare(coord, sunPos, -0.25, 0.01, size * 0.15) * vec3(0.3, 0.4, 0.38);
        fl += DonorFlare(coord, sunPos, -0.25, 0.02, size * 0.08) * 0.2;
        fl += DonorFlare(coord, sunPos,  0.05, 0.01, size * 0.03) * 0.1;
        fl += DonorFlare(coord, sunPos,  0.30, 0.02, size * 0.20) * vec3(0.2, 0.18, 0.14);
        fl += DonorFlare(coord, sunPos,  1.20, 0.03, size * 0.10) * 0.2;

        lf += fl * (FLARE_BRIGHTNESS * 0.3);
    #endif

    lf *= sunVisibility;

    return lf;
}

#endif // LENS_GLARE || LENS_FLARE_ORB
