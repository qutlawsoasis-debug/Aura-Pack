
#define DONOR3_BLOOM_AMOUNT    1.0   // [0.1 0.2 0.3 0.5 0.7 1.0 1.5 2.0 3.0 4.0 5.0 7.0 10.0]  Интенсивность донорского блума
#define DONOR3_BLOOMY_FOG_MUL  1.0   // [0.1 0.5 1.0 1.5 2.0]  Умножитель туманного блума
#define DONOR3_BLEND_MODE      2     // [0 1 2]  0=additive 1=mix 2=tone-preserve

vec4 DonorBicubic(sampler2D tex, vec2 coord, vec2 texSize) {
    vec2 texPixelSize = 1.0 / texSize;
    coord = coord * texSize - 0.5;
    vec2 p = floor(coord);
    vec2 f = coord - p;
    vec2 ff = f * f;
    vec4 w0, w1;
    w0.xz = 1.0 - f; w0.xz *= w0.xz * w0.xz;
    w1.yw = ff * f;
    w1.xz = 3.0 * w1.yw + 4.0 - 6.0 * ff;
    w0.yw = 6.0 - w1.xz - w1.yw - w0.xz;
    vec4 s = w0 + w1;
    vec4 c = p.xxyy + vec2(-0.5, 1.5).xyxy + w1 / s;
    c *= texPixelSize.xxyy;
    vec2 m = s.xz / (s.xz + s.yw);
    return mix(
        mix(textureLod(tex, c.yw, 0.0), textureLod(tex, c.xw, 0.0), m.x),
        mix(textureLod(tex, c.yz, 0.0), textureLod(tex, c.xz, 0.0), m.x),
        m.y
    );
}


vec3 DonorBloomRead(vec2 coord) {
   
    return CurveToLinear(DonorBicubic(colortex29, coord * 0.5, screenSize).rgb);
}


void ApplyDonorBloom(inout vec3 color, in ivec2 texel) {
    vec3 bloomData = DonorBloomRead(screenCoord);

    float bloomAmount = DONOR3_BLOOM_AMOUNT * 0.15;

    
    float exposure = texelFetch(colortex5, ivec2(0), 0).a;
    bloomAmount /= fma(max(exposure, 1.0), 0.7, 0.3);

    // Dirty Lens
    #if DIRT_STYLE > 0
    {
        float newAspectRatio = 1.777777777777778 / aspectRatio;
        vec2 scale = vec2(max(newAspectRatio, 1.0), max(1.0 / newAspectRatio, 1.0));
        vec2 dirtCoord = (screenCoord - 0.5) / scale + 0.5;
        float dirt = texture2D(DIRTY_LENS_SAMPLER, dirtCoord).r;
        float brightness = length(bloomData / (1.0 + bloomData));
        dirt *= brightness * DIRTY_LENS_STRENGTH;
        #ifdef DIRTY_LENS_BLOOM_BOOST
            bloomData *= (dirt * DIRTY_LENS_BLOOM_STRENGTH + 1.0);
        #else
            bloomData *= (dirt * 16.0 + 1.0);
        #endif
    }
    #endif

    // Туманный блум
    #ifdef BLOOMY_FOG
    {
        float fogTransmittance = texelFetch(colortex6, texel, 0).x;
        float fogMask = 1.0 - fogTransmittance;
        bloomAmount = max(bloomAmount, fogMask * DONOR3_BLOOMY_FOG_MUL * 0.1);
        color = mix(bloomData * DONOR3_BLOOMY_FOG_MUL * 0.5, color, fogTransmittance);
    }
    #endif

    // FUCK ME I HATE PORTING FROM OTHER SHADERS AND USE DCBUILDER THIS SHIT FU DUREXXX
    #if DONOR3_BLEND_MODE == 0
        color += bloomData * bloomAmount;
    #elif DONOR3_BLEND_MODE == 1
        color = mix(color, bloomData, bloomAmount);
    #else
        color = (color + bloomData * bloomAmount) / (1.0 + bloomAmount * 0.5);
    #endif


    #if !defined IS_NETHER
    if (isEyeInWater == 0 && wetness > 1e-2) {
        float rain = texelFetch(colortex0, texel, 0).b * 0.35;
        color = color * (1.0 - rain) + bloomData * rain * 1.25;
    }
    #endif
}
