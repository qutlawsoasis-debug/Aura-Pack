/*
================================================================================
  ReSTIR.glsl — Reservoir Spatio-Temporal Importance Resampling
  Зберігання в colortex8 (radiance + W) та colortex9 (hitNormal + M + wSum)

  Алгоритм:
    1. Initial Candidates   — генеруємо N кандидатів через RSM-семплінг
    2. Temporal Reuse       — зливаємо з попереднім резервуаром (з репроекцією)
    3. Spatial Reuse        — зливаємо з K сусідами по екрану
    4. Final Shading        — множимо radiance на W для отримання освітлення

  Без залежності від вокселів, SSBO чи Photonics.
================================================================================
*/

// ─── Compile-time tunables ────────────────────────────────────────────────────
#ifndef RESTIR_CANDIDATES
    #define RESTIR_CANDIDATES 4          // [1 2 3 4 6 8]  початкові кандидати
#endif
#ifndef RESTIR_TEMPORAL_MAX
    #define RESTIR_TEMPORAL_MAX 32.0     // максимальна кількість накоп. семплів
#endif
#ifndef RESTIR_SPATIAL_K
    #define RESTIR_SPATIAL_K 4           // [2 4 6 8]  сусідів для просторового reuse
#endif
#ifndef RESTIR_SPATIAL_RADIUS
    #define RESTIR_SPATIAL_RADIUS 10.0   // [4.0 6.0 8.0 10.0 12.0 16.0]  пікселів
#endif
#ifndef RESTIR_STRENGTH
    #define RESTIR_STRENGTH 1.0          // загальний множник яскравості ReSTIR
#endif
#ifndef RESTIR_SM_SAMPLES
    #define RESTIR_SM_SAMPLES 4          // [2 4 6 8]  семплів для shadow-map кандидатів
#endif
#ifndef RESTIR_SM_RADIUS
    #define RESTIR_SM_RADIUS 12.0        // [6.0 8.0 10.0 12.0 16.0 24.0]
#endif
#ifndef RESTIR_SM_BRIGHTNESS
    #define RESTIR_SM_BRIGHTNESS 1.0     // [0.5 0.75 1.0 1.25 1.5 2.0]
#endif
#ifndef RESTIR_GI_RADIUS
    #define RESTIR_GI_RADIUS 15.0        // радіус пошуку в RSM для кандидатів
#endif
#ifndef RESTIR_GI_STEPS
    #define RESTIR_GI_STEPS 8            // кроків пошуку в RSM для кандидатів
#endif
#ifndef RESTIR_DEPTH_TOL
    #define RESTIR_DEPTH_TOL 0.02        // допуск по глибині для просторового reuse
#endif
#ifndef RESTIR_NORMAL_TOL
    #define RESTIR_NORMAL_TOL 0.5        // мінімальний dot нормалей для spatial reuse
#endif

// ─── Reservoir ────────────────────────────────────────────────────────────────

struct Reservoir {
    vec3  radiance;   // накопичений колір / вибраний зразок
    vec3  hitNormal;  // нормаль у точці попадання луча
    float wSum;       // сума ваг кандидатів
    float W;          // кінцева незміщена вага  W = wSum / (M * p̂(y))
    float M;          // кількість накопичених семплів
};

// Порожній резервуар
Reservoir ReSTIR_Empty() {
    Reservoir r;
    r.radiance  = vec3(0.0);
    r.hitNormal = vec3(0.0);
    r.wSum      = 0.0;
    r.W         = 0.0;
    r.M         = 0.0;
    return r;
}

// Потоковий відбір O(1) — вибираємо зразок з імовірністю ∝ weight
bool ReSTIR_Update(inout Reservoir r, vec3 rad, vec3 norm, float weight, float rng) {
    r.wSum += weight;
    r.M    += 1.0;
    if (rng * r.wSum < weight) {
        r.radiance  = rad;
        r.hitNormal = norm;
        return true;
    }
    return false;
}

// Фінальна незміщена вага (викликати після всіх Update / Merge)
void ReSTIR_Finalize(inout Reservoir r, float targetPdf) {
    float denom = max(r.M, 1.0) * max(targetPdf, 1e-7);
    r.W = r.wSum / denom;
}

// Злиття двох резервуарів для spatial / temporal reuse
// targetPdf — p̂(src.y) на поточному пікселі
void ReSTIR_Merge(inout Reservoir dst, Reservoir src, float targetPdf, float rng) {
    float w = targetPdf * src.W * src.M;
    if (w > 0.0) {
        ReSTIR_Update(dst, src.radiance, src.hitNormal, w, rng);
        dst.M += src.M - 1.0; // -1 бо Update вже додав 1.0
    }
}

// ─── Packing / Unpacking ──────────────────────────────────────────────────────
// colortex8  → .rgb = radiance, .a = W
// colortex9  → .rg  = oct-encoded hitNormal, .b = M/255, .a = wSum

vec4 ReSTIR_PackA(Reservoir r) {
    return clamp16F(vec4(r.radiance, r.W));
}

vec4 ReSTIR_PackB(Reservoir r) {
    float mPacked = min(r.M, 255.0) * (1.0 / 255.0);
    return clamp16F(vec4(EncodeNormal(r.hitNormal), mPacked, r.wSum));
}

Reservoir ReSTIR_Unpack(vec4 a, vec4 b) {
    Reservoir r;
    r.radiance  = max(a.rgb, vec3(0.0));
    r.W         = max(a.a,   0.0);
    r.hitNormal = DecodeNormal(b.xy);
    r.M         = b.z * 255.0;
    r.wSum      = max(b.w, 0.0);
    return r;
}

// ─── Initial Candidate Generation (RSM-based) ─────────────────────────────────
// Генеруємо RESTIR_GI_STEPS кандидатів з shadow map і заповнюємо резервуар.
// Повертає резервуар з одним вибраним семплом та wSum для подальшого reuse.

Reservoir ReSTIR_GenerateCandidates(vec3 worldPos, vec3 worldNormal,
                                     float dither, float skyLightmap) {
    Reservoir r = ReSTIR_Empty();

    // --- shadow-space координати receiver ---
    vec3 shadowProj  = WorldToShadowProj(worldPos);
    vec3 shadowNorm  = mat3(shadowModelView) * worldNormal;
    shadowNorm.z     = -shadowNorm.z;

    const float realRes  = float(shadowMapResolution) * MC_SHADOW_QUALITY;
    const float scale    = RESTIR_GI_RADIUS * rcp(realRes);
    const float rSteps   = 1.0 / float(RESTIR_GI_STEPS);

    // golden-angle spiral
    const float goldenAngle  = TAU * (1.0 - rcp(PHI1 + 1.0));
    const mat2  goldenRotate = mat2(cos(goldenAngle), -sin(goldenAngle),
                                    sin(goldenAngle),  cos(goldenAngle));

    // RESTIR_CANDIDATES визначає скільки незалежних спіралей ми пускаємо
    const int totalSteps = RESTIR_GI_STEPS * RESTIR_CANDIDATES;

    vec2 rot = sincos(dither * TAU) * scale;
    float fi0 = dither * rSteps;

    uint seed = uint(gl_FragCoord.x) * 1973u + uint(gl_FragCoord.y) * 9277u;

    for (int i = 0; i < totalSteps; ++i, rot *= goldenRotate) {
        float fi     = float(i) * rSteps + fi0;
        vec2  coord  = shadowProj.xy + rot * fi;
        ivec2 texel  = ivec2(ShadowProjToUV(coord) * realRes);

        float sampleDepth = texelFetch(shadowtex1, texel, 0).x * 10.0 - 5.0;
        vec3  sv          = vec3(coord - shadowProj.xy, sampleDepth - shadowProj.z);

        float dist2 = dotSelf(sv);
        if (dist2 < 1e-10) continue;

        // глибинний кліп
        const float baseDepthDiff = scale * GI_DEPTH_TOLERANCE;
        float slopeBias = 1.0 - abs(dot(shadowNorm, sv * inversesqrt(dist2)));
        if (abs(sv.z) > baseDepthDiff * (1.0 + slopeBias * 2.5)) continue;

        vec3 sampleDir = sv * inversesqrt(dist2);

        float diffuse = WrapCos(dot(shadowNorm, sampleDir));
        if (diffuse < 1e-5) continue;

        RSMSample rsmS = GetRSMSample(texel);
        if (!rsmS.valid) continue;

        float bounce = WrapCos(dot(rsmS.normal, sampleDir));
        if (bounce < 1e-5) continue;

        // falloff
        const float sqRef    = RESTIR_GI_RADIUS * RESTIR_GI_RADIUS;
        const float radAdd   = sqrt(sqRef * rSteps);
        float falloff = rcp(dist2 + radAdd * radAdd * 0.5);

        float sqNormDist = dot(sv.xy / scale, sv.xy / scale);
        float edgeFade   = saturate(1.0 - sqNormDist);
        falloff *= edgeFade * edgeFade;

        #if defined IS_OVERWORLD
            float skylightW = rsmS.isGlass ? 1.0 : SkylightWeight(rsmS.skylight, skyLightmap, 4.0);
        #else
            float skylightW = 1.0;
        #endif

        float woolBoost = rsmS.isWool ? GI_WOOL_BOUNCE_BOOST : 1.0;

        vec3  radiance = rsmS.albedo * falloff * skylightW * bounce * diffuse * woolBoost;
        float targetPdf = dot(radiance, vec3(0.2126, 0.7152, 0.0722)) + 1e-6;

        // псевдовипадкове число
        seed = seed * 747796405u + 2891336453u;
        float rng = float(seed >> 8u) * (1.0 / 16777216.0);

        ReSTIR_Update(r, radiance, rsmS.normal, targetPdf, rng);
    }

    return r;
}

// ─── Temporal Reuse ───────────────────────────────────────────────────────────
// Завантажує попередній резервуар з colortex8/9, робить репроекцію,
// перевіряє валідність і зливає з поточним.

Reservoir ReSTIR_TemporalReuse(Reservoir cur, vec3 worldPos, vec3 worldNormal,
                                 float depth, float dither) {
    // репроекція у минулий кадр
    vec4 prevClip = gbufferPreviousProjection *
                    (gbufferPreviousModelView * vec4(worldPos, 1.0));
    vec3 prevNDC  = prevClip.xyz / prevClip.w;
    vec2 prevUV   = prevNDC.xy * 0.5 + 0.5;

    if (clamp(prevUV, 0.0, 1.0) != prevUV) return cur; // поза екраном

    ivec2 prevTexel = ivec2(prevUV * vec2(viewWidth, viewHeight) * 0.5);

    vec4 prevA = texelFetch(colortex8, prevTexel, 0);
    vec4 prevB = texelFetch(colortex9, prevTexel, 0);
    Reservoir prev = ReSTIR_Unpack(prevA, prevB);

    // обрізаємо M щоб уникнути надмірного накопичення
    prev.M = min(prev.M, RESTIR_TEMPORAL_MAX);

    // перевіряємо нормаль (валідність пікселя)
    if (dot(prev.hitNormal, worldNormal) < RESTIR_NORMAL_TOL) return cur;

    float curPdf = dot(cur.radiance, vec3(0.2126, 0.7152, 0.0722)) + 1e-6;

    uint seed = uint(gl_FragCoord.x) * 3119u + uint(gl_FragCoord.y) * 6271u;
    seed = seed * 747796405u + 2891336453u;
    float rng = float(seed >> 8u) * (1.0 / 16777216.0);

    Reservoir merged = cur;
    ReSTIR_Merge(merged, prev, curPdf, rng);
    ReSTIR_Finalize(merged, curPdf);

    return merged;
}

// ─── Spatial Reuse ────────────────────────────────────────────────────────────
// Збирає RESTIR_SPATIAL_K сусідів, перевіряє геометрію і зливає резервуари.

Reservoir ReSTIR_SpatialReuse(Reservoir cur, vec3 worldNormal,
                                float depth, float dither, ivec2 texel) {
    float curPdf = dot(cur.radiance, vec3(0.2126, 0.7152, 0.0722)) + 1e-6;
    Reservoir merged = cur;

    uint seed = uint(texel.x) * 2333u + uint(texel.y) * 4651u
              + uint(frameCounter) * 7919u;

    for (int k = 0; k < RESTIR_SPATIAL_K; ++k) {
        seed = seed * 747796405u + 2891336453u;
        float ra = float(seed >> 8u) * (1.0 / 16777216.0);
        seed = seed * 747796405u + 2891336453u;
        float rb = float(seed >> 8u) * (1.0 / 16777216.0);

        // рівномірно по диску
        float r   = RESTIR_SPATIAL_RADIUS * sqrt(ra);
        float ang = rb * TAU + dither * TAU;
        ivec2 off = ivec2(vec2(cos(ang), sin(ang)) * r);
        ivec2 nbTexel = texel + off;

        // перевірка кордонів (половинна роздільна здатність)
        ivec2 maxTex = ivec2(viewWidth, viewHeight) / 2 - 1;
        if (clamp(nbTexel, ivec2(0), maxTex) != nbTexel) continue;

        // геометрична перевірка по глибині
        float nbDepth = texelFetch(depthtex0, nbTexel * 2, 0).x;
        if (abs(nbDepth - depth) > RESTIR_DEPTH_TOL * max(depth, 0.01)) continue;

        // перевірка нормалі
        vec4 nbB = texelFetch(colortex9, nbTexel, 0);
        vec3 nbNormal = DecodeNormal(nbB.xy);
        if (dot(nbNormal, worldNormal) < RESTIR_NORMAL_TOL) continue;

        vec4 nbA = texelFetch(colortex8, nbTexel, 0);
        Reservoir nb = ReSTIR_Unpack(nbA, nbB);

        seed = seed * 747796405u + 2891336453u;
        float rng = float(seed >> 8u) * (1.0 / 16777216.0);

        ReSTIR_Merge(merged, nb, curPdf, rng);
    }

    ReSTIR_Finalize(merged, curPdf);
    return merged;
}

// ─── Final Output ─────────────────────────────────────────────────────────────
// Повертає остаточний внесок освітлення від ReSTIR.
// Викликати після SpatialReuse.

vec3 ReSTIR_Shade(Reservoir r, float skyLightmap) {
    float giIntensity = RESTIR_STRENGTH * GI_STRENGTH * GI_SkyIntensity(skyLightmap);
    return clamp16F(r.radiance * r.W * giIntensity);
}
