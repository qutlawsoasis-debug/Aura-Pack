// lib/Lighting/VoxelSample.glsl
// Семплює voxel floodfill grid у deferred/composite шейдерах.
// #include "/lib/Lighting/VoxelSample.glsl"
//
// Потребує:
//   uniform sampler3D colortex30;  (voxelGridA — фінальний результат після propagate)
//   uniform vec3 cameraPosition;

#ifndef VOXEL_VOLUME_SIZE
    #define VOXEL_VOLUME_SIZE 64
#endif

#ifndef VOXEL_FLOODFILL_BRIGHTNESS
    #define VOXEL_FLOODFILL_BRIGHTNESS 1.0
#endif

// worldPos — абсолютна позиція у світі (local viewspace + cameraPosition)
vec3 SampleVoxelLight(vec3 worldPos) {
    vec3 gridOrigin = floor(cameraPosition) - vec3(float(VOXEL_VOLUME_SIZE) * 0.5);

    vec3 local = worldPos - gridOrigin;
    vec3 uvw = local / float(VOXEL_VOLUME_SIZE);

    if (any(lessThan(uvw, vec3(0.0))) || any(greaterThan(uvw, vec3(1.0)))) {
        return vec3(0.0);
    }

    // colortex30 = voxelGridA (після всіх кроків propagate)
    return texture(colortex30, uvw).rgb;
}

// Версія зі зміщенням по нормалі — щоб світло не протікало крізь стіни.
// normal — нормаль у world space (mat3(gbufferModelViewInverse) * viewNormal)
vec3 SampleVoxelLightNormal(vec3 worldPos, vec3 normal) {
    return SampleVoxelLight(worldPos + normal * 0.6);
}
