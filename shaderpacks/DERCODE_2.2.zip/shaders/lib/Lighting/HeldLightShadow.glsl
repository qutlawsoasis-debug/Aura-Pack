#ifndef HELD_LIGHT_SHADOW_GLSL
#define HELD_LIGHT_SHADOW_GLSL
#ifndef HELD_LIGHT_FOV
	#define HELD_LIGHT_FOV 0.35 // [-0.10 -0.15 -0.20 -0.25 -0.30 -0.35 -0.40 -0.45 -0.50 -0.55 -0.60 -0.65 -0.70 -0.75 -0.80 -0.85 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85]
#endif
#ifndef HELD_LIGHT_COLOR_TEMP
	#define HELD_LIGHT_COLOR_TEMP 1 // [1 2]
#endif
#ifndef HELD_LIGHT_SHADOW_INTENSITY
	#define HELD_LIGHT_SHADOW_INTENSITY 1.0
#endif
#ifndef COLORED_HAND_LIGHT
	#define COLORED_HAND_LIGHT 1 // [0 1] 
#endif
#define HELD_LIGHT_RANGE 10

//----------------------------------------------------------------------------------------------//

#if HELD_LIGHT_COLOR_TEMP == 1
	const vec3 heldLightColorDefault = vec3(1.0, 0.78, 0.5);
#elif HELD_LIGHT_COLOR_TEMP == 2
	const vec3 heldLightColorDefault = vec3(0.75, 0.85, 1.0);
#else
	const vec3 heldLightColorDefault = vec3(1.0);
#endif

// IsHandLightItem визначена поза COLORED_HAND_LIGHT — потрібна завжди
bool IsHandLightItem(int item) {
	return (item >= 13001 && item <= 13013) || (item >= 15013 && item <= 15016);
}

#if COLORED_HAND_LIGHT == 1

vec3 GetHandLightColorByItem(int item) {
	if (item == 13001) return vec3(0.9, 0.3686, 0.0);      // Glowstone, Torch, Jack'o Lantern, Lantern, Campfire, Shroomlight, Lava Bucket, Blaze Rod
	if (item == 13002) return vec3(0.4863, 0.7686, 0.9882); // Beacon
	if (item == 13003) return vec3(0.4863, 0.0235, 0.0235); // Redstone Torch
	if (item == 13004) return vec3(0.0, 0.1843, 0.6);       // Soul Lantern, Soul Campfire, Soul Torch
	if (item == 13005) return vec3(0.0, 0.8549, 0.6667);    // Sea Lantern
	if (item == 13006) return vec3(0.9765, 0.3412, 1.0);    // End Rod, Crying Obsidian, End Crystal, Nether Star
	if (item == 13007) return vec3(0.8275, 0.8314, 0.4118); // Sea Pickle
	if (item == 13008) return vec3(0.9922, 0.9255, 0.7059); // Conduit
	if (item == 13009) return vec3(0.8275, 0.8314, 0.4118); // Froglight Ochre
	if (item == 13010) return vec3(0.4941, 0.8314, 0.4118); // Froglight Verdant
	if (item == 13011) return vec3(0.7294, 0.5412, 0.9725); // Froglight Pearlescent
	if (item == 13012) return vec3(1.0, 0.2353, 0.0);       // Magma Block
	if (item == 13013) return vec3(1.0, 0.5529, 0.3216);    // Copper Bulb 
	if (item == 15013) return vec3(1.0, 0.5882, 0.2941);    // Copper Lantern
	if (item == 15014) return vec3(1.0, 1.6235, 0.3608);    // Exposed Copper Lantern 
	if (item == 15015) return vec3(0.7137, 1.7569, 0.4980); // Weathered Copper Lantern 
	if (item == 15016) return vec3(0.4078, 2.7137, 0.5333); // Oxidized Copper Lantern 

	return heldLightColorDefault;
}

vec3 GetHandLightColor() {
	bool leftLit  = IsHandLightItem(heldItemId2);
	bool rightLit = IsHandLightItem(heldItemId);

	if (!leftLit && !rightLit) return heldLightColorDefault;

	vec3 leftCol  = leftLit  ? GetHandLightColorByItem(heldItemId2) : vec3(0.0);
	vec3 rightCol = rightLit ? GetHandLightColorByItem(heldItemId)  : vec3(0.0);

	if (leftLit && rightLit) {
		float xpos = (gl_FragCoord.x / viewWidth) * 2.0 - 1.0;
		float fade = (clamp(xpos * 2.0, -1.0, 1.0) + 1.0) * 0.5;
		return mix(leftCol, rightCol, fade);
	} else if (leftLit) {
		return leftCol;
	} else {
		return rightCol;
	}
}

#endif // COLORED_HAND_LIGHT

//----------------------------------------------------------------------------------------------//
// Дальність тіні залежить від предмету в руці
// Множники відносно HELD_LIGHT_RANGE:
//   Redstone Torch    — 0.45 (слабий червоний, коротка тінь)
//   Soul Torch/etc    — 0.60 (холодний синій, слабше звичайного)
//   Magma Block       — 0.50 (тліючий, розсіяний)
//   Звичайний факел/etc — 1.00 (дефолт)
//   Sea Lantern       — 1.10 (трохи яскравіше і далі)
//   End Rod / Nether  — 1.30 (направлене чисте світло)
//   Beacon            — 1.50 (максимальна дальність)
//----------------------------------------------------------------------------------------------//

float GetHandLightShadowRange(int item) {
	if (item == 13003) return HELD_LIGHT_RANGE * 0.45; // Redstone Torch
	if (item == 13004) return HELD_LIGHT_RANGE * 0.60; // Soul Torch / Soul Lantern / Soul Campfire
	if (item == 13012) return HELD_LIGHT_RANGE * 0.50; // Magma Block
	if (item == 13005) return HELD_LIGHT_RANGE * 1.10; // Sea Lantern
	if (item == 13006) return HELD_LIGHT_RANGE * 1.30; // End Rod, Crying Obsidian, End Crystal, Nether Star
	if (item == 13002) return HELD_LIGHT_RANGE * 1.50; // Beacon
	// Все інше (факел, ліхтар, glowstone, campfire, shroomlight тощо) — дефолт
	return HELD_LIGHT_RANGE;
}

// Повертає дальність тіні для активного предмету (права рука в пріоритеті)
float GetActiveShadowRange() {
	bool rightLit = IsHandLightItem(heldItemId);
	bool leftLit  = IsHandLightItem(heldItemId2);
	if (rightLit) return GetHandLightShadowRange(heldItemId);
	if (leftLit)  return GetHandLightShadowRange(heldItemId2);
	return HELD_LIGHT_RANGE;
}

//----------------------------------------------------------------------------------------------//

float HeldLightSpotShape(float r) {
	float shape = curve(saturate(r * 2.0 - (2.0 - HELD_LIGHT_FOV)));
	shape += curve(saturate(r * 1.25 - (1.0 - HELD_LIGHT_FOV))) * 0.01;
	return shape;
}

//----------------------------------------------------------------------------------------------//
//FU DUREXXX
//----------------------------------------------------------------------------------------------//
// shadowRange — дальність тіні для даного предмету (з GetActiveShadowRange)
float HeldLightScreenSpaceShadow(vec3 viewPos, vec3 viewDir, vec3 normal, vec3 shadowDir, float dither, float shadowIntensity, float shadowRange) {
	shadowDir.z = max(shadowDir.z, 1e-5);

	float rayLength = -0.04 * viewPos.z / shadowDir.z;
	// Масштабуємо довжину променя пропорційно shadowRange / HELD_LIGHT_RANGE
	rayLength *= (shadowRange / max(HELD_LIGHT_RANGE, 1e-4));

	vec3 viewRayDir = shadowDir * rayLength;

	vec3 start = viewPos;

	float pixelScale = max(screenPixelSize.x, screenPixelSize.y);
	float NdotL = saturate(dot(shadowDir, normal));

	float fov = atan(1.0 / gbufferProjection[1][1]) * 360.0 * rPI;
	start += viewRayDir * (pixelScale * max(0.04 / max(dot(normal, -viewDir), 0.1), 1e3));
	start += normal * (8e-3 * fov * -viewPos.z * pixelScale / max(NdotL, 0.01));

	vec3 end = start + viewRayDir;

	start = vec3(vec2(gbufferProjection[0][0], gbufferProjection[1][1]) * start.xy, -start.z);
	end   = vec3(vec2(gbufferProjection[0][0], gbufferProjection[1][1]) * end.xy,   -end.z);

	vec3 screenRayDir = (end - start);
	screenRayDir.xy *= 0.5;

	start.xy += gbufferProjection[3].xy;
	start.xy *= 0.5;

	vec2 offsetCoord = vec2(0.5);
	#ifdef TAA_ENABLED
		offsetCoord = 0.5 + taaOffset * 0.5;
	#endif

	float minDist = GetDepthLinear(0.7);

	float shadow = 2.1;
	float stepLength = 1.0;

	for (int i = 0; i < 8; i++, start += screenRayDir * stepLength, stepLength += 0.3) {
		vec3 samplePos = start + screenRayDir * dither * stepLength;

		if (samplePos.z < minDist) break;

		samplePos.xy = samplePos.xy / samplePos.z + offsetCoord;

		if (saturate(samplePos.xy) != samplePos.xy) break;

		float sampleDepth = textureLod(depthtex1, samplePos.xy, 0.0).x;

		if (sampleDepth < 0.7) break;

		float sampleDist = GetDepthLinear(sampleDepth);

		if (samplePos.z - sampleDist > 0.0) {
			shadow = 0.0;
			break;
		}
	}

	// shadow = 0.0 означає окклюдер знайдено, 2.1 = нема тіні
	float hit = step(shadow, 0.5);
	return 1.0 - hit * saturate(shadowIntensity);
}


vec3 HeldLighting(vec3 viewPos, vec3 viewDir, vec3 normal, float dither) {
	vec3 result = vec3(0.0);

	#if HELD_LIGHT_ENABLED == 1
		float heldStrength = max(float(heldBlockLightValue), float(heldBlockLightValue2)) * (1.0 / 15.0);
		if (heldStrength <= 0.0) return result;

		#if COLORED_HAND_LIGHT == 1
			vec3 heldLightColor = GetHandLightColor();
		#else
			vec3 heldLightColor = heldLightColorDefault;
		#endif

		float activeShadowRange = GetActiveShadowRange();

		#if HELD_LIGHT_MODE == 1
			
			vec3 lightPos = vec3(HELD_LIGHT_POS_R_X, HELD_LIGHT_POS_R_Y, 0.0);
			vec3 toSurface = viewPos - lightPos;
			float dist = length(toSurface);
			vec3 shadowDir = toSurface / max(dist, 1e-4);

			if (dist < activeShadowRange) {
				float spot = HeldLightSpotShape(dot(shadowDir, vec3(0.0, 0.0, -1.0)));
				float atten = pow(max(dist, 0.6), -2.2) * smoothstep(activeShadowRange, activeShadowRange * 0.5, dist);

				float lightAmount = spot * atten;

				if (lightAmount > 1e-4) {
					#if HELD_LIGHT_SHADOW == 1
						lightAmount *= HeldLightScreenSpaceShadow(viewPos, viewDir, normal, -shadowDir, dither, HELD_LIGHT_SHADOW_INTENSITY, activeShadowRange);
					#endif

					float NdotL = max(0.0, dot(normal, -shadowDir));
					result = heldLightColor * (lightAmount * NdotL * HELD_LIGHT_BRIGHTNESS * heldStrength);
				}
			}
		#else
		
			vec3 lightPosR = vec3(HELD_LIGHT_POS_R_X, HELD_LIGHT_POS_R_Y, 0.0);
			vec3 toSurfaceR = viewPos - lightPosR;
			float distR = length(toSurfaceR);
			vec3 shadowDirR = toSurfaceR / max(distR, 1e-4);

			float attenR = pow(max(distR, 0.6), -HELD_LIGHT_FALLOFF);
			float NdotLR = max(0.0, dot(normal, -shadowDirR));
			float lightAmountR = attenR * NdotLR;

			if (lightAmountR > 1e-4) {
				#if HELD_LIGHT_SHADOW == 1
					lightAmountR *= HeldLightScreenSpaceShadow(viewPos, viewDir, normal, -shadowDirR, dither, HELD_LIGHT_SHADOW_INTENSITY, activeShadowRange);
				#endif

				result += heldLightColor * lightAmountR;
			}
		#endif

		result *= HELD_LIGHT_BRIGHTNESS * heldStrength * 0.6;
	#endif

	return result;
}

#endif // HELD_LIGHT_SHADOW_GLSL
