

#ifndef SSGI_SLICES
    #define SSGI_SLICES 4
#endif
#ifndef SSGI_RAY_STEPS
    #define SSGI_RAY_STEPS 8
#endif
#ifndef SSGI_RADIUS
    #define SSGI_RADIUS 0.5
#endif
#ifndef SSGI_RAY_THICKNESS
    #define SSGI_RAY_THICKNESS 0.3
#endif
#ifndef SSGI_STRENGTH
    #define SSGI_STRENGTH 1.0
#endif

// Косинусно-зважений сэмпл по полусфері
vec3 SSGI_CosHemisphereSample(vec3 normal, vec2 u) {
    float r     = sqrt(u.x);
    float theta = TAU * u.y;

    vec3 up      = abs(normal.y) > 0.99 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
    vec3 tangent = normalize(cross(normal, up));
    vec3 bitan   = cross(normal, tangent);

    return tangent * (r * cos(theta))
         + bitan   * (r * sin(theta))
         + normal  * sqrt(max(0.0, 1.0 - u.x));
}

// Визначаємо колір і силу емісиву за blockLight + albedo хіт-пікселя.
// Блоки з block.properties ID > 255 обрізаються при збереженні в colortex7.z,
// тому єдиний надійний спосіб — читати blockLight (colortex7.x) і колір альбедо.
vec3 SSGI_GetEmissive(vec2 hitUV, vec3 albedo) {
    float emLum = textureLod(colortex7, hitUV, 0).w;
    if (emLum < 0.01) return vec3(0.0);
    // Відновлюємо колір: luminance * albedo (зберігає відтінок)
    float albedoLum = max(GetLuminance(albedo), 0.001);
    return albedo * (emLum * 16.0 / albedoLum);
}

vec3 CalculateSSGI(vec3 viewPos, vec3 viewNormal, float dither) {
    vec3  indirectLight = vec3(0.0);
    float totalWeight   = 0.0;

    // Базовий рандом-сід: координати пікселя + кадр
    vec2 randSeed = hash2(vec3(gl_FragCoord.xy, float(frameCounter)));

    for (int i = 0; i < SSGI_SLICES; i++) {
        // Квазі-рандомні координати для семплу (golden ratio shuffle)
        vec2 u = fract(randSeed + vec2(float(i) * 0.6180339887, float(i) * 0.7548776662) + dither * 0.5);

        vec3 rayDir = SSGI_CosHemisphereSample(viewNormal, u);

        // Перший крок з jitter, щоб прибрати banding
        float stepSize   = SSGI_RADIUS / float(SSGI_RAY_STEPS);
        vec3  rayStep    = rayDir * stepSize;
        vec3  currentPos = viewPos + rayStep * (dither * 0.5 + 0.5);

        vec3  hitColor  = vec3(0.0);
        float hitWeight = 0.0;

        for (int j = 0; j < SSGI_RAY_STEPS; j++) {
            vec3 sampleScreen = ViewToScreenSpace(currentPos);

            // Виходимо за межі екрана — стоп
            if (clamp(sampleScreen.xy, 0.0, 1.0) != sampleScreen.xy || sampleScreen.z > 1.0) break;

            // Семплуємо тверду геометрію (depthtex1, без прозорих блоків)
            float sampleDepth   = texelFetch(depthtex1, ivec2(sampleScreen.xy * screenSize), 0).x;
            vec3  sampleViewPos = ScreenToViewSpace(vec3(sampleScreen.xy, sampleDepth));

            float thickness = currentPos.z - sampleViewPos.z;

            // Перетин знайдено — збираємо колір
            if (thickness > 0.0 && thickness < SSGI_RAY_THICKNESS) {
                vec2 hitUV = sampleScreen.xy;

                // Читаємо albedo і lightmap хіт-пікселя
                vec3 albedo  = textureLod(colortex6, hitUV, 0).rgb;
                vec4  lmData  = textureLod(colortex7, hitUV, 0);
                float blockLM = lmData.x; // blockLight 0-1
                int   matID   = int(lmData.z * 255.0 + 0.5);

                // Emissive від факелів та інших світних блоків
                vec3 emissive = SSGI_GetEmissive(hitUV, albedo);

                // Мідні лампи (включені) — matID 80–87, зберігаються коректно
                if (matID >= 80 && matID <= 87) {
                    emissive = albedo * vec3(1.0, 0.55, 0.25) * 12.0;
                }

                // Відбитий GI з попереднього кадру (bounce від сонця/неба)
                // colortex0 зберігає indirect lighting в лівій половині (0..0.5 x)
                vec3 bounceLight = textureLod(colortex0, hitUV * vec2(0.5, 1.0), 0).rgb;

                // Фінальний колір хіту = emissive + bounce відбитий альбедо
                hitColor = emissive + bounceLight * albedo;

                // Нормаль у точці попадання (для врахування кута відбиття)
                vec3 hitNormal     = DecodeNormal(textureLod(colortex3, hitUV, 0).xy);
                vec3 hitNormalView = mat3(gbufferModelView) * (mat3(gbufferModelViewInverse) * hitNormal);

                float dist        = distance(viewPos, sampleViewPos);
                float attenuation = 1.0 / (1.0 + dist * dist * 0.5);
                float bounce      = saturate(dot(-rayDir, hitNormalView));

                hitWeight = attenuation * bounce;
                break;
            }

            // Логарифмічне збільшення кроку — більше покриття без додаткових кроків
            currentPos += rayStep;
            rayStep    *= 1.15;
        }

        indirectLight += hitColor * hitWeight;
        totalWeight   += 1.0;
    }

    if (totalWeight > 0.0) {
        indirectLight /= totalWeight;
    }

    return clamp16F(indirectLight * SSGI_STRENGTH);
}
