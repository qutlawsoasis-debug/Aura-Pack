#define SSIL_ENABLED                 // [0 1]
#define SSIL_SAMPLES         12      // [6 8 12 16 24 32]
#define SSIL_SLICES           8      // [2 3 4 6 8]
#define SSIL_RADIUS           0.12   // [0.05 0.08 0.1 0.12 0.15 0.2 0.25 0.3]
#define SSIL_THICKNESS        1.5    // [0.5 1.0 1.5 2.0 3.0 4.0]
#define SSIL_LIGHT_STRENGTH   10.2    // [0.1 0.3 0.5 0.7 1.0 1.2 1.5 2.0 3.0]
#define SSIL_SHADOW_STRENGTH  0.8    // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Сила/разброс шума (джиттера) — больше = более рваные/шумные тени
#define SSIL_NOISE_AMOUNT     1.0    // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0 4.0]
// Доп. усиление контраста самих теней от шума (помимо SSIL_SHADOW_STRENGTH)
#define SSIL_SHADOW_CONTRAST  1.0    // [0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 4.0]

// 0 = тень НЕ зависит от ванильной lightmap (убирает видимую границу-пятиугольник,
//     остаются только тени от шума/дизеринга SSIL)
// 1 = оригинальное поведение (тень масштабируется blockLightmap)
#define SSIL_SHADOW_USE_LIGHTMAP 0

// Порог, ниже которого SSIL вообще не считается (для производительности).
// Сделан маленьким, чтобы не создавать собственную видимую границу.
#define SSIL_MIN_LIGHTMAP 0.02

#ifdef SSIL_ENABLED

vec4 CalculateSSIL(vec2 coord, vec3 viewPos, vec3 normal, vec3 torchColor, float blockLightmap) {
    if (blockLightmap < SSIL_MIN_LIGHTMAP) return vec4(0.0, 0.0, 0.0, 1.0);

    vec3  indirectLight = vec3(0.0);
    float shadowFactor  = 0.0;
    float weightTotal   = 0.0;

    float jitter = fract(
        52.9829189 * fract(0.06711056 * coord.x * screenSize.x
                         + 0.00583715 * coord.y * screenSize.y)
        + float(frameCounter) * 0.618034
    );

    float jitterScaled = jitter * SSIL_NOISE_AMOUNT;

    float sliceAngleStep = TAU / float(SSIL_SLICES);

    for (int slice = 0; slice < SSIL_SLICES; ++slice) {
        float angle = (float(slice) + jitterScaled) * sliceAngleStep;
        vec2 dir = normalize(vec2(cos(angle), sin(angle) * aspectRatio))
                 * vec2(1.0 / aspectRatio, 1.0);

        float stepSize  = SSIL_RADIUS / float(SSIL_SAMPLES);
        float curLen    = stepSize * (0.5 + jitterScaled * 0.5);

        vec3  sliceLight  = vec3(0.0);
        float sliceShadow = 0.0;
        float sliceWeight = 0.0;

        for (int s = 0; s < SSIL_SAMPLES; ++s, curLen += stepSize) {
            vec2 sampleUV = coord + dir * curLen;
            if (clamp(sampleUV, 0.001, 0.999) != sampleUV) continue;

            ivec2 sTexel = ivec2(sampleUV * screenSize);
            float sDepth = texelFetch(depthtex0, sTexel, 0).x;
            if (sDepth >= 1.0) continue;

            vec3  sViewPos = ScreenToViewSpace(vec3(sampleUV, sDepth));
            vec3  diff     = sViewPos - viewPos;
            float distSq   = dot(diff, diff);
            if (distSq < 1e-4) continue;

            float dist    = sqrt(distSq);
            vec3  diffDir = diff / dist;
            float NdotS   = dot(normal, diffDir);

            float falloff = saturate(1.0 - dist / SSIL_RADIUS);
            falloff      *= falloff;

            float sBlockLM = texelFetch(colortex7, sTexel, 0).r;
            float sBlockLMCurved = sBlockLM;
            GetBlocklightFalloff(sBlockLMCurved);

            // Тени (мягкие, по разнице lightmap)
            if (sBlockLM < blockLightmap - 0.1 && NdotS > 0.05) {
                float diff_lm    = saturate((blockLightmap - sBlockLM) * 5.0);
                float thickCheck = saturate(abs(sViewPos.z - viewPos.z) / SSIL_THICKNESS);
                float shadowC    = diff_lm * falloff * NdotS * (1.0 - thickCheck * 0.5);
                sliceShadow     += shadowC;
                sliceWeight     += falloff;
            }

            // Непрямой свет
            if (sBlockLM > 0.08 && NdotS > 0.0) {
                vec3 sAlbedo    = SRGBtoLinear(texelFetch(colortex6, sTexel, 0).rgb);
                vec3 lightColor = sAlbedo * sBlockLMCurved * torchColor;
                float bounce    = saturate(-NdotS * 0.5 + 0.5);
                float thickness = abs(sViewPos.z - viewPos.z);
                float thickMask = saturate(1.0 - thickness / SSIL_THICKNESS);
                sliceLight  += lightColor * falloff * bounce * thickMask;
                sliceWeight += falloff;
            }
        }

        if (sliceWeight > 1e-5) {
            indirectLight += sliceLight  / sliceWeight;
            shadowFactor  += sliceShadow / sliceWeight;
        }
        weightTotal += 1.0;
    }

    if (weightTotal > 0.0) {
        indirectLight /= weightTotal;
        shadowFactor  /= weightTotal;
    }

    shadowFactor *= SSIL_SHADOW_CONTRAST;

    #if SSIL_SHADOW_USE_LIGHTMAP == 1
        float shadow = 1.0 - saturate(shadowFactor * SSIL_SHADOW_STRENGTH * 4.0) * blockLightmap;
    #else
        float shadow = 1.0 - saturate(shadowFactor * SSIL_SHADOW_STRENGTH * 4.0);
    #endif

    return vec4(indirectLight * SSIL_LIGHT_STRENGTH, shadow);
}

#endif