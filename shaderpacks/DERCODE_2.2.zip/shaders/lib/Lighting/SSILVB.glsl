

//================================================================================================//
// CONFIG
//================================================================================================//
#ifndef SSILVB_ENABLED
    #define SSILVB_ENABLED 0            // [0 1]
#endif
#ifndef SSILVB_SLICE_COUNT
    #define SSILVB_SLICE_COUNT 1        // [1 2 3 4] — больше срезов = меньше шума, дороже (на fragment shader держим низким)
#endif
#ifndef SSILVB_SAMPLE_COUNT
    #define SSILVB_SAMPLE_COUNT 12      // [4 6 8 10 12 14 16 18 20 24 28 32]
#endif
#ifndef SSILVB_SECTOR_COUNT
    #define SSILVB_SECTOR_COUNT 32      // [4 8 16 32]
#endif
#ifndef SSILVB_HIT_THICKNESS
    #define SSILVB_HIT_THICKNESS 1.0    // [0.25 0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 5.5 6.0 6.5 7.0 7.5 8.0]
#endif
#ifndef SSILVB_RADIUS
    #define SSILVB_RADIUS 1.0           // [0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0] — масштаб длины трассировки луча
#endif
#ifndef SSILVB_STRENGTH
    #define SSILVB_STRENGTH 0.5         // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0]
#endif
#ifndef SSILVB_MAX_RADIANCE
    #define SSILVB_MAX_RADIANCE 64.0   // [64.0 128.0 256.0 512.0 1024.0 2048.0] — клэмп яркости семпла (от вспышек/огней)
#endif

//================================================================================================//
// ЛОКАЛЬНЫЕ МАТЕМАТИЧЕСКИЕ ХЕЛПЕРЫ (изолированы под SSILVB_, чтобы не конфликтовать
// с одноимёнными функциями в остальном шейдере)
//================================================================================================//

float SSILVB_EPS = 1e-7;

float SSILVB_SatSnorm(float x) { return clamp(x, -1.0, 1.0); }
vec2  SSILVB_SatSnorm(vec2  x) { return clamp(x, vec2(-1.0), vec2(1.0)); }

float SSILVB_SignMul(float y, float x) { return x >= 0.0 ? y : -y; }
float SSILVB_SignI(float x) { return x >= 0.0 ? 1.0 : -1.0; }

// 4th order polynomial acos approximation (Drobot, ShaderFastMathLib)
float SSILVB_AcosFast4(float inX) {
    float x1 = abs(inX);
    float x2 = x1 * x1;
    float x3 = x2 * x1;
    float s;
    s = -0.2121144 * x1 + 1.5707288;
    s =  0.0742610 * x2 + s;
    s = -0.0187293 * x3 + s;
    s =  sqrt(1.0 - x1) * s;
    return inX >= 0.0 ? s : PI - s;
}
vec2 SSILVB_AcosFast4(vec2 inX) {
    return vec2(SSILVB_AcosFast4(inX.x), SSILVB_AcosFast4(inX.y));
}
float SSILVB_AsinFast4(float inX) { return (PI * 0.5) - SSILVB_AcosFast4(inX); }

vec2 SSILVB_Cmul(vec2 c0, vec2 c1) {
    return vec2(c0.x * c1.x - c0.y * c1.y, c0.y * c1.x + c0.x * c1.y);
}

float SSILVB_SamplePartialSlice(float x, float sin_thVN) {
    float abs_x = abs(x);
    if ((abs_x - 0.5) < 0.5) {
        float s = sin_thVN;

        float o = s - s * s;
        float slp0 = 1.0 / (1.0 + (PI  - 1.0) * (s - o * 0.30546));
        float slp1 = 1.0 / (1.0 - (1.0 - exp2(-20.0)) * (s + o * mix(0.5, 0.785, s)));
        float k = mix(0.1, 0.25, s);

        const float a = 1.0 - (PI - 2.0) / (PI - 1.0);
        const float b = 1.0 / (PI - 1.0);

        float d0 =   a - slp0 * b;
        float d1 = 1.0 - slp1;

        float f0 = d0 * (PI * abs_x - SSILVB_AsinFast4(abs_x));
        float f1 = d1 * (abs_x - 1.0);

        float kk = k * k;

        float h0 = sqrt(f0 * f0 + kk) - k;
        float h1 = sqrt(f1 * f1 + kk) - k;

        float hh = (h0 * h1) / (h0 + h1);

        float y = abs_x - sqrt(hh * (hh + 2.0 * k));

        return SSILVB_SignMul(y, x);
    }
    return x;
}

// dir: normalized vector | out: angle in [-1,1] == ArcTan(dir) / PI
float SSILVB_ArcTan11(vec2 dir) {
    float x = abs(dir.x);
    float y =     dir.y;

    float u = 2.0 + x * (1.27324 + x * (-0.189431 + (0.08204 - 0.0242564 * x) * x));
    float f = y / u;

    if (dir.x < 0.0) f = SSILVB_SignI(dir.y) - f;
    return f;
}

vec2 SSILVB_SamplePartialSliceDir(vec3 vvsN, vec2 dir0) {
    float l = dot(vvsN.xy, vvsN.xy);
    if (l > 0.0) {
        float rl = inversesqrt(l);
        vec2 n = vvsN.xy * rl;
        dir0 = SSILVB_Cmul(dir0, n * vec2(1.0, -1.0));

        float x = SSILVB_ArcTan11(dir0);
        float ang = SSILVB_SamplePartialSlice(x, l * rl) * PI;

        vec2 dir = vec2(cos(ang), sin(ang));
        return SSILVB_Cmul(dir, n);
    }
    return dir0;
}

vec4 SSILVB_GetQuaternion(vec3 to) {
    vec3 xyz = vec3(-to.y, to.x, 0.0);
    float s  =                to.z;
    float u = inversesqrt(saturate(s * 0.5 + 0.5));
    s    = 1.0 / u;
    xyz *= u * 0.5;
    return vec4(xyz, s);
}

vec3 SSILVB_Transform_Qz0(vec3 v, vec4 q) {
    float k = v.y * q.x - v.x * q.y;
    float g = 2.0 * (v.z * q.w + k);

    vec3 r;
    r.xy = v.xy + q.yx * vec2(g, -g);
    r.z  = v.z  + 2.0 * (q.w * k - v.z * dot(q.xy, q.xy));
    return r;
}

vec3 SSILVB_Transform_Vz0Qz0(vec2 v, vec4 q) {
    float o = q.x * v.y;
    float c = q.y * v.x;
    vec3 b = vec3(o - c, -o + c, o - c);
    return vec3(v, 0.0) + 2.0 * (b * q.yxw);
}

vec2 SSILVB_SliceRelCDF_Cos(vec2 x, float angN, float cosN) {
    vec2 phi = x * PI - (PI * 0.5);

    vec2 t0 = 3.0 * cosN + -cos(angN - 2.0 * phi) + (4.0 * angN - 2.0 * phi + PI) * sin(angN);
    float t1 = 4.0 * (cosN + angN * sin(angN));

    return mix(x, t0 / t1, step(abs(x - 0.5), vec2(0.5)));
}

// https://cdrinmatane.github.io/posts/ssaovb-code/
uint SSILVB_UpdateSectors(vec2 horizon) {
    const uint sectorCount = uint(SSILVB_SECTOR_COUNT);
    uint startBit = uint(horizon.x * float(sectorCount));

    uint horizonAngle = uint(ceil((horizon.y - horizon.x) * float(sectorCount)));
    uint angleBit = horizonAngle > 0u ? uint(0xFFFFFFFFu >> (sectorCount - horizonAngle)) : 0u;

    return angleBit << startBit;
}

//================================================================================================//
// MAIN ENTRY POINT
//================================================================================================//
// viewPos      — позиция поверхности (view-space)
// worldNormal  — нормаль поверхности (world-space)
// dither       — [0,1) шум на кадр/пиксель (используй InterleavedGradientNoiseTemporal/R2Sequence)
// Возвращает: rgb = накопленный indirect bounce-цвет (включая цветной блочный свет),
//             a   = visibility term (1.0 = полностью открыто, 0.0 = полностью затенено) —
//                    можно использовать как доп. AO множитель для прочего освещения.
vec4 CalculateSSILVB(vec3 viewPos, vec3 worldNormal, float dither) {
    #if SSILVB_ENABLED == 0
        return vec4(0.0, 0.0, 0.0, 1.0);
    #else

    const int sliceCount  = SSILVB_SLICE_COUNT;
    const int sampleCount = SSILVB_SAMPLE_COUNT;
    const uint sectorCount = uint(SSILVB_SECTOR_COUNT);
    const float hitThickness = SSILVB_HIT_THICKNESS * 0.1;

    const float rSliceCount  = 1.0 / float(sliceCount);
    const float rSampleCount = 1.0 / float(sampleCount);

    vec2 fragCoord = gl_FragCoord.xy * screenPixelSize;

    vec3 viewDir    = normalize(-viewPos);
    vec3 viewNormal = mat3(gbufferModelView) * worldNormal;

    vec3 viewDirOffset = viewDir * hitThickness * SSILVB_RADIUS;

    vec4 Q_toV   = SSILVB_GetQuaternion(viewDir);
    vec4 Q_fromV = Q_toV * vec4(vec3(-1.0), 1.0);
    vec3 normalVVS = SSILVB_Transform_Qz0(viewNormal, Q_fromV);

    vec4 irradiance = vec4(0.0);

    for (int slice = 0; slice < sliceCount; ++slice) {
        // Псевдослучайное направление среза — золотое сечение по срезу + dither по кадру.
        float sliceDither = fract(dither + float(slice) * 0.618033988749895);
        float sliceAngle  = sliceDither * PI;
        vec2  dir = SSILVB_SamplePartialSliceDir(normalVVS, vec2(cos(sliceAngle), sin(sliceAngle)));
        vec3  smplDirVS = SSILVB_Transform_Vz0Qz0(dir, Q_toV);

        vec3 sliceN = cross(viewDir, smplDirVS);
        vec3 projN  = viewNormal - sliceN * dot(viewNormal, sliceN);

        float projNSqrLen = dot(projN, projN);
        if (projNSqrLen < SSILVB_EPS) continue;

        float cosN = dot(projN, viewDir) * inversesqrt(projNSqrLen);

        float angN = SSILVB_SignMul(SSILVB_AcosFast4(SSILVB_SatSnorm(cosN)), dot(viewDir, cross(sliceN, projN)));
        float angOff = angN / PI + 0.5;

        float w0 = saturate((sin(angN) / (cos(angN) + angN * sin(angN))) * (PI / 4.0) + 0.5);
        float w0_remap_mul = 1.0 / max(1.0 - w0, 1e-5);
        float w0_remap_add = -w0 * w0_remap_mul;

        vec2 rayDir = ViewToScreenSpace(smplDirVS + viewPos).xy - fragCoord;
        rayDir *= minOf((step(0.0, rayDir) - fragCoord) / rayDir);

        float rayDirNorm = inversesqrt(dot(rayDir * screenSize, rayDir * screenSize));
        float stepScale  = -rSampleCount * log2(saturate(rayDirNorm));

        float stepLength = exp2(stepScale * dither);
        stepScale = exp2(stepScale);
        rayDir *= rayDirNorm;

        uint bitMask = 0u;

        for (int samp = 0; samp < sampleCount; ++samp) {
            vec2 sampleUV = fragCoord + rayDir * stepLength;
            stepLength *= stepScale;

            if (saturate(sampleUV) == sampleUV) {
                ivec2 sampleTexel = ivec2(sampleUV * screenSize);
                float sampleDepth = texelFetch(depthtex1, sampleTexel, 0).x;

                if (sampleDepth >= 1.0 - 1e-6) continue;

                vec3 samplePos = ScreenToViewSpace(vec3(sampleUV, sampleDepth));

                vec3 sampleDirFront = samplePos - viewPos;
                vec3 sampleDirBack  = sampleDirFront + viewDirOffset * samplePos.z;

                vec2 frontBackHorizon = vec2(
                    inversesqrt(dot(sampleDirFront, sampleDirFront)) * dot(sampleDirFront, viewDir),
                    inversesqrt(dot(sampleDirBack,  sampleDirBack )) * dot(sampleDirBack,  viewDir)
                );

                frontBackHorizon = SSILVB_AcosFast4(SSILVB_SatSnorm(frontBackHorizon));
                frontBackHorizon = saturate(frontBackHorizon / PI + angOff);

                frontBackHorizon = SSILVB_SliceRelCDF_Cos(frontBackHorizon, angN, cosN);
                frontBackHorizon = frontBackHorizon * w0_remap_mul + w0_remap_add;

                uint sBitMask = SSILVB_UpdateSectors(frontBackHorizon);
                uint sampleOccludedBit = sBitMask & ~bitMask;

                if (sampleOccludedBit > 0u) {
                    vec3 sampleRadiance = texelFetch(colortex4, sampleTexel, 0).rgb;
                    sampleRadiance = min(sampleRadiance, vec3(SSILVB_MAX_RADIANCE));
                    irradiance.rgb += float(bitCount(sampleOccludedBit)) * sampleRadiance;

                    bitMask |= sBitMask;
                    if (bitMask == 0xFFFFFFFFu) break;
                }
            }
        }

        irradiance.a += float(bitCount(bitMask));
    }

    irradiance *= rSliceCount / float(sectorCount);
    irradiance = vec4(irradiance.rgb * SSILVB_STRENGTH, saturate(1.0 - irradiance.a));

    return irradiance;
    #endif
}
