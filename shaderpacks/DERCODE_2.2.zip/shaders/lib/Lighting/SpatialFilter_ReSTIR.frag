/*
================================================================================
  SpatialFilter_ReSTIR.frag — Просторовий фільтр для ReSTIR резервуарів
  Включається в deferred3.fsh замість SpatialFilter.frag коли RESTIR_ENABLED.

  Читає colortex8/9 (резервуари після temporal reuse з Deferred3.glsl)
  Виконує Spatial Reuse (K сусідів по колу радіуса RESTIR_SPATIAL_RADIUS)
  Пише підсумковий irradiance у colortex0 (щоб Deferred2 його підхопив)
================================================================================
*/

layout(location = 0) out vec4 indirectData; // colortex0
layout(location = 1) out vec4 reservoirAOut; // colortex8 (оновлений після spatial)
layout(location = 2) out vec4 reservoirBOut; // colortex9

/* DRAWBUFFERS:089 */

in vec2 screenCoord;

#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"
#include "/lib/Head/Functions.inc"

uniform sampler2D colortex8;
uniform sampler2D colortex9;

#include "/lib/Lighting/ReSTIR.glsl"

//----// MAIN //---------------------------------------------------------------//

void main() {
    ivec2 texel = ivec2(gl_FragCoord.xy);

    // Passthrough для пікселів що не обробляємо (верхня половина — нормалі/глибина)
    indirectData  = texelFetch(colortex0, texel, 0);
    reservoirAOut = texelFetch(colortex8, texel, 0);
    reservoirBOut = texelFetch(colortex9, texel, 0);

    // Обробляємо тільки нижній лівий квадрант (1/4 res, як і AO/GI)
    if (!all(lessThan(texel, ivec2(ceil(screenSize * 0.5))))) return;

    float depth = texelFetch(depthtex0, texel * 2, 0).x;
    if (depth >= 1.0) return;

    vec3 viewPos    = ScreenToViewSpace(vec3(gl_FragCoord.xy * screenPixelSize * 2.0, depth));
    vec3 viewNormal = GetNormals(texel * 2);
    vec3 worldNormal = mat3(gbufferModelViewInverse) * viewNormal;

    // Завантажуємо поточний резервуар
    Reservoir center = UnpackReservoir(
        texelFetch(colortex8, texel, 0),
        texelFetch(colortex9, texel, 0)
    );

    // ---- Spatial Reuse: K сусідів по диску ---------------------------------
    Reservoir combined = center;

    float angleStep = TAU / float(RESTIR_SPATIAL_K);
    // Рандомний початковий кут (зміщуємо кожен кадр для TAA)
    float baseAngle = float(frameCounter) * 0.6180339887 * TAU;

    for (int k = 0; k < RESTIR_SPATIAL_K; k++) {
        float angle = baseAngle + float(k) * angleStep;

        // Поступово збільшуємо радіус пошуку (0.3..1.0 від RESTIR_SPATIAL_RADIUS)
        float radius  = RESTIR_SPATIAL_RADIUS * (0.3 + 0.7 * float(k) / float(max(RESTIR_SPATIAL_K - 1, 1)));
        ivec2 offset  = ivec2(round(vec2(cos(angle), sin(angle)) * radius));
        ivec2 sTexel  = clamp(texel + offset, ivec2(0), ivec2(screenSize * 0.5) - 1);

        // Перевірка сумісності сусіда (нормаль + глибина)
        float sDepth  = texelFetch(depthtex0, sTexel * 2, 0).x;
        if (sDepth >= 1.0) continue;

        vec3 sNormal  = GetNormals(sTexel * 2);
        vec3 sWorldN  = mat3(gbufferModelViewInverse) * sNormal;

        // Відкидаємо пікселі з іншою поверхнею (різні нормалі або різна глибина)
        if (dot(sWorldN, worldNormal) < 0.707) continue;

        vec3 sViewPos = ScreenToViewSpace(vec3(vec2(sTexel) * screenPixelSize * 2.0, sDepth));
        if (abs(length(viewPos) - length(sViewPos)) > 1.0) continue;

        // Завантажуємо резервуар сусіда
        Reservoir neighbor = UnpackReservoir(
            texelFetch(colortex8, sTexel, 0),
            texelFetch(colortex9, sTexel, 0)
        );

        if (neighbor.M < 0.5) continue; // пустий резервуар

        // Перевіряємо видимість: чи підходить radiance сусіда до нашої нормалі
        float visWeight = saturate(dot(viewNormal, neighbor.hitNormal));
        if (visWeight < 0.1) continue;

        float neighborPdf = GetLuminance(neighbor.radiance) * visWeight;
        float rng = fract(float(triple32(uint(k + frameCounter * RESTIR_SPATIAL_K))) * 2.3283064e-10);
        MergeReservoir(combined, neighbor, neighborPdf, rng);
    }

    // Фіналізуємо після spatial reuse
    ComputeReservoirWeight(combined, GetLuminance(combined.radiance));
    combined.W = min(combined.W, 32.0);

    // ---- Обчислення підсумкового irradiance --------------------------------
    vec3 irradiance = vec3(0.0);
    if (combined.W > 0.0) {
        float NdotRay = saturate(dot(viewNormal, combined.hitNormal));
        irradiance = combined.radiance * combined.W * NdotRay * RESTIR_STRENGTH;
    }

    // ---- Зберігаємо в colortex0 (як GI/SSAO це роблять) -------------------
    // Зберігаємо irradiance в .rgb, .a залишаємо від AO (якщо є)
    vec4 prevIndirect = texelFetch(colortex0, texel, 0);
    indirectData = clamp16F(vec4(irradiance, prevIndirect.a));

    // Зберігаємо оновлений резервуар (щоб наступний кадр мав кращу історію)
    reservoirAOut = PackReservoirA(combined);
    reservoirBOut = PackReservoirB(combined);
}
