
#ifndef RSM_DEBUG_MODE
    #define RSM_DEBUG_MODE 0
#endif

vec3 RSM_Calculate(vec3 viewPos, vec3 worldNormal, float dither) {
    vec3 result = CalculateRSM(viewPos, worldNormal, dither);

    #if GI_RSM == 1
        
        result += CalculateRSM_Far(viewPos, worldNormal, fract(dither + 0.5));
    #endif

    return result;
}

vec3 RSM_Debug(vec3 viewPos, vec3 worldNormal, float dither) {
    #if RSM_DEBUG_MODE == 1
        return CalculateRSM(viewPos, worldNormal, dither);
    #elif RSM_DEBUG_MODE == 2
        #if GI_RSM == 1
            return CalculateRSM_Far(viewPos, worldNormal, dither);
        #else
            return vec3(0.0);
        #endif
    #elif RSM_DEBUG_MODE == 3
        return RSM_Calculate(viewPos, worldNormal, dither);
    #else
        return RSM_Calculate(viewPos, worldNormal, dither);
    #endif
}
