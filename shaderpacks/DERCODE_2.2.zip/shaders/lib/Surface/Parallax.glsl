
// uniform ivec2 atlasSize;
/*
float BilinearHeightSample(in vec2 coord)
{
    ivec2 tileOffset = ivec2(tileOffset * tileScale);
    coord = coord * atlasSize - 0.5;
    ivec2 i = ivec2(coord);

    vec4 sh = vec4(
        texelFetch(normals, (i + ivec2(0, 1)) % atlasSize + tileOffset, 0).a,
        texelFetch(normals, (i + ivec2(1, 1)) % atlasSize + tileOffset, 0).a,
        texelFetch(normals, (i + ivec2(1, 0)) % atlasSize + tileOffset, 0).a,
        texelFetch(normals, (i + ivec2(0, 0)) % atlasSize + tileOffset, 0).a
    );

    sh += step(sh, vec4(1e-3));
    vec2 fpc = fract(coord);

    sh.xy = mix(sh.wx, sh.zy, fpc.x);
    return mix(sh.x, sh.y, fpc.y);
}
*/

// ============================================================
// PARALLAX_STYLE: 1 = Sharp, 2 = Smooth, 3 = Sharp+EdgeSmooth
// #define PARALLAX_STYLE 1 // [1 2 3]
// ============================================================
#ifndef PARALLAX_STYLE
#define PARALLAX_STYLE 1 // [1 2 3]
#endif

// ============================================================
// SmoothHeightSample — bilinear інтерполяція між 4 сусідніми текселями.
//
// tileCoord — [0,1] всередині тайлу.
// tileScale — розмір тайлу в UV-просторі атласу (з вертексного шейдера).
// textureSize(normals, 0) — розмір атласу в пікселях.
//
// Один тексель у тайл-просторі [0,1]:
//   tilePixelSize = vec2(1.0) / (tileScale * atlasSize / tileScale)
//                = vec2(1.0) / atlasPixelsPerTile
//   де atlasPixelsPerTile = vec2(textureSize(normals,0)) * tileScale / tileScale
//   Спрощено: tilePixelSize = 1.0 / float(textureResolution)
//   де textureResolution = atlasSize * tileScale (пікселів у тайлі по одній осі).
//   Ще простіше: зсув одного текселя в тайл-просторі = tileScale / atlasSize,
//   переведений назад у тайл-простір: ділимо на tileScale → 1/atlasSize по осям.
//   Але нам потрібно в тайл-просторі [0,1], тому:
//   px_tile = (1/atlasSize) / tileScale * tileScale = 1 / (atlasSize * ?)
//
// Найпряміше: один тексель в тайл-просторі = 1.0 / N,
//   де N = textureSize.x * tileScale.x (пікселів тайлу по горизонталі).
//   Але tileScale.x — це частка атласу, тому N = textureSize.x * tileScale.x.
//
// Резюме: tilePixelSize.x = 1.0 / (textureSize(normals,0).x * tileScale.x)
//         tilePixelSize.y = 1.0 / (textureSize(normals,0).y * tileScale.y)
// ============================================================
#if PARALLAX_STYLE >= 2

float SmoothHeightSample(in vec2 coord, in mat2 texGrad) {
    // Розмір 1 текселя в тайл-просторі [0,1]
    vec2 tilePixelSize = 1.0 / (vec2(textureSize(normals, 0)) * tileScale);

    // Субпіксельна позиція всередині поточного текселя
    vec2 f = fract(coord / tilePixelSize);

    // UV 4 сусідів в атласі
    vec2 uv00 = OffsetCoord(coord);
    vec2 uv10 = OffsetCoord(coord + vec2(tilePixelSize.x, 0.0));
    vec2 uv01 = OffsetCoord(coord + vec2(0.0, tilePixelSize.y));
    vec2 uv11 = OffsetCoord(coord + tilePixelSize);

    float h00 = textureGrad(normals, uv00, texGrad[0], texGrad[1]).a;
    float h10 = textureGrad(normals, uv10, texGrad[0], texGrad[1]).a;
    float h01 = textureGrad(normals, uv01, texGrad[0], texGrad[1]).a;
    float h11 = textureGrad(normals, uv11, texGrad[0], texGrad[1]).a;

    return mix(mix(h00, h10, f.x), mix(h01, h11, f.x), f.y);
}

#endif

// ============================================================
// Style 2 — Smooth parallax
// Bilinear height + лінійна інтерполяція між кроками при перетині.
// ============================================================
#if PARALLAX_STYLE == 2

vec3 CalculateParallax(in vec3 tangentViewVector, in mat2 texGrad, in float dither) {
    vec3 offsetCoord = vec3(tileCoord, 1.0);
    vec3 stepSize    = vec3(tangentViewVector.xy, -1.0) * rcp(float(PARALLAX_SAMPLES));
    stepSize.xy     *= PARALLAX_DEPTH * rcp(-tangentViewVector.z);
    stepSize        *= 2.0 / float(PARALLAX_SAMPLES);

    offsetCoord += stepSize * dither;

    vec3 prevCoord   = offsetCoord;
    float prevHeight = SmoothHeightSample(offsetCoord.xy, texGrad);

    for (uint i = 1u; i < PARALLAX_SAMPLES; ++i) {
        prevCoord    = offsetCoord;
        offsetCoord += stepSize * float(i);

        float currHeight = SmoothHeightSample(offsetCoord.xy, texGrad);

        if (currHeight > offsetCoord.z) {
            // Лінійна інтерполяція між попереднім (над поверхнею)
            // і поточним (під поверхнею) кроком
            float dAfter  = currHeight  - offsetCoord.z;
            float dBefore = prevCoord.z - prevHeight;
            float t = dAfter / max(dAfter + dBefore, 1e-5);
            return mix(offsetCoord, prevCoord, t);
        }

        prevHeight = currHeight;
    }

    return offsetCoord;
}

// ============================================================
// Style 3 — Sharp скрізь + Smooth тільки на краях тайлу
// В центрі текстури: чистий sharp. На краях (~2px): bilinear.
// ============================================================
#elif PARALLAX_STYLE == 3

#ifndef PARALLAX_EDGE_SMOOTH_PX
#define PARALLAX_EDGE_SMOOTH_PX 2.0
#endif

// Маска краю: 0.0 = на краю тайлу, 1.0 = в центрі
// edgeDist в тайл-просторі [0..0.5], ділимо на розмір 1 текселя → отримуємо пікселі
float TileEdgeMask(in vec2 coord) {
    vec2 f        = fract(coord);
    vec2 edgeDist = min(f, 1.0 - f);                              // 0 на краю, 0.5 в центрі

    // Розмір 1 текселя в тайл-просторі
    vec2 tilePixelSize = 1.0 / (vec2(textureSize(normals, 0)) * tileScale);

    // Відстань від краю в текселях
    vec2 edgePx = edgeDist / tilePixelSize;

    return smoothstep(0.0, PARALLAX_EDGE_SMOOTH_PX, min(edgePx.x, edgePx.y));
}

vec3 CalculateParallax(in vec3 tangentViewVector, in mat2 texGrad, in float dither) {
    vec3 offsetCoord = vec3(tileCoord, 1.0);
    vec3 stepSize    = vec3(tangentViewVector.xy, -1.0) * rcp(PARALLAX_SAMPLES);
    stepSize.xy     *= PARALLAX_DEPTH * rcp(-tangentViewVector.z);
    stepSize        *= 2.0 / PARALLAX_SAMPLES;

    int currRefinements = 0;
    offsetCoord += stepSize * dither;

    // Маска рахується один раз по початковому tileCoord
    float edgeMask = TileEdgeMask(tileCoord);

    for (uint i = 1u; i < PARALLAX_SAMPLES; ++i) {
        offsetCoord += stepSize * float(i);

        float sharpH      = textureGrad(normals, OffsetCoord(offsetCoord.xy), texGrad[0], texGrad[1]).a;
        float smoothH     = SmoothHeightSample(offsetCoord.xy, texGrad);
        float sampleHeight = mix(smoothH, sharpH, edgeMask);

        #ifdef PARALLAX_REFINEMENT
            if (sampleHeight > offsetCoord.z) {
                if (currRefinements >= PARALLAX_REFINEMENT_STEPS) break;
                offsetCoord -= stepSize * float(i);
                stepSize    *= 0.5;
                ++currRefinements;
            }
        #else
            if (sampleHeight > offsetCoord.z) break;
        #endif
    }

    return offsetCoord;
}

// ============================================================
// Style 1 — Sharp оригінал (без змін)
// ============================================================
#else

vec3 CalculateParallax(in vec3 tangentViewVector, in mat2 texGrad, in float dither) {
    vec3 offsetCoord = vec3(tileCoord, 1.0);
    vec3 stepSize = vec3(tangentViewVector.xy, -1.0) * rcp(PARALLAX_SAMPLES);
    stepSize.xy *= PARALLAX_DEPTH * rcp(-tangentViewVector.z);
    stepSize *= 2.0 / PARALLAX_SAMPLES;

    int currRefinements = 0;
    offsetCoord += stepSize * dither;
    for (uint i = 1u; i < PARALLAX_SAMPLES; ++i) {
        offsetCoord += stepSize * i;

        #ifdef SMOOTH_PARALLAX
            float sampleHeight = BilinearHeightSample(OffsetCoord(offsetCoord.xy));
        #else
            float sampleHeight = textureGrad(normals, OffsetCoord(offsetCoord.xy), texGrad[0], texGrad[1]).a;
        #endif

        #ifdef PARALLAX_REFINEMENT
            if (sampleHeight > offsetCoord.z) {
                if (currRefinements >= PARALLAX_REFINEMENT_STEPS) break;
                offsetCoord -= stepSize * i;
                stepSize *= 0.5;
                ++currRefinements;
            }
        #endif
    }

    return offsetCoord;
}

#endif // PARALLAX_STYLE

// ============================================================
// Parallax Shadow
// ============================================================
#ifdef PARALLAX_SHADOW
    float CalculateParallaxShadow(in vec3 tangentLightVector, in vec3 offsetCoord, in mat2 texGrad, in float dither) {
        float parallaxShadow = 1.0;

        vec3 stepSize = vec3(tangentLightVector.xy, 1.0) * offsetCoord.z * rcp(PARALLAX_SAMPLES);
        stepSize.xy *= PARALLAX_DEPTH * rcp(tangentLightVector.z);
        stepSize *= 2.0 / PARALLAX_SAMPLES;

        offsetCoord += stepSize * dither;
        for (uint i = 1u; i < PARALLAX_SAMPLES; ++i) {
            offsetCoord += stepSize * i;

            #if PARALLAX_STYLE == 2
                float sampleHeight = SmoothHeightSample(offsetCoord.xy, texGrad);
            #elif PARALLAX_STYLE == 3
                float sharpH  = textureGrad(normals, OffsetCoord(offsetCoord.xy), texGrad[0], texGrad[1]).a;
                float smoothH = SmoothHeightSample(offsetCoord.xy, texGrad);
                float sampleHeight = mix(smoothH, sharpH, TileEdgeMask(offsetCoord.xy));
            #else
                #ifdef SMOOTH_PARALLAX
                    float sampleHeight = BilinearHeightSample(OffsetCoord(offsetCoord.xy));
                #else
                    float sampleHeight = textureGrad(normals, OffsetCoord(offsetCoord.xy), texGrad[0], texGrad[1]).a;
                #endif
            #endif

            parallaxShadow *= float(offsetCoord.z > sampleHeight);
            if (parallaxShadow < 1e-4) break;
        }

        return 1.0 - parallaxShadow;
    }
#endif