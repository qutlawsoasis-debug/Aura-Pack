#define RAYTRACED_REFRACTION
//#define REFRACTIVE_DISPERSION

#define GLASS_REFRACTION_INTENSITY 4.5 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.25 1.5 2.0 2.25 2.50 3.0 3.25 3.50 4.0 4.25 4.50 5.0]
#define GLASS_REFRACTION_CIRCLE_EDGE_FACTOR 0.1 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.25 1.5 2.0 2.25 2.50 3.0 3.25 3.50 4.0 4.25 4.50 5.0]

#define REFRACTION_SSRT_SAMPLES 16 // [4 8 12 16 24 32 48 64]
#define REFRACTION_SSRT_REFINEMENT
#define REFRACTION_SSRT_REFINEMENT_STEPS 4 // [2 3 4 5 6 7 8]

//================================================================================================//

vec3 fastRefract(in vec3 dir, in vec3 normal, in float eta) {
    float NdotD = dot(normal, dir);
    float k = 1.0 - eta * eta * oneMinus(NdotD * NdotD);
    if (k < 0.0) return vec3(0.0);
    return dir * eta - normal * (sqrt(k) + NdotD * eta);
}

// x * y * (1-x) * (1-y)
float RefractEdgeFade(in vec2 coord) {
    float fade = coord.x * coord.y * (1.0 - coord.x) * (1.0 - coord.y);
    return saturate(fade * 1e2);
}

//================================================================================================//
// Screen-space raytracer — стиль донора (Revelation Shaders)
// Использует fixZ-трюк для корректного перевода view->screen dir,
// а также бинарное уточнение позиции хита.
//================================================================================================//

bool RefractScreenSpaceRaytrace(in vec3 viewPos, in vec3 viewDir, in float dither,
                                 in uint steps, inout vec3 screenPos) {
    vec3 rayOrigin = screenPos;

    // Трюк донора: fixZ гарантирует что мы не уходим за near plane
    float fixZ = step(viewDir.z, 0.0) * 1e23 - (viewPos.z + near) / viewDir.z;
    vec3 rayDir = normalize(ViewToScreenSpace(viewDir * fixZ + viewPos) - rayOrigin);

    // Шаг по всей длине до края экрана
    rayDir *= minOf((step(0.0, rayDir) - screenPos) / rayDir);

    float rSteps = 1.0 / float(steps);
    float invDirZ = rcp(abs(rayDir.z));
    vec3 rayStep = rayDir * rSteps;

    float compareTolerance = max(abs(rayStep.z), (rayOrigin.z + gbufferProjection[2].z) * rSteps);

    bool hit = false;
    float t = dither * rSteps;
    float stepMin = rSteps * 0.01;
    float stepMax = rSteps * 1.1;

    for (uint i = 0u; i < steps; ++i) {
        vec3 rayPos = rayOrigin + rayDir * t;

        if (saturate(rayPos.xy) != rayPos.xy) break;
        if (rayPos.z >= 1.0) break;

        ivec2 sampleTexel = ivec2(rayPos.xy * vec2(viewWidth, viewHeight));
        float sampleDepth = texelFetch(depthtex1, sampleTexel, 0).x;

        float depthDiff = sampleDepth - rayPos.z;
        if (abs(depthDiff + compareTolerance) < compareTolerance) {
            screenPos = rayPos;
            hit = true;
            break;
        }

        t += clamp(depthDiff * invDirZ, stepMin, stepMax);
    }

    // Бинарное уточнение позиции хита (как в доноре)
    #ifdef REFRACTION_SSRT_REFINEMENT
    if (hit) {
        for (uint i = 0u; i < REFRACTION_SSRT_REFINEMENT_STEPS; ++i) {
            rayStep *= 0.5;

            ivec2 sampleTexel = ivec2(screenPos.xy * vec2(viewWidth, viewHeight));
            float sampleDepth = texelFetch(depthtex1, sampleTexel, 0).x;

            float depthDiff = sampleDepth - screenPos.z;
            if (abs(depthDiff + compareTolerance) < compareTolerance) {
                screenPos -= rayStep;
            } else {
                screenPos += rayStep;
            }
        }
    }
    #endif

    return hit;
}

//================================================================================================//

#ifdef RAYTRACED_REFRACTION

vec2 CalculateRefractCoord(in TranslucentMask mask, in vec3 normal, in vec3 viewDir,
                            in vec3 viewPos, in float depth, in float ior) {
    if (!mask.translucent) return screenCoord;

    vec3 refractedDir = fastRefract(viewDir, normal, 1.0 / ior);

    vec3 hitPos = vec3(screenCoord, depth);
    bool hit = RefractScreenSpaceRaytrace(
        viewPos, refractedDir,
        InterleavedGradientNoiseTemporal(gl_FragCoord.xy),
        uint(REFRACTION_SSRT_SAMPLES), hitPos
    );

    vec2 refractCoord;
    if (hit) {
        refractCoord = hitPos.xy;
    } else {
        // Fallback — проецируем сдвинутую точку на экран
        refractCoord = ViewToScreenSpace(viewPos + refractedDir * 0.5).xy;
    }

    vec2 clampedCoord = saturate(refractCoord);

    // Не показываем рефракцию поверх непрозрачной геометрии ближе к камере
    float refractDepthOpaque = texture(depthtex1, clampedCoord).x;
    if (refractDepthOpaque < depth) return screenCoord;

    float fade = RefractEdgeFade(clampedCoord);
    return mix(screenCoord, clampedCoord, fade);
}

#else

#include "/lib/Water/WaterWave.glsl"

vec2 CalculateRefractCoord(in TranslucentMask mask, in vec3 normal, in vec3 worldPos,
                            in vec3 viewPos, in float depth, in float depthT) {
    if (!mask.translucent) return screenCoord;

    vec2 refractCoord;
    float waterDepth     = GetDepthLinear(depthT);
    float refractionDepth = GetDepthLinear(depth) - waterDepth;

    if (mask.water) {
        // --- Вода: нормаль из волновой функции (как в доноре CalculateWaterNormal) ---
        vec3 worldPosFull = worldPos + cameraPosition;

        vec3 wavesNormal = GetWavesNormal(worldPosFull.xz - worldPosFull.y);
        wavesNormal.xy = clamp(wavesNormal.xy, -0.35, 0.35);
        wavesNormal = normalize(wavesNormal);

        // Переводим нормаль в view-space (стиль донора)
        vec3 waterNormalView = normalize(mat3(gbufferModelView) * wavesNormal.xzy);

        // Базовый up-вектор воды в view-space (столбец Y матрицы gbufferModelView)
        vec3 nv = normalize(gbufferModelView[1].xyz + 1e-6);
        refractCoord = nv.xy - waterNormalView.xy;

        // Масштаб рефракции: плавно нарастает с глубиной, как в доноре
        float depthFactor    = smoothstep(0.0, 1.2, refractionDepth);
        float refractionScale = depthFactor * 0.5 / (waterDepth + 1e-4);
        refractionScale       = min(refractionScale * 1.8, 0.5);

        refractCoord *= refractionScale;
        refractCoord += screenCoord;

    } else {
        // --- Стекло: физически корректная рефракция через fastRefract ---
        vec3 refractDir = fastRefract(normalize(viewPos), normal, 1.0 / GLASS_REFRACT_IOR);
        refractDir /= saturate(dot(refractDir, -normal));

        float depthFactor = smoothstep(0.0, 0.8 * GLASS_REFRACTION_CIRCLE_EDGE_FACTOR, refractionDepth);
        refractDir *= depthFactor * (0.42 * GLASS_REFRACTION_INTENSITY);

        refractCoord = ViewToScreenSpace(viewPos + refractDir).xy;
    }

    vec2 clampedCoord = saturate(refractCoord);

    float refractDepthOpaque = texture(depthtex1, clampedCoord).x;
    float refractDepthFull   = texture(depthtex0, clampedCoord).x;

    // Проверки корректности: не показываем рефракцию через непрозрачные объекты
    if (refractDepthFull   < depthT - 1e-4) return screenCoord;
    if (refractDepthOpaque < depthT)         return screenCoord;

    float fade = RefractEdgeFade(refractCoord);
    return mix(screenCoord, clampedCoord, fade);
}

#if defined DISTANT_HORIZONS
    vec2 CalculateRefractCoordDH(in TranslucentMask mask, in vec3 normal, in vec3 worldPos,
                                  in vec3 viewPos, in float depth, in float depthT) {
        if (!mask.translucent) return screenCoord;

        vec2 refractCoord;
        float waterDepth      = GetDepthLinearDH(depthT);
        float refractionDepth = GetDepthLinearDH(depth) - waterDepth;

        if (mask.water) {
            vec3 worldPosFull = worldPos + cameraPosition;

            vec3 wavesNormal = GetWavesNormal(worldPosFull.xz - worldPosFull.y);
            wavesNormal.xy = clamp(wavesNormal.xy, -0.35, 0.35);
            wavesNormal = normalize(wavesNormal);

            vec3 waterNormalView = normalize(mat3(gbufferModelView) * wavesNormal.xzy);
            vec3 nv = normalize(gbufferModelView[1].xyz + 1e-6);

            refractCoord = nv.xy - waterNormalView.xy;

            float depthFactor    = smoothstep(0.0, 1.2, refractionDepth);
            float refractionScale = depthFactor * 0.5 / (waterDepth + 1e-4);
            refractionScale       = min(refractionScale * 1.8, 0.5);

            refractCoord *= refractionScale;
            refractCoord += screenCoord;

        } else {
            vec3 refractDir = fastRefract(normalize(viewPos), normal, 1.0 / GLASS_REFRACT_IOR);
            refractDir /= saturate(dot(refractDir, -normal));

            float depthFactor = smoothstep(0.0, 0.8 * GLASS_REFRACTION_CIRCLE_EDGE_FACTOR, refractionDepth);
            refractDir *= depthFactor * (0.42 * GLASS_REFRACTION_INTENSITY);

            refractCoord = ViewToScreenSpaceDH(viewPos + refractDir).xy;
        }

        float refractDepthOpaque = texture(dhDepthTex1, saturate(refractCoord)).x;
        float refractDepthFull   = texture(dhDepthTex0, saturate(refractCoord)).x;

        if (refractDepthFull   < depthT - 1e-4) return screenCoord;
        if (refractDepthOpaque < depthT)         return screenCoord;

        float fade = RefractEdgeFade(refractCoord);
        return mix(screenCoord, saturate(refractCoord), fade);
    }
#endif

#endif // RAYTRACED_REFRACTION
