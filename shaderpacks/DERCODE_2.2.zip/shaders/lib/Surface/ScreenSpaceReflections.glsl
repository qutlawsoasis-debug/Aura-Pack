#include "/lib/Surface/BRDF.glsl"

#define RAYTRACE_SAMPLES 16           
#define RAYTRACE_REFINEMENT
#define RAYTRACE_REFINEMENT_STEPS 4   
#define WATER_REFRACT_IOR 1.333       

#define FLICKER_SUPPRESS_DISTANCE 160.0

//================================================================================================//
// REFLECTION TYPE / SKY / DEPTH SOURCE CONFIG
//================================================================================================//

// Тип отражений:
// 0 = SSR                — обычный screen-space трейс (быстрый, ограничен экраном)
// 1 = WORLD REFLECTIONS  — полный мировой multi-bounce трейс (CalculatePathTracedReflections)
// 2 = HYBRID SSR + RSM   — сперва screen-space трейс, при промахе — world-space RSM-трассировка
//                          (Reflective Shadow Map) в точку вдоль луча, как "AO-трассировка" поверх SSR
#ifndef REFLECTION_TYPE
    #define REFLECTION_TYPE 0
#endif

//================================================================================================//
// HYBRID (REFLECTION_TYPE == 2) CONFIG
// Кол-во RSM семплов берётся из RSM_SAMPLES (sun/sky RSM, см. GlobalIllumination.glsl)
// и RSM_BLOCKLIGHT_SAMPLES (block-light-only RSM, если HYBRID_RSM_INDOOR == 1).
//================================================================================================//
#ifndef HYBRID_RSM_TRACE_DIST
    #define HYBRID_RSM_TRACE_DIST 32.0   // [8.0 12.0 16.0 20.0 24.0 28.0 32.0 40.0 48.0 64.0] — макс. дистанция мирового луча для RSM-поиска
#endif
#ifndef HYBRID_RSM_STRENGTH
    #define HYBRID_RSM_STRENGTH 100.0      // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0]
#endif
#ifndef HYBRID_RSM_INDOOR
    #define HYBRID_RSM_INDOOR 1          // [0 1] — использовать Block-Light-Only RSM (закрытые помещения, без sun/sky) в доп. к обычному RSM
#endif

// Показывать ли небо/skybox в отражениях (0 = выкл, 1 = вкл)
#ifndef REFLECTION_SHOW_SKY
    #define REFLECTION_SHOW_SKY 1
#endif

// Источник глубины для трейса:
// 0 = depthtex1 (без полупрозрачных/руки/частиц поверх — как раньше)
// 1 = depthtex0 (включая всё что рисуется после непрозрачной геометрии)
#ifndef REFLECTION_DEPTH_SOURCE
    #define REFLECTION_DEPTH_SOURCE 0
#endif

#if REFLECTION_DEPTH_SOURCE == 1
    #define REFLECTION_DEPTH_TEX depthtex0
#else
    #define REFLECTION_DEPTH_TEX depthtex1
#endif

vec3 CalculateUnderwaterReflectDir(in vec3 viewDir, in vec3 normal) {
    vec3 reflectDir = reflect(viewDir, normal);
    float NdotV = max(dot(normal, -viewDir), 0.0);
    vec3 upVector = vec3(0.0, 1.0, 0.0);
    float upAlignment = dot(reflectDir, upVector);
    reflectDir.xz = mix(reflectDir.xz, normalize(reflectDir.xz) * 0.9, saturate(upAlignment * 0.5));
    return normalize(reflectDir);
}

bool ValidateDepthContinuity(in ivec2 texel, in float centerDepth, in float threshold) {
    float depthL = texelFetch(REFLECTION_DEPTH_TEX, texel + ivec2(-1, 0), 0).x;
    float depthR = texelFetch(REFLECTION_DEPTH_TEX, texel + ivec2(1, 0), 0).x;
    float depthU = texelFetch(REFLECTION_DEPTH_TEX, texel + ivec2(0, -1), 0).x;
    float depthD = texelFetch(REFLECTION_DEPTH_TEX, texel + ivec2(0, 1), 0).x;
    
    float avgDepth = (depthL + depthR + depthU + depthD) * 0.25;
    float variance = abs(depthL - avgDepth) + abs(depthR - avgDepth) + 
                     abs(depthU - avgDepth) + abs(depthD - avgDepth);
    
    return variance < threshold;
}

bool ScreenSpaceRayTrace(in vec3 viewPos, in vec3 viewDir, in float dither, in uint steps, 
                         inout vec3 rayPos, vec3 worldPos, bool isUnderwater) {
    const float maxLength = 1.0 / steps;
    const float minLength = length(screenPixelSize);
    
    vec3 position = ViewToScreenSpace(viewDir * abs(viewPos.z) + viewPos);
    vec3 screenDir = normalize(position - rayPos);
    float stepWeight = 1.0 / abs(screenDir.z);
    float stepLength = minOf((step(0.0, screenDir) - rayPos) / screenDir) * rcp(steps);
    
    screenDir.xy *= screenSize;
    rayPos.xy *= screenSize;
    
    float stableDither = dither;
    float distRatio = 0.0;
    
    if (isUnderwater) {
        distRatio = saturate(length(viewPos) / FLICKER_SUPPRESS_DISTANCE);
        
        stableDither = mix(dither, 0.5, distRatio * 0.9);
    }
    
    float spiralAngle = stableDither * TAU;
    vec2 spiralOffset = vec2(cos(spiralAngle), sin(spiralAngle)) * minLength * 2.0;
    
    vec3 rayStep = screenDir * stepLength;
    rayPos += rayStep * stableDither + screenDir * minLength + vec3(spiralOffset, 0.0);
    
    float depthTolerance = max(abs(rayStep.z) * 3.0, 0.02 / sqr(viewPos.z));
    
    if (isUnderwater) {
        depthTolerance *= 2.0;
        
        depthTolerance *= (1.0 + distRatio * 4.0);
    }
    
    bool hit = false;
    float depth = texelFetch(REFLECTION_DEPTH_TEX, ivec2(rayPos.xy), 0).x;
    
    for (uint i = 0u; i < steps; ++i) {
        if (clamp(rayPos.xy, vec2(0.0), screenSize) != rayPos.xy) return false;
        if (rayPos.z >= 1.0) break;
        
        stepLength = abs(depth - rayPos.z) * stepWeight;
        
        float adaptiveStep = clamp(stepLength, minLength, maxLength);
        if (isUnderwater && i < 4u) {
            adaptiveStep *= 0.5;
        }
        
        rayPos += screenDir * adaptiveStep;
        depth = texelFetch(REFLECTION_DEPTH_TEX, ivec2(rayPos.xy), 0).x;
        
        if (depth < rayPos.z && abs(depthTolerance - (rayPos.z - depth)) < depthTolerance) {
            if (isUnderwater) {
                if (distRatio > 0.8) {
                    hit = true;
                    break;
                } else if (ValidateDepthContinuity(ivec2(rayPos.xy), depth, 0.1 * (1.0 + distRatio))) {
                    hit = true;
                    break;
                }
            } else {
                hit = true;
                break;
            }
        }
    }
    
    if (!hit) return false;
    rayStep = screenDir * stepLength;
    
    #ifdef RAYTRACE_REFINEMENT
        for (uint i = 0u; i < RAYTRACE_REFINEMENT_STEPS; ++i) {
            if (clamp(rayPos.xy, vec2(0.0), screenSize) != rayPos.xy) break;
            rayStep *= 0.5;
            depth = texelFetch(REFLECTION_DEPTH_TEX, ivec2(rayPos.xy), 0).x;
            if (depth < rayPos.z && abs(depthTolerance - (rayPos.z - depth)) < depthTolerance) {
                rayPos -= rayStep;
            } else {
                rayPos += rayStep;
            }
        }
    #endif
    
    return depth < 1.0;
}

bool ScreenSpaceRayTrace(in vec3 viewPos, in vec3 viewDir, in float dither, in uint steps, 
                         inout vec3 rayPos, vec3 worldPos) {
    return ScreenSpaceRayTrace(viewPos, viewDir, dither, steps, rayPos, worldPos, false);
}

bool ScreenSpaceRayTrace(in vec3 viewPos, in vec3 viewDir, in float dither, in uint steps, 
                         inout vec3 rayPos) {
    vec3 fallbackWorldPos = vec3(0.0, cameraPosition.y - 100.0, 0.0);
    return ScreenSpaceRayTrace(viewPos, viewDir, dither, steps, rayPos, fallbackWorldPos, false);
}

#if defined DISTANT_HORIZONS
    bool ScreenSpaceRayTraceDH(in vec3 viewPos, in vec3 viewDir, in float dither, in uint steps, 
                               inout vec3 rayPos, vec3 worldPos, bool isUnderwater) {
        const float maxLength = 1.0 / steps;
        const float minLength = length(screenPixelSize);
        
        vec3 position = ViewToScreenSpaceDH(viewDir * abs(viewPos.z) + viewPos);
        vec3 screenDir = normalize(position - rayPos);
        float stepWeight = 1.0 / abs(screenDir.z);
        float stepLength = minOf((step(0.0, screenDir) - rayPos) / screenDir) * rcp(steps);
        
        screenDir.xy *= screenSize;
        rayPos.xy *= screenSize;
        
        float stableDither = dither;
        float distRatio = 0.0;
        
        if (isUnderwater) {
            distRatio = saturate(length(viewPos) / FLICKER_SUPPRESS_DISTANCE);
            stableDither = mix(dither, 0.5, distRatio * 0.9);
        }
        
        float spiralAngle = stableDither * TAU;
        vec2 spiralOffset = vec2(cos(spiralAngle), sin(spiralAngle)) * minLength * 2.0;
        
        vec3 rayStep = screenDir * stepLength;
        rayPos += rayStep * stableDither + screenDir * minLength + vec3(spiralOffset, 0.0);
        
        float depthTolerance = max(abs(rayStep.z) * 3.0, 0.02 / sqr(viewPos.z));
        
        if (isUnderwater) {
            depthTolerance *= 2.5;
            depthTolerance *= (1.0 + distRatio * 5.0);
        }
        
        bool hit = false;
        float depth = texelFetch(dhDepthTex1, ivec2(rayPos.xy), 0).x;
        
        for (uint i = 0u; i < steps; ++i) {
            if (clamp(rayPos.xy, vec2(0.0), screenSize) != rayPos.xy) return false;
            if (rayPos.z >= 1.0) break;
            
            stepLength = abs(depth - rayPos.z) * stepWeight;
            
            float adaptiveStep = clamp(stepLength, minLength, maxLength);
            if (isUnderwater && i < 4u) {
                adaptiveStep *= 0.5;
            }
            
            rayPos += screenDir * adaptiveStep;
            depth = texelFetch(dhDepthTex1, ivec2(rayPos.xy), 0).x;
            
            if (depth < rayPos.z && abs(depthTolerance - (rayPos.z - depth)) < depthTolerance) {
                if (isUnderwater) {
                    if (distRatio > 0.8) {
                        hit = true;
                        break;
                    }
                    float depthNeighbor = texelFetch(dhDepthTex1, ivec2(rayPos.xy) + ivec2(1, 0), 0).x;
                    if (abs(depth - depthNeighbor) < 0.05 * (1.0 + distRatio * 2.0)) {
                        hit = true;
                        break;
                    }
                } else {
                    hit = true;
                    break;
                }
            }
        }
        
        if (!hit) return false;
        rayStep = screenDir * stepLength;
        
        #ifdef RAYTRACE_REFINEMENT
            for (uint i = 0u; i < RAYTRACE_REFINEMENT_STEPS; ++i) {
                if (clamp(rayPos.xy, vec2(0.0), screenSize) != rayPos.xy) break;
                rayStep *= 0.5;
                depth = texelFetch(dhDepthTex1, ivec2(rayPos.xy), 0).x;
                if (depth < rayPos.z && abs(depthTolerance - (rayPos.z - depth)) < depthTolerance) {
                    rayPos -= rayStep;
                } else {
                    rayPos += rayStep;
                }
            }
        #endif
        
        return depth < 1.0;
    }
    
    bool ScreenSpaceRayTraceDH(in vec3 viewPos, in vec3 viewDir, in float dither, in uint steps, 
                               inout vec3 rayPos, vec3 worldPos) {
        return ScreenSpaceRayTraceDH(viewPos, viewDir, dither, steps, rayPos, worldPos, false);
    }
    
    bool ScreenSpaceRayTraceDH(in vec3 viewPos, in vec3 viewDir, in float dither, in uint steps, 
                               inout vec3 rayPos) {
        vec3 fallbackWorldPos = vec3(0.0, cameraPosition.y - 100.0, 0.0);
        return ScreenSpaceRayTraceDH(viewPos, viewDir, dither, steps, rayPos, fallbackWorldPos, false);
    }
#endif

vec3 sampleGGXVNDF(in vec3 viewDir, in float roughness, in vec2 xy) {
    #define SPECULAR_TAIL_CLAMP
    #ifdef SPECULAR_TAIL_CLAMP
        xy.y = clamp(xy.y * 0.25, 1e-3, 0.25);
    #endif
    viewDir = normalize(vec3(roughness * viewDir.xy, viewDir.z));
    float phi = TAU * xy.x;
    float cosTheta = oneMinus(xy.y) * (1.0 + viewDir.z) - viewDir.z;
    float sinTheta = sqrt(saturate(1.0 - cosTheta * cosTheta));
    vec3 reflected = vec3(cossin(phi) * sinTheta, cosTheta);
    vec3 halfway = reflected + viewDir;
    return normalize(vec3(roughness * halfway.xy, halfway.z));
}
//================================================================================================//
// PATH TRACED REFLECTIONS — multi-bounce SSPT
// Реализует настоящий path tracing по экранному пространству.
// Каждый bounce: семплируем VNDF (физически корректное GGX распределение),
// трейсим луч, берём цвет хита, применяем Fresnel. До PATH_REFLECTION_BOUNCES отражений.
//
// Архитектура Bedrock RTX: primary hit → stochastic bounce → temporal accumulate → SVGF denoise
//================================================================================================//

#if PATH_REFLECTIONS == 1

// Хэш для псевдослучайной последовательности (Laine-Karras permutation).
uint LKHash(uint x) {
    x += x << 10u; x ^= x >> 6u;
    x += x <<  3u; x ^= x >> 11u;
    x += x << 15u;
    return x;
}

// 2D → vec2 [0,1) — низкодискрепантная последовательность Собола/R2.
vec2 R2Sequence(uint i, uint seed) {
    uint h = LKHash(i ^ seed);
    return vec2(
        float(h & 0xFFFFu)          * (1.0 / 65536.0),
        float((h >> 16u) & 0xFFFFu) * (1.0 / 65536.0)
    );
}

// Построение ортонормированного базиса вокруг вектора N (метод Frisvad/Duff).
mat3 BuildTBN(in vec3 N) {
    vec3 up  = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
    vec3 T   = normalize(cross(up, N));
    vec3 B   = cross(N, T);
    return mat3(T, B, N);
}

// Семплирование hemisphere для диффузного GI-bounce (cosine-weighted).
vec3 SampleCosineHemisphere(in vec2 xi) {
    float phi      = TAU * xi.x;
    float cosTheta = sqrt(xi.y);
    float sinTheta = sqrt(1.0 - xi.y);
    return vec3(cos(phi) * sinTheta, sin(phi) * sinTheta, cosTheta);
}

// Семплирование GGX VNDF в мировом пространстве.
// viewDirLocal — направление камеры в TBN-пространстве.
vec3 SampleGGXWorld(in vec3 worldViewDir, in vec3 worldNormal, in float roughness, in vec2 xi) {
    mat3 tbn        = BuildTBN(worldNormal);
    vec3 localView  = worldViewDir * tbn; // world→local
    vec3 localH     = sampleGGXVNDF(localView, roughness, xi);
    return normalize(reflect(-worldViewDir, tbn * localH)); // local→world
}

#ifndef WORLD_REFLECTION_RSM
    #define WORLD_REFLECTION_RSM 1   // [0 1] — RSM-освещение (от ламп/RSM-источников) в точке промаха луча отражения
#endif

#ifndef WORLD_REFLECTION_RSM_DIST
    #define WORLD_REFLECTION_RSM_DIST 24.0   // макс. дистанция вдоль луча, на которой ищем RSM-точку при промахе
#endif

// Попытка трейснуть один bounce в screen-space.
// Возвращает цвет хита (fallback — RSM-освещение в точке промаха и/или skybox).
// hitPos — screen-space позиция хита (xy = texel / screenSize, z = depth).
vec3 TraceReflectionBounce(
    in  vec3  viewPos,       // позиция поверхности в view-space
    in  vec3  bounceDir,     // направление луча в view-space
    in  float dither,
    out bool  hit,
    out vec3  hitScreenPos
) {
    uint steps    = uint(PATH_REFLECTION_SAMPLES);
    hitScreenPos  = ViewToScreenSpace(viewPos);

    hit = ScreenSpaceRayTrace(viewPos, bounceDir, dither, steps, hitScreenPos, 
                               transMAD(gbufferModelViewInverse, viewPos), false);

    if (hit) {
        ivec2 hitTexel = ivec2(hitScreenPos.xy);
        // Берём освещённый цвет из color buffer (colortex4 — финальный lit HDR буфер).
        return texelFetch(colortex4, hitTexel, 0).rgb;
    }

    vec3 result = vec3(0.0);

    #if WORLD_REFLECTION_RSM == 1 && defined WORLD_REFLECTION_RSM_AVAILABLE
        // Miss по экрану — луч ушёл "в мир". Считаем RSM прямо вдоль направления луча:
        // берём виртуальную точку на фиксированной дистанции (как если бы там была
        // поверхность, развёрнутая навстречу лучу) и спрашиваем у shadowmap/RSM,
        // освещена ли она каким-то источником (лампой и т.п.) — без привязки к skylight.
        vec3 rsmWorldPos    = transMAD(gbufferModelViewInverse, viewPos + bounceDir * WORLD_REFLECTION_RSM_DIST);
        vec3 rsmViewPos     = transMAD(gbufferModelView, rsmWorldPos);
        vec3 rsmWorldNormal = mat3(gbufferModelViewInverse) * (-bounceDir);

        result += RSM_Calculate(rsmViewPos, rsmWorldNormal, dither);
    #endif

    #if REFLECTION_SHOW_SKY == 1
        // Доп. слой неба поверх RSM (или единственный источник, если RSM выключен).
        vec3 worldDir = mat3(gbufferModelViewInverse) * bounceDir;
        vec3 skyColor = textureBicubic(colortex5, ProjectSky(worldDir) 
                                       + vec2(0.0, skyCaptureRes.y * screenPixelSize.y)).rgb;
        result += skyColor;
    #endif

    return result;
}

// Главная функция: path-traced reflections для поверхности.
// normal, viewPos, material — из g-buffer.
// Возвращает radiance от отражений (без Fresnel множителя — он применяется снаружи).
vec3 CalculatePathTracedReflections(
    in vec3     viewPos,
    in vec3     viewNormal,
    in Material material,
    in float    skylight,
    in uint     bounces,
    in float    dither
) {
    if (!material.hasReflections) return vec3(0.0);

    vec3  viewDir      = normalize(viewPos);
    vec3  result       = vec3(0.0);
    vec3  throughput   = vec3(1.0);

    // Текущая позиция и нормаль (обновляются при каждом bounce).
    vec3  curViewPos   = viewPos;
    vec3  curNormal    = viewNormal;
    float curRoughness = material.roughness;
    float curF0        = material.f0;
    float curIsMetal   = material.isMetal;

    uint seed = uint(gl_FragCoord.x) * 1973u + uint(gl_FragCoord.y) * 9277u
              + uint(frameCounter) * 26699u;

    for (uint b = 0u; b < bounces; ++b) {
        if (maxOf(throughput) < 0.01) break; // Russian Roulette по throughput

        float alpha2 = sqr(curRoughness);

        // Семплируем VNDF — направление bounce-луча в view-space.
        vec2  xi        = R2Sequence(b, seed);
        vec3  worldNorm = mat3(gbufferModelViewInverse) * curNormal;
        vec3  worldView = mat3(gbufferModelViewInverse) * (-viewDir);

        // Для зеркальных поверхностей (металлы, вода) — зеркальный bounce.
        // Для шероховатых — стохастический GGX bounce.
        vec3  bounceWorldDir;
        if (curRoughness < 1e-3) {
            bounceWorldDir = reflect(mat3(gbufferModelViewInverse) * viewDir, worldNorm);
        } else {
            bounceWorldDir = SampleGGXWorld(-worldView, worldNorm, curRoughness, xi);
        }

        vec3  bounceViewDir = mat3(gbufferModelView) * bounceWorldDir;

        // Проверяем что луч идёт от поверхности (не под неё).
        float NdotL = dot(curNormal, bounceViewDir);
        if (NdotL < 1e-4) break;

        float NdotV = max(dot(curNormal, -viewDir), 1e-4);
        float LdotH = max(dot(bounceViewDir, normalize(bounceViewDir - viewDir)), 1e-4);

        // Fresnel для этого bounce.
        float F;
        if (curIsMetal > 0.5) {
            F = FresnelSchlick(NdotV, curF0);
        } else {
            F = FresnelSchlick(LdotH, curF0);
        }

        // Цвет металла окрашивает отражение.
        vec3 reflectTint = mix(vec3(1.0), vec3(0.7, 0.75, 0.8), curIsMetal);

        // BRDF weight для этого bounce (GGX visibility term).
        float Vis = V2SmithGGX(NdotV, max(NdotL, 1e-4), alpha2);

        // Ограничиваем чтоб не взрывало яркость на grazing.
        float brdfWeight = min(F * Vis * NdotL * 4.0, 8.0);

        // Трейсим bounce.
        bool  hit;
        vec3  hitScreenPos;
        float bounceDither = fract(dither + float(b) * 0.618033988); // golden ratio offset
        vec3  hitColor = TraceReflectionBounce(curViewPos, bounceViewDir, bounceDither, 
                                                hit, hitScreenPos);

        result    += throughput * hitColor * brdfWeight * reflectTint;
        throughput *= F * reflectTint;

        // Если промахнулись (miss) — дальше трейсить нечего.
        if (!hit) break;

        // Обновляем текущую позицию и нормаль для следующего bounce.
        curViewPos = ScreenToViewSpace(hitScreenPos);

        // Читаем нормаль хита из g-buffer (colortex3 xy = packed normal).
        ivec2 hitTexel  = ivec2(hitScreenPos.xy);
        vec4  gbuf3Hit  = texelFetch(colortex3, hitTexel, 0);
        curNormal       = DecodeNormal(gbuf3Hit.xy);

        // Читаем материал хита.
        vec2  specHit   = texelFetch(colortex0, hitTexel, 0).xy;
        curRoughness    = sqr(1.0 - specHit.r);
        curF0           = specHit.g;

        // Упрощённая металличность для дальних bounces.
        curIsMetal = float(specHit.g > (229.5 / 255.0));

        viewDir    = normalize(curViewPos);

        // Ограничиваем количество отражённых отражений (зеркало в зеркале).
        if (curRoughness > 0.5 && b > 1u) break;
    }

    // Clamp для стабильности (fireflies suppression).
    return clamp(result, vec3(0.0), vec3(PATH_REFLECTION_MAX_DIST));
}

#endif // PATH_REFLECTIONS

//================================================================================================//
// HYBRID REFLECTIONS — SSR + WORLD RSM (REFLECTION_TYPE == 2)
// Сначала обычный screen-space трейс (быстрый, как REFLECTION_TYPE == 0).
// Если SSR промахнулся — луч продолжается в мировом пространстве и в точке,
// где он "упирается" (на фиксированной дистанции вдоль направления), берётся
// RSM-освещение (Reflective Shadow Map) от ламп/блок-света — как дешёвая
// аппроксимация "trace into world" без полноценного path tracing.
// По сути это AO/RSM трассировка поверх обычного SSR, отрисованная вторым слоем.
//================================================================================================//
#if REFLECTION_TYPE == 2

vec3 CalculateHybridReflectionRSM(
    in vec3  viewPos,     // позиция поверхности (view-space)
    in vec3  rayDir,      // направление отражённого луча (view-space)
    in float dither
) {
    // Виртуальная точка на фиксированной дистанции вдоль луча отражения —
    // там, где "должна быть" поверхность, если бы луч продолжил путь в мире.
    vec3 rsmViewPos     = viewPos + rayDir * HYBRID_RSM_TRACE_DIST;
    vec3 rsmWorldNormal = mat3(gbufferModelViewInverse) * (-rayDir);

    #if HYBRID_RSM_INDOOR == 1
        vec3 rsmLight = RSM_Calculate_Indoor(rsmViewPos, rsmWorldNormal, dither);
    #else
        vec3 rsmLight = RSM_Calculate(rsmViewPos, rsmWorldNormal, dither);
    #endif

    return rsmLight * HYBRID_RSM_STRENGTH;
}

#endif // REFLECTION_TYPE == 2


