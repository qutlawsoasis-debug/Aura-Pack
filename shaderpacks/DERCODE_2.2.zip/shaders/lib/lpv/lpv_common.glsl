// LPV Common - adapted for 128x64x128 volume
// How far light propagates (block, sky)
const vec2 LpvBlockSkyRange = vec2(15.0, 24.0);

// Non-cubic volume: 128 x 64 x 128
const uvec3 LpvSize3 = uvec3(128u, 64u, 128u);

vec3 GetLpvPosition(const in vec3 playerPos) {
	vec3 cameraOffset = fract(cameraPosition);
	return playerPos + cameraOffset + vec3(LpvSize3) / 2.0;
}
