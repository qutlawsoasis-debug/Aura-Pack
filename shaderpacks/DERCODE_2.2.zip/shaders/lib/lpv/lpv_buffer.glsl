// LPV Buffer image bindings
// Maps to my shader's registered images:
//   lightimg0 -> imgLpv1  (rgba16f 3D)
//   lightimg1 -> imgLpv2  (rgba16f 3D)
//   voxelGridA -> imgVoxelMask (r8ui 3D)
//   imgBlockData -> rg32ui 1D (new, declared in setup/shadowcomp)

#ifdef RENDER_SHADOWCOMP
    layout(rgba16f) uniform restrict image3D imgLpv1;
    layout(rgba16f) uniform restrict image3D imgLpv2;
#else
    layout(rgba16f) uniform readonly image3D imgLpv1;
    layout(rgba16f) uniform readonly image3D imgLpv2;
#endif
