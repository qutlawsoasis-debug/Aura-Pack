// Voxel mask image — uses my shader's voxelGridA (r8ui 3D)
// In shadow pass: write; elsewhere: read-only

#ifdef RENDER_SHADOW
    layout(r8ui) uniform uimage3D imgVoxelMask;
#else
    layout(r8ui) uniform readonly uimage3D imgVoxelMask;
#endif

const uvec3 VoxelSize3 = uvec3(128u, 64u, 128u);

#define BLOCK_EMPTY 0

ivec3 GetVoxelIndex(const in vec3 playerPos) {
    vec3 cameraOffset = fract(cameraPosition);
    return ivec3(floor(playerPos + cameraOffset) + ivec3(VoxelSize3) / 2);
}

void SetVoxelBlock(const in vec3 playerPos, const in uint blockId) {
    ivec3 voxelPos = GetVoxelIndex(playerPos);
    if (clamp(voxelPos, ivec3(0), ivec3(VoxelSize3) - 1) != voxelPos) return;
    imageStore(imgVoxelMask, voxelPos, uvec4(blockId));
}
