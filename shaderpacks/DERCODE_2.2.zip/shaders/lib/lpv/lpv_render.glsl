// LPV sampling and block/sky light extraction
// Used in terrain, block, textured frags

uniform sampler3D texLpv1;
uniform sampler3D texLpv2;

// LPV block brightness scale  1/15
const float LpvBlockBrightness = 0.066666;

float lpvCurve(float v) {
    return v * v;
}

vec4 SampleLpvLinear(const in vec3 lpvPos) {
    vec3 texcoord = lpvPos / vec3(LpvSize3);

    vec4 lpvSample = (frameCounter % 2) == 0
        ? textureLod(texLpv1, texcoord, 0)
        : textureLod(texLpv2, texcoord, 0);

    vec3 hsv = RgbToHsv(lpvSample.rgb);
    hsv.z = lpvCurve(hsv.b) * LpvBlockSkyRange.x;
    lpvSample.rgb = HsvToRgb(hsv);

    lpvSample.rgb = clamp(lpvSample.rgb / 15.0, 0.0, 1.0);

    return lpvSample;
}

vec3 GetLpvBlockLight(const in vec4 lpvSample) {
    return LpvBlockBrightness * lpvSample.rgb;
}

float GetLpvSkyLight(const in vec4 lpvSample) {
    float skyLight = clamp(lpvSample.a, 0.0, 1.0);
    return skyLight * skyLight;
}

// Apply LPV to block light, with smooth falloff at volume edges
vec3 ApplyLpvBlockLight(
    in vec3 vanillaBlockLight,
    in float vanillaLightmap,
    in vec3 lpvPos
) {
    vec4 lpvSample = SampleLpvLinear(lpvPos);
    vec3 lpvBlockLight = GetLpvBlockLight(lpvSample);

    // Smooth edge falloff (10 block fade)
    float fadeLength = 10.0;
    vec3 cubicRadius = clamp(
        min((vec3(LpvSize3) - 1.0 - lpvPos) / fadeLength, lpvPos / fadeLength),
        0.0, 1.0
    );
    float voxelRangeFalloff = cubicRadius.x * cubicRadius.y * cubicRadius.z;
    voxelRangeFalloff = 1.0 - pow(1.0 - pow(voxelRangeFalloff, 1.5), 3.0);

    return mix(vanillaBlockLight, lpvSample.rgb, voxelRangeFalloff);
}
