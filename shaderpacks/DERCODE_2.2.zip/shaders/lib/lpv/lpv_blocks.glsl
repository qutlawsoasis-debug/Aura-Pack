// LPV Block data 1D image (rg32ui)
// Stores per-blockID light color, range, tint, and mask

#ifdef RENDER_SETUP
    layout(rg32ui) uniform writeonly uimage1D imgBlockData;
#else
    layout(rg32ui) uniform readonly uimage1D imgBlockData;
#endif
