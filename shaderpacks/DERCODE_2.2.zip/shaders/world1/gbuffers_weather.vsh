#version 450 compatibility

#include "/program/Gbuffers/WeatherDef.glsl"

out float tint;
out vec2 texcoord;

uniform float frameTimeCounter;
uniform vec3 cameraPosition;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec2 taaOffset;

void main() {
    texcoord = mat2(gl_TextureMatrix[0]) * gl_MultiTexCoord0.xy + gl_TextureMatrix[0][3].xy;
    texcoord /= RAIN_SIZE;

    vec4 worldPos = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
    float distFromCam = length(worldPos.xyz);
    float startFade = 1.0; 
    if (float(RAIN_DIST) > 0.001) {
        startFade = smoothstep(float(RAIN_DIST) * 0.8, float(RAIN_DIST), distFromCam);
    }

    tint = gl_Color.a * RAIN_VISIBILITY * startFade;

    float windPos = dot(worldPos.xyz + cameraPosition, vec3(2.0));
    float wind = fma(sin(windPos + frameTimeCounter * 0.1), 0.25, 0.25);
    
    vec2 windDir = vec2(RAIN_WIND_X, RAIN_WIND_Y);
    worldPos.xz -= worldPos.y * wind * windDir * RAIN_DISTURBANCE_INTESIVITY;

    gl_Position = gl_ProjectionMatrix * gbufferModelView * worldPos;

    #ifdef TAA_ENABLED
        gl_Position.xy += taaOffset * gl_Position.w * 0.5;
    #endif
}