#version 450 compatibility

#include "/program/Gbuffers/WeatherDef.glsl"

out vec3 albedoData;

/* DRAWBUFFERS:0 */

uniform sampler2D tex;

in vec2 texcoord;
in float tint;

void main() {
    float albedoAlpha = texture(tex, texcoord * vec2(4.0, 2.0)).a;
    if (albedoAlpha < 0.1) discard;
    vec3 baseColor = vec3(RAIN_COLOR_R, RAIN_COLOR_G, RAIN_COLOR_B) * RAIN_ALBEDO;
    vec2 dropUV = fract(texcoord * vec2(4.0, 2.0)) * 2.0 - 1.0;
    float distFromCenter = dot(dropUV, dropUV); 
    float lensEffect = (1.0 - distFromCenter) * RAIN_DROP_SHADE;
    float refractionModifier = 1.0 + (RAIN_REFRACTION * 0.5);
    albedoData = baseColor * max(lensEffect, 0.2); 
    albedoData *= albedoAlpha * tint * refractionModifier;
}