
uniform vec2 taaOffset;
uniform int blockEntityId;
uniform vec3 cameraPosition;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferModelView;

//#if MC_VERSION < 11500
//	layout(location = 12) in vec4 at_tangent;
//#else
//	layout(location = 13) in vec4 at_tangent;
//#endif

out vec4 vs_tint;
out vec2 vs_texcoord;
out vec3 vs_minecraftPos;
out vec4 vs_viewPos;
out vec2 vs_lightmap;

// Локальная позиция вершины внутри блока (0..1) — нужна geom-шейдеру, чтобы
// понять, верхняя это грань snow layer (для продавливания) или боковая/нижняя.
out vec3 vs_localPos;

//flat out mat3 tbnMatrix;

flat out int vs_materialIDs;

#include "/Settings.glsl"

void main() {
	vs_texcoord = gl_MultiTexCoord0.xy;

	vs_lightmap = clamp(gl_MultiTexCoord1.xy * (1.0 / 240.0), 0.0, 1.0);

    //tbnMatrix[2] = normalize(gl_NormalMatrix * gl_Normal);
	//#if defined MC_NORMAL_MAP || defined RAIN_SPLASH_EFFECT
	//	tbnMatrix[0] = normalize(gl_NormalMatrix * at_tangent.xyz);
	//	tbnMatrix[1] = cross(tbnMatrix[0], tbnMatrix[2]) * sign(at_tangent.w);
	//#endif

	vs_viewPos = gl_ModelViewMatrix * gl_Vertex;
	vs_minecraftPos = mat3(gbufferModelViewInverse) * vs_viewPos.xyz + gbufferModelViewInverse[3].xyz + cameraPosition;

	vs_localPos = fract(gl_Vertex.xyz);

	// gl_Position нужен как passthrough-фолбэк для обычных (не-снежных) блоков —
	// geometry shader пересчитывает позицию заново только для снега.
	gl_Position = gl_ProjectionMatrix * vs_viewPos;
	#ifdef TAA_ENABLED
		gl_Position.xy += taaOffset * gl_Position.w;
	#endif

	vs_tint = gl_Color;

	vs_materialIDs = max(blockEntityId - 10000, 0);
}
