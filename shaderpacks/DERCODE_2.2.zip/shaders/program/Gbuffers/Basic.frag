layout(location = 0) out vec3 albedoData;
layout(location = 1) out vec4 colortex7Out;
//layout(location = 2) out vec2 colortex3Out;

/* DRAWBUFFERS:67 */

//uniform mat4 gbufferModelView;

flat in vec4 tint;
in vec2 lightmap;

#include "/lib/Head/Common.inc"

//#define EMISSIVE_SELECT_OUTLINE

//----// CUSTOM OUTLINE STYLE //--------------------------------------------------//
// 0 = OFF (vanilla outline color)
// 1 = BLACK   - classic solid black outline
// 2 = GLOW    - warm pulsing glow color
// 3 = RGB     - animated rainbow outline
// 4 = CUSTOM  - fixed user color
// 5 = CYAN-PINK FADE - animated cyan <-> pink fading glow
// 6 = RGB GLOW STRONG - same rainbow animation, much stronger glow
#ifndef OUTLINE_STYLE
	#define OUTLINE_STYLE 3 // [0 1 2 3 4 5 6]
#endif

#ifndef OUTLINE_GLOW_SPEED
	#define OUTLINE_GLOW_SPEED 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#endif

#ifndef OUTLINE_RGB_SPEED
	#define OUTLINE_RGB_SPEED 0.5 // [0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#endif

#ifndef OUTLINE_CUSTOM_COLOR
	#define OUTLINE_CUSTOM_COLOR vec3(1.0, 0.85, 0.2) // R G B, 0.0-1.0
#endif

#ifndef OUTLINE_FADE_SPEED
	#define OUTLINE_FADE_SPEED 0.75 // [0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#endif

#if OUTLINE_STYLE == 2 || OUTLINE_STYLE == 3 || OUTLINE_STYLE == 5 || OUTLINE_STYLE == 6
	uniform float frameTimeCounter;
#endif

#if OUTLINE_STYLE == 3 || OUTLINE_STYLE == 6
	// Simple HSV-style hue rotation -> RGB
	vec3 OutlineHueShift(in float hue) {
		vec3 rgb = clamp(abs(mod(hue * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0);
		return rgb;
	}
#endif

vec3 GetOutlineColor(in vec3 vanillaColor) {
	#if OUTLINE_STYLE == 0
		return vanillaColor;
	#elif OUTLINE_STYLE == 1
		return vec3(0.0);
	#elif OUTLINE_STYLE == 2
		// Warm pulsing glow
		float pulse = sin(frameTimeCounter * OUTLINE_GLOW_SPEED * 2.0) * 0.5 + 0.5;
		return mix(vec3(1.0, 0.7, 0.25), vec3(1.0, 0.95, 0.8), pulse);
	#elif OUTLINE_STYLE == 3
		// Animated rainbow, varies slightly across the screen
		float hue = fract(frameTimeCounter * OUTLINE_RGB_SPEED * 0.1 + (gl_FragCoord.x + gl_FragCoord.y) * 0.001);
		return OutlineHueShift(hue);
	#elif OUTLINE_STYLE == 4
		return OUTLINE_CUSTOM_COLOR;
	#elif OUTLINE_STYLE == 5
		// Flowing cyan <-> pink gradient (like the RGB style, but 2-color)
		float wave = sin((gl_FragCoord.x + gl_FragCoord.y) * 0.05 - frameTimeCounter * OUTLINE_FADE_SPEED) * 0.5 + 0.5;
		vec3 cyan = vec3(0.2, 0.95, 1.0);
		vec3 pink = vec3(1.0, 0.25, 0.75);
		vec3 col = mix(cyan, pink, wave);
		// extra brightness boost so the glow reads strongly
		return col * 1.3;
	#elif OUTLINE_STYLE == 6
		// RGB rainbow with a much stronger glow boost
		float hue = fract(frameTimeCounter * OUTLINE_RGB_SPEED * 0.1 + (gl_FragCoord.x + gl_FragCoord.y) * 0.001);
		return OutlineHueShift(hue) * 2.5;
	#else
		return vanillaColor;
	#endif
}

float bayer2 (vec2 a) { a = 0.5 * floor(a); return fract(1.5 * fract(a.y) + a.x); }
#define bayer4(a) (bayer2(0.5 * (a)) * 0.25 + bayer2(a))

void main() {
	int materialIDs = 1;

	if (tint.a < 0.1) { discard; return; }

	albedoData = GetOutlineColor(tint.rgb);
	#ifdef EMISSIVE_SELECT_OUTLINE
		if (abs(tint.a - 0.4) + dotSelf(tint.rgb) < 1e-2) {
            discard;
            return;
		}
	#endif
	colortex7Out.xy = lightmap + (bayer4(gl_FragCoord.xy) - 0.5) * rcp(255.0);
	colortex7Out.z = float(materialIDs + 0.1) * rcp(255.0);
	//colortex3Out = EncodeNormal(mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0));
}