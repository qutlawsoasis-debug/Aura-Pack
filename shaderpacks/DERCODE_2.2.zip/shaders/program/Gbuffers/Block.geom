// Block.geom - Эффект продавливания снежного покрова (snow layer) вокруг игрока.
// Аналог физики Physics Mod: вершины верхней грани снега проседают рядом с игроком,
// плавно восстанавливаясь к краям вмятины. Работает только для отдельного материала
// snow layers (block.20131 в block.properties), не трогает snow_block/лёд и т.д.

#include "/lib/Head/Common.inc"

// ============================================================
// SNOW PRESS — НАСТРОЙКИ ПОЛЬЗОВАТЕЛЯ
// ============================================================

#define SNOW_PRESS_ENABLED 0      // [0 1] Главный тумблер эффекта продавливания снега

#define SNOW_PRESS_RADIUS 10.9     // [0.5 0.7 0.9 1.1 1.4 1.8] Радиус вмятины вокруг игрока (блоки)
#define SNOW_PRESS_DEPTH 10.85     // [0.3 0.5 0.65 0.85 1.0]   Максимальная глубина продавливания (доля высоты слоя)
#define SNOW_PRESS_RIM 0.12       // [0.0 0.05 0.1 0.15 0.2]   Выпирание снега по краю вмятины (валик)
#define SNOW_PRESS_SOFTNESS 1.6   // [1.0 1.4 1.6 2.0 2.6]     Мягкость спада (выше = плавнее переход)

// Материал ID, соответствующий снежному покрову. Должен совпадать с
// (block.20131 - 10000) = 131 из block.properties.
#define SNOW_MATERIAL_ID 131

// ============================================================

layout(triangles) in;
layout(triangle_strip, max_vertices = 3) out;

in vec4 vs_tint[];
in vec2 vs_texcoord[];
in vec3 vs_minecraftPos[];
in vec4 vs_viewPos[];
in vec2 vs_lightmap[];
in vec3 vs_localPos[];
flat in int vs_materialIDs[];

out vec4 tint;
out vec2 texcoord;
out vec3 minecraftPos;
out vec4 viewPos;
out vec2 lightmap;
flat out int materialIDs;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 relativeEyePosition; // позиция глаз игрока относительно камеры (как в Terrain.geom)
uniform vec2 taaOffset;
uniform float frameTimeCounter;

#if SNOW_PRESS_ENABLED == 1

vec4 toClipSpace3GeomB(vec3 viewSpacePosition) {
    return vec4(projMAD(gl_ProjectionMatrix, viewSpacePosition), -viewSpacePosition.z);
}

// Лёгкий шум для неровного, не идеально круглого следа (как настоящий снег)
float pressNoise(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

// Считает вертикальное смещение (продавливание) для точки world-space XZ
// относительно позиции игрока. Возвращает отрицательное значение = вниз.
float calcSnowPress(vec3 worldPos) {
    // Позиция игрока в world space (relativeEyePosition уже учитывает камеру)
    vec3 playerWorldPos = cameraPosition + relativeEyePosition;
    playerWorldPos.y -= 1.62; // от глаз до уровня ступней (стандартный рост игрока)

    vec2 toPlayer = worldPos.xz - playerWorldPos.xz;
    float dist = length(toPlayer);

    // Лёгкая нерегулярность формы следа (не идеальный круг)
    float angle = atan(toPlayer.y, toPlayer.x);
    float shapeNoise = 1.0 + 0.06 * sin(angle * 5.0 + worldPos.x * 0.7);
    float effDist = dist * shapeNoise;

    float radius = SNOW_PRESS_RADIUS;

    // Основная яма: гладкий спад от центра к краю
    float pit = 1.0 - smoothstep(0.0, radius, effDist);
    pit = pow(pit, SNOW_PRESS_SOFTNESS);

    // Валик приподнятого снега сразу за краем вмятины (физически снег "выдавливается" наружу)
    float rim = smoothstep(radius * 0.65, radius, effDist) *
                (1.0 - smoothstep(radius, radius * 1.35, effDist));

    float offset = -pit * SNOW_PRESS_DEPTH + rim * SNOW_PRESS_RIM;
    return offset;
}

void emitSnowVertex(int idx, float pressOffset, bool isTopFace) {
    vec3 worldPos = vs_minecraftPos[idx];

    if (isTopFace) {
        worldPos.y += pressOffset;
    }

    vec3 viewSpacePos = mat3(gbufferModelView) * (worldPos - cameraPosition) + gbufferModelView[3].xyz;

    gl_Position = toClipSpace3GeomB(viewSpacePos);
    #ifdef TAA_ENABLED
        gl_Position.xy += taaOffset * gl_Position.w;
    #endif

    tint        = vs_tint[idx];
    texcoord    = vs_texcoord[idx];
    minecraftPos = worldPos;
    viewPos     = vec4(viewSpacePos, vs_viewPos[idx].w);
    lightmap    = vs_lightmap[idx];
    materialIDs = vs_materialIDs[idx];

    EmitVertex();
}

#endif

void main() {
#if SNOW_PRESS_ENABLED == 1
    bool isSnow = (vs_materialIDs[0] == SNOW_MATERIAL_ID);

    if (isSnow) {
        // Определяем верхнюю грань по локальному Y: если у всех трёх вершин
        // локальная Y-координата близка к высоте слоя (верх блока), считаем это top face.
        // localPos.y у snow layer обычно лежит в диапазоне 0..(1/8 * layers), но
        // верх всегда максимум среди вершин примитива — этого достаточно, чтобы отличить
        // верхнюю грань от боковых (где Y варьируется по высоте) и нижней (Y == 0 у всех).
        float y0 = vs_localPos[0].y;
        float y1 = vs_localPos[1].y;
        float y2 = vs_localPos[2].y;
        float maxY = max(y0, max(y1, y2));
        float minY = min(y0, min(y1, y2));

        // Top face: все три вершины примерно на одной (максимальной для блока) высоте
        bool isTopFace = (maxY - minY < 0.01) && (maxY > 0.02);

        for (int i = 0; i < 3; i++) {
            float press = isTopFace ? calcSnowPress(vs_minecraftPos[i]) : 0.0;
            // На боковых гранях у верхнего ребра тоже подтягиваем вершину вниз,
            // чтобы не было разрыва меша между продавленным верхом и непродвинутым низом.
            if (!isTopFace && vs_localPos[i].y > 0.02) {
                press = calcSnowPress(vs_minecraftPos[i]);
                vec3 worldPos = vs_minecraftPos[i];
                worldPos.y += press;
                vec3 viewSpacePos = mat3(gbufferModelView) * (worldPos - cameraPosition) + gbufferModelView[3].xyz;
                gl_Position = toClipSpace3GeomB(viewSpacePos);
                #ifdef TAA_ENABLED
                    gl_Position.xy += taaOffset * gl_Position.w;
                #endif
                tint = vs_tint[i];
                texcoord = vs_texcoord[i];
                minecraftPos = worldPos;
                viewPos = vec4(viewSpacePos, vs_viewPos[i].w);
                lightmap = vs_lightmap[i];
                materialIDs = vs_materialIDs[i];
                EmitVertex();
            } else {
                emitSnowVertex(i, press, isTopFace);
            }
        }
        EndPrimitive();
        return;
    }
#endif

    // === ОБЫЧНЫЕ БЛОКИ (без эффекта) — простой passthrough ===
    for (int i = 0; i < 3; i++) {
        gl_Position = gl_in[i].gl_Position;
        tint        = vs_tint[i];
        texcoord    = vs_texcoord[i];
        minecraftPos = vs_minecraftPos[i];
        viewPos     = vs_viewPos[i];
        lightmap    = vs_lightmap[i];
        materialIDs = vs_materialIDs[i];
        EmitVertex();
    }
    EndPrimitive();
}
