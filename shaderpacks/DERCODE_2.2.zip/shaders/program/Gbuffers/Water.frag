layout(location = 0) out vec3 colortex7Out;
layout(location = 1) out vec4 reflectionData;
layout(location = 2) out vec4 colortex3Out;

/* DRAWBUFFERS:723 */

#include "/lib/Head/Common.inc"

uniform sampler2D tex;


#ifdef MC_NORMAL_MAP
    uniform sampler2D normals;
#endif

#include "/lib/Head/Uniforms.inc"

in vec2 texcoord;
in vec2 lightmap;

uniform float enterWater;
uniform float exitWater;
uniform float waterSplashPosX;
uniform float waterSplashPosZ;
in vec3 minecraftPos;

in vec4 tint;
in vec4 viewPos;

flat in mat3 tbnMatrix;

flat in uint materialIDs;

uniform int worldDay;

// Moon textures (albedo + normal, for MOON_STYLE 1/2)
uniform sampler2D colortex16;
uniform sampler2D colortex37;

#include "/lib/Atmosphere/Atmosphere.glsl"

#define PHYSICS_OCEAN_SUPPORT

#ifdef PHYSICS_OCEAN
    #define PHYSICS_FRAGMENT
    #include "/lib/Water/PhysicsOceans.glsl"
#endif

#include "/lib/Water/WaterWave.glsl"

vec2 GetWaterParallaxCoord(in vec3 position, in vec3 tangentViewVector) {
    vec3 stepSize = tangentViewVector * vec3(vec2(0.1 * WATER_WAVE_HEIGHT), 1.0);
    stepSize *= 0.02 / abs(stepSize.z);

    vec3 samplePos = vec3(position.xz - position.y, 1.0) + stepSize;
    float sampleHeight = WaterHeight(samplePos.xy);

    for (uint i = 0u; sampleHeight < samplePos.z && i < 60u; ++i) {
        samplePos += stepSize;
        sampleHeight = WaterHeight(samplePos.xy);
    }

    return samplePos.xy;
}

#include "/lib/Surface/RainEffect.glsl"
#include "/lib/Head/Functions.inc"
#include "/lib/Head/Material.inc"
#include "/lib/Surface/ScreenSpaceReflections.glsl"

// =============================================================================
//  ЭФФЕКТ ОПТИЧЕСКОГО МЕЛКОВОДЬЯ
//  Вода выглядит мельче из-за преломления — классическая иллюзия рефракции.
//  Управляется своим define, не зависит от RAYTRACED_REFRACTION.
// =============================================================================

// Включить / выключить эффект (закомментируй чтобы отключить)
#define WATER_SHALLOW_ILLUSION

// Сила иллюзии.
// 0.5 = физически корректно (IOR 1.33 даёт ~25% подъём дна)
// 1.0–2.0 = преувеличено, очень заметно
#define WATER_SHALLOW_STRENGTH 1.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 1.0 1.25 1.5 2.0]

// Потолок UV-смещения. Защита от артефактов при косом взгляде.
#define WATER_SHALLOW_MAX_OFFSET 0.15 // [0.04 0.06 0.08 0.10 0.12 0.15 0.20]

#ifdef WATER_SHALLOW_ILLUSION

vec4 WaterShallowIllusion(in vec3 normal, in vec3 viewPos) {
    vec2  uv          = gl_FragCoord.xy * screenPixelSize;
    float waterDepth  = gl_FragCoord.z;

    
    float solidRaw = texture(depthtex1, uv).x;

   
    if (solidRaw >= 1.0) return vec4(0.0);

    float waterLin = GetDepthLinear(waterDepth);
    float solidLin = GetDepthLinear(solidRaw);
    float column   = max(0.0, solidLin - waterLin);

   
    if (column < 0.05) return vec4(0.0);


    float iorFactor = 1.0 - (1.0 / WATER_REFRACT_IOR);
    vec2  uvOffset  = normal.xy * column * WATER_SHALLOW_STRENGTH * iorFactor;

    // Ограничение смещения — защита от артефактов
    float len = length(uvOffset);
    if (len > WATER_SHALLOW_MAX_OFFSET)
        uvOffset *= WATER_SHALLOW_MAX_OFFSET / len;

    vec2 refractUV = clamp(uv + uvOffset, vec2(0.0), vec2(1.0));

    // Защита: не читаем пиксели перед водой (руки, блоки поверх)
    float bgDepth = texture(depthtex1, refractUV).x;
    if (bgDepth < waterDepth - 1e-4) return vec4(0.0);

    // Плавное затухание у краёв экрана — убирает чёрные полосы
    float e    = refractUV.x * refractUV.y * (1.0 - refractUV.x) * (1.0 - refractUV.y);
    float fade = clamp(e * 1e2, 0.0, 1.0);
    if (fade < 1e-3) return vec4(0.0);

    // Читаем albedo дна из colortex6 (terrain пишет именно туда)
    vec3 bottomColor = texelFetch(
        colortex6,
        ivec2(refractUV * vec2(viewWidth, viewHeight)),
        0
    ).rgb;

    return vec4(bottomColor, fade);
}

#endif // WATER_SHALLOW_ILLUSION

vec3 UnderwaterReflectionBlur(vec3 centerReflection, vec2 screenCoord) {
    float centerLuma = GetLuminance(centerReflection);
    
    vec2 toEdge = min(screenCoord, screenSize - screenCoord - vec2(1.0));
    int safeRadius = int(min(min(toEdge.x, toEdge.y), 2.0));
    
    if (safeRadius < 1) {
        return centerReflection;
    }
    
    vec3 weightedSum = vec3(0.0);
    float totalWeight = 0.0;
    float maxLuma = centerLuma;
    vec3 brightestColor = centerReflection;
    
    for (int x = -safeRadius; x <= safeRadius; x++) {
        for (int y = -safeRadius; y <= safeRadius; y++) {
            if (x == 0 && y == 0) continue;
            
            ivec2 sampleCoord = ivec2(screenCoord) + ivec2(x, y);
            vec3 neighborColor = texelFetch(colortex4, sampleCoord, 0).rgb;
            float neighborLuma = GetLuminance(neighborColor);
            
            if (neighborLuma > maxLuma) {
                maxLuma = neighborLuma;
                brightestColor = neighborColor;
            }
            
            float dist = sqrt(float(x*x + y*y));
            float distWeight = 1.0 / (1.0 + dist * 0.6);
            
            float brightnessWeight = neighborLuma * neighborLuma * 3.0 + 0.2;
            if (neighborLuma < 0.12) brightnessWeight *= 0.3;
            
            float combinedWeight = distWeight * brightnessWeight;
            weightedSum += neighborColor * combinedWeight;
            totalWeight += combinedWeight;
        }
    }
    
    if (totalWeight < 0.001) {
        return brightestColor;
    }
    
    vec3 brightDominantColor = weightedSum / totalWeight;
    vec3 dilatedColor = max(centerReflection, brightestColor);
    float darkFactor = 1.0 - smoothstep(0.0, 0.25, centerLuma);
    vec3 targetColor = mix(dilatedColor, brightDominantColor, darkFactor);
    
    return targetColor;
}

vec4 CalculateSpecularReflections(in vec3 normal, in float skylight, in vec3 viewPos, in vec3 worldPos) {
    skylight = smoothstep(0.3, 0.8, skylight);
    vec3 viewDir = normalize(viewPos);
    
    bool isUnderwater = (isEyeInWater == 1);
    
    vec3 rayDir;
    if (isUnderwater) {
        rayDir = CalculateUnderwaterReflectDir(viewDir, normal);
    } else {
        rayDir = reflect(viewDir, normal);
    }
    
    float NdotL = dot(normal, rayDir);
    if (NdotL < 1e-6) return vec4(0.0);
    
    float dither = InterleavedGradientNoiseTemporal(gl_FragCoord.xy);
    vec3 screenPos = vec3(gl_FragCoord.xy * screenPixelSize, gl_FragCoord.z);
    
    float NdotV = max(1e-6, dot(normal, -viewDir));
    
    bool hit = ScreenSpaceRayTrace(viewPos, rayDir, dither, RAYTRACE_SAMPLES, screenPos, worldPos, isUnderwater);
    
    vec3 reflection;
    float reflectionConfidence = 0.0;
    
    if (materialIDs == 17u) {
        #ifdef REAL_SKY_REFLECTION
            if (!isUnderwater) {
                if (skylight > 1e-3) {
                    vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
                    float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
                    vec4 skyboxData = textureBicubic(colortex5, ProjectSky(rayDirWorld) + vec2(0.0, skyCaptureRes.y * screenPixelSize.y));
                    
                    vec3 sunmoon = RenderSunReflection(rayDirWorld, worldSunVector);
                    sunmoon += RenderMoonReflection(rayDirWorld, worldSunVector);
                    
                    reflection = hit ? texelFetch(colortex4, ivec2(screenPos.xy), 0).rgb : skyboxData.rgb * skylight * NdotU;
                    reflection += sunmoon * skyboxData.a * skylight * AtmosphereAbsorption(rayDirWorld, AtmosphereExtent);
                    reflectionConfidence = hit ? 1.0 : 0.3;
                }
            } else {
                if (hit) {
                    reflection = texelFetch(colortex4, ivec2(screenPos.xy), 0).rgb;
                    reflectionConfidence = 1.0;
                } else {
                    vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
                    float upFactor = saturate(rayDirWorld.y * 0.5 + 0.5);
                    reflection = vec3(0.05, 0.4, 0.8) * 0.4 * (1.0 + upFactor * 2.0);
                    reflectionConfidence = 0.2;
                }
            }
        #else
            if (hit) {
                reflection = texelFetch(colortex4, ivec2(screenPos.xy), 0).rgb;
                reflectionConfidence = 1.0;
            }
            #if defined IS_OVERWORLD
                else if (skylight > 1e-3) {
                    if (!isUnderwater) {
                        vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
                        float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
                        vec4 skyboxData = textureBicubic(colortex5, ProjectSky(rayDirWorld) + vec2(0.0, skyCaptureRes.y * screenPixelSize.y));
                        reflection = skyboxData.rgb * skylight * NdotU;
                        reflectionConfidence = 0.3;
                    } else {
                        vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
                        float upFactor = saturate(rayDirWorld.y * 0.5 + 0.5);
                        reflection = vec3(0.05, 0.4, 0.8) * 0.3 * (1.0 + upFactor) * (timeNoon + timeMidnight * NIGHT_BRIGHTNESS);
                        reflectionConfidence = 0.15;
                    }
                }
            #elif defined IS_END
                else {
                    if (!isUnderwater) {
                        vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
                        float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
                        #ifdef DARK_END
                            bool darkEnd = bossBattle == 2 || bossBattle == 3;
                        #else
                            const bool darkEnd = false;
                        #endif
                        vec3 sunDisc = RenderSun(rayDirWorld, worldSunVector);
                        sunDisc *= vec3(0.99, 0.93, 0.65) * 0.1;
                        reflection = mix(vec3(0.396, 0.352, 0.108), vec3(0.04, 0.02, 0.05), float(darkEnd) * 0.9) * 2.0 * exp2(-max0(rayDirWorld.y) * 1.5);
                        if (!darkEnd) reflection += sunDisc;
                        reflection *= NdotU;
                        reflectionConfidence = 0.3;
                    } else {
                        reflection = vec3(0.05, 0.3, 0.6) * 0.2;
                        reflectionConfidence = 0.1;
                    }
                }
            #endif
        #endif
    } else {
        if (hit) {
            reflection = texelFetch(colortex4, ivec2(screenPos.xy), 0).rgb;
            reflectionConfidence = 1.0;
        }
        #if defined IS_OVERWORLD
            else if (skylight > 1e-3) {
                vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
                float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
                vec4 skyboxData = textureBicubic(colortex5, ProjectSky(rayDirWorld) + vec2(0.0, skyCaptureRes.y * screenPixelSize.y));
                reflection = skyboxData.rgb * skylight * NdotU;
                reflectionConfidence = 0.3;
            }
        #elif defined IS_END
            else {
                vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
                float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
                #ifdef DARK_END
                    bool darkEnd = bossBattle == 2 || bossBattle == 3;
                #else
                    const bool darkEnd = false;
                #endif
                vec3 sunDisc = RenderSun(rayDirWorld, worldSunVector);
                sunDisc *= vec3(0.99, 0.93, 0.65) * 0.1;
                reflection = mix(vec3(0.396, 0.352, 0.108), vec3(0.04, 0.02, 0.05), float(darkEnd) * 0.9) * 2.0 * exp2(-max0(rayDirWorld.y) * 1.5);
                if (!darkEnd) reflection += sunDisc;
                reflection *= NdotU;
                reflectionConfidence = 0.3;
            }
        #endif
    }
    
    float specular;
    if (isUnderwater) {
        specular = FresnelDielectricN(NdotV, 1.0 / WATER_REFRACT_IOR);
    } else {
        specular = FresnelDielectricN(NdotV, materialIDs == 17u ? WATER_REFRACT_IOR : GLASS_REFRACT_IOR);
    }
    
    if (isUnderwater) {
        reflection *= 0.85;
        reflection = UnderwaterReflectionBlur(reflection, screenPos.xy);
    }
    
    return clamp16F(vec4(reflection * specular, 1.0 - specular));
}

void main() {
    vec4 albedo = texture(tex, texcoord) * tint;

    vec3 normalData;
    #ifdef PHYSICS_OCEAN
        if (materialIDs == 17u) {
            WavePixelData wave = physics_wavePixel(physics_localPosition.xz, physics_localWaviness, physics_iterationsNormal, physics_gameTime);
            normalData = mat3(gbufferModelView) * wave.normal;
            normalData = isEyeInWater == 1 ? -normalData : normalData;
        } else {
            #ifdef MC_NORMAL_MAP
                normalData = texture(normals, texcoord).rgb;
                DecodeNormalTex(normalData);
            #else
                normalData = vec3(0.0, 0.0, 1.0);
            #endif

            #if defined IS_OVERWORLD
                #ifdef RAIN_SPLASH_EFFECT
                    if (wetnessCustom > 1e-2) {
                        vec2 rainNormal = GetRainNormal(wetnessCustom, minecraftPos);
                        normalData.xy += rainNormal * wetnessCustom * saturate(lightmap.y * 10.0 - 9.0);
                    }
                #endif
            #endif

            normalData = normalize(tbnMatrix * normalData);
        }
    #else
        if (materialIDs == 17u) {
            #ifdef WATER_PARALLAX
                vec2 position = GetWaterParallaxCoord(minecraftPos, normalize(viewPos.xyz * tbnMatrix));
                normalData = GetWavesNormal(position);
            #else
                normalData = GetWavesNormal(minecraftPos.xz - minecraftPos.y);
            #endif
        } else {
            #ifdef MC_NORMAL_MAP
                normalData = texture(normals, texcoord).rgb;
                DecodeNormalTex(normalData);
            #else
                normalData = vec3(0.0, 0.0, 1.0);
            #endif
        }

        #if defined IS_OVERWORLD
            #ifdef RAIN_SPLASH_EFFECT
                if (wetnessCustom > 1e-2) {
                    vec2 rainNormal = GetRainNormal(minecraftPos);
                    normalData.xy += rainNormal * wetnessCustom * saturate(lightmap.y * 10.0 - 9.0);
                }
            #endif
        #endif

        normalData = normalize(tbnMatrix * normalData);
    #endif

    if (materialIDs == 17u) {
        float splashFade = max(enterWater, exitWater);
        if (splashFade > 0.01) {
            vec2  splashCenter = vec2(waterSplashPosX, waterSplashPosZ);
            float splashDist   = length(minecraftPos.xz - splashCenter);
            float maxR = 6.0;
            if (splashDist < maxR) {
                float distFactor = 1.0 - smoothstep(0.5, maxR, splashDist);
                // Кільце розходиться назовні: фронт рухається з часом
                float ringPhase  = splashDist * 5.0 - frameTimeCounter * 7.0;
                float ring       = sin(ringPhase) * distFactor * distFactor;
                // Нормаль нахиляємо в напрямку до центру всплеску
                vec2  toCenter   = normalize(splashCenter - minecraftPos.xz + 1e-5);
                float ringStr    = ring * splashFade * 0.6;
                normalData.xy   += toCenter * ringStr;
                normalData        = normalize(normalData);
            }
        }
    }
    // =========================================================================
    // =========================================================================
    #ifdef WATER_SHALLOW_ILLUSION
    if (materialIDs == 17u && isEyeInWater == 0) {
        vec4 shallowResult = WaterShallowIllusion(normalData, viewPos.xyz);
        if (shallowResult.a > 1e-3) {
            // Чем прозрачнее вода (меньше albedo.a), тем виднее дно сквозь неё
            albedo.rgb = mix(albedo.rgb, shallowResult.rgb, shallowResult.a * (1.0 - albedo.a * 0.5));
        }
    }
    #endif
    // =========================================================================

    colortex7Out.xy = lightmap + (bayer4(gl_FragCoord.xy) - 0.5) * rcp(255.0);
    colortex7Out.z = float(materialIDs + 0.1) * rcp(255.0);

    colortex3Out.xy = EncodeNormal(normalData);
    colortex3Out.z = PackUnorm2x8(albedo.rg);
    colortex3Out.w = PackUnorm2x8(albedo.ba);

    reflectionData = CalculateSpecularReflections(normalData, cube(lightmap.g), viewPos.xyz, minecraftPos);
}