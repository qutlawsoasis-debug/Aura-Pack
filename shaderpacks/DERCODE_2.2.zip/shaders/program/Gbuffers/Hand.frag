
layout(location = 0) out vec4 albedoData;
layout(location = 1) out vec3 colortex7Out;
layout(location = 2) out vec4 colortex3Out;

/* DRAWBUFFERS:673 */

#include "/lib/Head/Common.inc"

uniform sampler2D tex;
#ifdef MC_NORMAL_MAP
    uniform sampler2D normals;
#endif
#ifdef MC_SPECULAR_MAP
    uniform sampler2D specular;
#endif

uniform float wetnessCustom;

// ============================================================
// HAND TORCH BLOOM
// В Lab PBR формате emissive = specularData.a (не .b!).
// Это поле читается в composite как gbuffer.material.emissiveness
// и передаётся в TextureLighting → добавляется в bloom.
//
// Маска огня скопирована из BlockLighting.glsl case 21:
//   albedo.r > 0.8             — яркий жёлтый/белый (центр пламени)
//   albedo.r > albedo.g * 1.4  — тёплый оранжевый (R доминирует над G)
// Коричневая палка: R≈G → маска = 0 → не светится.
//
// Для каждого предмета своя логика детекции "огненного" пикселя
// и своя сила emissive.
// ============================================================
uniform int heldItemId;
uniform int heldItemId2;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;

// ============================================================
// HAND TORCH BLOOM — сила bloom emissive для факела в руке.
// Умножает итоговое значение specularData.a (Lab PBR emissive).
// Определяется в Temporal.vert и шарится через Settings.glsl,
// здесь дублируем дефайн как fallback если Settings не включён.
//
// HAND_TORCH_BLOOM_STRENGTH — яркость bloom (насколько ярко светится)
// HAND_TORCH_BLOOM_RANGE    — дальность/ширина bloom вокруг факела.
//   Работает через степенной буст emissive: чем выше значение,
//   тем больше энергии уходит в дальние mip-уровни bloom pipeline,
//   что визуально расширяет ореол вокруг огня.
//   1.0 = стандартный радиус, 2.0 = вдвое шире, 3.0 = широкий ореол.
// ============================================================
#ifndef HAND_TORCH_BLOOM_STRENGTH
    #define HAND_TORCH_BLOOM_STRENGTH 1.5
#endif
#ifndef HAND_TORCH_BLOOM_RANGE
    #define HAND_TORCH_BLOOM_RANGE 1.0
#endif

// Возвращает силу emissive (0 = не светится).
// Значение попадёт в specularData.a → emissiveness в composite.
float GetHandTorchEmissiveStrength(int item) {
    if (item == 13001) return 1.0;   // Torch, Lantern, Glowstone, Campfire, Shroomlight, Lava Bucket, Blaze Rod
    if (item == 13002) return 1.0;   // Beacon
    if (item == 13003) return 0.65;  // Redstone Torch
    if (item == 13004) return 0.75;  // Soul Torch / Soul Lantern / Soul Campfire
    if (item == 13005) return 0.9;   // Sea Lantern
    if (item == 13006) return 1.0;   // End Rod, Crying Obsidian, End Crystal, Nether Star
    if (item == 13007) return 0.5;   // Sea Pickle
    if (item == 13008) return 1.0;   // Conduit
    if (item == 13009) return 0.85;  // Froglight Ochre
    if (item == 13010) return 0.85;  // Froglight Verdant
    if (item == 13011) return 0.85;  // Froglight Pearlescent
    if (item == 13012) return 0.75;  // Magma Block
    if (item == 13013) return 0.9;   // Copper Bulb
    if (item == 15013) return 0.9;   // Copper Lantern
    if (item == 15014) return 0.9;   // Exposed Copper Lantern
    if (item == 15015) return 0.9;   // Weathered Copper Lantern
    if (item == 15016) return 0.9;   // Oxidized Copper Lantern
    return 0.0;
}

// Определяет "огненный" пиксель для предмета.
// Логика идентична BlockLighting.glsl case 21 (torch-like).
// Возвращает [0..1]: 0 = палка/рука, 1 = огонь/свечение.
float GetHandFireMask(int item, vec3 albedo) {
    // Тёплые предметы (torch, lantern, campfire, glowstone, etc.)
    // Маска: case 21 из BlockLighting — ровно та же логика
    if (item == 13001 || item == 13008 || item == 13009 ||
        item == 13012 || item == 13013 || item == 15013 ||
        item == 15014 || item == 15015 || item == 15016) {
        // albedo.r > 0.8: ярко-жёлтый/белый центр пламени
        // albedo.r > albedo.g * 1.4: оранжевый (R явно выше G)
        return float(albedo.r > 0.8 || albedo.r > albedo.g * 1.4);
    }

    // Soul Torch — синее пламя: b доминирует
    if (item == 13004) {
        return float(albedo.b > 0.55 || albedo.b > albedo.r * 1.5);
    }

    // Redstone Torch — красный: R >> G+B (как case 25 BlockLighting)
    if (item == 13003) {
        return step(1.3, albedo.r / max(albedo.g + albedo.b, 0.001)) *
               step(0.35, albedo.r);
    }

    // End Rod / Crying Obsidian / Nether Star — фиолетовый/белый: общая яркость
    if (item == 13006) {
        float luma = dot(albedo, vec3(0.2126, 0.7152, 0.0722));
        return smoothstep(0.55, 0.80, luma);
    }

    // Sea Lantern — холодный белый: высокая общая яркость
    if (item == 13005) {
        float luma = dot(albedo, vec3(0.2126, 0.7152, 0.0722));
        return smoothstep(0.50, 0.75, luma);
    }

    // Beacon — яркий белый
    if (item == 13002) {
        float luma = dot(albedo, vec3(0.2126, 0.7152, 0.0722));
        return smoothstep(0.60, 0.85, luma);
    }

    // Sea Pickle / Verdant Froglight — зелёный: g доминирует
    if (item == 13007 || item == 13010) {
        return float(albedo.g > 0.50 || albedo.g > albedo.r * 1.3);
    }

    // Pearlescent Froglight — розово-фиолетовый
    if (item == 13011) {
        float luma = dot(albedo, vec3(0.2126, 0.7152, 0.0722));
        return smoothstep(0.45, 0.70, luma);
    }

    return 0.0;
}

in vec4 tint;
in vec2 texcoord;
in vec4 viewPos;

in vec2 lightmap;

flat in mat3 tbnMatrix;

float bayer2 (vec2 a) { a = 0.5 * floor(a); return fract(1.5 * fract(a.y) + a.x); }
#define bayer4(a) (bayer2(0.5 * (a)) * 0.25 + bayer2(a))

void main() {	
	vec4 albedo = texture(tex, texcoord) * tint;

	#ifdef WHITE_WORLD
		albedo.rgb = vec3(1.0);
	#endif

	if (albedo.a < 0.1) { discard; return; }

	#ifdef MC_SPECULAR_MAP
		vec4 specularData = texture(specular, texcoord);
	#else
		vec4 specularData = vec4(0.0);
	#endif

    #ifdef MC_NORMAL_MAP
        vec3 normalData = texture(normals, texcoord).rgb;
        DecodeNormalTex(normalData);
    #else
        vec3 normalData = vec3(0.0, 0.0, 1.0);
    #endif

	#if defined IS_OVERWORLD
		if (wetnessCustom > 1e-2) {
			float wetFact = wetnessCustom;
			wetFact *= remap(0.5, 0.9, tbnMatrix[2].y);
			wetFact *= saturate(lightmap.y * 10.0 - 9.0);

			#ifdef MC_NORMAL_MAP
				normalData = mix(normalData.xyz, vec3(0.0, 0.0, 1.0), wetFact);
			#endif

			#ifdef FORCE_WET_EFFECT
				specularData.r = mix(specularData.r, 1.0, wetFact);
				specularData.g = max(specularData.g, 0.04 * wetFact);
			#endif

			vec3 wetAlbedo = ColorSaturation(albedo.rgb, 0.75) * 0.85;
			#ifdef POROSITY
				float porosity = specularData.b > 64.5 / 255.0 ? 0.0 : remap(specularData.b, 0.0, 64.0 / 255.0) * 0.7;
				wetAlbedo *= oneMinus(porosity) / oneMinus(porosity * wetAlbedo);
			#endif
			albedo.rgb = mix(albedo.rgb, wetAlbedo, wetFact);
		}
	#endif

	normalData = normalize(tbnMatrix * normalData);
	albedoData = albedo;

	colortex7Out.xy = lightmap + (bayer4(gl_FragCoord.xy) - 0.5) * rcp(255.0);
	colortex7Out.z = 4.1 / 255.0;

	// ============================================================
	// HAND TORCH BLOOM — пишем в specularData.a (Lab PBR emissive).
	// composite читает это как gbuffer.material.emissiveness →
	// TextureLighting → bloom pipeline.
	//
	// Приоритет: правая рука (heldItemId), если не светится — левая.
	// ============================================================
	bool hasLight = (heldBlockLightValue > 0 || heldBlockLightValue2 > 0);
	if (hasLight) {
	    int activeItem = (heldBlockLightValue > 0) ? heldItemId : heldItemId2;
	    float emissiveStrength = GetHandTorchEmissiveStrength(activeItem);

	    if (emissiveStrength > 0.0) {
	        float fireMask = GetHandFireMask(activeItem, albedo.rgb);
	        // STRENGTH — яркость bloom
	        // RANGE — ширина: возводим в степень < 1 чтобы поднять
	        // низкие значения маски, давая больше энергии дальним mip'ам
	        float rangeBoost = (HAND_TORCH_BLOOM_RANGE > 1.0)
	            ? pow(fireMask, 1.0 / HAND_TORCH_BLOOM_RANGE)
	            : fireMask;
	        specularData.a = max(specularData.a, rangeBoost * emissiveStrength * HAND_TORCH_BLOOM_STRENGTH);
	    }
	}

	colortex3Out.xy = EncodeNormal(normalData);
	colortex3Out.z = PackUnorm2x8(specularData.rg);
	colortex3Out.w = PackUnorm2x8(specularData.ba);
}
