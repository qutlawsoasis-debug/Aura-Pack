// ==========================================
// НАСТРОЙКА ЦВЕТА СВЕЧЕНИЯ (RGB от 0.0 до 1.0)
// ==========================================
#define ZOMBIE_R 1.0
#define ZOMBIE_G 1.0
#define ZOMBIE_B 1.0

#define HUSK_R 1.0
#define HUSK_G 0.6
#define HUSK_B 0.0

#define DROWNED_R 0.0
#define DROWNED_G 0.8
#define DROWNED_B 1.0

#define ENDERMAN_R 0.7
#define ENDERMAN_G 0.0
#define ENDERMAN_B 1.0

// Настройки для Железного Голема
#define GOLEM_RED_R 1.0    // Цвет для глаз и цветов на лианах (Красный)
#define GOLEM_RED_G 0.0
#define GOLEM_RED_B 0.0

#define GOLEM_YELLOW_R 1.0 // Цвет для желтых пикселей
#define GOLEM_YELLOW_G 0.85
#define GOLEM_YELLOW_B 0.0
// ==========================================

layout(location = 0) out vec4 albedoData;
layout(location = 1) out vec3 colortex7Out;
layout(location = 2) out vec4 colortex3Out;

/* DRAWBUFFERS:673 */

#include "/lib/Head/Common.inc"

#define BOAT_LEAK_FIX

uniform sampler2D tex;
#ifdef MC_NORMAL_MAP
    uniform sampler2D normals;
#endif
#ifdef MC_SPECULAR_MAP
    uniform sampler2D specular;
#endif

uniform float wetnessCustom;
uniform vec4 entityColor;

in vec4 tint;
in vec2 texcoord;
in vec4 viewPos;
in vec2 lightmap;
in vec3 flatNormal;

flat in int materialIDs;

#include "/lib/Surface/ManualTBN.glsl"

float bayer2 (vec2 a) { a = 0.5 * floor(a); return fract(1.5 * fract(a.y) + a.x); }
#define bayer4(a) (bayer2(0.5 * (a)) * 0.25 + bayer2(a))

void main() {
	vec4 albedo = texture(tex, texcoord) * tint;
	#ifdef ENTITY_STATUS_COLOR
		albedo.rgb = mix(albedo.rgb, entityColor.rgb, entityColor.a);
	#endif

	if (materialIDs == 12) albedo = vec4(0.6, 0.5, 1.0, 1.0);

	#ifdef WHITE_WORLD
		albedo.rgb = vec3(1.0);
	#endif

	// --- ИНДИВИДУАЛЬНОЕ СВЕЧЕНИЕ ЧАСТЕЙ ТЕЛА ---
	vec2 finalLightmap = lightmap;
	vec3 glowColor = vec3(0.0);
	bool isGlowingPart = false;

	// Получаем пиксельные координаты развертки
	vec2 pixelCoord = texcoord * 64.0;
	float pX = floor(pixelCoord.x);
	float pY = floor(pixelCoord.y);
	vec4 rawTex = texture(tex, texcoord);

	// --- МАСКА "ЛИЦО" ДЛЯ FACE BLUR (любой моб + игрок, без привязки к materialIDs) ---
	// Стандартная зона "головы" на 64x64 UV-развертке (front/side/back/top/bottom, БЕЗ overlay/шапки,
	// чтобы случайно не зацепить декор/рога/капюшоны других мобов с другой раскладкой)
	bool isFaceZone = (pY >= 0.0 && pY <= 15.0) && (pX >= 0.0 && pX <= 31.0);

	// Обычный зомби (ID 40) - Глаза
	if (materialIDs == 40) { 
		if (pY == 12.0 && ((pX >= 9.0 && pX <= 10.0) || (pX >= 13.0 && pX <= 14.0))) {
			isGlowingPart = true;
			glowColor = vec3(ZOMBIE_R, ZOMBIE_G, ZOMBIE_B);
		}
	}
	// Кадавр / Husk (ID 42) - Глаза
	else if (materialIDs == 42) {
		if (pY == 12.0 && ((pX >= 9.0 && pX <= 10.0) || (pX >= 13.0 && pX <= 14.0))) {
			isGlowingPart = true;
			glowColor = vec3(HUSK_R, HUSK_G, HUSK_B);
		}
	}
	// Утопленник / Drowned (ID 43) - Фильтр ярко-голубых пикселей на лице
	else if (materialIDs == 43) {
		bool isFaceUV = (pY >= 8.0 && pY <= 15.0) && ((pX >= 8.0 && pX <= 15.0) || (pX >= 40.0 && pX <= 47.0));
		if (isFaceUV && rawTex.b > 0.55 && rawTex.g > 0.55 && rawTex.r < 0.65) {
			isGlowingPart = true;
			glowColor = vec3(DROWNED_R, DROWNED_G, DROWNED_B);
		}
	}
	// Эндермен / Enderman (ID 44) - Глаза
	else if (materialIDs == 44) {
		if (pY == 12.0 && ((pX >= 8.0 && pX <= 10.0) || (pX >= 13.0 && pX <= 15.0))) {
			isGlowingPart = true;
			glowColor = vec3(ENDERMAN_R, ENDERMAN_G, ENDERMAN_B);
		}
	}
	// Железный Голем / Iron Golem (ID 45) - Глаза, цветы и желтые элементы
	else if (materialIDs == 45) {
		// Фильтр для чисто красных пикселей (глаза голема и бутоны маков на лианах)
		if (rawTex.r > 0.55 && rawTex.g < 0.25 && rawTex.b < 0.25) {
			isGlowingPart = true;
			glowColor = vec3(GOLEM_RED_R, GOLEM_RED_G, GOLEM_RED_B);
		}
		// Фильтр для золотистых/желтых пикселей
		else if (rawTex.r > 0.55 && rawTex.g > 0.45 && rawTex.b < 0.35) {
			isGlowingPart = true;
			glowColor = vec3(GOLEM_YELLOW_R, GOLEM_YELLOW_G, GOLEM_YELLOW_B);
		}
	}

	// Применяем свечение к выбранным частям
	if (isGlowingPart) {
		finalLightmap = vec2(1.0);
		albedo.rgb = glowColor;
	}
	// -------------------------------------------

    mat3 tbnMatrix = manualTBN(viewPos.xyz, texcoord);

	if (albedo.a < 0.1
	#ifdef BOAT_LEAK_FIX
	 	&& materialIDs != 14
	#endif
	) { discard; return; }

	#ifdef MC_SPECULAR_MAP
		vec4 specularData = texture(specular, texcoord);
	#else
		vec4 specularData = vec4(0.0);
	#endif

    #ifdef MC_NORMAL_MAP
        vec3 normalData = texture(normals, texcoord).rgb;
        DecodeNormalTex(normalData);
	#else
        vec3 normalData = vec3(0.0, 0.0, 1.0);
	#endif

	#if defined IS_OVERWORLD
		if (wetnessCustom > 1e-2 && materialIDs != 12) {
			float wetFact = wetnessCustom;
			wetFact *= remap(0.5, 0.9, tbnMatrix[2].y);
			wetFact *= saturate(lightmap.y * 10.0 - 9.0);

			#ifdef MC_NORMAL_MAP
				normalData = mix(normalData.xyz, vec3(0.0, 0.0, 1.0), wetFact);
			#endif

			#ifdef FORCE_WET_EFFECT
				specularData.r = mix(specularData.r, 1.0, wetFact);
				specularData.g = max(specularData.g, 0.04 * wetFact);
			#endif

			vec3 wetAlbedo = ColorSaturation(albedo.rgb, 0.75) * 0.85;
			#ifdef POROSITY
				float porosity = specularData.b > 64.5 / 255.0 ? 0.0 : remap(specularData.b, 0.0, 64.0 / 255.0) * 0.7;
				wetAlbedo *= oneMinus(porosity) / oneMinus(porosity * wetAlbedo);
			#endif
			albedo.rgb = mix(albedo.rgb, wetAlbedo, wetFact);
		}
	#endif

	#if TEXTURE_FORMAT == 0 && defined MC_SPECULAR_MAP
		if (materialIDs == 13) {
			specularData.rg = vec2(1.0, 0.04);
			#if SUBSERFACE_SCATTERING_MODE == 1
				specularData.b = max(0.65, specularData.b);
			#elif SUBSERFACE_SCATTERING_MODE == 0
				specularData.b = 0.65;
			#endif
		}
	#elif SUBSERFACE_SCATTERING_MODE < 2
		specularData.a = 0.0;
		if (materialIDs == 13) specularData = vec4(1.0, 0.04, 0.0, 0.65); 
	#endif

	normalData = materialIDs == 819925 ? flatNormal : normalize(tbnMatrix * normalData);

	albedoData = albedo;

	colortex7Out.xy = finalLightmap + (bayer4(gl_FragCoord.xy) - 0.5) * rcp(255.0);
	colortex7Out.z = float((isFaceZone ? materialIDs + 100 : materialIDs) + 0.1) * rcp(255.0);

	colortex3Out.xy = EncodeNormal(normalData);
	colortex3Out.z = PackUnorm2x8(specularData.rg);
	colortex3Out.w = PackUnorm2x8(specularData.ba);
}