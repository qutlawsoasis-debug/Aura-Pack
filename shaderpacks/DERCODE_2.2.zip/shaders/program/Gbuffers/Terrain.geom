// Terrain.geom - Shader Grass + Shader Moss geometry shader
// Uses GS invocations (instanced GS) for density: each invocation emits 1 blade at a
// random position within the triangle, avoiding NVIDIA's per-invocation vertex limit.
// Adapted from Eclipse-Shader all_solid.gsh by Robobo1221 / co0rdinates

#include "/lib/Head/Common.inc"

// ============================================================
// SHADER GRASS — НАСТРОЙКИ ПОЛЬЗОВАТЕЛЯ (USER SETTINGS)
// ============================================================

#define SHADER_GRASS 0          // [0 1] Главный тумблер шейдерной травы

#define SHADER_GRASS_REPLACE_VANILLA 1  // [0 1] 1 = заменяем ванильную траву, 0 = рисуем поверх

// 1 = 2D Плоская
// 2 = 3D Кластерная (разная высота)
// 3 = Оригинальная 3D (не изменена)
// 4 = Тонкая трава (тонкие лезвия, смешаны низкие и высокие)
#define GRASS_STYLE 3           // [1 2 3 4]

#define GRASS_WIDTH 0.12        // [0.05 0.08 0.12 0.15 0.20]
#define GRASS_HEIGHT_MULT 1.0   // [0.5 0.8 1.0 1.2 1.5 2.0]
#define GRASS_COLOR_VAR 0.15    // [0.0 0.1 0.15 0.2 0.3]
#define MIN_GRASS_SAMPLES 2     // [2 4 8]
#define BEAUTIFUL_FADING 1      // [0 1]
#define GRASS_WIND_SPEED 1.0    // [0.5 1.0 1.5 2.0]
#define GRASS_TRAMPLE_PRESS 1   // [0 1]

#ifndef GRASS_RANGE
    #define GRASS_RANGE 128.0   // [4.0 8.0 12.0 16.0 24.0 32.0 64.0 128.0 256.0 512.0 1024.0]
#endif

#define GRASS_SAMPLES 16        // [4.0 8.0 12.0 16.0 18.0 20.0 24.0 32.0 64.0 128.0 256.0 512.0 1024.0]

// ============================================================
// SHADER MOSS — НАСТРОЙКИ ПОЛЬЗОВАТЕЛЯ (USER SETTINGS)
// ============================================================

#define SHADER_MOSS 0           // [0 1] Главный тумблер шейдерного мха

#define MOSS_DETECTION_MODE 1       // [0 1] 0 = Дефолт (строго по зеленым прожилкам), 1 = По всей зелени (салатовый, лаймовый, любые зеленые оттенки)
#define MOSS_DENSITY 10.5    // [1.0 2.0 3.0 5.0] Общая плотность мха: чем выше, тем больше травинок по всей площади

#define MOSS_BLADE_LENGTH 0.05  // Базовая максимальная длина (было 0.15)
#define MOSS_BLADE_WIDTH 0.008  // Базовая жирность (очень тонкие)
#define MOSS_WIND_STRENGTH 0.0      // [0.0 0.5 1.0 1.5 2.0 3.0] Сила наклона мха от ветра
#define MOSS_BLADES_PER_SAMPLE 128    // [1 2 3 4 5] Сколько травинок в одном пучке (умножает густоту)

#ifndef MOSS_RANGE
    #define MOSS_RANGE 48.0     // [8.0 16.0 24.0 32.0 48.0 64.0 96.0]
#endif 

#define MOSS_SAMPLES 100         // [4 6 8 12 16 20 24 32 34 42 48 50 52 58 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200 240 1000]
#define MOSS_SIZE 0.055         // [0.02 0.035 0.055 0.075 0.10 0.15]
#define MOSS_HEIGHT 0.06        // [0.02 0.04 0.06 0.08 0.12 0.18]
#define MOSS_HEIGHT_RANDOM 0.70 // [0.0 0.3 0.50 0.70 0.90 1.0]
#define MOSS_SIZE_RANDOM 0.55   // [0.0 0.25 0.55 0.80 1.0]
#define MOSS_COLOR_VAR 0.20     // [0.0 0.08 0.15 0.20 0.30 0.45]
#define MOSS_ON_SIDES 1         // [0 1]
#define MOSS_SIDE_DOT_MIN -0.2  // [-0.5 -0.2 0.0 0.2 0.4]

// materialID замшелых блоков: block.10096 → (10096 - 10000) = 96
#define MOSS_MATERIAL_ID 96u

// ============================================================
// LAYOUT
// ============================================================

#if SHADER_GRASS == 1 && SHADER_MOSS == 1
    #if GRASS_SAMPLES >= MOSS_SAMPLES
        #define GEOM_INVOCATIONS GRASS_SAMPLES
    #else
        #define GEOM_INVOCATIONS MOSS_SAMPLES
    #endif
    layout(triangles, invocations = GEOM_INVOCATIONS) in;
#elif SHADER_GRASS == 1
    #define GEOM_INVOCATIONS GRASS_SAMPLES
    layout(triangles, invocations = GEOM_INVOCATIONS) in;
#elif SHADER_MOSS == 1
    #define GEOM_INVOCATIONS MOSS_SAMPLES
    layout(triangles, invocations = GEOM_INVOCATIONS) in;
#else
    layout(triangles) in;
#endif

#if SHADER_GRASS == 1
    #if GRASS_STYLE == 4 || GRASS_STYLE == 3 || GRASS_STYLE == 2
        #if GRASS_QUALITY == 2
            layout(triangle_strip, max_vertices = 33) out;
        #elif GRASS_QUALITY == 1
            layout(triangle_strip, max_vertices = 23) out;
        #else
            layout(triangle_strip, max_vertices = 13) out;
        #endif
    #else
        #if GRASS_QUALITY == 2
            layout(triangle_strip, max_vertices = 11) out;
        #elif GRASS_QUALITY == 1
            layout(triangle_strip, max_vertices = 9) out;
        #else
            layout(triangle_strip, max_vertices = 7) out;
        #endif
    #endif
#elif SHADER_MOSS == 1
    // Мох: каждая шишечка = 2 квада по 4 вершины, EndPrimitive после каждого
    layout(triangle_strip, max_vertices = 64) out;
#else
    layout(triangles) in;
    layout(triangle_strip, max_vertices = 3) out;
#endif

// ============================================================
// INPUTS / OUTPUTS
// ============================================================

in vec4 vs_tint[];
in vec2 vs_texcoord[];
in vec3 vs_minecraftPos[];
in vec3 vs_viewPos[];
in vec2 vs_lightmap[];
flat in mat3 vs_tbnMatrix[];
flat in uint vs_materialIDs[];

#if defined PARALLAX || ANISOTROPIC_FILTER > 0
in vec2 vs_tileCoord[];
flat in vec2 vs_tileOffset[];
flat in vec2 vs_tileScale[];
#endif

out vec4 tint;
out vec2 texcoord;
out vec3 minecraftPos;
out vec3 viewPos;
out vec2 lightmap;
flat out mat3 tbnMatrix;
flat out uint materialIDs;

#if defined PARALLAX || ANISOTROPIC_FILTER > 0
out vec2 tileCoord;
flat out vec2 tileOffset;
flat out vec2 tileScale;
#endif

// ============================================================
// UNIFORMS
// ============================================================

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform vec2 taaOffset;
uniform vec3 relativeEyePosition;
uniform sampler2D noisetex;
uniform sampler2D gtexture;

// ============================================================
// ОБЩИЕ УТИЛИТЫ
// ============================================================

const float PI48 = 150.796447372 * WAVY_SPEED * GRASS_WIND_SPEED;

vec2 calcWave(in vec3 pos) {
    float magnitude = abs(sin(dot(vec4(frameTimeCounter, pos), vec4(1.0, 0.005, 0.005, 0.005))) * 0.5 + 0.72) * 0.013;
    vec2 ret = (sin(PI48 * frameTimeCounter * vec2(0.0063, 0.0015) * 4.0 - pos.xz + pos.y * 0.05) + 0.1) * magnitude;
    return ret;
}

vec3 calcMovePlants(in vec3 pos) {
    vec2 move1 = calcWave(pos);
    float move1y = -length(move1);
    return vec3(move1.x, move1y, move1.y) * 5.0 * GRASS_WAVY_STRENGTH;
}

vec4 toClipSpace3Geom(vec3 viewSpacePosition) {
    return vec4(projMAD(gl_ProjectionMatrix, viewSpacePosition), -viewSpacePosition.z);
}

void emitPassThrough(int idx, vec3 playerPos) {
    gl_Position = toClipSpace3Geom(mat3(gbufferModelView) * playerPos + gbufferModelView[3].xyz);
    #ifdef TAA_ENABLED
        gl_Position.xy += taaOffset * gl_Position.w;
    #endif
    tint        = vs_tint[idx];
    texcoord    = vs_texcoord[idx];
    minecraftPos = vs_minecraftPos[idx];
    viewPos     = vs_viewPos[idx];
    lightmap    = vs_lightmap[idx];
    tbnMatrix   = vs_tbnMatrix[idx];
    materialIDs = vs_materialIDs[idx];
    #if defined PARALLAX || ANISOTROPIC_FILTER > 0
        tileCoord   = vs_tileCoord[idx];
        tileOffset  = vs_tileOffset[idx];
        tileScale   = vs_tileScale[idx];
    #endif
    EmitVertex();
}

// ============================================================
// SHADER GRASS — ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================

#if SHADER_GRASS == 1
    #if defined PARALLAX || ANISOTROPIC_FILTER > 0
        vec2 bladeTileCoord_g;
        vec2 bladeTileOffset_g;
        vec2 bladeTileScale_g;
    #endif

    void emitBladeVertex(vec3 vPos, vec3 vNorm, vec4 baseColor, vec2 tCoord, vec2 lMap, float heightOffset, float distFade) {
        gl_Position = toClipSpace3Geom(mat3(gbufferModelView) * vPos + gbufferModelView[3].xyz);
        #ifdef TAA_ENABLED
            gl_Position.xy += taaOffset * gl_Position.w;
        #endif

        vec4 grassTint;

        #if GRASS_STYLE == 3
            float heightfade = smoothstep(-0.35, 1.0, heightOffset) * distFade;
            grassTint = baseColor * heightfade;
            if (baseColor.rgb == vec3(1.0)) grassTint.rgb = vec3(0.22, 0.32, 0.11) * heightfade;
        #else
            #if BEAUTIFUL_FADING == 1
                float rootShadow = smoothstep(-0.1, 0.85, heightOffset);
                grassTint = baseColor;
                grassTint.rgb *= mix(vec3(0.14, 0.16, 0.09), vec3(1.0), rootShadow);
                if (baseColor.rgb == vec3(1.0)) grassTint.rgb *= vec3(0.35, 0.5, 0.2);
                grassTint.a *= distFade;
            #else
                float heightfade = smoothstep(-0.35, 1.0, heightOffset) * distFade;
                grassTint = baseColor * heightfade;
                if (baseColor.rgb == vec3(1.0)) grassTint.rgb = vec3(0.22, 0.32, 0.11) * heightfade;
            #endif
        #endif

        tint        = grassTint;
        texcoord    = tCoord;
        minecraftPos = vPos + cameraPosition;
        viewPos     = mat3(gbufferModelView) * vPos + gbufferModelView[3].xyz;
        lightmap    = lMap;
        vec3 viewSpaceNormal = normalize(mat3(gbufferModelView) * vNorm);
        mat3 grassTBN;
        grassTBN[2] = viewSpaceNormal;
        vec3 upRef = abs(viewSpaceNormal.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
        grassTBN[0] = normalize(cross(upRef, viewSpaceNormal));
        grassTBN[1] = cross(viewSpaceNormal, grassTBN[0]);
        tbnMatrix   = grassTBN;
        materialIDs = 65535u;

        #if defined PARALLAX || ANISOTROPIC_FILTER > 0
            tileCoord  = bladeTileCoord_g;
            tileOffset = bladeTileOffset_g;
            tileScale  = bladeTileScale_g;
        #endif

        EmitVertex();
    }
#endif

// ============================================================
// SHADER MOSS — ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================

#if SHADER_MOSS == 1

#if defined PARALLAX || ANISOTROPIC_FILTER > 0
        vec2 mossTileCoord_g;
        vec2 mossTileOffset_g;
        vec2 mossTileScale_g;
    #endif

    float mossHash(float seed) {
        return fract(sin(seed * 127.1 + 311.7) * 43758.5453);
    }

    float mossHash2(float seed) {
        return fract(cos(seed * 91.3 + 7.5) * 12345.6789);
    }

    void mossBasis(vec3 normal, out vec3 tangent, out vec3 bitangent) {
        vec3 up = abs(normal.y) < 0.9 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
        tangent   = normalize(cross(up, normal));
        bitangent = cross(normal, tangent);
    }

void emitMossGrassVertex(vec3 vPos, vec3 vNorm, vec4 grassColor, vec2 lMap, vec2 mTex, float heightOffset) {
        gl_Position = toClipSpace3Geom(mat3(gbufferModelView) * vPos + gbufferModelView[3].xyz);
        #ifdef TAA_ENABLED
            gl_Position.xy += taaOffset * gl_Position.w;
        #endif

        // Затемняем корень травинки для объема (Fake AO)
        float rootShadow = smoothstep(-0.02, MOSS_HEIGHT, heightOffset);
        vec4 finalColor = grassColor;
        finalColor.rgb *= mix(vec3(0.3, 0.4, 0.2), vec3(1.0), rootShadow);

        tint         = finalColor;
        texcoord     = mTex; 
        minecraftPos = vPos + cameraPosition;
        viewPos      = mat3(gbufferModelView) * vPos + gbufferModelView[3].xyz;
        lightmap     = lMap;

        vec3 viewN = normalize(mat3(gbufferModelView) * vNorm);
        mat3 mTBN;
        mTBN[2] = viewN;
        vec3 uRef = abs(viewN.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
        mTBN[0] = normalize(cross(uRef, viewN));
        mTBN[1] = cross(viewN, mTBN[0]);
        tbnMatrix   = mTBN;
        materialIDs = MOSS_MATERIAL_ID;

        #if defined PARALLAX || ANISOTROPIC_FILTER > 0
            tileCoord  = mossTileCoord_g;
            tileOffset = mossTileOffset_g;
            tileScale  = mossTileScale_g;
        #endif

        EmitVertex();
    }

    // Генерирует одну шишечку мха — 2 квада крест-накрест (2x EndPrimitive)
void generateMossGrass(vec3 triA, vec3 triB, vec3 triC, vec3 faceNormal, vec4 baseTint, vec2 mossLightmap, float worldSeed, int invID) {
    float r1 = fract(sin(float(invID) * 12.9898 + worldSeed) * 43758.5453);
    float r2 = fract(sin(float(invID) * 78.233 + worldSeed) * 53741.7291);
    if (r1 + r2 > 1.0) { r1 = 1.0 - r1; r2 = 1.0 - r2; }
    float r3 = 1.0 - r1 - r2;
    vec3 origin = r1 * triA + r2 * triB + r3 * triC;
    vec2 mTex = r1 * vs_texcoord[0] + r2 * vs_texcoord[1] + r3 * vs_texcoord[2];

    vec3 blockAlbedo = textureLod(gtexture, mTex, 0.0).rgb;
    
    // Вычисляем "зеленость"
    #if MOSS_DETECTION_MODE == 1
        float greenVein = (blockAlbedo.g > blockAlbedo.b * 1.1) ? (blockAlbedo.g - blockAlbedo.r * 0.5) : 0.0;
    #else
        float greenVein = max(0.0, blockAlbedo.g - max(blockAlbedo.r, blockAlbedo.b));
    #endif

    // Если недостаточно зелени, выходим
    if (greenVein < 0.02) return; 

    // ВАЖНО: Вероятность спавна теперь зависит от густоты зелени и дефайна плотности
    // Чем выше MOSS_DENSITY и чем зеленее пиксель, тем больше травы
    float chance = greenVein * MOSS_DENSITY;
    float rndSpawn = fract(sin(worldSeed + float(invID) * 99.0) * 888.8);
    
    if (rndSpawn > chance) return;

    vec3 right = cross(faceNormal, vec3(0.0, 1.0, 0.0));
    if (length(right) < 0.1) right = cross(faceNormal, vec3(1.0, 0.0, 0.0));
    right = normalize(right);
    vec3 front = normalize(cross(right, faceNormal));

    vec4 mossColor = vec4(blockAlbedo * vec3(0.8, 1.3, 0.8), 1.0);

    // Рисуем одну, но с учетом вероятности (можно поднять до MOSS_BLADES_PER_SAMPLE)
    for (int b = 0; b < MOSS_BLADES_PER_SAMPLE; b++) {
        float rndA = fract(sin(worldSeed + float(invID + b) * 11.0) * 123.4);
        float rndB = fract(cos(worldSeed + float(invID + b) * 17.0) * 456.7);
        
        vec3 bladeOrigin = origin + (right * (rndA - 0.5) + front * (rndB - 0.5)) * 0.08;

        float h = MOSS_BLADE_LENGTH * (0.5 + rndA * 0.7);
        float w = MOSS_BLADE_WIDTH * (h / MOSS_BLADE_LENGTH); 

        vec3 topPos = bladeOrigin + faceNormal * h;
        topPos += right * (rndA - 0.5) * h * 1.8 + front * (rndB - 0.5) * h * 1.8;
        topPos += 1.6 * calcMovePlants(bladeOrigin + cameraPosition) * (h / 0.1) * MOSS_WIND_STRENGTH;

        vec2 corners[4] = vec2[](vec2(0,1), vec2(0.866, -0.5), vec2(-0.866, -0.5), vec2(0,1));
        
        for (int c = 0; c < 4; c++) {
            vec3 bOffset = (right * corners[c].x + front * corners[c].y) * w;
            vec3 tOffset = (right * corners[c].x + front * corners[c].y) * (w * 0.15);
            vec3 bNorm = normalize(right * corners[c].x + front * corners[c].y);

            emitMossGrassVertex(bladeOrigin + bOffset, bNorm, mossColor, mossLightmap, mTex, 0.0);
            emitMossGrassVertex(topPos + tOffset, bNorm, mossColor, mossLightmap, mTex, h);
        }
        EndPrimitive();
    }
}
#endif
// ============================================================
// MAIN
// ============================================================

void main() {

    // ---- PASS-THROUGH (invocation 0 только) ----
    if (gl_InvocationID == 0) {
        bool skipPassThrough = false;

        #if SHADER_GRASS == 1
            uint m0 = vs_materialIDs[0], m1 = vs_materialIDs[1], m2 = vs_materialIDs[2];
            #if defined(GRASS_HIDE_BASE)
                if (m0 == 88u || m1 == 88u || m2 == 88u)
                    skipPassThrough = true;
            #endif
            #if SHADER_GRASS_REPLACE_VANILLA == 1
                if (m0 == 4u || m1 == 4u || m2 == 4u) skipPassThrough = true;
                if (m0 == 5u || m1 == 5u || m2 == 5u) skipPassThrough = true;
                if (m0 == 34222u || m1 == 34222u || m2 == 34222u) skipPassThrough = true;
            #endif
        #endif

        if (!skipPassThrough) {
            for (int i = 0; i < 3; i++) emitPassThrough(i, gl_in[i].gl_Position.xyz);
            EndPrimitive();
        }
    }

    // ============================================================
    // SHADER GRASS
    // ============================================================

    #if SHADER_GRASS == 1
    {
        vec3 worldNormal = mat3(gbufferModelViewInverse) * vs_tbnMatrix[1][2];

        uint mid0 = vs_materialIDs[0];
        uint mid1 = vs_materialIDs[1];

        bool isGrassBlock     = (mid1 == 88u && worldNormal.y > 0.9);
        bool isTallGrassUpper = (mid1 == 4u);
        bool isTallGrassLower = (mid1 == 5u);
        bool isShortGrass     = (mid1 == 34222u);

        bool shouldGenerate = isGrassBlock || isTallGrassUpper || isTallGrassLower || isShortGrass;

        if (shouldGenerate) {
            float sourceHeightMult = 1.0;
            if (isTallGrassUpper) sourceHeightMult = 2.0;
            if (isTallGrassLower) sourceHeightMult = 1.2;
            if (isShortGrass)     sourceHeightMult = 0.55;

            vec3 triCenter = (gl_in[0].gl_Position.xyz + gl_in[1].gl_Position.xyz + gl_in[2].gl_Position.xyz) / 3.0;
            float centerDist = length(triCenter);
            if (centerDist >= GRASS_RANGE) return;

            int maxAllowedSamples = GRASS_SAMPLES;
            if (GRASS_RANGE > 128.0) {
                if (centerDist > 20.0) {
                    int steps = int((centerDist - 20.0) / 4.0);
                    maxAllowedSamples = GRASS_SAMPLES - (steps * 2);
                    if (maxAllowedSamples < MIN_GRASS_SAMPLES)
                        maxAllowedSamples = MIN_GRASS_SAMPLES;
                }
            }
            if (gl_InvocationID >= maxAllowedSamples) return;

            vec3 anchor0 = round(gl_in[0].gl_Position.xyz + cameraPosition);
            float worldSeed = dot(anchor0, vec3(17.0, 31.0, 53.0));
            float invID = float(gl_InvocationID);

            float r1 = fract(sin(invID * 127.1 + worldSeed * 0.001) * 43758.5453);
            float r2 = fract(sin(invID * 311.7 + worldSeed * 0.001) * 53741.7291);
            if (r1 + r2 > 1.0) { r1 = 1.0 - r1; r2 = 1.0 - r2; }
            float r3 = 1.0 - r1 - r2;
            vec3 vertex = r1 * gl_in[0].gl_Position.xyz + r2 * gl_in[1].gl_Position.xyz + r3 * gl_in[2].gl_Position.xyz;
            float vertexDist = length(vertex);

            if (vertexDist >= GRASS_RANGE) return;

            float distanceFade  = 1.0 - smoothstep(GRASS_RANGE * 0.75, GRASS_RANGE, vertexDist);
            vec4  bladeColor    = r1 * vs_tint[0]    + r2 * vs_tint[1]    + r3 * vs_tint[2];
            vec2  bladeLightmap = r1 * vs_lightmap[0] + r2 * vs_lightmap[1] + r3 * vs_lightmap[2];
            vec2  bladeTexcoord = r1 * vs_texcoord[0] + r2 * vs_texcoord[1] + r3 * vs_texcoord[2];

            #if defined PARALLAX || ANISOTROPIC_FILTER > 0
                bladeTileCoord_g  = r1 * vs_tileCoord[0] + r2 * vs_tileCoord[1] + r3 * vs_tileCoord[2];
                bladeTileOffset_g = vs_tileOffset[0];
                bladeTileScale_g  = vs_tileScale[0];
            #endif

            int max_segs = 1;
            #if GRASS_QUALITY == 2
                max_segs = 3;
            #elif GRASS_QUALITY == 1
                max_segs = 2;
            #endif

            int segs = max_segs;
            float lodMult = 1.0;
            if (max_segs >= 3 && vertexDist > 7.5)  { segs = 2; lodMult = 1.5; }
            if (max_segs >= 2 && vertexDist > 15.0) { segs = 1; lodMult = 2.25; }

            #ifndef BASE_GRASS_HEIGHT
                #define BASE_GRASS_HEIGHT 1.0
            #endif

            float finalHeight = BASE_GRASS_HEIGHT * GRASS_HEIGHT_MULT * sourceHeightMult;
            float finalWidth  = GRASS_WIDTH * (lodMult * 0.85);

            #if GRASS_STYLE == 4
                float heightRnd4 = fract(sin(invID * 63.7 + worldSeed * 0.03) * 7291.45);
                if (heightRnd4 > 0.6)       finalHeight *= 1.35;
                else if (heightRnd4 > 0.25) finalHeight *= 0.75;
                else                        finalHeight *= 0.35;
                finalWidth *= 0.45;
            #elif GRASS_STYLE == 2
                float heightRnd = fract(sin(invID * 45.2 + worldSeed * 0.02) * 982.12);
                if (heightRnd > 0.75)       finalHeight *= 1.4;
                else if (heightRnd > 0.35)  finalHeight *= 0.9;
                else { finalHeight *= 0.45; finalWidth *= 1.2; }
            #elif GRASS_STYLE == 1
                finalHeight *= (0.8 + fract(sin(invID * 12.3) * 100.0) * 0.4);
            #endif

            vec3 worldUp  = vec3(0.0, 1.0, 0.0);
            vec3 offsetPos = vertex + worldUp + relativeEyePosition;
            vec2 dir2     = normalize(vertex.xz + relativeEyePosition.xz);
            float playerXZDist = length(offsetPos.xz);

            float trampleFactor = 0.0;
            float oldPlayerDist = 0.0;

            #if GRASS_STYLE == 3
                oldPlayerDist = smoothstep(0.5, 0.05, playerXZDist) * smoothstep(1.0, 0.2, abs(offsetPos.y));
            #else
                #if GRASS_TRAMPLE_PRESS == 1
                    trampleFactor = 1.0 - smoothstep(0.0, 1.3, playerXZDist);
                    trampleFactor *= smoothstep(1.8, 0.5, abs(offsetPos.y));
                #else
                    oldPlayerDist = smoothstep(0.5, 0.05, playerXZDist) * smoothstep(1.0, 0.2, abs(offsetPos.y));
                #endif
            #endif

            vec2 worldXZ   = (vertex + cameraPosition).xz;
            vec2 randomDir = 2.0 * (texture(noisetex, worldXZ * 0.05).xy + texture(noisetex, worldXZ.yx * 0.035).xy) - 1.0;
            #ifndef GRASS_RANDOMNESS
                #define GRASS_RANDOMNESS 1.0
            #endif
            vec2 totalRandBend = GRASS_RANDOMNESS * randomDir;
            vec3 dir = normalize(vertex + vec3(r1 - 0.33, 0.0, r2 - 0.33));
            vec3 originalVertex = vertex;

            vec3 right = normalize(cross(worldUp, dir));
            #if GRASS_STYLE == 1 || GRASS_STYLE == 4
                float angle = fract(sin(invID * 21.4 + worldSeed) * 53.2) * 3.14159;
                vec3 rotDir = vec3(cos(angle), 0.0, sin(angle));
                right = normalize(cross(worldUp, rotDir));
            #endif

            float colorVar = 1.0 - (fract(worldSeed * 0.01) * GRASS_COLOR_VAR);
            bladeColor.rgb *= colorVar;

            vec3  cPos[4];
            float cWidth[4];
            for (int s = 0; s <= segs; s++) {
                float t         = float(s) / float(segs);
                float curvature = t * t;
                vec3 pos = originalVertex;

                pos.y += t * finalHeight;

                #if GRASS_STYLE == 3
                    pos.xz += 0.7 * oldPlayerDist * dir2 * curvature;
                #else
                    #if GRASS_TRAMPLE_PRESS == 1
                        pos.y  -= t * finalHeight * trampleFactor * 0.95;
                        pos.xz += dir2 * (t * finalHeight * trampleFactor * 0.8);
                    #else
                        pos.xz += 0.7 * oldPlayerDist * dir2 * curvature;
                    #endif
                #endif

                pos.xz  += curvature * totalRandBend;
                pos.xyz += 1.6 * calcMovePlants(pos + cameraPosition) * curvature * curvature;

                cPos[s]   = pos;
                cWidth[s] = finalWidth * (1.0 - t);
            }

            vec3 faceNormal = normalize(cross(worldUp, right));

            #if GRASS_STYLE == 4 || GRASS_STYLE == 3 || GRASS_STYLE == 2
                vec3 rVec = right;
                vec3 fVec = faceNormal;

                for (int seg = 0; seg < segs; seg++) {
                    vec3  bCenter = cPos[seg];
                    vec3  tCenter = cPos[seg + 1];
                    float bw = cWidth[seg];
                    float tw = cWidth[seg + 1];

                    vec2 corners[5] = vec2[](vec2(1,1), vec2(1,-1), vec2(-1,-1), vec2(-1,1), vec2(1,1));
                    for (int c = 0; c < 5; c++) {
                        vec3 bOffset = (rVec * corners[c].x + fVec * corners[c].y) * bw;
                        vec3 tOffset = (rVec * corners[c].x + fVec * corners[c].y) * tw;
                        vec3 bNorm   = normalize(rVec * corners[c].x + fVec * corners[c].y);

                        emitBladeVertex(bCenter + bOffset, bNorm, bladeColor, bladeTexcoord, bladeLightmap, bCenter.y - originalVertex.y, distanceFade);
                        emitBladeVertex(tCenter + tOffset, bNorm, bladeColor, bladeTexcoord, bladeLightmap, tCenter.y - originalVertex.y, distanceFade);
                    }
                    EndPrimitive();
                }

            #else
                for (int s = 0; s <= segs; s++) {
                    vec3  pCenter = cPos[s];
                    float w       = cWidth[s];

                    vec3 norm = faceNormal;
                    if (s < segs) {
                        vec3 tangent = normalize(cPos[s + 1] - cPos[s]);
                        norm = normalize(cross(tangent, right));
                    }

                    emitBladeVertex(pCenter - right * w, norm, bladeColor, bladeTexcoord, bladeLightmap, pCenter.y - originalVertex.y, distanceFade);
                    emitBladeVertex(pCenter + right * w, norm, bladeColor, bladeTexcoord, bladeLightmap, pCenter.y - originalVertex.y, distanceFade);
                }
                EndPrimitive();
            #endif

        } // end if (shouldGenerate)
    }
    #endif // SHADER_GRASS

    // ============================================================
    // SHADER MOSS
    // ============================================================

    #if SHADER_MOSS == 1
    {
        uint mid0 = vs_materialIDs[0];
        uint mid1 = vs_materialIDs[1];
        uint mid2 = vs_materialIDs[2];

        bool isMossyBlock = (mid0 == MOSS_MATERIAL_ID || mid1 == MOSS_MATERIAL_ID || mid2 == MOSS_MATERIAL_ID);

        if (isMossyBlock && gl_InvocationID < MOSS_SAMPLES) {
            // Нормаль грани в мировом пространстве
            vec3 faceNormal = mat3(gbufferModelViewInverse) * vs_tbnMatrix[0][2];

            bool shouldGenMoss = (faceNormal.y > 0.5);
            #if MOSS_ON_SIDES == 1
                shouldGenMoss = shouldGenMoss || (faceNormal.y > MOSS_SIDE_DOT_MIN);
            #endif

            if (shouldGenMoss) {
                vec3 triA = gl_in[0].gl_Position.xyz;
                vec3 triB = gl_in[1].gl_Position.xyz;
                vec3 triC = gl_in[2].gl_Position.xyz;

                vec3  triCenter  = (triA + triB + triC) / 3.0;
                float centerDist = length(triCenter);

                if (centerDist < float(MOSS_RANGE)) {
                    vec4 mossColor    = (vs_tint[0] + vs_tint[1] + vs_tint[2]) / 3.0;
                    vec2 mossLightmap = (vs_lightmap[0] + vs_lightmap[1] + vs_lightmap[2]) / 3.0;

                    // Fade по дистанции
                    float distFade = 1.0 - smoothstep(float(MOSS_RANGE) * 0.7, float(MOSS_RANGE), centerDist);
                    mossColor.a *= distFade;
                    if (mossColor.a < 0.01) return;

                    // Стабильный seed из мировой позиции блока
                    vec3  anchor    = round(triA + cameraPosition);
                    float worldSeed = dot(anchor, vec3(17.0, 31.0, 53.0));

for(int i = 0; i < 6; i++) {
    generateMossGrass(triA, triB, triC, faceNormal, mossColor, mossLightmap, worldSeed + float(i), gl_InvocationID + i);
}
                }
            }
        }
    }
    #endif // SHADER_MOSS

}
