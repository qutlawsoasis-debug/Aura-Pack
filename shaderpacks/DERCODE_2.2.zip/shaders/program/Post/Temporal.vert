flat out float exposure;

//------------------------------------------------------------------------------------------------//
#define EXPOSURE_STYLE 1 // [1 2 3]
//------------------------------------------------------------------------------------------------//
#define HAND_TORCH_BLOOM_STRENGTH 1.5 // [0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 4.0 5.0]
#define HAND_TORCH_BLOOM_RANGE    1.0 // [1.0 1.25 1.5 1.75 2.0 2.5 3.0 4.0 5.0]
#define HAND_TORCH_EXPOSURE_ENABLED 0    // [0 1]
#define HAND_TORCH_EXPOSURE_TARGET  0.08 // [0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.25 0.30]
#define HAND_TORCH_EXPOSURE_BLEND   0.15 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.85 0.9 0.95 1.0]
#define HAND_TORCH_EXPOSURE_SPEED   2.0  // [0.5 0.75 1.0 1.5 2.0 3.0 4.0 6.0]

#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"

#ifdef DOF_ENABLED
    flat out float centerDepthSmooth;
#endif

//----// FUNCTIONS //-----------------------------------------------------------------------------//

float CalculateAverageExposure() {
    const float tileSize = exp2(float(AUTO_EXPOSURE_LOD));

	ivec2 tileSteps = ivec2(screenSize * rcp(tileSize));

    float exposure = 0.0;
    float sumWeight = 0.0;

	for (uint x = 0u; x < tileSteps.x; ++x) {
        for (uint y = 0u; y < tileSteps.y; ++y) {
            float luminance = GetLuminance(texelFetch(colortex4, ivec2(x, y), AUTO_EXPOSURE_LOD).rgb);

            float weight = 1.0 - remap(0.25, 0.75, length(vec2(x, y) / tileSteps * 2.0 - 1.0));
            weight = curve(weight) * 0.9 + 0.1;

            exposure += max(log(luminance), -18.0) * weight;
            sumWeight += weight;
        }
	}

    exposure /= max(sumWeight, 1.0);

	return fastExp(exposure * 0.75);
}

//----// MAIN //----------------------------------------------------------------------------------//
void main() {
	gl_Position = vec4(gl_Vertex.xy * 2.0 - 1.0, 0.0, 1.0);

 	#ifdef AUTO_EXPOSURE
		exposure = CalculateAverageExposure();

        float targetExposure = 1.0;

        #if EXPOSURE_STYLE == 1
            // ---- 1. ТВОЙ ДЕФОЛТНЫЙ СТИЛЬ ----
            #if defined IS_END
                const float K = 12.0;
            #else
                const float K = 19.0;
            #endif

            const float calibration = exp2(AUTO_EXPOSURE_BIAS) * K * 1e-2;

            const float a = K * 1e-2 * 18.0;
            const float b = a - K * 1e-2 * 0.04;

            targetExposure = calibration / (a - b * fastExp(-exposure * rcp(b)));

        #elif EXPOSURE_STYLE == 2
            // ---- 2. СТИЛЬ SEUS PTGI ----
            // Экспозиция обратно пропорциональна средней яркости сцены с жестким контролем пересветов
            float calibration = exp2(AUTO_EXPOSURE_BIAS) * 0.18;
            targetExposure = calibration / max(exposure, 0.0001);
            targetExposure = clamp(targetExposure, 0.02, 6.5); // Защита от ослепления в полной темноте

        #elif EXPOSURE_STYLE == 3
            // ---- 3. СТИЛЬ SEUS RENEWED ----
            // Похожий алгоритм, но базовая калибровка выше — делает картинку заметно ярче и сочнее
            float calibration = exp2(AUTO_EXPOSURE_BIAS) * 0.14;
            targetExposure = calibration / max(exposure, 0.0001);
            targetExposure = clamp(targetExposure, 0.04, 8.5); 
        #endif

        // ============================================================
        // HAND TORCH EXPOSURE
        // Если в руке светящийся предмет — тянем targetExposure
        // к HAND_TORCH_EXPOSURE_TARGET. Это заставляет сцену
        // потемнеть вокруг факела, как глаз адаптируется к свету.
        // heldBlockLightValue > 0 = правая рука, > 0 = левая.
        // ============================================================
        #if HAND_TORCH_EXPOSURE_ENABLED == 1
        {
            float torchLight = float(heldBlockLightValue + heldBlockLightValue2);
            if (torchLight > 0.5) {
                // torchTarget в тех же единицах что targetExposure:
                // exposure = calibration / avgLuminance,
                // поэтому torchTarget = calibration / TORCH_TARGET_LUMA
                float torchTargetExposure = 1.0;

                #if EXPOSURE_STYLE == 1
                    #if defined IS_END
                        const float K_t = 12.0;
                    #else
                        const float K_t = 19.0;
                    #endif
                    const float cal_t = exp2(AUTO_EXPOSURE_BIAS) * K_t * 1e-2;
                    const float a_t = K_t * 1e-2 * 18.0;
                    const float b_t = a_t - K_t * 1e-2 * 0.04;
                    float torchLuma = HAND_TORCH_EXPOSURE_TARGET;
                    float torchExp  = fastExp(log(torchLuma) * 0.75);
                    torchTargetExposure = cal_t / (a_t - b_t * fastExp(-torchExp * rcp(b_t)));
                #elif EXPOSURE_STYLE == 2
                    torchTargetExposure = exp2(AUTO_EXPOSURE_BIAS) * 0.18 / max(HAND_TORCH_EXPOSURE_TARGET, 0.0001);
                    torchTargetExposure = clamp(torchTargetExposure, 0.02, 6.5);
                #elif EXPOSURE_STYLE == 3
                    torchTargetExposure = exp2(AUTO_EXPOSURE_BIAS) * 0.14 / max(HAND_TORCH_EXPOSURE_TARGET, 0.0001);
                    torchTargetExposure = clamp(torchTargetExposure, 0.04, 8.5);
                #endif

                // Плавно смешиваем обычный target с torch-target
                targetExposure = mix(targetExposure, torchTargetExposure, HAND_TORCH_EXPOSURE_BLEND);
            }
        }
        #endif

        float prevExposure = clamp16F(texelFetch(colortex5, ivec2(0), 0).a);

        // При наличии факела — адаптируемся быстрее (HAND_TORCH_EXPOSURE_SPEED)
        #if HAND_TORCH_EXPOSURE_ENABLED == 1
        {
            float torchLight = float(heldBlockLightValue + heldBlockLightValue2);
            float torchSpeedMult = mix(1.0, HAND_TORCH_EXPOSURE_SPEED, saturate(torchLight));
            float speed = targetExposure < prevExposure ? 1.5 * torchSpeedMult : torchSpeedMult;
            exposure = mix(targetExposure, prevExposure, fastExp(-speed * frameTime * EXPOSURE_SPEED));
        }
        #else
        float speed = targetExposure < prevExposure ? 1.5 : 1.0;
        exposure = mix(targetExposure, prevExposure, fastExp(-speed * frameTime * EXPOSURE_SPEED));
        #endif
	#else
		exposure = rcp(MANUAL_EXPOSURE_VALUE) * 0.8;
	#endif

    #ifdef DOF_ENABLED
        float centerDepth = texelFetch(depthtex2, ivec2(screenSize * 0.5), 0).x * 2.0 - 1.0;
        centerDepth = 1.0 / (centerDepth * gbufferProjectionInverse[2][3] + gbufferProjectionInverse[3][3]);
        float prevCenterDepth = texelFetch(colortex5, ivec2(1), 0).a;
        centerDepthSmooth = mix(prevCenterDepth, centerDepth, saturate(fastExp(-0.1 / (frameTime * FOCUSING_SPEED)) / (centerDepth + 0.2)));
    #endif
}