
out vec3 bloomTiles;

/* DRAWBUFFERS:4 */

uniform sampler2D colortex5;

uniform vec2 screenPixelSize;

in vec2 screenCoord;

// Локальная копия GetLuminance (без подключения всего Common.inc, чтобы
// не тащить /Settings.glsl и не рисковать конфликтом переобъявлений в
// этой отдельной, простой программе).
float GetLuminanceLocal(in vec3 color) {
	return dot(color, vec3(0.2722, 0.6741, 0.0537));
}

//----// VHS2 INDEPENDENT BLOOM//----------------------------------//
#define RETRO_VHS2_ENABLED 0         // [0 1]
#define RETRO_VHS2_BLOOM_ENABLED 1    // [0 1] 
#define RETRO_VHS2_BLOOM_STRENGTH 1.0 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define RETRO_VHS2_BLOOM_RADIUS 2.0    // [1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0]


#if PARTICLE_BLOOM_MODE == 3
	uniform sampler2D colortex31;
#endif

//----// FUNCTIONS //-----------------------------------------------------------------------------//

vec3 DualBlurDownSample() {
	vec3 bloomTile = textureLod(colortex5, screenCoord, 0).rgb;
	bloomTile += textureLod(colortex5, vec2( 1.0,  1.0) * screenPixelSize + screenCoord, 0).rgb;
	bloomTile += textureLod(colortex5, vec2(-1.0,  1.0) * screenPixelSize + screenCoord, 0).rgb;
	bloomTile += textureLod(colortex5, vec2( 1.0, -1.0) * screenPixelSize + screenCoord, 0).rgb;
	bloomTile += textureLod(colortex5, vec2(-1.0, -1.0) * screenPixelSize + screenCoord, 0).rgb;

	return bloomTile * 0.2;

	//vec3  bloomTile = vec3(0.0);
	//float sumWeight = 0.0;

	//for (int y = -1; y <= 1; ++y) {
	//	for (int x = -1; x <= 1; ++x) {
	//		float weight = clamp(1.0 - length(vec2(x, y)) * 0.25, 0.0, 1.0);
	//		      weight *= weight;

	//		bloomTile += textureLod(colortex5, screenCoord + vec2(x, y) * screenPixelSize, 0).rgb * weight;
	//		sumWeight += weight;
	//	}
	//}

	//return bloomTile / sumWeight;
}

// Независимый VHS2 bloom: более широкая 3x3 выборка с настраиваемым радиусом,
// возвращает дополнительный вклад в bloomTiles, не зависящий от основного DualBlurDownSample
vec3 VHS2BloomDownSample() {
	vec3 bloomTile = vec3(0.0);
	float sumWeight = 0.0;

	for (int y = -1; y <= 1; ++y) {
		for (int x = -1; x <= 1; ++x) {
			float weight = clamp(1.0 - length(vec2(x, y)) * 0.35, 0.0, 1.0);
			      weight *= weight;

			vec2 sampleCoord = screenCoord + vec2(x, y) * screenPixelSize * RETRO_VHS2_BLOOM_RADIUS;
			bloomTile += textureLod(colortex5, sampleCoord, 0).rgb * weight;
			sumWeight += weight;
		}
	}

	return (bloomTile / sumWeight) * RETRO_VHS2_BLOOM_STRENGTH;
}

#if PARTICLE_BLOOM_MODE == 3
// Чистый блум партиклов: НЕ читает sceneData/colortex5 для маски, целиком
// берёт яркость из исходного albedo партикла в colortex31. Поэтому сам
// партикл на экране не становится ярче — светится только bloom-tile.
vec3 ParticleBloomDownSample() {
	vec3 bloomTile = vec3(0.0);

	vec4 p0 = textureLod(colortex31, screenCoord, 0);
	vec4 p1 = textureLod(colortex31, vec2( 1.0,  1.0) * screenPixelSize + screenCoord, 0);
	vec4 p2 = textureLod(colortex31, vec2(-1.0,  1.0) * screenPixelSize + screenCoord, 0);
	vec4 p3 = textureLod(colortex31, vec2( 1.0, -1.0) * screenPixelSize + screenCoord, 0);
	vec4 p4 = textureLod(colortex31, vec2(-1.0, -1.0) * screenPixelSize + screenCoord, 0);

	float luma0 = GetLuminanceLocal(p0.rgb) * step(0.5, p0.a);
	float luma1 = GetLuminanceLocal(p1.rgb) * step(0.5, p1.a);
	float luma2 = GetLuminanceLocal(p2.rgb) * step(0.5, p2.a);
	float luma3 = GetLuminanceLocal(p3.rgb) * step(0.5, p3.a);
	float luma4 = GetLuminanceLocal(p4.rgb) * step(0.5, p4.a);

	bloomTile += p0.rgb * smoothstep(PARTICLE_BLOOM_THRESHOLD, PARTICLE_BLOOM_THRESHOLD + 0.1, luma0);
	bloomTile += p1.rgb * smoothstep(PARTICLE_BLOOM_THRESHOLD, PARTICLE_BLOOM_THRESHOLD + 0.1, luma1);
	bloomTile += p2.rgb * smoothstep(PARTICLE_BLOOM_THRESHOLD, PARTICLE_BLOOM_THRESHOLD + 0.1, luma2);
	bloomTile += p3.rgb * smoothstep(PARTICLE_BLOOM_THRESHOLD, PARTICLE_BLOOM_THRESHOLD + 0.1, luma3);
	bloomTile += p4.rgb * smoothstep(PARTICLE_BLOOM_THRESHOLD, PARTICLE_BLOOM_THRESHOLD + 0.1, luma4);

	return (bloomTile * 0.2) * PARTICLE_BLOOM_INTENSITY;
}
#endif

/////////////////////////MAIN///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////MAIN///////////////////////////////////////////////////////////////////////////////////////////
void main() {
	bloomTiles = DualBlurDownSample();

	#if RETRO_VHS2_ENABLED == 1 && RETRO_VHS2_BLOOM_ENABLED == 1
		bloomTiles += VHS2BloomDownSample();
	#endif

	#if PARTICLE_BLOOM_MODE == 3
		bloomTiles += ParticleBloomDownSample();
	#endif

	bloomTiles = clamp(bloomTiles, 0.0, 65535.0);
}
