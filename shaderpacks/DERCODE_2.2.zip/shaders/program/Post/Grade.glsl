#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"

// Dirty Lens 
#if DIRT_STYLE > 0
    #if DIRT_STYLE == 1
        uniform sampler2D colortex10;  // astralex
        #define DIRTY_LENS_SAMPLER colortex10
    #elif DIRT_STYLE == 2
        uniform sampler2D colortex11; // bodycam
        #define DIRTY_LENS_SAMPLER colortex11
    #elif DIRT_STYLE == 3
        uniform sampler2D colortex12; // big
        #define DIRTY_LENS_SAMPLER colortex12
    #elif DIRT_STYLE == 4
        uniform sampler2D colortex13; // blink
        #define DIRTY_LENS_SAMPLER colortex13
    #endif
#endif



//--// Internal Settings //---------------------------------------------------//

/*
    const int   colortex0Format             = RGBA16F;
    const int   colortex1Format             = RGBA16F;
    const int   colortex2Format             = RGBA16F;
    const int   colortex3Format             = RGBA16F; // было RGBA16, поднято под HDR (8bit/UNORM не хранит >1 и отрицательные значения)
    const int   colortex4Format             = R11F_G11F_B10F;
    const int   colortex5Format             = RGBA16F;
    const int   colortex6Format             = RGB8;
    const int   colortex7Format             = RGB8;
    const int   colortex8Format             =RGBA16F
    const int   colortex9Format             =RGBA16F

    const int colortex29Format = RGBA16F;


    const bool  colortex0Clear              = false;
    const bool  colortex1Clear              = false;
    const bool  colortex2Clear              = false;
    const bool  colortex4Clear              = false;
    const bool  colortex5Clear              = false;
    const bool  colortex7Clear              = true;

    const float shadowIntervalSize          = 2.0;
    const float ambientOcclusionLevel       = 0.05f; // [0.01f 0.02f 0.03f 0.04f 0.05f 0.06f 0.07f 0.08f 0.09f 0.1f 0.2f 0.3f 0.4f 0.5f 0.6f 0.7f 0.8f 0.9f 1.0f]
	const float	sunPathRotation				= -35.0; // [-90.0 -89.0 -88.0 -87.0 -86.0 -85.0 -84.0 -83.0 -82.0 -81.0 -80.0 -79.0 -78.0 -77.0 -76.0 -75.0 -74.0 -73.0 -72.0 -71.0 -70.0 -69.0 -68.0 -67.0 -66.0 -65.0 -64.0 -63.0 -62.0 -61.0 -60.0 -59.0 -58.0 -57.0 -56.0 -55.0 -54.0 -53.0 -52.0 -51.0 -50.0 -49.0 -48.0 -47.0 -46.0 -45.0 -44.0 -43.0 -42.0 -41.0 -40.0 -39.0 -38.0 -37.0 -36.0 -35.0 -34.0 -33.0 -32.0 -31.0 -30.0 -29.0 -28.0 -27.0 -26.0 -25.0 -24.0 -23.0 -22.0 -21.0 -20.0 -19.0 -18.0 -17.0 -16.0 -15.0 -14.0 -13.0 -12.0 -11.0 -10.0 -9.0 -8.0 -7.0 -6.0 -5.0 -4.0 -3.0 -2.0 -1.0 0.0 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0 21.0 22.0 23.0 24.0 25.0 26.0 27.0 28.0 29.0 30.0 31.0 32.0 33.0 34.0 35.0 36.0 37.0 38.0 39.0 40.0 41.0 42.0 43.0 44.0 45.0 46.0 47.0 48.0 49.0 50.0 51.0 52.0 53.0 54.0 55.0 56.0 57.0 58.0 59.0 60.0 61.0 62.0 63.0 64.0 65.0 66.0 67.0 68.0 69.0 70.0 71.0 72.0 73.0 74.0 75.0 76.0 77.0 78.0 79.0 80.0 81.0 82.0 83.0 84.0 85.0 86.0 87.0 88.0 89.0 90.0]
    const float eyeBrightnessHalflife       = 10.0;
    const float wetnessHalflife             = 180.0; // [10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 115 120 125 130 315 140 145 150 155 160 165 170 175 180 185 190 195]
    const float drynessHalflife             = 60.0; // [10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 115 120 125 130 315 140 145 150 155 160 165 170 175 180 185 190 195]
    const bool  shadowHardwareFiltering1    = true;
*/

#ifdef PARALLAX
/*
    const int   colortex7Format             = RGBA8;
*/
#endif

//----------------------------------------------------------------------------//

//#define PURKINJE_SHIFT

#if !defined IS_OVERWORLD
    #undef PURKINJE_SHIFT
#endif
// ==== СРАВНЕНИЕ ТОНМАПОВ (SPLIT-SCREEN) ====
#define TONEMAP_1TO1 0 // [0 1]
#define TONEMAP_LEFT Bliss // [ISA SEUS_PTGI SEUS_RENEWED KUDA AcademyFit AcademyFull AgX_Minimal AgX_Full ReinhardSimple ExtendedReinhard Filmic HableFilmic Uncharted2Filmic Lottes Uchimura Drago PhotographicReinhard HejlDawson JodieReinhard BlueShadowCustom BlueShadowIntense BlueShadowSubtle FakeHDR Bliss IterationT_AgX Frostbite]
#define TONEMAP_RIGHT IterationT_AgX // [ISA SEUS_PTGI SEUS_RENEWED KUDA AcademyFit AcademyFull AgX_Minimal AgX_Full ReinhardSimple ExtendedReinhard Filmic HableFilmic Uncharted2Filmic Lottes Uchimura Drago PhotographicReinhard HejlDawson JodieReinhard BlueShadowCustom BlueShadowIntense BlueShadowSubtle FakeHDR Bliss IterationT_AgX Frostbite]

#define TONEMAP AcademyFit // [Bliss IterationT_AgX Frostbite ISA SEUS_PTGI SEUS_RENEWED KUDA AcademyFit AcademyFull AgX_Minimal AgX_Full ReinhardSimple ExtendedReinhard Filmic HableFilmic Uncharted2Filmic Lottes Uchimura Drago PhotographicReinhard HejlDawson JodieReinhard BlueShadowCustom BlueShadowIntense BlueShadowSubtle FakeHDR]


#define ENABLE_HDR_OUTPUT 0 // [0 1]

#if ENABLE_HDR_OUTPUT == 1
    #define HDRTONEMAP_SHOULDERSTART 36.0

    #define HDRTONEMAP_WHITECLIP 10000.0
#endif

//#define CINEMATIC_EFFECT

#define COLOR_GRADING
#define BRIGHTNESS      1.0  // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0]
#define GAMMA           1.0  // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0]
#define CONTRAST        1.0  // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0]
#define SATURATION      1.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0]
#define WHITE_BALANCE   6500 // [2500 3000 3500 4000 4100 4200 4300 4400 4500 4600 4700 4800 4900 5000 5100 5200 5300 5400 5500 5600 5700 5800 5900 6000 6100 6200 6300 6400 6500 6600 6700 6800 6900 7000 7100 7200 7300 7400 7500 7600 7700 7800 7900 8000 8100 8200 8300 8400 8500 8600 8700 8800 8900 9000 9100 9200 9300 9400 9500 9600 9700 9800 9900 10000 10100 10200 10300 10400 10500 10600 10700 10800 10900 11000 11100 11200 11300 11400 11500 11600 11700 11800 11900 12000]

//#define VIGNETTE_ENABLED
#define VIGNETTE_STRENGTH 1.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0 3.5 4.0 5.0]


#define BLOOM_STYLE 2    // [1 2]


#define SOFT_BLOOM_ENABLED 1 // [0 1]
#define SOFT_BLOOM_AMOUNT 0.1 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 3.5 4.0 5.0]
#define SOFT_BLOOM_RADIUS 5.0 // [0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 6.0 7.0 8.0 10.0]
#define SOFT_BLOOM_QUALITY 3 // [1 2 3 4 5] Количество LOD уровней для мягкого блума

#define DONOR_BLOOM_BLENDING_MODE 2  // [0 1 2]  0=additive, 1=mix, 2=tone-preserve
#define DONOR_BLOOM_INTENSITY 6.5    // [0.0 0.01 0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0 3.0 4.0 5.0 7.0 10.0 15.0 20.0]
#define DONOR_BLOOMY_FOG_INTENSITY 2.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.75 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0 3.5 4.0 5.0]

// ==== НАСТРОЙКИ BLUE SHADOW  ====
#define BLUE_SHADOW_STRENGTH 0.35  // [0.0 0.1 0.2 0.3 0.35 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BLUE_SHADOW_HUE_R 0.4      // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BLUE_SHADOW_HUE_G 0.5      // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BLUE_SHADOW_HUE_B 0.9      // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BLUE_SHADOW_RANGE 0.3      // [0.0 0.1 0.2 0.3 0.4 0.5]




//#define AXIAL_BLOOM_ENABLED // [0 1]
#define AXIAL_BLOOM_INTENSITY  0.23  // [0.0 0.05 0.1 0.15 0.2 0.23 0.3 0.4 0.5 0.6 0.8 1.0 1.5 2.0]
#define AXIAL_BLOOM_THRESHOLD  0.0   // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define AXIAL_BLOOM_KNEE       0.1   // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.4 0.5]

// ==== FULLSCREEN BLUR ====
//#define FULLSCREEN_BLUR_ENABLED
#define FULLSCREEN_BLUR_INTENSITY 1.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.5 2.0 3.0 4.0 5.0 6.0 8.0 10.0]
//#define DEBUG_COUNTER

//----------------------------------------------------------------------------//

out vec3 sceneColor;

/* DRAWBUFFERS:3 */

in vec2 screenCoord;

//----// FUNCTIONS //-----------------------------------------------------------------------------//

float ScreenToViewSpace(in float depth) {
    depth = depth * 2.0 - 1.0;
    return 1.0 / (depth * gbufferProjectionInverse[2][3] + gbufferProjectionInverse[3][3]);
}




vec4 BicubicTexture(sampler2D tex, vec2 coord, vec2 texSize) {
    vec2 texPixelSize = 1.0 / texSize;
    coord = coord * texSize - 0.5;

    vec2 p = floor(coord);
    vec2 f = coord - p;

    vec2 ff = f * f;
    vec4 w0, w1;
    
    w0.xz = 1.0 - f;
    w0.xz *= w0.xz * w0.xz;
    w1.yw = ff * f;
    w1.xz = 3.0 * w1.yw + 4.0 - 6.0 * ff;
    w0.yw = 6.0 - w1.xz - w1.yw - w0.xz;

    vec4 s = w0 + w1;
    vec4 c = p.xxyy + vec2(-0.5, 1.5).xyxy + w1 / s;
    c *= texPixelSize.xxyy;

    vec2 m = s.xz / (s.xz + s.yw);
    
    return mix(
        mix(textureLod(tex, c.yw, 0.0), textureLod(tex, c.xw, 0.0), m.x),
        mix(textureLod(tex, c.yz, 0.0), textureLod(tex, c.xz, 0.0), m.x),
        m.y
    );
}


vec2 CalculateTileOffset(int lod) {
    vec2 lodMult = floor(lod * 0.5 + vec2(0.0, 0.5));
    vec2 offset = vec2(1.0 / 3.0, 2.0 / 3.0) * (1.0 - exp2(-2.0 * lodMult));
    return lodMult * 16.0 * screenPixelSize + offset;
}


vec3 BloomUpSample(in sampler2D tex, in int lod, in vec2 coord) {
    float scale = exp2(-lod);
    vec2 sampleCoord = coord * scale + CalculateTileOffset(lod - 1);
    return BicubicTexture(tex, sampleCoord, screenSize).rgb;
}

#if BLOOM_STYLE == 2


vec3 DonorBloomGather(in vec2 coord) {
    vec3 bloom = vec3(0.0);
    bloom += BloomUpSample(colortex4, 1, coord);
    bloom += BloomUpSample(colortex4, 2, coord);
    bloom += BloomUpSample(colortex4, 3, coord);
    bloom += BloomUpSample(colortex4, 4, coord);
    bloom += BloomUpSample(colortex4, 5, coord);
    bloom += BloomUpSample(colortex4, 6, coord);
    bloom += BloomUpSample(colortex4, 7, coord);
    return bloom * (1.0 / 7.0);
}

void CombineBloomAndFogDonor(inout vec3 color, in ivec2 texel, in vec2 coord) {
    vec3 bloomData = DonorBloomGather(coord);

    float bloomIntensity = DONOR_BLOOM_INTENSITY * 0.1;

    #ifdef BLOOMY_FOG
        float fogTransmittance = texelFetch(colortex6, texel, 0).x;
        float fogMask = 1.0 - fogTransmittance;
        bloomIntensity = max(bloomIntensity, fogMask * DONOR_BLOOMY_FOG_INTENSITY);
    #endif

    // ---- Dirty Lens ----
    #if DIRT_STYLE > 0
    {
        float newAspectRatio = 1.777777777777778 / aspectRatio;
        vec2 scale = vec2(max(newAspectRatio, 1.0), max(1.0 / newAspectRatio, 1.0));
        vec2 dirtCoord = (coord - 0.5) / scale + 0.5;

        float dirt = texture2D(DIRTY_LENS_SAMPLER, dirtCoord).r;
        float brightness = length(bloomData / (1.0 + bloomData));
        dirt *= brightness * DIRTY_LENS_STRENGTH;

        #ifdef DIRTY_LENS_BLOOM_BOOST
            bloomData *= (dirt * DIRTY_LENS_BLOOM_STRENGTH + 1.0);
        #else
            bloomData *= (dirt * 16.0 + 1.0);
        #endif
    }
    #endif

 
    float exposure = texelFetch(colortex5, ivec2(0), 0).a;
    bloomIntensity /= max(exposure, 1.0) + 1.0;

    #if DONOR_BLOOM_BLENDING_MODE == 0
        color += bloomData * bloomIntensity;
    #elif DONOR_BLOOM_BLENDING_MODE == 1
        color = mix(color, bloomData, bloomIntensity);
    #else
        color = (color + bloomData * bloomIntensity) / (1.0 + bloomIntensity * 0.5);
    #endif


    #if !defined IS_NETHER
        if (isEyeInWater == 0 && wetness > 1e-2) {
            float rain = texelFetch(colortex0, texel, 0).b * 0.35;
            color = color * (1.0 - rain) + bloomData * rain * 1.25;
        }
    #endif
}
#endif

// ====================================================================
// ГЛАВНАЯ ФУНКЦИЯ БЛУМА
// ====================================================================

void CalculateBloomFog(inout vec3 color, in ivec2 texel) {
    vec3 bloomData = vec3(0.0);
    vec3 fogBloom = vec3(0.0);

    // Поддержка дождя 
    #if defined IS_OVERWORLD
        float rainAlpha = clamp(texelFetch(colortex0, texel, 0).a * wetness, 0.0, 1.0);
    #else
        const float rainAlpha = 0.0;
    #endif

    // ================================================================
    // АПСЕМПЛИНГ ВСЕХ LOD
    // ================================================================
    
    // LOD 1
    vec3 sampleTile = BloomUpSample(colortex4, 1, screenCoord);
    bloomData += sampleTile;
    fogBloom += sampleTile;

    // LOD 2 
    sampleTile = BloomUpSample(colortex4, 2, screenCoord);
    bloomData += sampleTile * mix(1.0, 0.83333333, rainAlpha);
    fogBloom += sampleTile * 1.5;

    // LOD 3
    sampleTile = BloomUpSample(colortex4, 3, screenCoord);
    bloomData += sampleTile * mix(1.0, 0.69444444, rainAlpha);
    fogBloom += sampleTile * 2.25;

    // LOD 4
    sampleTile = BloomUpSample(colortex4, 4, screenCoord);
    bloomData += sampleTile * mix(1.0, 0.57870370, rainAlpha);
    fogBloom += sampleTile * 3.375;

    // LOD 5
    sampleTile = BloomUpSample(colortex4, 5, screenCoord);
    bloomData += sampleTile * mix(1.0, 0.48225309, rainAlpha);
    fogBloom += sampleTile * 5.0625;

    // LOD 6
    sampleTile = BloomUpSample(colortex4, 6, screenCoord);
    bloomData += sampleTile * mix(1.0, 0.40187757, rainAlpha);
    fogBloom += sampleTile * 7.59375;

    // LOD 7
    sampleTile = BloomUpSample(colortex4, 7, screenCoord);
    bloomData += sampleTile * mix(1.0, 0.33489798, rainAlpha);
    fogBloom += sampleTile * 11.328125;


    bloomData *= mix(0.23118661, 1.4 / 7.0, rainAlpha);
    fogBloom *= 0.03108305;

    // ================================================================
    // МЯГКИЙ БЛУМ
    // ================================================================
    
    #ifdef SOFT_BLOOM_ENABLED
        vec3 softBloom = vec3(0.0);
        float totalWeight = 0.0;
        
        #if SOFT_BLOOM_QUALITY >= 1
            float weight1 = 1.0;
            softBloom += BloomUpSample(colortex4, 2, screenCoord) * weight1;
            totalWeight += weight1;
        #endif
        
        #if SOFT_BLOOM_QUALITY >= 2
            float weight2 = 1.2;
            softBloom += BloomUpSample(colortex4, 3, screenCoord) * weight2;
            totalWeight += weight2;
        #endif
        
        #if SOFT_BLOOM_QUALITY >= 3
            float weight3 = 1.5;
            softBloom += BloomUpSample(colortex4, 4, screenCoord) * weight3;
            totalWeight += weight3;
        #endif
        
        #if SOFT_BLOOM_QUALITY >= 4
            float weight4 = 1.8;
            softBloom += BloomUpSample(colortex4, 5, screenCoord) * weight4;
            totalWeight += weight4;
        #endif
        
        #if SOFT_BLOOM_QUALITY >= 5
            float weight5 = 2.0;
            softBloom += BloomUpSample(colortex4, 6, screenCoord) * weight5;
            totalWeight += weight5;
        #endif
        
        softBloom /= totalWeight;
        softBloom *= SOFT_BLOOM_AMOUNT * (SOFT_BLOOM_RADIUS * 0.5);
        
        
        bloomData = mix(bloomData, softBloom, 0.7);
        bloomData += softBloom * 0.3;
    #endif


    
    #if DIRT_STYLE > 0
        float newAspectRatio = 1.777777777777778 / aspectRatio;
        vec2 scale = vec2(max(newAspectRatio, 1.0), max(1.0 / newAspectRatio, 1.0));
        vec2 dirtCoord = (screenCoord - 0.5) / scale + 0.5;

        float dirt = texture2D(DIRTY_LENS_SAMPLER, dirtCoord).r;

        float brightness = length(bloomData / (1.0 + bloomData));
        dirt *= brightness * DIRTY_LENS_STRENGTH;

        #ifdef DIRTY_LENS_BLOOM_BOOST
            bloomData *= (dirt * DIRTY_LENS_BLOOM_STRENGTH + 1.0);
            fogBloom *= (dirt * (DIRTY_LENS_BLOOM_STRENGTH * 0.5) + 1.0);
        #else
            bloomData *= (dirt * 16.0 + 1.0);
            fogBloom *= (dirt * 8.0 + 1.0);
        #endif
    #endif

    fogBloom += bloomData;

    // ================================================================
    // СМЕШИВАНИЕ С ТУМАННЫМ БЛУМОМ
    // ================================================================
    
    #ifdef BLOOMY_FOG
        float fogTransmittance = texelFetch(colortex6, texel, 0).x;
        color = mix(fogBloom * 0.5, color, fogTransmittance);
    #endif

    // ================================================================
    // ПРИМЕНЕНИЕ БЛУМА С АДАПТАЦИЕЙ ПОД ЭКСПОЗИЦИЮ
    // ================================================================
    
    float bloomAmount = BLOOM_AMOUNT * 0.15;

    float exposure = texelFetch(colortex5, ivec2(0), 0).a;
    bloomAmount /= fma(max(exposure, 1.0), 0.7, 0.3);

    color += bloomData * bloomAmount;
    
    // ================================================================
    // ДОПОЛНИТЕЛЬНЫЙ БЛУМ ДЛЯ ДОЖДЯ/СНЕГА
    // ================================================================
    
    #if !defined IS_NETHER
        if (isEyeInWater == 0 && wetness > 1e-2) {
            float rain = texelFetch(colortex0, texel, 0).b * 0.35;
            fogBloom *= 1.0 + weatherSnowySmooth * 2.0;
            color = color * (1.0 - rain) + fogBloom * fma(clamp(exposure, 0.6, 2.0), 0.15, 0.3) * rain;
        }
    #endif
}
#ifdef AXIAL_BLOOM_ENABLED

float AxialBloomKnee(float luma) {
    #if AXIAL_BLOOM_THRESHOLD == 0.0
        return 1.0;
    #else
        float knee = AXIAL_BLOOM_THRESHOLD * AXIAL_BLOOM_KNEE;
        float rq   = clamp((luma - (AXIAL_BLOOM_THRESHOLD - knee)) / (knee * 2.0), 0.0, 1.0);
        return max(luma - AXIAL_BLOOM_THRESHOLD, rq * rq * knee * 2.0);
    #endif
}

void AxialGaussianBloom(inout vec3 color) {
    
    vec3 bloom = vec3(0.0);

    bloom += BloomUpSample(colortex4, 1, screenCoord) * 1.0;
    bloom += BloomUpSample(colortex4, 2, screenCoord) * 0.83333333;
    bloom += BloomUpSample(colortex4, 3, screenCoord) * 0.69444444;
    bloom += BloomUpSample(colortex4, 4, screenCoord) * 0.57870370;
    bloom += BloomUpSample(colortex4, 5, screenCoord) * 0.48225309;
    bloom += BloomUpSample(colortex4, 6, screenCoord) * 0.40187757;
    bloom += BloomUpSample(colortex4, 7, screenCoord) * 0.33489798;

    bloom *= 0.2774;

    float luma   = GetLuminance(bloom);
    float weight = AxialBloomKnee(luma);

    color += bloom * weight * AXIAL_BLOOM_INTENSITY;
}

#endif

#ifdef FULLSCREEN_BLUR_ENABLED

void FullscreenBlur(inout vec3 color, ivec2 texel) {
    const float weights[5] = float[5](0.27343750, 0.21875000, 0.10937500, 0.03125000, 0.00390625);

    int radius = int(clamp(FULLSCREEN_BLUR_INTENSITY * 4.0, 1.0, 16.0));

    vec3  acc    = vec3(0.0);
    float wSum   = 0.0;

    // меня заебало писать коменты в пизду блять 
    vec3 hBlur = vec3(0.0);
    float hSum = 0.0;
    for (int i = -4; i <= 4; ++i) {
        float w = weights[abs(i)];
        int   s = int(float(i) * FULLSCREEN_BLUR_INTENSITY);
        hBlur += texelFetch(colortex5, texel + ivec2(s, 0), 0).rgb * w;
        hSum  += w;
    }
    hBlur /= hSum;

    vec3 vBlur = vec3(0.0);
    float vSum = 0.0;
    for (int i = -4; i <= 4; ++i) {
        float w = weights[abs(i)];
        int   s = int(float(i) * FULLSCREEN_BLUR_INTENSITY);
    
        vBlur += texelFetch(colortex5, texel + ivec2(0, s), 0).rgb * w;
        vSum  += w;
    }
    vBlur /= vSum;

  
    color = (hBlur + vBlur) * 0.5;
}

#endif



const mat3 rgbToXyz = mat3(
    vec3(0.4124564, 0.3575761, 0.1804375),
    vec3(0.2126729, 0.7151522, 0.0721750),
    vec3(0.0193339, 0.1191920, 0.9503041)
);

const mat3 xyzToRgb = mat3(
    vec3(3.2409699419,  -1.5373831776, -0.4986107603),
    vec3(-0.9692436363,  1.8759675015,  0.0415550574),
    vec3(0.0556300797,  -0.2039769589,  1.0569715142)
);

#ifdef PURKINJE_SHIFT
    vec3 PurkinjeShift(in vec3 color) {
        const vec3 rodResponse = vec3(7.15e-5, 4.81e-1, 3.28e-1);
        vec3 xyz = color * rgbToXyz;

        vec3 scotopicLuminance = max0(xyz * (1.33 * (1.0 + (xyz.y + xyz.z) / xyz.x) - 1.68));

        float purkinje = dot(rodResponse, scotopicLuminance * xyzToRgb);
        return mix(color, purkinje * vec3(0.5, 0.7, 1.0), fastExp(-purkinje * 90.0));
    }
#endif

#if defined COLOR_GRADING && WHITE_BALANCE != 6500
    mat3 ChromaticAdaptationMatrix(vec3 srcXyz, vec3 dstXyz) {
        const mat3 bradfordConeResponse = mat3(
            0.89510, -0.75020,  0.03890,
            0.26640,  1.71350, -0.06850,
            -0.16140,  0.03670,  1.02960
        );

        vec3 srcLms = srcXyz * bradfordConeResponse;
        vec3 dstLms = dstXyz * bradfordConeResponse;
        vec3 quotient = dstLms / srcLms;

        mat3 vonKries = mat3(
            quotient.x, 0.0, 0.0,
            0.0, quotient.y, 0.0,
            0.0, 0.0, quotient.z
        );

        return (bradfordConeResponse * vonKries) * inverse(bradfordConeResponse);
    }

    mat3 WhiteBalanceMatrix() {
        vec3 srcXyz = Blackbody(float(WHITE_BALANCE)) * rgbToXyz;
        vec3 dstXyz = Blackbody(6500.0)               * rgbToXyz;

        return rgbToXyz * ChromaticAdaptationMatrix(srcXyz, dstXyz) * xyzToRgb;
    }
#endif

vec3 Contrast(in vec3 color) {
    const float logMidpoint = log2(0.16);
    color = log2(color + 1e-6) - logMidpoint;
    return max0(exp2(color * CONTRAST + logMidpoint) - 1e-6);
}

#include "/lib/Post/ACES.glsl"
#include "/lib/Post/AgX.glsl"


#if ENABLE_HDR_OUTPUT == 0

#if TONEMAP == ISA
// ISA Tonemap
vec3 ISA(in vec3 color) {
    float a = 2.51;
    float b = 0.03;
    float c = 2.43;
    float d = 0.59;
    float e = 0.14;
    
    vec3 result = saturate((color * (a * color + b)) / (color * (c * color + d) + e));

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(result);
}
#endif

#if TONEMAP == SEUS_RENEWED
// SEUS Renewed Tonemap 
vec3 SEUS_RENEWED(in vec3 color) {
   
    color *= 1.25; 
    
    float A = 0.15; // Shoulder Strength
    float B = 0.50; // Linear Strength
    float C = 0.10; // Linear Angle
    float D = 0.20; // Toe Strength
    float E = 0.02; // Toe Numerator
    float F = 0.30; // Toe Denominator
    vec3 W = vec3(11.2); // Linear White Point
    
    vec3 tonemapped = ((color * (A * color + C * B) + D * E) / (color * (A * color + B) + D * F)) - E / F;
    vec3 white = ((W * (A * W + C * B) + D * E) / (W * (A * W + B) + D * F)) - E / F;
    
    vec3 result = saturate(tonemapped / white);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(result);
}
#endif

#if TONEMAP == KUDA
// KUDA Tonemap 

vec3 KUDA(in vec3 color) {

    color *= 1.15; 
    vec3 x = max(vec3(0.0), color - 0.004);
    

    vec3 result = (x * (6.2 * x + 0.5)) / (x * (6.2 * x + 1.7) + 0.06);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif


    result = pow(result, vec3(2.2));

    return LinearToSRGB(result);
}
#endif

#if TONEMAP == SEUS_PTGI
// SEUS PTGI Tonemap — панчевый кинематографичный контраст
vec3 SEUS_PTGI(in vec3 color) {
    float A = 0.15; // Shoulder Strength
    float B = 0.50; // Linear Strength
    float C = 0.10; // Linear Angle
    float D = 0.20; // Toe Strength
    float E = 0.02; // Toe Numerator
    float F = 0.30; // Toe Denominator
    vec3 W = vec3(11.2); // Linear White Point Value
    
    vec3 tonemapped = ((color * (A * color + C * B) + D * E) / (color * (A * color + B) + D * F)) - E / F;
    vec3 white = ((W * (A * W + C * B) + D * E) / (W * (A * W + B) + D * F)) - E / F;
    
    vec3 result = saturate(tonemapped / white);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(result);
}
#endif

vec3 Bliss(in vec3 color) {
    color *= 1.15; // Легкий буст экспозиции
    
    // Crosstalk (смешивание каналов для пленочного лука)
    mat3 crosstalk = mat3(
        1.0,  0.05, 0.01,
        0.02, 1.0,  0.02,
        0.0,  0.03, 1.0
    );
    color = color * crosstalk;
    
    // Lottes-based curve с глубокими тенями
    float a = 1.6;
    float d = 0.977;
    float hdrMax = 8.0;
    float midIn = 0.18;
    float midOut = 0.22;

    float b = (-pow(midIn, a) + pow(hdrMax, a) * midOut) / ((pow(hdrMax, a * d) - pow(midIn, a * d)) * midOut);
    float c = (pow(hdrMax, a * d) * pow(midIn, a) - pow(hdrMax, a) * pow(midIn, a * d) * midOut) / ((pow(hdrMax, a * d) - pow(midIn, a * d)) * midOut);

    vec3 z = pow(max(color, vec3(0.0)), vec3(a));
    vec3 result = z / (pow(z, vec3(d)) * b + c);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}

// ====================================================================
// IterationT AgX (Punchy Modded)
// ====================================================================
vec3 IterationT_AgX(in vec3 val) {
    const mat3 agx_mat = mat3(
        0.842479062253094, 0.0423282422610123, 0.0423756549057051,
        0.0784335999999992,  0.878468636469772,  0.0784336,
        0.0792237451477643, 0.0791661274605434, 0.879142973793104
    );
    const float min_ev = -8.0;
    const float max_ev = 6.0;

    // IterationT signature pre-exposure punch
    val = agx_mat * val * 9.5; 
    val = clamp(log2(val), min_ev, max_ev);
    val = (val - min_ev) / (max_ev - min_ev);

    // AgX 7th degree contrast approximation
    vec3 x2 = val * val;
    vec3 x4 = x2 * x2;
    val = - 17.86 * x4 * x2 * val + 78.01 * x4 * x2 - 126.7 * x4 * val + 92.06 * x4 - 28.72 * x2 * val + 4.361 * x2 - 0.1718 * val + 0.002857;

    // IterationT CDL (Color Decision List) Look
    vec3 slope = vec3(1.0);
    vec3 power = vec3(1.35); // Жесткий контраст средних тонов
    float sat = 1.35;        // Высокая насыщенность
    
    float luma = dot(val, vec3(0.2126, 0.7152, 0.0722));
    val = pow(max(val * slope, vec3(0.0)), power);
    val = luma + sat * (val - luma);

    #ifdef COLOR_GRADING
        val = Contrast(val * BRIGHTNESS);
        val = pow(val, vec3(rcp(GAMMA)));
        val = ColorSaturation(val, SATURATION);
        #if WHITE_BALANCE != 6500
            val *= WhiteBalanceMatrix();
        #endif
    #endif

    const mat3 agx_mat_inv = mat3(
        1.19687900512017, -0.0528968517574562, -0.0529716355144438,
        -0.0980208811401368, 1.15190312990417, -0.0980434501171241,
        -0.0990297440797205, -0.0989611768448433, 1.15107367264116
    );
    return saturate(agx_mat_inv * val);
}

// ====================================================================
// Frostbite (EA Engine)
// ====================================================================
vec3 Frostbite(in vec3 color) {
    color *= 1.25; 
    
    vec3 x = color;
    vec3 result = (x * (0.22 * x + 0.03)) / (x * (0.22 * x + 0.3) + 0.06);
    
    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}

#if TONEMAP == ReinhardSimple
// Reinhard (2002) — luminance-based, preserves hue by mapping only luma
// Per-channel Reinhard is wrong and oversaturates; this is the correct form.
vec3 ReinhardSimple(in vec3 color) {
    float luma = GetLuminance(color);
    float lumaMapped = luma / (1.0 + luma);
    vec3 result = color * (lumaMapped / max(luma, 1e-6));

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == ExtendedReinhard
// Extended Reinhard — Jodie (2018) variant: blends luminance-mapped and per-channel
// Avoids hue shifts of pure per-channel while keeping color pop of per-channel in highlights
vec3 ExtendedReinhard(in vec3 color) {
    float luma    = GetLuminance(color);
    vec3  tcPerCh = color / (1.0 + color);          // per-channel Reinhard
    float tcLuma  = luma  / (1.0 + luma);           // luminance Reinhard

    // Blend: saturated pixels lean toward per-channel, dark pixels toward luma
    vec3 result = mix(color * (tcLuma / max(luma, 1e-6)), tcPerCh, tcPerCh);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == Filmic
// GT Tonemap — Timothy Lottes (2016), used in many modern engines
// Proper filmic S-curve with independent toe/shoulder control, no magic constants
vec3 Filmic(in vec3 color) {
    const float P  = 1.0;    // max display brightness
    const float a  = 1.0;    // contrast
    const float m  = 0.22;   // toe start (linear portion)
    const float l  = 0.4;    // toe length
    const float c  = 1.33;   // cross-over angle
    const float b  = 0.0;    // black tightness

    // Shoulder
    float l0 = (P - m) * l / a;
    float L0 = m - m / a;
    float L1 = m + (1.0 - m) / a;
    float S0 = m + l0;
    float S1 = m + a * l0;
    float C2 = a * P / (P - S1);
    float CP = -C2 / P;

    vec3 w0 = vec3(1.0 - smoothstep(0.0, m, color));
    vec3 w2 = vec3(step(m + l0, color));
    vec3 w1 = 1.0 - w0 - w2;

    vec3 T = vec3(m * pow(color / m, vec3(c)) + b);                    // toe
    vec3 S = vec3(P - (P - S1) * exp(CP * (color - S0)));              // shoulder
    vec3 L = vec3(m + a * (color - m));                                // linear

    vec3 result = T * w0 + L * w1 + S * w2;

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == HableFilmic
// Hable "Uncharted 2" Filmic — John Hable (2010), classic game industry tonemapper
// Proper white-point normalization so highlights don't clip to wrong value
vec3 HableFilmic(in vec3 color) {
    const float A = 0.15; // shoulder strength
    const float B = 0.50; // linear strength
    const float C = 0.10; // linear angle
    const float D = 0.20; // toe strength
    const float E = 0.02; // toe numerator
    const float F = 0.30; // toe denominator
    const float W = 11.2; // linear white point

    #define HABLE_CURVE(x) (((x) * (A * (x) + C * B) + D * E) / ((x) * (A * (x) + B) + D * F)) - E / F

    vec3 curr = HABLE_CURVE(color * 2.0);
    float whiteNorm = 1.0 / HABLE_CURVE(W);
    vec3 result = curr * whiteNorm;

    #undef HABLE_CURVE

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == Uncharted2Filmic
// Uncharted 2 Filmic — John Hable (2010)

vec3 Uncharted2Filmic(in vec3 color) {
    const float A = 0.22; // shoulder strength
    const float B = 0.30; // linear strength
    const float C = 0.10; // linear angle
    const float D = 0.20; // toe strength
    const float E = 0.01; // toe numerator
    const float F = 0.30; // toe denominator
    const float W = 11.2; // linear white point
    const float ExposureBias = 2.0;

    #define U2_CURVE(x) (((x) * (A * (x) + C * B) + D * E) / ((x) * (A * (x) + B) + D * F)) - E / F

    vec3 curr = U2_CURVE(color * ExposureBias);
    float whiteNorm = 1.0 / U2_CURVE(W);
    vec3 result = curr * whiteNorm;

    #undef U2_CURVE

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == Lottes
// Timothy Lottes (2016) general purpose tonemapper — AMD GPUOpen.

vec3 Lottes(in vec3 color) {
    const float hdrMax   = 16.0;  // максимальная входная яркость, которую держим без клиппинга
    const float contrast = 1.6;   // общий контраст кривой
    const float shoulder  = 0.97; // насколько резко "прижимаются" света к белому
    const float midIn     = 0.18; // входное серое (linear scene-referred)
    const float midOut    = 0.18; // выходное серое (display-referred)

    float b =
        (-pow(midIn, contrast) + pow(hdrMax, contrast) * midOut) /
        ((pow(hdrMax, contrast * shoulder) - pow(midIn, contrast * shoulder)) * midOut);
    float c =
        (pow(hdrMax, contrast * shoulder) * pow(midIn, contrast) - pow(hdrMax, contrast) * pow(midIn, contrast * shoulder) * midOut) /
        ((pow(hdrMax, contrast * shoulder) - pow(midIn, contrast * shoulder)) * midOut);

    vec3 z = pow(max(color, vec3(0.0)), vec3(contrast));
    vec3 result = z / (pow(z, vec3(shoulder)) * b + c);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == Uchimura
// Uchimura / "Gran Turismo" Tonemap — Hajime Uchimura (2017), CEDEC презентация Polyphony Digital.
// Кусочная кривая (линейная середина + toe + shoulder), которая используется в GT Sport
// и многих современных движках как нейтральная альтернатива ACES — меньше desaturation
// в светах, более предсказуемый средний диапазон.
float UchimuraCurve(in float x, in float P, in float a, in float m, in float l, in float c, in float b) {
    float l0 = (P - m) * l / a;
    float L0 = m - m / a;
    float L1 = m + (1.0 - m) / a;
    float S0 = m + l0;
    float S1 = m + a * l0;
    float C2 = a * P / (P - S1);
    float CP = -C2 / P;

    float w0 = 1.0 - smoothstep(0.0, m, x);
    float w2 = step(m + l0, x);
    float w1 = 1.0 - w0 - w2;

    float T = m * pow(x / m, c) + b;
    float S = P - (P - S1) * exp(CP * (x - S0));
    float L = m + a * (x - m);

    return T * w0 + L * w1 + S * w2;
}

vec3 Uchimura(in vec3 color) {
    const float P = 1.0;   // максимальная яркость дисплея
    const float a = 1.0;   // контраст
    const float m = 0.22;  // начало toe (линейный участок)
    const float l = 0.4;   // длина toe
    const float c = 1.33;  // угол перехода
    const float b = 0.0;   // плотность чёрного

    vec3 result = vec3(
        UchimuraCurve(color.r, P, a, m, l, c, b),
        UchimuraCurve(color.g, P, a, m, l, c, b),
        UchimuraCurve(color.b, P, a, m, l, c, b)
    );

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == Drago

vec3 Drago(in vec3 color) {
    const float maxLuminance = 1.0223; 
    const float bias = 0.85;          

    float luma = GetLuminance(color);
    float worldLuma = luma * (1.0 / maxLuminance);

    float logBias = log(bias) / log(0.5);
    float dragoLuma = log(1.0 + worldLuma) /
        ( log(2.0 + 8.0 * pow(worldLuma, logBias)) ) * (1.0 / log(1.0 + maxLuminance));

    float scale = max(dragoLuma, 1e-6) / max(luma, 1e-6);
    vec3 result = saturate(color * scale);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == PhotographicReinhard

vec3 PhotographicReinhard(in vec3 color) {
    const float key = 0.10001; 

    float luma = GetLuminance(color);
    float scaledLuma = luma * (key / max(luma, 1e-6)) * 2.0; 
    float lumaMapped = scaledLuma / (1.0 + scaledLuma);

    vec3 result = color * (lumaMapped / max(luma, 1e-6));

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == HejlDawson
// Khronos PBR Neutral — Khronos Group (2023), designed for physically-based rendering
// Preserves chromaticity in midtones, smooth rolloff into highlights, no sRGB baked in
vec3 HejlDawson(in vec3 color) {
    const float startCompression = 0.8 - 0.04;
    const float desaturation     = 0.15;

    float x = min(color.r, min(color.g, color.b));
    float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
    color -= offset;

    float peak = max(color.r, max(color.g, color.b));
    if (peak < startCompression) {
        vec3 result = color;
        #ifdef COLOR_GRADING
            result = Contrast(result * BRIGHTNESS);
            result = pow(result, vec3(rcp(GAMMA)));
            result = ColorSaturation(result, SATURATION);
            #if WHITE_BALANCE != 6500
                result *= WhiteBalanceMatrix();
            #endif
        #endif
        return LinearToSRGB(saturate(result));
    }

    const float d = 1.0 - startCompression;
    float newPeak = 1.0 - d * d / (peak + d - startCompression);
    color *= newPeak / peak;

    float g = 1.0 - 1.0 / (desaturation * (peak - newPeak) + 1.0);
    vec3 result = mix(color, vec3(newPeak), g);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == JodieReinhard
// Tony McMapface — Tomasz Stachowiak (2022), used in Bevy and other modern engines
// Works in display-referred space after an exposure mapping.
// Better hue preservation than Reinhard, smoother than ACES Fit.
// Approximated here without LUT via rational curve fit.
vec3 JodieReinhard(in vec3 color) {
    // Luminance-weighted blend: per-channel mapped vs luma-only mapped
    // Keeps saturation in midtones, desaturates smoothly in highlights
    float luma = GetLuminance(color);

    // Per-channel and luma-only Reinhard
    vec3  mappedPerCh = color / (1.0 + color);
    float mappedLuma  = luma  / (1.0 + luma);

    // Blend based on per-channel result: bright saturated channels fade to white
    vec3 result = mix(color * (mappedLuma / max(luma, 1e-6)), mappedPerCh, mappedPerCh * mappedPerCh);

    // Soft gamma toe to lift near-blacks slightly (filmic look)
    result = pow(max0(result), vec3(0.96));

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == BlueShadowCustom
vec3 BlueShadowCustom(in vec3 color) {
    color *= 1.15;
    
    float luminance = GetLuminance(color);
    
    float shadowMask = 1.0 - smoothstep(0.0, BLUE_SHADOW_RANGE, luminance);
    shadowMask = pow(shadowMask, 2.2);
    
    vec3 blueTint = vec3(BLUE_SHADOW_HUE_R, BLUE_SHADOW_HUE_G, BLUE_SHADOW_HUE_B);
    
    vec3 colorWithBlueShadows = mix(color, color * blueTint, shadowMask * BLUE_SHADOW_STRENGTH);
    
    vec3 result = colorWithBlueShadows / (1.0 + colorWithBlueShadows);
    
    float deepShadowMask = pow(shadowMask, 3.0);
    result = mix(result, result * vec3(0.5, 0.6, 1.2), deepShadowMask * 0.2);
    
    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif
    
    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == BlueShadowIntense
vec3 BlueShadowIntense(in vec3 color) {
    color *= 1.15;
    
    float luminance = GetLuminance(color);
    float shadowMask = 1.0 - smoothstep(0.0, 0.35, luminance);
    shadowMask = pow(shadowMask, 1.8);
    
    vec3 blueTint = vec3(0.3, 0.45, 1.8);
    float tintStrength = 0.5;
    
    vec3 colorWithBlueShadows = mix(color, color * blueTint, shadowMask * tintStrength);
    vec3 result = colorWithBlueShadows / (1.0 + colorWithBlueShadows);
    
    float deepShadowMask = pow(shadowMask, 2.5);
    result = mix(result, result * vec3(0.4, 0.55, 1.3), deepShadowMask * 0.3);
    
    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif
    
    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == BlueShadowSubtle
vec3 BlueShadowSubtle(in vec3 color) {
    color *= 1.15;
    
    float luminance = GetLuminance(color);
    float shadowMask = 1.0 - smoothstep(0.0, 0.25, luminance);
    shadowMask = pow(shadowMask, 2.8);
    
    vec3 blueTint = vec3(0.55, 0.65, 0.95);
    float tintStrength = 0.2;
    
    vec3 colorWithBlueShadows = mix(color, color * blueTint, shadowMask * tintStrength);
    vec3 result = colorWithBlueShadows / (1.0 + colorWithBlueShadows);
    
    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif
    
    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == FakeHDR

vec3 FakeHDR(in vec3 color) {
   
    color *= 1.2;

 
    const float A = 0.22; // shoulder strength 
    const float B = 0.30;
    const float C = 0.10;
    const float D = 0.20;
    const float E = 0.01;
    const float F = 0.30;
    const float W = 16.0; // дальше, чем обычные 11.2

    #define FAKEHDR_CURVE(x) (((x) * (A * (x) + C * B) + D * E) / ((x) * (A * (x) + B) + D * F)) - E / F

    vec3 curr = FAKEHDR_CURVE(color);
    float whiteNorm = 1.0 / FAKEHDR_CURVE(vec3(W).x);
    vec3 result = curr * whiteNorm;

    float luma = GetLuminance(result);
    float highlightMask = smoothstep(0.55, 1.0, luma);
    result = mix(result, result * result * (3.0 - 2.0 * result), highlightMask * 0.35);

    #undef FAKEHDR_CURVE

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION * 1.05); 
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#endif // ENABLE_HDR_OUTPUT == 0

#if ENABLE_HDR_OUTPUT == 1

#if defined(HDR_MOD_INSTALLED) && defined(HDR_ENABLED)
    uniform float HdrGamePeakBrightness;
    uniform float HdrGamePaperWhiteBrightness;
    uniform float HdrGameMinimumBrightness;
    uniform float HdrUIBrightness;
#endif

vec3 HDR_Reinhard(vec3 x, float peak) {
    return x / (x / peak + 1.0);
}

vec3 HDR_ReinhardExtended(vec3 x, float white_max, float peak) {
    return HDR_Reinhard(x, peak) * (1.0 + (peak * x) / (white_max * white_max));
}

float HDR_ComputeReinhardExtendableScale(float w, float p, float m, float x, float y) {
    return p * (w * w * y - (p * x * x)) / (w * w * x * (p - y));
}

vec3 HDR_ReinhardPiecewiseExtended(vec3 x, float white_max, float x_max, float shoulder) {
    const float x_min = 0.0;
    float exposure = HDR_ComputeReinhardExtendableScale(white_max, x_max, x_min, shoulder, shoulder);
    vec3 extended = HDR_ReinhardExtended(x * exposure, white_max * exposure, x_max);
    extended = min(extended, vec3(x_max));
    return mix(x, extended, step(shoulder, x));
}


vec3 HDRTonemap(in vec3 color) {
    #if defined(HDR_MOD_INSTALLED) && defined(HDR_ENABLED)
        float paperWhite = HdrGamePaperWhiteBrightness;
        float peak       = HdrGamePeakBrightness / paperWhite;
        float shoulder   = HDRTONEMAP_SHOULDERSTART / paperWhite;
        float whiteClip  = HDRTONEMAP_WHITECLIP / paperWhite;
    #else

        const float paperWhite = 203.0;
        float peak       = 1000.0 / paperWhite;
        float shoulder   = HDRTONEMAP_SHOULDERSTART / paperWhite;
        float whiteClip  = HDRTONEMAP_WHITECLIP / paperWhite;
    #endif

    vec3 result = HDR_ReinhardPiecewiseExtended(color, whiteClip, peak, shoulder);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return result;
}

#endif // ENABLE_HDR_OUTPUT == 1

#ifdef DEBUG_COUNTER
    #include "/lib/Post/PrintFloat.glsl"
#endif

//----// MAIN //----------------------------------------------------------------------------------//
void main() {
    ivec2 texel = ivec2(gl_FragCoord.xy);
    #ifdef MOTION_BLUR
        vec3 color = texelFetch(colortex2, texel, 0).rgb;
    #else
        vec3 color = texelFetch(colortex5, texel, 0).rgb;
    #endif

        #ifdef FULLSCREEN_BLUR_ENABLED
        FullscreenBlur(color, texel);
    #endif

    #ifdef BLOOM_ENABLED
        #if BLOOM_STYLE == 2
            CombineBloomAndFogDonor(color, texel, screenCoord);
        #else
            CalculateBloomFog(color, texel);
        #endif
    #endif

    #ifdef PURKINJE_SHIFT
        color = PurkinjeShift(color);
    #endif

    color *= texelFetch(colortex5, ivec2(0), 0).a; // Exposure

    #ifdef AXIAL_BLOOM_ENABLED
        AxialGaussianBloom(color);
    #endif

    #ifdef VIGNETTE_ENABLED
        color *= fastExp(-2.0 * dotSelf(screenCoord - 0.5) * VIGNETTE_STRENGTH);
    #endif

  

#if ENABLE_HDR_OUTPUT == 1
        color = HDRTonemap(color);
    #else
        #if TONEMAP_1TO1 == 1
            vec3 colorLeft = TONEMAP_LEFT(color);
            vec3 colorRight = TONEMAP_RIGHT(color);
            
        
            if (screenCoord.x < 0.5) {
                color = colorLeft;
            } else {
                color = colorRight;
            }
            
           
            float splitLine = abs(screenCoord.x - 0.5) < 0.0015 ? 1.0 : 0.0;
            color = mix(color, vec3(1.0), splitLine);
        #else
            color = TONEMAP(color);
        #endif
    #endif

    #ifdef CINEMATIC_EFFECT
        color *= step(abs(screenCoord.y - 0.5) * 2.0, aspectRatio * (9.0 / 21.0)); // 21:9
    #endif

    #ifdef DEBUG_COUNTER
        const float scale = 5.0, size = 1.0 / scale;
        vec2 tCoord = gl_FragCoord.xy * size;

        if (clamp(tCoord, vec2(0.0, 25.0), vec2(40.0, 50.0)) == tCoord) {
            color = min(color * 0.5, 0.8);
        }

        color += PrintFloat(shadowProjection[0].x, vec2(10.0, 35.0) * scale, size);
    #endif


    #if ENABLE_HDR_OUTPUT == 1
        sceneColor = color;
    #else
        sceneColor = saturate(color);
    #endif
}