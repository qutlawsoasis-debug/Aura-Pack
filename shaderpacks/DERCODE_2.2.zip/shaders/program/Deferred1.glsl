#define PRECOMPUTED_ATMOSPHERIC_SCATTERING

out vec4 cloudData;

/* DRAWBUFFERS:2 */

//in vec2 screenCoord;

flat in vec3 sunIlluminance;
flat in vec3 moonIlluminance;
flat in vec3 skyIlluminance;

#include "/lib/Head/Common.inc"

//----------------------------------------------------------------------------//

uniform sampler2D noisetex;

uniform sampler3D colortex4;
uniform sampler2D colortex5;

// 4 planet textures
uniform sampler2D colortex14;
uniform sampler2D colortex16;
uniform sampler2D colortex17;
uniform sampler2D colortex18;

// Moon textures (albedo + normal, for MOON_STYLE 1/2)

uniform sampler2D colortex37;

// Cubemap skybox textures (active depending on SKYBOX_STYLE)
#if SKYBOX_STYLE == 2
    uniform sampler2D shadowcolor0;
#elif SKYBOX_STYLE == 3
    uniform sampler2D colortex27;
#endif


uniform sampler2D depthtex0;

#if defined DISTANT_HORIZONS
	uniform sampler2D dhDepthTex0;
#endif

uniform float nightVision;
uniform float viewWidth;
uniform float viewHeight;
uniform float wetness;
uniform float eyeAltitude;
uniform float isLightningFlashing;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;

uniform vec3 worldSunVector;
uniform vec3 worldLightVector;

uniform int frameCounter;
uniform int moonPhase;
uniform int worldDay;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;

uniform vec2 screenSize;
uniform vec2 screenPixelSize;

//----// FUNCTIONS //-----------------------------------------------------------------------------//

#define GetDepth(texel) texelFetch(depthtex0, texel, 0).x

vec3 ScreenToViewSpaceRaw(in vec3 screenPos) {	
	vec3 NDCPos = screenPos * 2.0 - 1.0;
	vec3 viewPos = projMAD(gbufferProjectionInverse, NDCPos);
	viewPos /= gbufferProjectionInverse[2].w * NDCPos.z + gbufferProjectionInverse[3].w;

	return viewPos;
}

#include "/lib/Head/Noise.inc"

#include "/lib/Atmosphere/Atmosphere.glsl"

#include "/lib/Atmosphere/BlackHole.glsl"

#include "/lib/Atmosphere/VolumetricClouds.glsl"

#include "/lib/Atmosphere/PlanarClouds.glsl"

#ifdef AURORA
	#include "/lib/Atmosphere/Aurora.glsl"
#endif

#if defined DISTANT_HORIZONS
	float depthMax4x4DH(in vec2 coord) {
		vec4 depthSamples0 = textureGather(dhDepthTex0, coord + vec2( 2.0,  2.0) * screenPixelSize);
		vec4 depthSamples1 = textureGather(dhDepthTex0, coord + vec2(-2.0,  2.0) * screenPixelSize);
		vec4 depthSamples2 = textureGather(dhDepthTex0, coord + vec2( 2.0, -2.0) * screenPixelSize);
		vec4 depthSamples3 = textureGather(dhDepthTex0, coord + vec2(-2.0, -2.0) * screenPixelSize);

		return max(
			max(maxOf(depthSamples0), maxOf(depthSamples1)),
			max(maxOf(depthSamples2), maxOf(depthSamples3))
		);
	}
#else
	float depthMax4x4(in vec2 coord) {
		vec4 depthSamples0 = textureGather(depthtex0, coord + vec2( 2.0,  2.0) * screenPixelSize);
		vec4 depthSamples1 = textureGather(depthtex0, coord + vec2(-2.0,  2.0) * screenPixelSize);
		vec4 depthSamples2 = textureGather(depthtex0, coord + vec2( 2.0, -2.0) * screenPixelSize);
		vec4 depthSamples3 = textureGather(depthtex0, coord + vec2(-2.0, -2.0) * screenPixelSize);

		return max(
			max(maxOf(depthSamples0), maxOf(depthSamples1)),
			max(maxOf(depthSamples2), maxOf(depthSamples3))
		);
	}
#endif

#if TEMPORAL_UPSCALING == 2
	const ivec2[4] checkerboardOffset = ivec2[4](
		ivec2(0, 0), ivec2(1, 1),
		ivec2(1, 0), ivec2(0, 1)
	);
#elif TEMPORAL_UPSCALING == 3
	const ivec2[9] checkerboardOffset = ivec2[9](
		ivec2(0, 0), ivec2(2, 0), ivec2(0, 2),
		ivec2(2, 2), ivec2(1, 1), ivec2(1, 0),
		ivec2(1, 2), ivec2(0, 1), ivec2(2, 1)
	);
#elif TEMPORAL_UPSCALING == 4
	const ivec2[16] checkerboardOffset = ivec2[16](
		ivec2(0, 0), ivec2(2, 0), ivec2(0, 2), ivec2(2, 2),
		ivec2(1, 1), ivec2(3, 1), ivec2(1, 3), ivec2(3, 3),
		ivec2(1, 0), ivec2(3, 0), ivec2(1, 2), ivec2(3, 2),
		ivec2(0, 1), ivec2(2, 1), ivec2(0, 3), ivec2(2, 3)
	);
#endif

const int cloudsRenderFactor = TEMPORAL_UPSCALING * TEMPORAL_UPSCALING;

void GetPlanetCurvePosition(inout vec3 p) {
    p.y = length(p + vec3(0.0, planetRadius, 0.0)) - planetRadius;
}

vec4 RenderSkybox(in vec3 worldDir, in float dither, in CloudProperties cloudProperties) {
	vec4 cloudsData = vec4(0.0, 0.0, 0.0, 1.0);
	vec3 skyRadiance = texture(colortex5, ProjectSky(worldDir)).rgb;

    // ВНИМАНИЕ: Здесь убрано двойное применение ApplySkyboxPreset! 
    // skyRadiance уже имеет нужный пресет из Deferred0.glsl.
    
	float LdotV = dot(worldDir, worldLightVector);

	vec4 phases;
	phases.x = 	HenyeyGreensteinPhase(LdotV, cloudForwardG) 	  * 0.7  + HenyeyGreensteinPhase(LdotV, cloudBackwardG)		  * cloudBackwardWeight  	  + CornetteShanksPhase(LdotV, 0.9) * cloudProperties.cloudPeakWeight;
	phases.y = 	HenyeyGreensteinPhase(LdotV, cloudForwardG * 0.7) * 0.35 + HenyeyGreensteinPhase(LdotV, cloudBackwardG * 0.7) * cloudBackwardWeight * 0.6 + CornetteShanksPhase(LdotV, 0.6) * cloudProperties.cloudPeakWeight * 0.5;
	phases.z = 	HenyeyGreensteinPhase(LdotV, cloudForwardG * 0.5) * 0.17 + HenyeyGreensteinPhase(LdotV, cloudBackwardG * 0.5) * cloudBackwardWeight * 0.3 + CornetteShanksPhase(LdotV, 0.4) * cloudProperties.cloudPeakWeight * 0.2;
	phases.w = 	HenyeyGreensteinPhase(LdotV, cloudForwardG * 0.3) * 0.08 + HenyeyGreensteinPhase(LdotV, cloudBackwardG * 0.3) * cloudBackwardWeight * 0.2 + CornetteShanksPhase(LdotV, 0.2) * cloudProperties.cloudPeakWeight * 0.1;

	vec3 planeOrigin = vec3(0.0, planetRadius + eyeAltitude, 0.0);
    bool intersectsGround = RaySphereIntersection(planeOrigin, worldDir, planetRadius).y >= 0.0;

	#ifdef VOLUMETRIC_CLOUDS
		if ((worldDir.y > 0.0 && eyeAltitude < cloudProperties.altitude)
		|| (intersectsGround && eyeAltitude > cloudProperties.maxAltitude)) {

			vec2 bottomIntersection = RaySphereIntersection(planeOrigin, worldDir, planetRadius + cloudProperties.altitude);
			vec2 topIntersection = RaySphereIntersection(planeOrigin, worldDir, planetRadius + cloudProperties.maxAltitude);

			float startLength, endLength;
			if (eyeAltitude > cloudProperties.maxAltitude) {
				startLength = topIntersection.x;
				endLength = bottomIntersection.x;
			} else {
				startLength = bottomIntersection.y;
				endLength = topIntersection.y;
			}

			float rayRange = oneMinus(saturate((eyeAltitude - cloudProperties.maxAltitude) * 0.1)) *
							oneMinus(saturate((cloudProperties.altitude - eyeAltitude) * 0.1));
			float rayDist = bottomIntersection.y >= 0.0 && eyeAltitude > cloudProperties.altitude ? bottomIntersection.x : topIntersection.y;

			startLength *= oneMinus(rayRange);
			endLength = mix(endLength, rayDist, rayRange);

			uint raySteps = CLOUD_CUMULUS_SAMPLES;
			raySteps = uint(mix(raySteps, uint(raySteps * 0.6), abs(worldDir.y)));
			float rayLength = clamp(endLength - startLength, 0.0, 2e4) * rcp(raySteps);
			vec3 rayStep = rayLength * worldDir;
            GetPlanetCurvePosition(rayStep);
			vec3 rayPos = (startLength + rayLength * dither) * worldDir + cameraPosition;
            GetPlanetCurvePosition(rayPos);

			float noiseDetail = GetNoiseDetail(worldDir);
			float scatteringSun = 0.0;
			float scatteringSky = 0.0;
			float transmittanceCld = 1.0;

			for (uint i = 0u; i < raySteps; ++i, rayPos += rayStep) {
				if (transmittanceCld < minTransmittance) break;
				if (rayPos.y < cloudProperties.altitude || rayPos.y > cloudProperties.maxAltitude) continue;

				float dist = distance(rayPos, cameraPosition);
				if (dist > planetRadius + cloudProperties.maxAltitude) continue;

				float density = CloudVolumeDensity(cloudProperties, rayPos, 5u, mix(noiseDetail, 1.0, exp2(-dist * 0.001f)));
				if (density < 1e-4) continue;

				vec2 lightNoise = hash2(fract(rayPos)) * 0.4 + 0.3;

				float sunlightOD = CloudVolumeSunLightOD(cloudProperties, rayPos, lightNoise.x);
				float powder = oneMinus(fastExp(-density * 36.0)) * 0.82;
				powder /= 1.0 - powder;

				float sunlightEnergy = 	fastExp(-sunlightOD * 2.0) * phases.x;
				sunlightEnergy += 		fastExp(-sunlightOD * 0.8) * phases.y;
				sunlightEnergy += 		fastExp(-sunlightOD * 0.3) * phases.z;
				sunlightEnergy += 		fastExp(-sunlightOD * 0.1) * phases.w;

				float skylightEnergy = CloudVolumeSkyLightOD(cloudProperties, rayPos, lightNoise.y);
				skylightEnergy = fastExp(-skylightEnergy) + fastExp(-skylightEnergy * 0.1) * 0.1;

				float stepTransmittance = fastExp(-density * 0.12 * rayLength);
				float cloudsTemp = powder * transmittanceCld * oneMinus(stepTransmittance);
				scatteringSun += sunlightEnergy * cloudsTemp;
				scatteringSky += skylightEnergy * cloudsTemp;
				transmittanceCld *= stepTransmittance;	
			}

			if (transmittanceCld < 1.0 - minTransmittance) {
				bool moonlit = worldSunVector.y < -0.04;
				vec3 scattering = scatteringSun * 22.0 * cloudProperties.sunlighting * (moonlit ? moonIlluminance : sunIlluminance);
				scattering += scatteringSky * 0.15 * cloudProperties.skylighting * skyIlluminance;

				if (isLightningFlashing > 1e-2) scattering += sqr(scatteringSky) * 0.1 * lightningColor;
				#ifdef AURORA
					scattering += scatteringSky * vec3(0.0, 0.005, 0.0025) * auroraAmount;
				#endif

				rayPos -= cameraPosition;
				#ifdef FULL_AERIAL_PERSPECTIVE
					vec3 airTransmittance;
					vec3 aerialPerspective = 20.0 * GetSkyRadianceToPoint(atmosphereModel, rayPos, worldSunVector, airTransmittance);
					scattering *= airTransmittance;
					scattering += aerialPerspective * oneMinus(transmittanceCld);
					float atmosFade = fastExp(-length(rayPos) * (0.1 + 0.1 * wetness) * 1e-4);
				#else
					float atmosFade = fastExp(-length(rayPos) * (0.2 + 0.1 * wetness) * 1e-4);
				#endif
				scattering = scattering * atmosFade + skyRadiance * oneMinus(transmittanceCld) * oneMinus(atmosFade);

				cloudsData = vec4(scattering, transmittanceCld);
			}
		}
	#endif

	#ifdef PLANAR_CLOUDS
		if ((worldDir.y > 0.0 && eyeAltitude < CLOUD_PLANE_ALTITUDE)
		|| (intersectsGround && eyeAltitude > CLOUD_PLANE_ALTITUDE)) {
			vec2 intersection = RaySphereIntersection(planeOrigin, worldDir, planetRadius + CLOUD_PLANE_ALTITUDE);
			float cloudDistance = eyeAltitude > CLOUD_PLANE_ALTITUDE ? intersection.x : intersection.y;
			if (cloudDistance > 0.0 && cloudDistance < planetRadius + CLOUD_PLANE_ALTITUDE) {
				vec3 cloudPos = worldDir * cloudDistance;

				#ifdef FULL_AERIAL_PERSPECTIVE
					vec3 airTransmittance;
					vec3 aerialPerspective = 20.0 * GetSkyRadianceToPoint(atmosphereModel, cloudPos, worldSunVector, airTransmittance);
				#endif
				cloudPos += cameraPosition;

				vec4 cloudsTemp = vec4(0.0, 0.0, 0.0, 1.0);
				#ifdef CIRROCUMULUS_CLOUDS
					#ifdef CLOUDS_WEATHER
						if (cloudDynamicWeather.x < 0.4)
					#endif
					{
						vec4 sampleTemp = PlanarSample1(cloudDistance, cloudPos.xz, LdotV, dither, phases, worldDir);
						if (sampleTemp.a > minTransmittance) {
							#ifdef FULL_AERIAL_PERSPECTIVE
								float atmosFade = fastExp(-cloudDistance * fma(0.025, wetness, 0.05) * 0.00015);
								sampleTemp.rgb *= airTransmittance;
								sampleTemp.rgb += aerialPerspective * sampleTemp.a;
							#else
								float atmosFade = fastExp(-cloudDistance * fma(0.05, wetness, 0.1) * 0.00015);
							#endif
							sampleTemp.rgb = sampleTemp.rgb * atmosFade + skyRadiance * sampleTemp.a * oneMinus(atmosFade);
						}

						cloudsTemp.rgb = sampleTemp.rgb;
						cloudsTemp.a -= sampleTemp.a;
					}
				#endif
				#if CIRRUS_CLOUDS > 0
					#ifdef CLOUDS_WEATHER
						if (cloudDynamicWeather.y < 0.5)
					#endif
					{
						vec4 sampleTemp = PlanarSample0(cloudDistance, cloudPos.xz, LdotV);
						if (sampleTemp.a > minTransmittance) {
							#ifdef FULL_AERIAL_PERSPECTIVE
								float atmosFade = fastExp(-cloudDistance * fma(0.025, wetness, 0.05) * 0.00015);
								sampleTemp.rgb *= airTransmittance;
								sampleTemp.rgb += aerialPerspective * sampleTemp.a;
							#else
								float atmosFade = fastExp(-cloudDistance * fma(0.05, wetness, 0.1) * 0.00015);
							#endif
							sampleTemp.rgb = sampleTemp.rgb * atmosFade + skyRadiance * sampleTemp.a * oneMinus(atmosFade);
						}

						cloudsTemp.rgb += sampleTemp.rgb * cloudsTemp.a;
						cloudsTemp.a *= 1.0 - sampleTemp.a;
					}
				#endif

				if (eyeAltitude < CLOUD_PLANE_ALTITUDE) {
					cloudsData.rgb += cloudsTemp.rgb * cloudsData.a;
				} else {
					cloudsData.rgb = cloudsData.rgb * cloudsTemp.a + cloudsTemp.rgb;
				}

				cloudsData.a *= cloudsTemp.a;
			}
		}
	#endif

	vec4 outData;
	outData.rgb = cloudsData.rgb;

	#ifdef AURORA
		if (auroraAmount > 1e-2) outData.rgb += NightAurora(worldDir) * cloudsData.a;
	#endif

	// ── СОЛНЦЕ/ЛУНА: ЧЁТКИЙ ОВЕРЛЕЙ В ПОЛНОМ РАЗРЕШЕНИИ ──────
	// Солнце и луна считаются заново, аналитически, по настоящему worldDir
	// текущего пикселя экрана — как в отражениях — и подставляются поверх
	// запечённого фона внутри своего диска (discMask), плюс добавляется блик.
	float cloudAlpha = remap(minTransmittance, 1.0, cloudsData.a);

	vec3 sunDisc  = RenderSun(worldDir, worldSunVector);
	vec3 moonDisc = RenderMoonReflection(worldDir, worldSunVector);
	float discMask = max(sign(dot(sunDisc, sunDisc)), sign(dot(moonDisc, moonDisc))); // 1.0 внутри диска солнца/луны
	outData.rgb = mix(outData.rgb, sunDisc + moonDisc, discMask * cloudAlpha);

	vec3 glare = RenderSunReflection(worldDir, worldSunVector);
	outData.rgb += glare * cloudAlpha;

	// ── 4 PLANETS ───────────────────────────────────────────
	outData.rgb += RenderPlanet1(worldDir, worldSunVector)    * cloudAlpha;
	outData.rgb += RenderPlanet2Sky(worldDir, worldSunVector)  * cloudAlpha;
	outData.rgb += RenderPlanet3(worldDir, worldSunVector)    * cloudAlpha;
	outData.rgb += RenderPlanet4(worldDir, worldSunVector)    * cloudAlpha;


	#if SKYBOX_STYLE > 1
		outData.rgb += RenderCustomSkybox(worldDir) * cloudAlpha;
	#endif

	#if CLOUDMAP_ENABLED == 1
    #if !defined VOLUMETRIC_CLOUDS && !defined PLANAR_CLOUDS || CLOUDMAP_INDEPENDENT == 1
        vec4 cloudMapData = RenderCloudMap(worldDir);
        outData.rgb = outData.rgb * cloudMapData.a + cloudMapData.rgb;
        outData.a *= cloudMapData.a;
    #endif
	#endif

	// ── BLACK HOLE ──────────────────────────────────────────
	outData.rgb += RenderBlackHole(worldDir, cameraPosition) * cloudAlpha;
	outData.rgb += RenderProtoDisk(worldDir, cameraPosition) * cloudAlpha;
	
	outData.a = cloudAlpha;

	return clamp16F(outData);
}

//----// MAIN //----------------------------------------------------------------------------------//
void main() {
	ivec2 texel = ivec2(gl_FragCoord.xy);
	ivec2 cloudTexel = texel * TEMPORAL_UPSCALING + checkerboardOffset[frameCounter % cloudsRenderFactor];
	vec2 coord = cloudTexel * screenPixelSize;

	// Current clouds
	#if defined DISTANT_HORIZONS
		if (min(GetDepth(RawCoord(coord)), depthMax4x4DH(coord)) >= 1.0) {
	#else
		if (depthMax4x4(coord) >= 1.0) {
	#endif
		vec3 viewPos  = ScreenToViewSpaceRaw(vec3(coord, 1.0));
		vec3 worldDir = mat3(gbufferModelViewInverse) * normalize(viewPos);

		float dither = R1(frameCounter / cloudsRenderFactor, texelFetch(noisetex, cloudTexel & 255, 0).a);
		cloudData = RenderSkybox(worldDir, dither, GetGlobalCloudProperties());
	}
}