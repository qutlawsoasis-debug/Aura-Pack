#version 450 compatibility

#define IS_NETHER

// fogData (colortex1) = vec4(rgb, transmittance) — такой же формат как в оверворлде
layout(location = 0) out vec4 fogData;
layout(location = 1) out vec3 sceneData;

in vec2 screenCoord;

flat in vec3 directIlluminance;
flat in vec3 skyIlluminance;
flat in vec3 ambientColor;
flat in vec3 blocklightColor;

#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"
#include "/lib/Atmosphere/Atmosphere.glsl"

//----// STRUCTS //-------------------------------------------------------------------------------//

#include "/lib/Head/Mask.inc"

//----// FUNCTIONS //-----------------------------------------------------------------------------//

#include "/lib/Head/Functions.inc"

// Fogs.glsl подключает NetherVolumetricFog.glsl внутри через #ifdef IS_NETHER
#include "/lib/Atmosphere/Fogs.glsl"

#include "/lib/Water/WaterFog.glsl"

//----// MAIN //----------------------------------------------------------------------------------//
void main() {
	ivec2 texel = ivec2(gl_FragCoord.xy);
	vec2 sc     = gl_FragCoord.xy * screenPixelSize;

	int materialIDT = int(texelFetch(colortex7, texel, 0).z * 255.0);
	TranslucentMask materialMaskT = CalculateMasksT(materialIDT);

	sceneData = texelFetch(colortex4, texel, 0).rgb;

	// Водяной туман (лёд/вода под водой) — как в оверворлде
	if ((materialMaskT.water || materialMaskT.ice) && isEyeInWater == 0) {
		float depthSoild    = GetDepthSoild(texel);
		vec3  viewPos       = ScreenToViewSpace(vec3(sc, GetDepth(texel)));
		vec3  viewPosSoild  = ScreenToViewSpace(vec3(sc, depthSoild));
		WaterFog(sceneData, materialMaskT, 0.0, 0.0, distance(viewPos, viewPosSoild));
	}

	// Объёмный туман считаем только в левой половине (полуразрешение, как в оверворлде)
	if (any(greaterThanEqual(sc, vec2(0.5)))) return;

	// Переходим на полуразрешение
	ivec2 texel2  = texel * 2;
	vec2  sc2     = sc    * 2.0;

	float depth   = GetDepth(texel2);
	vec3  viewPos = ScreenToViewSpaceRaw(vec3(sc2, depth));

#if defined DISTANT_HORIZONS
	if (depth >= 1.0) viewPos = ScreenToViewSpaceRawDH(vec3(sc2, GetDepthDH(texel2)));
#endif

	// worldPos — от камеры в пространстве чанка (БЕЗ cameraPosition)
	// Функция использует cameraPosition сама, чтобы получить абсолютные координаты
	vec3 worldPos = mat3(gbufferModelViewInverse) * viewPos;
	vec3 worldDir = normalize(worldPos);

	fogData = vec4(0.0, 0.0, 0.0, 1.0);

	float dither = R1(frameCounter, texelFetch(noisetex, texel2 & 255, 0).a);

#ifdef NETHER_VOL_FOG_ENABLED
	fogData = CalculateNetherVolumetricFog(worldPos, worldDir, dither);
#endif


}

/* DRAWBUFFERS:14 */
