#version 450 compatibility

#ifndef RESTIR_ENABLED
    #define RESTIR_ENABLED 0 // [0 1]
#endif

#if RESTIR_ENABLED
    #include "/program/Deferred3.glsl"
#else
    #include "/program/SpatialFilter.frag"
#endif