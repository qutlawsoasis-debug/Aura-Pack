#version 450 compatibility

/* DRAWBUFFERS:6 */

out vec3 albedoData;

uniform sampler2D tex;

flat in vec3 tint;
in vec2 texcoord;
in float dist;

#include "/Settings.glsl"

/*
 * gbuffers_skytextured — рендерит солнце, луну и текстурированные элементы неба.
 *
 * Дистанс-фейд: объекты, которые дальше FAR (облака skybox / декорации),
 * плавно затухают чтобы не было резкой границы.
 */

// Настраиваемый дистанс-фейд для skytextured (например текстурированные облака ванили)
#ifndef SKY_TEXTURED_FADE_START
    #define SKY_TEXTURED_FADE_START 200.0
#endif
#ifndef SKY_TEXTURED_FADE_END
    #define SKY_TEXTURED_FADE_END   400.0
#endif

void main() {
    vec4 albedo = texture(tex, texcoord);

    if (albedo.a < 0.01) discard;

    vec3 color = albedo.rgb * tint;

    // Дистанс-фейд — плавное затухание дальних объектов
    // dist здесь это gl_Position.w, близко к реальной дистанции в clip space
    float fade = 1.0 - smoothstep(SKY_TEXTURED_FADE_START, SKY_TEXTURED_FADE_END, dist);

    // Применяем только для не-солнца/луны (у них альфа близко к 1 и tint белый)
    // Солнце/луна имеют tint.r > 0.9 и dist очень большой — фейдим тоже, но мягко
    color *= fade;

    if (fade < 0.01) discard;

    albedoData = color;
}
