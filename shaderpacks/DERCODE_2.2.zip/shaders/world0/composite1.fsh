#version 450 compatibility

/* SETTINGS_DELIMITER */
//----// FLASHLIGHT SETTINGS //-------------------------------------------------------------------//
#define FLASHLIGHT_TOGGLE 0 // [0 1 2 3]
#define FLASHLIGHT_SHADOW 1 // [0 1] Тень от фонарика (всегда активна, пока включён сам фонарик)
#define FLASHLIGHT_SHADOW_INTENSITY 0.85 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.85 0.9 1.0] 
#define FLASHLIGHT_STYLE 0 // [0 1 2 3 4] Style: Tactical LED, Warm Halogen, Wide Flood, Blue Modern, Searchlight
#define FLASHLIGHT_INTENSITY 3.5 // [0.0 0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 5.0 10.0]
#define FLASHLIGHT_RANGE 40.0 // [10.0 20.0 30.0 40.0 50.0 60.0 80.0 100.0]
#define FLASHLIGHT_DELAY 1 // [0 1]
#define FLASHLIGHT_DELAY_INTENSITY 1.2 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0 5.0]


#ifndef HELD_LIGHT_POS_R_X
	#define HELD_LIGHT_POS_R_X  0.32 // [-0.50 -0.45 -0.40 -0.35 -0.30 -0.25 -0.20 -0.15 -0.10 -0.5 0.0 0.1 0.5 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 1.0 5.0 10.0 15.0 20.0 25.0 30.0 0.32 35.0 40.0 45.0 50.0 55.0]
#endif
#ifndef HELD_LIGHT_POS_R_Y
	#define HELD_LIGHT_POS_R_Y -0.28 // [-0.50 -0.45 -0.40 -0.35 -0.30 -0.25 -0.20 -0.15 -0.10 -0.5 0.0 0.1 0.5 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 1.0 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0]
#endif

#include "/lib/Head/ParticleBloomSettings.inc"

uniform int worldTime;
uniform sampler2D colortex12;

#if PARTICLE_INDEPENDENT_SHADING == 1
	uniform sampler2D colortex31;
#endif

#define IS_OVERWORLD

#include "/lib/Head/Common.inc"

layout(location = 0) out vec3 sceneData;

#ifdef BLOOMY_FOG
	layout(location = 1) out float fogTransmittance;
	/* DRAWBUFFERS:46 */
#else
	/* DRAWBUFFERS:4 */
#endif

in vec2 screenCoord;

flat in vec3 directIlluminance;
flat in vec3 skyIlluminance;

#include "/lib/Head/Uniforms.inc"

uniform int worldDay;

// Moon textures (albedo + normal, for MOON_STYLE 1/2)
uniform sampler2D colortex16;
uniform sampler2D colortex37;

#include "/lib/Atmosphere/Atmosphere.glsl"

//----// STRUCTS //-------------------------------------------------------------------------------//

#include "/lib/Head/Mask.inc"
#include "/lib/Head/Material.inc"

//----// FUNCTIONS //-----------------------------------------------------------------------------//

#include "/lib/Head/Functions.inc"
#include "/lib/Lighting/HeldLightShadow.glsl"
#include "/lib/Surface/Refraction.glsl"
#include "/lib/Surface/ReflectionFilter.glsl"

#ifndef RAYTRACED_REFRACTION
	#include "/lib/Surface/ScreenSpaceReflections.glsl"
#endif

#include "/lib/Atmosphere/Fogs.glsl"
#include "/lib/Water/WaterFog.glsl"

#if defined VOXY && defined DISTANT_HORIZONS
vec4 VoxyWaterReflectionDH(in vec3 normal, in float skylight, in vec3 viewPos, in float depth) {
	const uint voxyRaytraceSamples = 16u;
	skylight = smoothstep(0.3, 0.8, skylight);
	vec3 viewDir = normalize(viewPos);

	vec3 rayDir = reflect(viewDir, normal);

	float NdotL = dot(normal, rayDir);
	if (NdotL < 1e-6) return vec4(0.0);

	float dither = InterleavedGradientNoiseTemporal(gl_FragCoord.xy);
	vec3 screenPos = vec3(gl_FragCoord.xy * screenPixelSize, depth);

	float NdotV = max(1e-6, dot(normal, -viewDir));
	#ifdef RAYTRACED_REFRACTION
		bool hit = false;
	#else
		bool hit = ScreenSpaceRayTraceDH(viewPos, rayDir, dither, voxyRaytraceSamples, screenPos);
	#endif

	vec3 reflection = vec3(0.0);
	if (hit) {
		reflection = texelFetch(colortex4, ivec2(screenPos.xy), 0).rgb;
	} else if (skylight > 1e-3) {
		if (isEyeInWater == 0) {
			vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
			float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
			vec4 skyboxData = textureBicubic(colortex5, ProjectSky(rayDirWorld) + vec2(0.0, skyCaptureRes.y * screenPixelSize.y));
			reflection = skyboxData.rgb * skylight * NdotU;
		} else {
			reflection = vec3(0.05, 0.7, 1.0) * 0.25 * (timeNoon + timeMidnight * NIGHT_BRIGHTNESS);
		}
	}

	float specular;
	if (isEyeInWater == 1) {
		specular = FresnelDielectricN(NdotV, 1.0 / WATER_REFRACT_IOR);
	} else {
		specular = FresnelDielectricN(NdotV, WATER_REFRACT_IOR);
	}

	return clamp16F(vec4(reflection * specular, 1.0 - specular));
}
#endif

//----// MAIN //----------------------------------------------------------------------------------//
void main() {
	ivec2 texel 		= ivec2(gl_FragCoord.xy);

	vec4 gbuffer3 		= texelFetch(colortex3, texel, 0);
	vec4 albedoT 		= vec4(UnpackUnorm2x8(gbuffer3.z), UnpackUnorm2x8(gbuffer3.w));

	vec3 normal 		= DecodeNormal(gbuffer3.xy);

	int materialIDT 	= int(texelFetch(colortex7, texel, 0).z * 255.0);
	TranslucentMask materialMaskT = CalculateMasksT(materialIDT);

	float depthSoild 	= GetDepthSoild(texel);
	float depth 		= GetDepthFix(texel);

	vec3 viewPos 		= ScreenToViewSpace(vec3(screenCoord, depth));

	#if defined DISTANT_HORIZONS
		bool dhRange = depth >= 1.0;
		if (dhRange) {
			depth = GetDepthDH(texel);
			depthSoild = GetDepthSoildDH(texel);
			viewPos = ScreenToViewSpaceDH(vec3(screenCoord, depth));
		}
	#endif

	vec3 viewDir 		= normalize(viewPos);
	vec3 worldPos 		= mat3(gbufferModelViewInverse) * viewPos;
	vec3 worldDir 		= normalize(worldPos);
	worldPos 			+= gbufferModelViewInverse[3].xyz;

	#if defined VOXY && defined DISTANT_HORIZONS
		if (dhRange && materialMaskT.water) {
			vec3 minecraftPos = worldPos + cameraPosition;
			vec3 waveNormal = GetWavesNormal(minecraftPos.xz - minecraftPos.y);
			mat3 tbnMatrix = mat3(
				normalize(gbufferModelView[0].xyz),
				normalize(gbufferModelView[2].xyz),
				normalize(mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0))
			);
			normal = normalize(tbnMatrix * waveNormal);
		}
	#endif

	if (depth < 1.0) {
		#ifdef RAYTRACED_REFRACTION
			#ifdef REFRACTIVE_DISPERSION
				vec2 refractCoord   = CalculateRefractCoord(materialMaskT, normal, viewDir, viewPos, depth, 1.5);
				vec3 refractedBackground = GetRefractedBackground(colortex0, refractCoord, mask);
				vec2 refractCoordR  = CalculateRefractCoord(materialMaskT, normal, viewDir, viewPos, depth, 1.45);
				vec2 refractCoordB  = CalculateRefractCoord(materialMaskT, normal, viewDir, viewPos, depth, 1.55);
				ivec2 refractTexel 	= ivec2(refractCoord * screenSize);
				ivec2 refractTexelR = ivec2(refractCoordR * screenSize);
				ivec2 refractTexelB = ivec2(refractCoordB * screenSize);

				sceneData.g 		= texelFetch(colortex4, refractTexel, 0).g;
				sceneData.r 		= texelFetch(colortex4, refractTexelR, 0).r;
				sceneData.b 		= texelFetch(colortex4, refractTexelB, 0).b;
			#else
				vec2 refractCoord   = CalculateRefractCoord(materialMaskT, normal, viewDir, viewPos, depth, 1.5);
				ivec2 refractTexel 	= ivec2(refractCoord * screenSize);

				sceneData 			= texelFetch(colortex4, refractTexel, 0).rgb;
			#endif
		#else
			
			#ifdef REFRACTIVE_DISPERSION


				#if defined DISTANT_HORIZONS
					vec2 refractCoord;
					if (dhRange) refractCoord = CalculateRefractCoordDH(materialMaskT, normal, worldPos, viewPos, depthSoild, depth);
					else         refractCoord = CalculateRefractCoord   (materialMaskT, normal, worldPos, viewPos, depthSoild, depth);
				#else
					vec2 refractCoord = CalculateRefractCoord(materialMaskT, normal, worldPos, viewPos, depthSoild, depth);
				#endif

		
				vec2 dispersionOffset = normal.xy * screenPixelSize * 3.5;
			
				if (!materialMaskT.water) dispersionOffset *= 0.45;

				vec2 refractCoordR = saturate(refractCoord + dispersionOffset * 1.10);
				vec2 refractCoordB = saturate(refractCoord - dispersionOffset * 0.90);

				ivec2 refractTexel  = ivec2(refractCoord  * screenSize);
				ivec2 refractTexelR = ivec2(refractCoordR * screenSize);
				ivec2 refractTexelB = ivec2(refractCoordB * screenSize);

				sceneData.g = texelFetch(colortex4, refractTexel,  0).g;
				sceneData.r = texelFetch(colortex4, refractTexelR, 0).r;
				sceneData.b = texelFetch(colortex4, refractTexelB, 0).b;

			#else
			
				#if defined DISTANT_HORIZONS
					vec2 refractCoord;
					if (dhRange) refractCoord = CalculateRefractCoordDH(materialMaskT, normal, worldPos, viewPos, depthSoild, depth);
					else         refractCoord = CalculateRefractCoord   (materialMaskT, normal, worldPos, viewPos, depthSoild, depth);
				#else
					vec2 refractCoord = CalculateRefractCoord(materialMaskT, normal, worldPos, viewPos, depthSoild, depth);
				#endif

				ivec2 refractTexel = ivec2(refractCoord * screenSize);
				sceneData          = texelFetch(colortex4, refractTexel, 0).rgb;
			#endif
		#endif

		vec3 albedoRaw 		= texelFetch(colortex6, refractTexel, 0).rgb;
		vec3 albedo 		= SRGBtoLinear(albedoRaw);

		Material material 	= GetMaterialData(texelFetch(colortex0, refractTexel, 0).xy);

//----// FLASHLIGHT EFFECT //---------------------------------------------------------------------//
#if FLASHLIGHT_TOGGLE > 0
    bool isNight = (worldTime > 13000 && worldTime < 23000);
    bool shouldBeOn = true;

    #if FLASHLIGHT_TOGGLE == 2
        if (!isNight) shouldBeOn = false;
    #elif FLASHLIGHT_TOGGLE == 3

        if (max(heldBlockLightValue, heldBlockLightValue2) <= 0) shouldBeOn = false;
    #endif


if (shouldBeOn) {
    float f_dist = length(viewPos);
    
    if (f_dist < FLASHLIGHT_RANGE) {
        vec3 flashlightDir = vec3(0.0, 0.0, -1.0);

        #if FLASHLIGHT_DELAY == 1
            vec2 mouseVelocity = (gbufferPreviousModelView[0].xy - gbufferModelView[0].xy) + (gbufferPreviousModelView[1].xy - gbufferModelView[1].xy);
            flashlightDir.xy += mouseVelocity * FLASHLIGHT_DELAY_INTENSITY;
            flashlightDir = normalize(flashlightDir);
        #endif

        float f_dot = dot(viewDir, flashlightDir);
        float f_hotspot = 0.0;
        float f_spill = 0.0;
        vec3 f_color = vec3(1.0);
        float f_falloffMult = 0.15;

        #if FLASHLIGHT_STYLE == 0 // TACTICAL LED
            f_hotspot = smoothstep(0.975, 0.985, f_dot); 
            f_spill = smoothstep(0.94, 0.975, f_dot) * 0.2; 
            f_color = mix(vec3(0.9, 0.95, 1.0), vec3(1.0), f_hotspot);
            f_falloffMult = 0.12;
        #elif FLASHLIGHT_STYLE == 1 // WARM HALOGEN
            f_hotspot = smoothstep(0.95, 0.98, f_dot);
            f_spill = smoothstep(0.88, 0.95, f_dot) * 0.3;
            f_color = vec3(1.0, 0.85, 0.6);
            f_falloffMult = 0.22;
        #elif FLASHLIGHT_STYLE == 2 // WIDE FLOOD
            f_hotspot = smoothstep(0.85, 0.95, f_dot);
            f_spill = smoothstep(0.65, 0.85, f_dot) * 0.4;
            f_color = vec3(1.0, 0.98, 0.95);
            f_falloffMult = 0.35;
        #elif FLASHLIGHT_STYLE == 3 // BLUE MODERN
            f_hotspot = smoothstep(0.98, 0.988, f_dot);
            f_spill = smoothstep(0.95, 0.98, f_dot) * 0.15;
            f_color = vec3(0.7, 0.85, 1.0);
            f_falloffMult = 0.1;
        #elif FLASHLIGHT_STYLE == 4 // SEARCHLIGHT
            f_hotspot = smoothstep(0.992, 0.997, f_dot);
            f_spill = smoothstep(0.985, 0.992, f_dot) * 0.1;
            f_color = vec3(1.0, 1.0, 1.0);
            f_falloffMult = 0.05;
        #endif

        float f_finalMask = clamp(f_hotspot + f_spill, 0.0, 1.0);

        if (f_finalMask > 0.0) {
            float f_atten = exp(-f_dist * f_falloffMult);
            f_atten *= smoothstep(FLASHLIGHT_RANGE, FLASHLIGHT_RANGE * 0.5, f_dist); 
            
            float f_ndotl = max(0.0, dot(normal, -viewDir));
            float f_strength = f_finalMask * f_atten * f_ndotl;

            #if FLASHLIGHT_SHADOW == 1
                if (f_strength > 1e-4) {

                    vec3 flashlightShadowPos = vec3(HELD_LIGHT_POS_R_X, HELD_LIGHT_POS_R_Y, 0.0);
                    vec3 toSurfaceFL = viewPos - flashlightShadowPos;
                    vec3 shadowDirFL = toSurfaceFL / max(length(toSurfaceFL), 1e-4);

                    f_strength *= HeldLightScreenSpaceShadow(viewPos, viewDir, normal, -shadowDirFL, InterleavedGradientNoiseTemporal(gl_FragCoord.xy), FLASHLIGHT_SHADOW_INTENSITY);
                }
            #endif

            sceneData += albedo * f_color * f_strength * (FLASHLIGHT_INTENSITY);
        }
    }
}
#endif
//------------------------------------------------------------------------------------------------//

		if (materialMaskT.stainedGlass) TransparentAbsorption(sceneData, albedoT);
		if (materialMaskT.ice) sceneData *= sqr(albedoT.rgb);

		if (materialMaskT.translucent) {
			vec4 reflectionData = texelFetch(colortex2, texel, 0);

			#if defined VOXY && defined DISTANT_HORIZONS
				if (dhRange && materialMaskT.water) {
					reflectionData = VoxyWaterReflectionDH(normal, cube(texelFetch(colortex7, texel, 0).y), viewPos, depth);
				}
			#endif

			sceneData = sceneData * reflectionData.a + reflectionData.rgb;
		} else if (material.hasReflections) {
			vec4 reflectionData = texelFetch(colortex2, texel, 0);
			#ifdef REFLECTION_FILTER
				if (material.isRough) reflectionData.rgb = ReflectionFilter(texel, reflectionData, material.roughness, normal, viewDir, 1.0, RandNext2F() - 0.5).rgb;
			#endif
			sceneData += reflectionData.rgb * mix(vec3(1.0), albedo, material.isMetal);
		}
	} else {
		sceneData = texelFetch(colortex4, texel, 0).rgb;
	}

	float fogDist = length(viewPos);

	if (isEyeInWater == 1) UnderwaterFog(sceneData, materialMaskT, fogDist);
	if (isEyeInWater == 0 && depth < 1.0) {
		#if defined DISTANT_HORIZONS
			#define far float(dhRenderDistance)
		#endif

		#ifdef LAND_ATMOSPHERIC_SCATTERING
			const float airNumberDensity       = 2.5035422e25; 
			const float ozoneConcentrationPeak = 4e-6; 
			const float ozoneNumberDensity     = airNumberDensity * exp(-35e3 / 8e3) * (134.628 / 48.0) * ozoneConcentrationPeak; 
			const vec3  ozoneCrossSection      = vec3(4.51103766177301E-21, 3.2854797958699E-21, 1.96774621921165E-22) * 0.0001; 

			const vec3  rayleighColor = vec3(6.433377384678407e+24, 1.0873673940138444e+25, 2.4861429602679963e+25);
			const float rayleighK     = 9.993284137187039e-31; 

			const vec3 atmosphere_coefficientRayleigh = rayleighK * rayleighColor;
			const vec3 atmosphere_coefficientOzone    = ozoneCrossSection * ozoneNumberDensity;
			const vec3 atmosphere_coefficientMie      = vec3(4e-6); 

			const vec3 baseAttenuationCoefficient = atmosphere_coefficientRayleigh + atmosphere_coefficientMie + atmosphere_coefficientOzone;
			const mat2x3 atmosphere_coefficientsScattering = mat2x3(atmosphere_coefficientRayleigh, atmosphere_coefficientMie * 0.9);

			float dist = fogDist * eyeSkylightFix * 20.0;
			vec3 opticalDepth = baseAttenuationCoefficient * dist;
			vec3 transmittance   = exp(-opticalDepth);
			vec3 visibleFraction = min(oneMinus(transmittance) / opticalDepth, 1.0);

			float LdotV = dot(worldLightVector, worldDir);

			vec3 scattering = atmosphere_coefficientsScattering * vec2(RayleighPhase(LdotV), HenyeyGreensteinPhase(LdotV, mie_phase_g)) * directIlluminance;
			scattering += atmosphere_coefficientsScattering * vec2(0.25 * rPI) * skyIlluminance;
			scattering *= dist * visibleFraction;

			sceneData = sceneData * transmittance + scattering * 20.0 * oneMinus(wetness * 0.6);
		#elif !defined BORDER_FOG
			float density = eyeSkylightFix * 0.4 * (1.0 + wetness);
			float transmittance = fastExp(-fogDist / far * density);

			sceneData *= transmittance;
			sceneData += skyIlluminance * oneMinus(wetness * 0.8) * oneMinus(transmittance);
		#endif

		#ifdef BORDER_FOG
			float density = 1.0 - exp2(-sqr(pow4(length(worldPos.xz) * eyeSkylightFix / far)) * 8.0);
			density *= oneMinus(saturate(worldDir.y * 3.0));
			vec3 skyRadiance = textureBicubic(colortex5, ProjectSky(worldDir)).rgb;
			sceneData = mix(sceneData, skyRadiance, density);
		#endif
	}

	#if defined VOLUMETRIC_FOG || defined VOLUMETRIC_LIGHT || defined UW_VOLUMETRIC_LIGHT
		#if defined DISTANT_HORIZONS
			vec4 VFData;
			if (dhRange) VFData = SpatialUpscaleDH(colortex1, gl_FragCoord.xy, GetDepthLinearDH(depth));
			else VFData = SpatialUpscale(colortex1, gl_FragCoord.xy, GetDepthLinear(depth));
		#else
			vec4 VFData = SpatialUpscale(colortex1, gl_FragCoord.xy, GetDepthLinear(depth));
		#endif

		sceneData *= VFData.a;
		sceneData += VFData.rgb;

		#ifdef BLOOMY_FOG
			fogTransmittance = VFData.a;
			#if FOG_TYPE == 3
				fogTransmittance = fogTransmittance * 0.3 + 0.7;
			#endif
		#endif
	#elif defined BLOOMY_FOG
		fogTransmittance = 1.0;
	#endif

	CommonFog(sceneData, fogDist);

	#ifdef BLOOMY_FOG
		float fogDensity = wetness * eyeSkylightFix * 2e-3;
		if (isEyeInWater == 1) fogDensity = 0.06 * WATER_FOG_DENSITY;
		if (isEyeInWater > 1) fogDensity = 1.0;
		fogTransmittance = min(fastExp(-fogDensity * fogDist), fogTransmittance);
	#endif

	// ============================================================
	// ПАРТИКЛЫ — НЕЗАВИСИМЫЙ FORWARD-ШЕЙДИНГ (как Entities-buffer в Bliss)
	// ============================================================
	// Полностью игнорирует всё, что deferred5.fsh насчитал на этом пикселе
	// (тени/PBR/GI/SSR), и считает партикл простым forward-освещением:
	// albedo * (blocklight + skylight). Не зависит от теневой карты вообще.
	#if PARTICLE_INDEPENDENT_SHADING == 1
	{
		vec4 particleData = texelFetch(colortex31, texel, 0);

		// depthtex2 не учитывает руку (и translucent), depthtex0 учитывает всё.
		// Если рука рисуется поверх этого пикселя, depthtex0 будет БЛИЖЕ
		// (меньше), чем depthtex2 — значит партикл здесь перекрыт рукой и
		// не должен просвечивать сквозь неё.
		bool occludedByHand = texelFetch(depthtex0, texel, 0).x < texelFetch(depthtex2, texel, 0).x - 1e-6;

		if (particleData.a > 0.5 && !occludedByHand) {
			vec2 mcLightmapP = texelFetch(colortex7, texel, 0).rg;
			mcLightmapP.g = isEyeInWater == 1 ? 0.75 : cube(mcLightmapP.g);

			float blocklightP = mcLightmapP.r;
			GetBlocklightFalloff(blocklightP);

			// Простой нейтрально-тёплый блоклайт (без зависимости от внешних
			// torchlight-переменных, которых нет в этом проходе) + skylight
			// + прямой солнечный свет (по lightmap.g, без направления — у
			// партиклов обычно нет полезной нормали) + база.
			vec3 particleLight  = blocklightP * vec3(1.0, 0.75, 0.5) * 3.0;
			     particleLight += skyIlluminance * mcLightmapP.g * SKYLIGHT_INTENSITY;
			     particleLight += directIlluminance * mcLightmapP.g * SUNLIGHT_INTENSITY * PARTICLE_SUNLIGHT_STRENGTH;
			     particleLight += BASIC_BRIGHTNESS + nightVision * 0.1;

			vec3 particleResult = particleData.rgb * particleLight;

			// Режим 2: яркость + блум для ВСЕХ партиклов (буст виден на экране)
			#if PARTICLE_BLOOM_MODE == 2
				float particleLuma = GetLuminance(particleData.rgb);
				float bloomMask = smoothstep(PARTICLE_BLOOM_THRESHOLD, PARTICLE_BLOOM_THRESHOLD + 0.1, particleLuma);
				particleResult += particleData.rgb * bloomMask * PARTICLE_BLOOM_INTENSITY;
			#endif

			// Режим 4: яркость + блум, но ТОЛЬКО для белых партиклов
			#if PARTICLE_BLOOM_MODE == 4
				// "Белизна" = минимальный канал ярче порога (все три канала
				// высокие) И каналы близки друг к другу (нет окраски).
				float whiteness   = minOf(particleData.rgb);
				float colorSpread = maxOf(particleData.rgb) - whiteness;
				float whiteMask = smoothstep(PARTICLE_BLOOM_THRESHOLD, PARTICLE_BLOOM_THRESHOLD + 0.1, whiteness)
				                 * oneMinus(smoothstep(PARTICLE_BLOOM_WHITE_TOLERANCE * 0.5, PARTICLE_BLOOM_WHITE_TOLERANCE, colorSpread));
				particleResult += particleData.rgb * whiteMask * PARTICLE_BLOOM_INTENSITY;
			#endif

			// Режим 3 (только блум, без буста видимой яркости) здесь НЕ
			// обрабатывается — он считается отдельно прямо в DownSample0.glsl
			// напрямую из colortex31, не трогая sceneData партикла.

			sceneData = particleResult;
		}
	}
	#endif

	#if DEBUG_NORMAL == 0
		sceneData = clamp16F(sceneData);
	#elif DEBUG_NORMAL == 1
		sceneData = normal;
	#else
		sceneData = mat3(gbufferModelViewInverse) * normal;
	#endif
}