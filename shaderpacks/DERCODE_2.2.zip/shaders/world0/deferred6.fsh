#version 450 compatibility

#define IS_OVERWORLD

//================================================================================================//
// REFLECTIONS CONFIG
//================================================================================================//
// REFLECTION_TYPE:
//   0 = SSR               — обычный screen-space трейс
//   1 = WORLD REFLECTIONS — полный мировой multi-bounce трейс
//   2 = HYBRID SSR + RSM  — сперва SSR, при промахе — world RSM-трассировка (AO-style) поверх
#define REFLECTION_TYPE 0

// REFLECTION_SHOW_SKY: 0 = небо не отражается, 1 = небо видно в отражениях
#define REFLECTION_SHOW_SKY 1

// REFLECTION_DEPTH_SOURCE:
//   0 = depthtex1 (без полупрозрачных объектов/руки поверх)
//   1 = depthtex0 (с учётом всего что рисуется после непрозрачной геометрии)
#define REFLECTION_DEPTH_SOURCE 0

// /*
// const bool colortex4MipmapEnabled = true;
// */

layout(location = 0) out vec4 reflectionData;
//layout(location = 1) out vec3 sceneData;


#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"

uniform int worldDay;

// Moon textures (albedo + normal, for MOON_STYLE 1/2)
uniform sampler2D colortex16;
uniform sampler2D colortex37;

#include "/lib/Atmosphere/Atmosphere.glsl"

uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;

//----// STRUCTS //-------------------------------------------------------------------------------//

#include "/lib/Head/Material.inc"

//----// FUNCTIONS //-----------------------------------------------------------------------------//

#include "/lib/Head/Functions.inc"

#include "/lib/Lighting/GlobalIllumination.glsl"
#define WORLD_REFLECTION_RSM_AVAILABLE
#include "/lib/Surface/ScreenSpaceReflections.glsl"

vec4 CalculateSpecularReflections(/*inout vec3 color, */in vec3 normal, in vec3 screenPos, Material material, in float skylight, in vec3 viewPos) {
	skylight = smoothstep(0.3, 0.8, skylight);
	vec3 viewDir = normalize(viewPos);

	vec3 rayDir;
	#ifdef ROUGH_REFLECTIONS
		if (material.isRough) {
			mat3 tangentToWorld;
			tangentToWorld[0] = normalize(cross(gbufferModelView[1].xyz, normal));
			tangentToWorld[1] = cross(normal, tangentToWorld[0]);
			tangentToWorld[2] = normal;

			vec3 tangentView = -viewDir * tangentToWorld;
			vec3 facetNormal = tangentToWorld * sampleGGXVNDF(tangentView, material.roughness, RandNext2F());
			rayDir = reflect(viewDir, facetNormal);
		} else
	#endif
	{ rayDir = reflect(viewDir, normal); }

	float NdotL = dot(normal, rayDir);
	if (NdotL < 1e-6) return vec4(0.0);

	//float dither = BlueNoiseTemporal(0.447213595);
	float dither = InterleavedGradientNoiseTemporal(gl_FragCoord.xy);
	//vec3 screenPos = vec3(screenCoord, depth);

	float NdotV = max(1e-6, dot(normal, -viewDir));

	#if REFLECTION_TYPE == 1
		// WORLD REFLECTIONS — полный мировой multi-bounce трейс
		vec3 worldReflection = CalculatePathTracedReflections(
			viewPos, normal, material, skylight,
			#ifdef PATH_REFLECTION_BOUNCES
				uint(PATH_REFLECTION_BOUNCES),
			#else
				1u,
			#endif
			dither
		);
		bool hit = ScreenSpaceRayTrace(viewPos, rayDir, dither, uint(RAYTRACE_SAMPLES * oneMinus(material.roughness)), screenPos);
	#else
		// SSR — обычный screen-space трейс (используется как есть и для REFLECTION_TYPE == 2)
		bool hit = ScreenSpaceRayTrace(viewPos, rayDir, dither, uint(RAYTRACE_SAMPLES * oneMinus(material.roughness)), screenPos);
	#endif

	#if REFLECTION_TYPE == 2
		// HYBRID: если SSR промахнулся — трассируем RSM (Reflective Shadow Map) в мировой
		// точке вдоль луча. Рисуется "поверх" — то есть это фоллбэк только на miss,
		// SSR-хиты остаются приоритетными и не трогаются этим блоком.
		vec3 hybridRSMReflection = vec3(0.0);
		if (!hit) {
			hybridRSMReflection = CalculateHybridReflectionRSM(viewPos, rayDir, dither);
		}
	#endif

	vec3 reflection = vec3(0.0);

	#if REFLECTION_TYPE == 1
		// WORLD REFLECTIONS уже содержит multi-bounce цвет (включая попадание в скайбокс
		// внутри самого трейса, если он промахнулся по экрану на каждом bounce).
		reflection = worldReflection;
	#endif

    #ifdef REAL_SKY_REFLECTION
		// if (hit) reflection = textureLod(colortex4, screenPos.xy * screenPixelSize, int(8.0 * sqrt(material.roughness))).rgb;
		#if REFLECTION_TYPE != 1
			if (hit) reflection = texelFetch(colortex4, ivec2(screenPos.xy), 0).rgb;
		#endif
		#if REFLECTION_TYPE == 2
			// Промах SSR — подкладываем RSM-трассировку как базу ПЕРЕД небом/солнцем,
			// чтобы skybox (ниже) лёг поверх неё там, где skylight > 0.
			if (!hit) reflection = hybridRSMReflection;
		#endif
		#if REFLECTION_SHOW_SKY == 1
			if (skylight > 1e-3) {
				vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
				float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
				//float tileSize = floor(min(viewWidth * rcp(3.0), viewHeight * 0.5)) * 0.25;
				vec4 skyboxData = textureBicubic(colortex5, ProjectSky(rayDirWorld) + vec2(0.0, skyCaptureRes.y * screenPixelSize.y));

				vec3 sunmoon = RenderMoonReflection(rayDirWorld, worldSunVector);
				if (material.isRough) {
					sunmoon += RenderSunReflection(rayDirWorld, worldSunVector);
				} else {
					sunmoon += RenderSun(rayDirWorld, worldSunVector);
				}

				if (!hit) {
					#if REFLECTION_TYPE == 2
						// Небо рисуется поверх RSM, смешиваясь по skylight (в помещении
						// skylight ~ 0, поэтому там останется чистый RSM block-light результат).
						reflection = mix(hybridRSMReflection, skyboxData.rgb * NdotU, skylight);
					#else
						reflection = skyboxData.rgb * skylight * NdotU;
					#endif
				}
				reflection += sunmoon * skyboxData.a * AtmosphereAbsorption(rayDirWorld, AtmosphereExtent);
			}
		#endif
	#else
		#if REFLECTION_TYPE != 1
			if (hit) {
				// reflection = textureLod(colortex4, screenPos.xy * screenPixelSize, int(8.0 * sqrt(material.roughness))).rgb;
				reflection = texelFetch(colortex4, ivec2(screenPos.xy), 0).rgb;
			}
			#if REFLECTION_SHOW_SKY == 1
				else if (skylight > 1e-3) {
					vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
					float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
					//float tileSize = floor(min(viewWidth * rcp(3.0), viewHeight * 0.5)) * 0.25;
					vec4 skyboxData = textureBicubic(colortex5, ProjectSky(rayDirWorld) + vec2(0.0, skyCaptureRes.y * screenPixelSize.y));

					// vec3 sunmoon = RenderMoonReflection(rayDirWorld, worldSunVector);
					// if (material.isRough) {
					// 	sunmoon += RenderSunReflection(rayDirWorld, worldSunVector);
					// } else {
					// 	sunmoon += RenderSun(rayDirWorld, worldSunVector);
					// }

					// skyboxData.rgb += sunmoon * skyboxData.a * AtmosphereAbsorption(rayDirWorld, AtmosphereExtent);
					#if REFLECTION_TYPE == 2
						reflection = mix(hybridRSMReflection, skyboxData.rgb * NdotU, skylight);
					#else
						reflection = skyboxData.rgb * skylight * NdotU;
					#endif
				}
				#if REFLECTION_TYPE == 2
					else if (!hit) {
						// Нет skylight вообще (закрытое помещение) — чистый RSM block-light результат.
						reflection = hybridRSMReflection;
					}
				#endif
			#else
				#if REFLECTION_TYPE == 2
					else if (!hit) {
						reflection = hybridRSMReflection;
					}
				#endif
			#endif
		#endif
	#endif

	float dist = 0.0;
	float specular = 0.0;
	if (material.isRough || wetnessCustom > 1e-2) {
		//vec3 lightDir = normalize(reflect(viewDir, normal) + normal * roughness);
		vec3 halfWay = normalize(rayDir - viewDir);
		float LdotH = saturate(dot(rayDir, halfWay));

		float F = FresnelSchlick(LdotH, material.f0);
		float alpha2 = material.roughness * material.roughness;
		float V2 = V2SmithGGX(NdotV, NdotL, alpha2);
		float V1Inverse = V1SmithGGXInverse(NdotV, alpha2);

		specular = NdotL * F * V2 * V1Inverse;
		//specular *= 1.0 - saturate(material.roughness * 4.0 - 1.5);	//roughness clamp
		vec3 reflectViewPos = ScreenToViewSpace(vec3(screenPos.xy * screenPixelSize, GetDepthFix(ivec2(screenPos.xy))));
		float rDist = distance(reflectViewPos, viewPos);

		dist = saturate(max(rDist * 2.0, material.roughness * 3.0));
	} else {
		specular = FresnelDielectric(NdotV, material.f0);
	}

	specular *= oneMinus(material.isMetal);
	//color *= oneMinus(specular);

	return clamp16F(vec4(reflection * (specular + material.isMetal), dist));
}

//----// MAIN //----------------------------------------------------------------------------------//
void main() {
	ivec2 texel = ivec2(gl_FragCoord.xy);

	//vec3 gbuffer3 = texelFetch(colortex3, texel, 0).rgb;
	//specTex = UnpackUnorm2x8(gbuffer3.z);
	Material material = GetMaterialData(texelFetch(colortex0, texel, 0).xy);

	//sceneData = texelFetch(colortex4, texel, 0).rgb;
	if (material.hasReflections) {
		vec2 screenCoord = gl_FragCoord.xy * screenPixelSize;

		vec3 normal = GetNormals(texel);
		float depth = GetDepthFix(texel);
		vec3 screenPos = vec3(screenCoord, depth);
		vec3 viewPos = ScreenToViewSpace(screenPos);
		float skyLightmap = cube(texelFetch(colortex7, texel, 0).g);
		reflectionData = CalculateSpecularReflections(/*sceneData, */normal, screenPos, material, skyLightmap, viewPos);
	}
}

/* DRAWBUFFERS:2 */
