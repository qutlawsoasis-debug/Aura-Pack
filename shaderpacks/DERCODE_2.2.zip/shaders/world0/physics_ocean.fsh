#version 450 compatibility

#define PHYSICS_OCEAN
#define IS_OVERWORLD

#include "/program/Gbuffers/Water.frag"
