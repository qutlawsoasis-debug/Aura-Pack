#version 450 compatibility

uniform vec2 taaOffset;

flat out int isCloud;

#include "/Settings.glsl"

void main() {
    gl_Position = ftransform();

#ifdef TAA_ENABLED
    gl_Position.xy += taaOffset * gl_Position.w * 0.5;
#endif

    // Ванильные облака — белые вершины (r > 0.5)
    // Заливка неба — чёрная или очень тёмная
    isCloud = int(gl_Color.r > 0.5);
}
