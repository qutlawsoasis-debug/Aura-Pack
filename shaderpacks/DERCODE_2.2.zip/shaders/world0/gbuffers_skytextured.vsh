#version 450 compatibility

uniform vec2 taaOffset;

flat out vec3 tint;
out vec2 texcoord;
out float dist; // расстояние для фейда

#include "/Settings.glsl"

void main() {
    gl_Position = ftransform();

#ifdef TAA_ENABLED
    gl_Position.xy += taaOffset * gl_Position.w * 0.5;
#endif

    tint     = gl_Color.rgb;
    texcoord = mat2(gl_TextureMatrix[0]) * gl_MultiTexCoord0.xy + gl_TextureMatrix[0][3].xy;

    // Передаём W-компоненту как "дистанцию" (у skybox всегда большая)
    dist = gl_Position.w;
}
