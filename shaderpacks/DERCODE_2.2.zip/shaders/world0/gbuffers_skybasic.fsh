#version 450 compatibility

/* DRAWBUFFERS:6 */

out vec3 albedoData;

flat in int isCloud;

#include "/Settings.glsl"

// Цвет ванильных облаков — настраивается в меню
#ifndef VANILLA_CLOUD_R
    #define VANILLA_CLOUD_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#endif
#ifndef VANILLA_CLOUD_G
    #define VANILLA_CLOUD_G 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#endif
#ifndef VANILLA_CLOUD_B
    #define VANILLA_CLOUD_B 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#endif

void main() {
    if (isCloud == 1) {
        albedoData = vec3(VANILLA_CLOUD_R, VANILLA_CLOUD_G, VANILLA_CLOUD_B);
        return;
    }
    discard;
}
