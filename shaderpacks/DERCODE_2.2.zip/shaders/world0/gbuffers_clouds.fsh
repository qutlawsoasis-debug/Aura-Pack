#version 450 compatibility

uniform sampler2D texture;
in vec2 texcoord;
in vec4 glColor;

/* DRAWBUFFERS:4 */ 
// Цифра 4 означает colortex4. 
// Если ты хочешь писать в несколько буферов, тут должно быть, например, DRAWBUFFERS:45
layout(location = 0) out vec4 colorOut; 

void main() {
    vec4 albedo = texture(texture, texcoord) * glColor;
    if (albedo.a < 0.1) discard;

    // ВАЖНО: Умножаем яркость, так как ванильные облака сами по себе темные
    albedo.rgb *= 2.0;

    colorOut = albedo;
}