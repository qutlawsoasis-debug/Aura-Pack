Builder's QOL (Forked) is an unofficial fork of Builder's QOL Shaders.
This version is maintained and updated for newer Minecraft versions.
Verified working on Minecraft 26.3 with Iris 1.11.6+ (OpenGL backend). See changelog.txt.