#include "/lib/Head/Common.inc"

layout(location = 0) out vec3 colortex7Out;
layout(location = 1) out vec4 reflectionData;
layout(location = 2) out vec4 colortex3Out;

vec3 voxy_face_normal(uint face) {
    return vec3(
        uint((face >> 1) == 2),
        uint((face >> 1) == 0),
        uint((face >> 1) == 1)
    ) * (float(int(face) & 1) * 2.0 - 1.0);
}

float voxy_dither() {
    return fract(
        52.9829189 * fract(
            0.06711056 * gl_FragCoord.x +
            0.00583715 * gl_FragCoord.y +
            0.00623715 * float(frameCounter & 63)
        )
    );
}

uint voxy_material_id(uint customId) {
    uint materialID = customId;
    if (materialID >= 10000u) materialID -= 10000u;
    if (materialID == 0u) materialID = 16u;
    return min(materialID, 255u);
}

vec2 voxy_lightmap(vec2 lightmap) {
    return saturate((lightmap - 0.03125) * 1.06667);
}

vec4 voxy_reflection_data(uint materialID, vec2 lightmap, vec3 normal) {
    float NoV = saturate(abs(normal.z));

    if (materialID == 17u) {
        float specular = 0.02037 + 0.97963 * pow(1.0 - NoV, 5.0);
        vec3 reflection = vec3(0.025, 0.045, 0.07) * mix(0.35, 1.0, lightmap.y) * specular;
        return vec4(reflection, 1.0 - specular);
    }

    if (materialID == 16u || materialID == 18u) {
        float specular = 0.04 + 0.96 * pow(1.0 - NoV, 5.0);
        return vec4(vec3(0.01) * specular, 1.0 - 0.8 * specular);
    }

    return vec4(0.0, 0.0, 0.0, 1.0);
}

void voxy_emitFragment(VoxyFragmentParameters parameters) {
    vec4 albedo = parameters.sampledColour * parameters.tinting;
    vec3 normal = normalize(mat3(gbufferModelView) * voxy_face_normal(parameters.face));
    uint materialID = voxy_material_id(parameters.customId);
    vec2 lightmap = voxy_lightmap(parameters.lightMap);

    colortex7Out.xy = lightmap + (voxy_dither() - 0.5) * rcp(255.0);
    colortex7Out.z = (float(materialID) + 0.1) * rcp(255.0);
    colortex3Out.xy = EncodeNormal(normal);
    colortex3Out.z = PackUnorm2x8(albedo.rg);
    colortex3Out.w = PackUnorm2x8(albedo.ba);
    reflectionData = voxy_reflection_data(materialID, lightmap, normal);
}
