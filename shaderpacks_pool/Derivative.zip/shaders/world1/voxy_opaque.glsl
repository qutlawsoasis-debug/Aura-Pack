#define IS_END
#include "/program/voxy_opaque.glsl"
