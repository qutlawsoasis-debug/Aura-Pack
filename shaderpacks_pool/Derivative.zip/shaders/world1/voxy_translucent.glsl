#define IS_END
#include "/program/voxy_translucent.glsl"
