#version 450 compatibility

#define IS_END


layout(location = 0) out vec4 fogData;
layout(location = 1) out vec3 sceneData;


uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;

in vec2 screenCoord;

#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"
#include "/lib/Atmosphere/Atmosphere.glsl"

//----// STRUCTS //-------------------------------------------------------------------------------//

#include "/lib/Head/Mask.inc"

//----// FUNCTIONS //-----------------------------------------------------------------------------//

#include "/lib/Head/Functions.inc"

#include "/lib/Atmosphere/VolumetricFogEnd.glsl"
#include "/lib/Atmosphere/EndClouds.glsl"

#include "/lib/Water/WaterFog.glsl"

//----// MAIN //----------------------------------------------------------------------------------//
void main() {
	ivec2 texel = ivec2(gl_FragCoord.xy);

	int materialIDT = int(texelFetch(colortex7, texel, 0).z * 255.0);
	TranslucentMask materialMaskT = CalculateMasksT(materialIDT);

	sceneData = texelFetch(colortex4, texel, 0).rgb;
	if ((materialMaskT.water || materialMaskT.ice) && isEyeInWater == 0) {
		float depthSoild = GetDepthSoild(texel);
		vec3 viewPos = ScreenToViewSpace(vec3(screenCoord, GetDepth(texel)));
		vec3 viewPosSoild = ScreenToViewSpace(vec3(screenCoord, depthSoild));

		#if defined DISTANT_HORIZONS || defined VOXY
			if (depthSoild >= 1.0) {
				viewPos = ScreenToViewSpaceDH(vec3(screenCoord, GetDepthDH(texel)));
				viewPosSoild = ScreenToViewSpaceDH(vec3(screenCoord, GetDepthSoildDH(texel)));
			}
		#endif
		vec3 worldDir = mat3(gbufferModelViewInverse) * normalize(viewPos);
		float LdotV = dot(worldLightVector, worldDir);
		float skyLightmap = cube(texelFetch(colortex7, texel, 0).g);
		WaterFog(sceneData, materialMaskT, 1.0, LdotV, distance(viewPos, viewPosSoild));
	}

	if (any(greaterThanEqual(screenCoord, vec2(0.5)))) return;

	texel *= 2;
	float depth = GetDepth(texel);
	vec3 viewPos = ScreenToViewSpaceRaw(vec3(screenCoord * 2.0, depth));

	#if defined DISTANT_HORIZONS || defined VOXY
		if (depth >= 1.0) viewPos = ScreenToViewSpaceRawDH(vec3(screenCoord * 2.0, GetDepthDH(texel)));
	#endif

	vec3 worldPos = mat3(gbufferModelViewInverse) * viewPos;
	vec3 worldDir = normalize(worldPos);
	// worldPos += gbufferModelViewInverse[3].xyz;

	fogData = vec4(0.0, 0.0, 0.0, 1.0);
	float dither = R1(frameCounter, texelFetch(noisetex, texel & 255, 0).a);

	if (isEyeInWater == 0) fogData = CalculateVolumetricFog(worldPos, worldDir, dither);

	// Облака — отдельный, независимый от тумана второй проход рейтрейса
	// (см. EndClouds.glsl). Композитим front-to-back поверх уже готового
	// fogData.
	#ifdef END_CLOUDS
		if (isEyeInWater == 0) {
			vec4 cloudsData = CalculateEndClouds(worldPos, worldDir, dither);
			fogData.rgb += cloudsData.rgb * fogData.a;
			fogData.a *= cloudsData.a;
		}
	#endif

	// 2й слой облаков — независимый от первого, свой toggle/настройки/высота.
	#ifdef END_CLOUDS_LAYER2
		if (isEyeInWater == 0) {
			vec4 clouds2Data = CalculateEndClouds2(worldPos, worldDir, dither);
			fogData.rgb += clouds2Data.rgb * fogData.a;
			fogData.a *= clouds2Data.a;
		}
	#endif

		#ifdef END_CLOUDS_LAYER3
		if (isEyeInWater == 0) {
			vec4 clouds3Data = CalculateEndClouds3(worldPos, worldDir, dither);
			fogData.rgb += clouds3Data.rgb * fogData.a;
			fogData.a *= clouds3Data.a;
		}
	#endif

		#ifdef END_CLOUDS_LAYER4
		if (isEyeInWater == 0) {
			vec4 clouds4Data = CalculateEndClouds4(worldPos, worldDir, dither);
			fogData.rgb += clouds4Data.rgb * fogData.a;
			fogData.a *= clouds4Data.a;
		}
	#endif

		#ifdef END_CLOUDS_LAYER5
		if (isEyeInWater == 0) {
			vec4 clouds5Data = CalculateEndClouds5(worldPos, worldDir, dither);
			fogData.rgb += clouds5Data.rgb * fogData.a;
			fogData.a *= clouds5Data.a;
		}
	#endif

		#ifdef END_CLOUDS_LAYER6
		if (isEyeInWater == 0) {
			vec4 clouds6Data = CalculateEndClouds6(worldPos, worldDir, dither);
			fogData.rgb += clouds6Data.rgb * fogData.a;
			fogData.a *= clouds6Data.a;
		}
	#endif

		#ifdef END_CLOUDS_LAYER7
		if (isEyeInWater == 0) {
			vec4 clouds7Data = CalculateEndClouds7(worldPos, worldDir, dither);
			fogData.rgb += clouds7Data.rgb * fogData.a;
			fogData.a *= clouds7Data.a;
		}
	#endif

	#ifdef UW_VOLUMETRIC_LIGHT
		if (isEyeInWater == 1) fogData.rgb = UnderwaterVolumetricLight(worldPos, worldDir, dither);
	#endif

	// Анти-бандинг: гладкие градиенты тумана режутся на видимые полосы при
	// записи в буфер, если colortex1/colortex4 хранятся в низкой битности
	// (RGBA8) — ЭТО не лечится увеличением числа семплов марша, потому что
	// полосы появляются уже ПОСЛЕ марша, на этапе квантования при записи.
	// Раздизеренный шум ниже переводит резкую границу полосы в шум, который
	// потом убирает TAA. dither тут НЕ переиспользуем (тот привязан к маршу
	// лучей и коррелирован с ним) — берём независимый спейс-онли шум.
	float ditherOut = InterleavedGradientNoise(gl_FragCoord.xy);
	fogData.rgb += (ditherOut - 0.5) * (1.0 / 255.0);

	// Если после этого полосы остаются — значит дело не в 8-битном
	// квантовании, а в формате буфера или апскейле из half-res; тогда
	// в первую очередь проверь строки colortex1/colortex4 в shaders.properties
	// (должны быть RGBA16F, а не RGBA8/RGB8).
}

/* DRAWBUFFERS:14 */
