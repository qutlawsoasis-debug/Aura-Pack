
#include "/lib/Head/Common.inc"

#if MULTICOLORED_BLOCKLIGHT == 1 || WATER_TRAIL == 1
	#extension GL_ARB_shader_image_load_store : enable
#endif

uniform vec3 cameraPosition;
uniform mat4 shadowModelViewInverse;
uniform int renderStage;

#if WATER_TRAIL == 1
	uniform vec3 relativeEyePosition;
#endif

uniform int blockEntityId;

#ifndef MC_GL_VENDOR_INTEL
	#define attribute in
#endif

attribute vec4 mc_Entity;
attribute vec4 at_tangent;

#if MULTICOLORED_BLOCKLIGHT == 1
	attribute vec3 at_midBlock;

	writeonly uniform uimage3D voxelimg;

	#if REFLECTION_MODE >= 1
		writeonly uniform uimage3D voxellodimg;
	#endif
#endif

#if WATER_TRAIL == 1
	#if MULTICOLORED_BLOCKLIGHT == 0
		attribute vec3 at_midBlock;
	#endif

	writeonly uniform uimage2D waterpresenceimg;
#endif

out vec2 texcoord;
out vec3 tint;
out vec2 lightmap;
out vec3 viewPos;
out vec3 minecraftPos;

flat out mat3 tbnMatrix;

flat out float isWater;

#if MULTICOLORED_BLOCKLIGHT == 1 && REFLECTION_MODE >= 1
	flat out float voxelWriteEligible;
#endif

uniform mat4 shadowProjection;

#include "/lib/Lighting/ShadowDistortion.glsl"

#if MULTICOLORED_BLOCKLIGHT == 1
	#include "/lib/util/voxelMapHelper.glsl"
	#include "/lib/util/voxelMap.glsl"
#endif

#if WATER_TRAIL == 1
	#include "/lib/util/waterTrailHelper.glsl"
#endif

//----// MAIN //----------------------------------------------------------------------------------//
void main() {
	if (blockEntityId == 10030) {
		gl_Position = vec4(-1.0);
		return;
	}

    tbnMatrix[2] = normalize(gl_NormalMatrix * gl_Normal);
	#ifdef SHADOW_BACKFACE_CULLING
		if (tbnMatrix[2].z < 0.0) {
			gl_Position = vec4(-1.0);
			return;
		}
	#endif

	tint = gl_Color.rgb;


	vec4 endRotatedVertex = gl_Vertex;
	endRotatedVertex.xyz = RotateEndShadowY(endRotatedVertex.xyz);

	isWater = 0.0;
	if (int(mc_Entity.x) == 10017) {
		tbnMatrix[0] = normalize(gl_NormalMatrix * at_tangent.xyz);
		tbnMatrix[1] = cross(tbnMatrix[0], tbnMatrix[2]) * sign(at_tangent.w);

		isWater = 1.0;
	}

	lightmap = gl_MultiTexCoord1.xy * rcp(240.0);
	texcoord = mat2(gl_TextureMatrix[0]) * gl_MultiTexCoord0.xy + gl_TextureMatrix[0][3].xy;

	viewPos = transMAD(gl_ModelViewMatrix, endRotatedVertex.xyz);
	minecraftPos = transMAD(shadowModelViewInverse, viewPos) + cameraPosition;

	#if MULTICOLORED_BLOCKLIGHT == 1
		bool isTerrain = (renderStage == MC_RENDER_STAGE_TERRAIN_SOLID)
			|| (renderStage == MC_RENDER_STAGE_TERRAIN_TRANSLUCENT)
			|| (renderStage == MC_RENDER_STAGE_TERRAIN_CUTOUT)
			|| (renderStage == MC_RENDER_STAGE_TERRAIN_CUTOUT_MIPPED);

		if (isTerrain) {
			int materialID = int(mc_Entity.x) - 10000;
			UpdateVoxelMap(gl_VertexID, materialID, isWater > 0.5);

			#if REFLECTION_MODE >= 1
				voxelWriteEligible = (isWater > 0.5 || materialID == 40 || materialID == 189) ? 0.0 : 1.0;
			#endif
		} else {
			#if REFLECTION_MODE >= 1
				voxelWriteEligible = 0.0;
			#endif
		}
	#endif

	#if WATER_TRAIL == 1
		#if MULTICOLORED_BLOCKLIGHT == 0
			bool isTerrainForTrail = (renderStage == MC_RENDER_STAGE_TERRAIN_SOLID)
				|| (renderStage == MC_RENDER_STAGE_TERRAIN_TRANSLUCENT)
				|| (renderStage == MC_RENDER_STAGE_TERRAIN_CUTOUT)
				|| (renderStage == MC_RENDER_STAGE_TERRAIN_CUTOUT_MIPPED);
		#else
			bool isTerrainForTrail = isTerrain;
		#endif

if (isTerrainForTrail && gl_VertexID % 4 == 0) {
			vec3 feetPos = gl_Vertex.xyz + at_midBlock / 64.0;
			vec3 viewPosForTrail = transMAD(gl_ModelViewMatrix, feetPos);
			vec3 worldPosForTrail = transMAD(shadowModelViewInverse, viewPosForTrail);

			// XZ
			vec2 trailWritePos = WorldToTrail(worldPosForTrail.xz);
			
			if (IsInTrailVolume(trailWritePos)) {
				float absoluteWaterY = worldPosForTrail.y + cameraPosition.y;
				
				uint presenceValue = (isWater > 0.5) ? EncodeWaterY(absoluteWaterY) : 0u;
				imageStore(waterpresenceimg, ivec2(trailWritePos), uvec4(presenceValue, 0u, 0u, 0u));
			}
		}
	#endif

	gl_Position.xyz = DistortShadowSpace(projMAD(gl_ProjectionMatrix, viewPos));
	gl_Position.w = 1.0;
}
