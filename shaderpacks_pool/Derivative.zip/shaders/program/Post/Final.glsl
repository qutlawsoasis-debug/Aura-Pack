out vec3 finalData;

#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"

#include "/lib/Head/Noise.inc"

#define INFO 0 // [0 1]
#define Version 0	// [0 1 2 3]
#define Version_Type 0 // [0 1 2 3]

#define DLSS_MODE 1 // Пресеты в духе DLSS. Резкость и анти-гостинг подстраиваются под выбранный режим — Render Scale в видеонастройках Minecraft/Iris нужно выставить вручную под тот же пресет! [0 1 2 3 4]
	// 0 = Выкл — обычный CAS без адаптации под масштаб
	// 1 = Quality           -> выстави Render Scale 77% (0.77)
	// 2 = Balanced          -> выстави Render Scale 67% (0.67)
	// 3 = Performance       -> выстави Render Scale 59% (0.59)
	// 4 = Ultra Performance -> выстави Render Scale 50% (0.50)

#if DLSS_MODE == 0
	#define DLSS_SHARPEN_BOOST 1.0
#elif DLSS_MODE == 1
	#define DLSS_SHARPEN_BOOST 1.1
#elif DLSS_MODE == 2
	#define DLSS_SHARPEN_BOOST 1.25
#elif DLSS_MODE == 3
	#define DLSS_SHARPEN_BOOST 1.4
#elif DLSS_MODE == 4
	#define DLSS_SHARPEN_BOOST 1.6
#endif

#define ASPECT_RATIO_ENABLED 0 // Принудительное соотношение сторон экрана — вкл/выкл [0 1]

#define ASPECT_RATIO_STYLE 0 // Как применять соотношение сторон / разрешение, если ASPECT_RATIO_ENABLED или RESOLUTION_ENABLED включены [0 1]
	// 0 = Letterbox — картинка вписывается целиком, лишнее место закрашивается чёрными полосами
	// 1 = Stretch   — картинка растягивается/сжимается на весь экран под нужный формат, БЕЗ полос (искажает пропорции)

#define ASPECT_RATIO_MODE 1 // Какое соотношение сторон применять, если ASPECT_RATIO_ENABLED включен [1 2 3 4]
	// 1 = 4:3    (классика)
	// 2 = 16:9   (стандартное широкоформатное)
	// 3 = 10:10  (квадрат 1:1)
	// 4 = 21:9   (кино/ультраширокое)

//----------------------------------------------------------------------------//

#define RESOLUTION_ENABLED 0 // Принудительное разрешение экрана (как в списке Render Resolution) — вкл/выкл [0 1]
	// Работает так же, как ASPECT_RATIO выше (Letterbox или Stretch по ASPECT_RATIO_STYLE),
	// но вместо соотношения сторон задаёт конкретную пару width x height напрямую.
	// Если включены оба блока разом, приоритет у RESOLUTION_ENABLED — ASPECT_RATIO игнорируется.

#define RESOLUTION_MODE 0 // Какое разрешение применять, если RESOLUTION_ENABLED включен [0 1 2 3 4 5 6 7 8 9 10 11]
	// 0  = 3840 x 2160 (4K)
	// 1  = 2560 x 1440 (2K)
	// 2  = 1920 x 1080 (рекомендовано)
	// 3  = 1760 x 990
	// 4  = 1680 x 1050
	// 5  = 1600 x 900
	// 6  = 1366 x 768
	// 7  = 1280 x 1024
	// 8  = 1280 x 720
	// 9  = 1128 x 634
	// 10 = 1024 x 768
	// 11 = 800  x 600

#if RESOLUTION_ENABLED == 1
	#if RESOLUTION_MODE == 0
		#define TARGET_ASPECT (3840.0 / 2160.0)
	#elif RESOLUTION_MODE == 1
		#define TARGET_ASPECT (2560.0 / 1440.0)
	#elif RESOLUTION_MODE == 2
		#define TARGET_ASPECT (1920.0 / 1080.0)
	#elif RESOLUTION_MODE == 3
		#define TARGET_ASPECT (1760.0 / 990.0)
	#elif RESOLUTION_MODE == 4
		#define TARGET_ASPECT (1680.0 / 1050.0)
	#elif RESOLUTION_MODE == 5
		#define TARGET_ASPECT (1600.0 / 900.0)
	#elif RESOLUTION_MODE == 6
		#define TARGET_ASPECT (1366.0 / 768.0)
	#elif RESOLUTION_MODE == 7
		#define TARGET_ASPECT (1280.0 / 1024.0)
	#elif RESOLUTION_MODE == 8
		#define TARGET_ASPECT (1280.0 / 720.0)
	#elif RESOLUTION_MODE == 9
		#define TARGET_ASPECT (1128.0 / 634.0)
	#elif RESOLUTION_MODE == 10
		#define TARGET_ASPECT (1024.0 / 768.0)
	#elif RESOLUTION_MODE == 11
		#define TARGET_ASPECT (800.0 / 600.0)
	#endif
#elif ASPECT_RATIO_ENABLED == 1
	#if ASPECT_RATIO_MODE == 1
		#define TARGET_ASPECT (4.0 / 3.0)
	#elif ASPECT_RATIO_MODE == 2
		#define TARGET_ASPECT (16.0 / 9.0)
	#elif ASPECT_RATIO_MODE == 3
		#define TARGET_ASPECT (1.0)
	#elif ASPECT_RATIO_MODE == 4
		#define TARGET_ASPECT (21.0 / 9.0)
	#endif
#endif

//#define DEBUG_DRAWBUFFERS

//----------------------------------------------------------------------------//

#define minOf(a, b, c, d, e, f, g, h, i) min(a, min(b, min(c, min(d, min(e, min(f, min(g, min(h, i))))))))
#define maxOf(a, b, c, d, e, f, g, h, i) max(a, max(b, max(c, max(d, max(e, max(f, max(g, max(h, i))))))))

#define SampleColor(texel) texelFetch(colortex3, texel, 0).rgb

#define PIXELATION_ENABLED 0 // Ретро-пикселизация финальной картинки, чисто screen-space эффект [0 1]
#define PIXELIZATION_STRENGTH 4 // Размер блока в пикселях. Больше = крупнее блоки [1 2 3 4 6 8 12 16 24 32]

#define UPSCALE_MODE 1 // Метод апскейла при MC_RENDER_QUALITY < 1.0 [0 1]
	// 0 = Catmull-Rom + CAS (текущий, дешевле)
	// 1 = AMD FSR1 (EASU + RCAS) — открытый MIT-алгоритм, четче на краях объектов

#define UPSCALE_RES_PRESET 0 // Пресет масштаба рендера — чисто справочно! Render Scale всё равно выставляется руками в видеонастройках Minecraft/Iris, шейдер не может менять его сам [0 1 2 3 4]
	// 0 = Native            -> выстави Render Scale 100% (1.00)
	// 1 = Quality           -> выстави Render Scale 77% (0.77)
	// 2 = Balanced          -> выстави Render Scale 67% (0.67)
	// 3 = Performance       -> выстави Render Scale 59% (0.59)
	// 4 = Ultra Performance -> выстави Render Scale 50% (0.50)

#if UPSCALE_RES_PRESET == 0
	#define UPSCALE_RENDER_SCALE 1.00
	#define FSR_SHARPNESS 0.30
#elif UPSCALE_RES_PRESET == 1
	#define UPSCALE_RENDER_SCALE 0.77
	#define FSR_SHARPNESS 0.20
#elif UPSCALE_RES_PRESET == 2
	#define UPSCALE_RENDER_SCALE 0.67
	#define FSR_SHARPNESS 0.15
#elif UPSCALE_RES_PRESET == 3
	#define UPSCALE_RENDER_SCALE 0.59
	#define FSR_SHARPNESS 0.10
#elif UPSCALE_RES_PRESET == 4
	#define UPSCALE_RENDER_SCALE 0.50
	#define FSR_SHARPNESS 0.05
#endif
// Чем сильнее апскейл (меньше Render Scale), тем меньше исходного материала
// у EASU для реконструкции — RCAS-резкость приходится снижать, иначе на
// агрессивных пресетах (Performance/Ultra Performance) лезут артефакты и
// звон на краях. Значения выше подобраны так, чтобы UPSCALE_RES_PRESET сам
// задавал FSR_SHARPNESS без ручной подстройки под каждый пресет.

//----------------------------------------------------------------------------//

// Contrast Adaptive Sharpening (CAS)
// Reference: Lou Kramer, FidelityFX CAS, AMD Developer Day 2019,
// https://gpuopen.com/wp-content/uploads/2019/07/FidelityFX-CAS.pptx
vec3 CASFilter(in ivec2 texel) {
	#ifndef CAS_ENABLED
		return SampleColor(texel);
	#endif

	vec3 a = SampleColor(texel + ivec2(-1, -1));
	vec3 b = SampleColor(texel + ivec2( 0, -1));
	vec3 c = SampleColor(texel + ivec2( 1, -1));
	vec3 d = SampleColor(texel + ivec2(-1,  0));
	vec3 e = SampleColor(texel);
	vec3 f = SampleColor(texel + ivec2( 1,  0));
	vec3 g = SampleColor(texel + ivec2(-1,  1));
	vec3 h = SampleColor(texel + ivec2( 0,  1));
	vec3 i = SampleColor(texel + ivec2( 1,  1));

	vec3 minColor = minOf(a, b, c, d, e, f, g, h, i);
	vec3 maxColor = maxOf(a, b, c, d, e, f, g, h, i);

    vec3 sharpeningAmount = sqrt(min(1.0 - maxColor, minColor) / maxColor);
    vec3 w = sharpeningAmount * mix(-0.125, -0.2, CAS_STRENGTH);

	//float minG = minOf(a.g, b.g, c.g, d.g, e.g, f.g, g.g, h.g, i.g);
	//float maxG = maxOf(a.g, b.g, c.g, d.g, e.g, f.g, g.g, h.g, i.g);

    //float sharpeningAmount = sqrt(min(1.0 - maxG, minG) / maxG);
    //float w = sharpeningAmount * mix(-0.125, -0.2, CAS_STRENGTH);

	return ((b + d + f + h) * w + e) / (4.0 * w + 1.0);
}

//----------------------------------------------------------------------------//

//approximation from SMAA presentation from siggraph 2016
vec3 textureCatmullRomFast(in sampler2D tex, in vec2 position, in const float sharpness) {
	//vec2 screenSize = textureSize(sampler, 0);
	//vec2 screenPixelSize = 1.0 / screenSize;

	//vec2 position = screenSize * coord;
	vec2 centerPosition = floor(position - 0.5) + 0.5;
	vec2 f = position - centerPosition;
	vec2 f2 = f * f;
	vec2 f3 = f * f2;

	vec2 w0 = -sharpness        * f3 + 2.0 * sharpness         * f2 - sharpness * f;
	vec2 w1 = (2.0 - sharpness) * f3 - (3.0 - sharpness)       * f2 + 1.0;
	vec2 w2 = (sharpness - 2.0) * f3 + (3.0 - 2.0 * sharpness) * f2 + sharpness * f;
	vec2 w3 = sharpness         * f3 - sharpness               * f2;

	vec2 w12 = w1 + w2;

	vec2 tc0 = screenPixelSize * (centerPosition - 1.0);
	vec2 tc3 = screenPixelSize * (centerPosition + 2.0);
	vec2 tc12 = screenPixelSize * (centerPosition + w2 / w12);

	float l0 = w12.x * w0.y;
	float l1 = w0.x  * w12.y;
	float l2 = w12.x * w12.y;
	float l3 = w3.x  * w12.y;
	float l4 = w12.x * w3.y;

	vec3 color =  texture(tex, vec2(tc12.x, tc0.y )).rgb * l0
				+ texture(tex, vec2(tc0.x,  tc12.y)).rgb * l1
				+ texture(tex, vec2(tc12.x, tc12.y)).rgb * l2
				+ texture(tex, vec2(tc3.x,  tc12.y)).rgb * l3
				+ texture(tex, vec2(tc12.x, tc3.y )).rgb * l4;

	return color / (l0 + l1 + l2 + l3 + l4);
}

//----------------------------------------------------------------------------//
// AMD FidelityFX Super Resolution 1.0 (FSR1) — открытый MIT-алгоритм AMD.
// Собственная GLSL-реализация по опубликованной структуре EASU+RCAS
// (см. https://gpuopen.com/fidelityfx-superresolution/), адаптированная
// под texelFetch-стиль этого пака. Официальный ffx_fsr1.h использует
// битовые трюки быстрой инверсии/lane-swizzle интринсики для GPU wavefront
// оптимизаций компьют-шейдеров — здесь вместо них обычная float-математика,
// т.к. это fragment shader и такие интринсики тут недоступны и не нужны.
//----------------------------------------------------------------------------//

#if UPSCALE_MODE == 1

float FsrLuma(in vec3 c) {
	return c.g * 2.0 + (c.r + c.b);
}

// Ланцош-2: sinc(x) * sinc(x/2), обнуляется за пределами окна |x| >= 2
float FsrLanczos2(in float x) {
	x = abs(x);
	if (x >= 2.0) return 0.0;
	float pix = PI * max(x, 1e-4);
	return (sin(pix) * sin(pix * 0.5)) / (pix * pix * 0.5);
}

// EASU: 12-tap направленный апскейл с эллиптическим Ланцош-ядром
vec3 FSR_EASU(in sampler2D tex, in vec2 outputTexel, in float scale) {
	vec2 pp = outputTexel * scale;
	vec2 fp = floor(pp);
	vec2 f  = pp - fp;

	ivec2 fpi = ivec2(fp);
	vec3 A = texelFetch(tex, fpi + ivec2( 0,-1), 0).rgb;
	vec3 B = texelFetch(tex, fpi + ivec2( 1,-1), 0).rgb;
	vec3 C = texelFetch(tex, fpi + ivec2(-1, 0), 0).rgb;
	vec3 D = texelFetch(tex, fpi + ivec2( 0, 0), 0).rgb;
	vec3 E = texelFetch(tex, fpi + ivec2( 1, 0), 0).rgb;
	vec3 F = texelFetch(tex, fpi + ivec2( 2, 0), 0).rgb;
	vec3 G = texelFetch(tex, fpi + ivec2(-1, 1), 0).rgb;
	vec3 H = texelFetch(tex, fpi + ivec2( 0, 1), 0).rgb;
	vec3 I = texelFetch(tex, fpi + ivec2( 1, 1), 0).rgb;
	vec3 J = texelFetch(tex, fpi + ivec2( 2, 1), 0).rgb;
	vec3 K = texelFetch(tex, fpi + ivec2( 0, 2), 0).rgb;
	vec3 L = texelFetch(tex, fpi + ivec2( 1, 2), 0).rgb;

	// Градиент по центральному 2x2 (D,E,H,I) — направление и сила края
	float gx = (FsrLuma(E) + FsrLuma(I)) - (FsrLuma(D) + FsrLuma(H));
	float gy = (FsrLuma(H) + FsrLuma(I)) - (FsrLuma(D) + FsrLuma(E));
	float gradLen = length(vec2(gx, gy));

	vec2 dir = gradLen > 1e-5 ? vec2(gx, gy) / gradLen : vec2(1.0, 0.0);
	float stretch = saturate(gradLen * 4.0); // 0 = круглое ядро, 1 = вытянуто вдоль края

	vec3 taps[12]    = vec3[12](A, B, C, D, E, F, G, H, I, J, K, L);
	vec2 offsets[12] = vec2[12](
		vec2(0,-1), vec2(1,-1),
		vec2(-1,0), vec2(0,0), vec2(1,0), vec2(2,0),
		vec2(-1,1), vec2(0,1), vec2(1,1), vec2(2,1),
		vec2(0,2), vec2(1,2)
	);

	vec3 result = vec3(0.0);
	float sumWeight = 0.0;

	for (int i = 0; i < 12; ++i) {
		vec2 sampleOffset = offsets[i] - f;
		float along  = dot(sampleOffset, dir);
		float across = dot(sampleOffset, vec2(-dir.y, dir.x));
		// Растягиваем поперечную ось вдоль края — так ядро становится
		// эллиптическим, в этом и есть суть Edge-Adaptive части EASU
		float warped = length(vec2(along, across * mix(1.0, 2.2, stretch)));

		float weight = FsrLanczos2(warped);
		result += taps[i] * weight;
		sumWeight += weight;
	}

	result = sumWeight > 1e-5 ? result / sumWeight : D;

	// Anti-ringing: клампим к min/max центрального 2x2, чтобы Ланцош
	// не давал звона/овершута на резких контрастных краях
	vec3 minC = min(min(D, E), min(H, I));
	vec3 maxC = max(max(D, E), max(H, I));
	return clamp(result, minC, maxC);
}

// RCAS: 5-tap резкость с адаптивным весом, устойчивым к клиппингу
vec3 FSR_RCAS(in vec3 center, in vec3 up, in vec3 down, in vec3 left, in vec3 right, in float sharpness) {
	vec3 minC = min(min(min(up, down), min(left, right)), center);
	vec3 maxC = max(max(max(up, down), max(left, right)), center);

	// Запас до края локального диапазона — чем меньше запас, тем слабее
	// резкость в этом канале, чтобы не словить клиппинг/пересвет (это и
	// отличает "robust" CAS от обычного)
	vec3 headroom = min(1.0 - maxC, minC);
	vec3 negLobe = saturate(headroom / max(maxC, 1e-5));

	float lobeStrength = mix(0.25, 0.05, sharpness);
	vec3 w = sqrt(negLobe) * -lobeStrength;

	return (center + (up + down + left + right) * w) / (1.0 + 4.0 * w);
}

#endif

//----------------------------------------------------------------------------//
// Единая точка входа для апскейла — сама решает, FSR это будет или
// Catmull-Rom+CAS, в зависимости от UPSCALE_MODE. Благодаря тому что весь
// if/else живёт ВНУТРИ одной функции, а не размножается по main() через
// дублирующиеся #if/#else блоки с двумя "else" в тексте, парсер Iris
// (glsl-transformer/ANTLR) больше не путается при активном UPSCALE_MODE == 1.
//----------------------------------------------------------------------------//
vec3 DoUpscale(in ivec2 texel) {
	#if UPSCALE_MODE == 1
		// EASU для текущего пикселя и 4 соседей — нужны для RCAS-пасса ниже
		vec3 center = FSR_EASU(colortex3, vec2(texel),               MC_RENDER_QUALITY);
		vec3 up     = FSR_EASU(colortex3, vec2(texel + ivec2(0,-1)), MC_RENDER_QUALITY);
		vec3 down   = FSR_EASU(colortex3, vec2(texel + ivec2(0, 1)), MC_RENDER_QUALITY);
		vec3 left   = FSR_EASU(colortex3, vec2(texel + ivec2(-1,0)), MC_RENDER_QUALITY);
		vec3 right  = FSR_EASU(colortex3, vec2(texel + ivec2( 1,0)), MC_RENDER_QUALITY);

		return FSR_RCAS(center, up, down, left, right, FSR_SHARPNESS);
	#else
		// Апскейл через Catmull-Rom с реконструкцией недостающих деталей
		vec3 result = textureCatmullRomFast(colortex3, texel * MC_RENDER_QUALITY, 0.6);

		#ifdef CAS_ENABLED
			// DLSS-подобная финальная резкость: без этого апскейл выглядит "мыльным",
			// т.к. CASFilter() выше работает только с native res буфером, а не с апскейленным кадром
			vec3 a = textureCatmullRomFast(colortex3, (texel + ivec2(-1, -1)) * MC_RENDER_QUALITY, 0.6);
			vec3 b = textureCatmullRomFast(colortex3, (texel + ivec2( 0, -1)) * MC_RENDER_QUALITY, 0.6);
			vec3 c = textureCatmullRomFast(colortex3, (texel + ivec2( 1, -1)) * MC_RENDER_QUALITY, 0.6);
			vec3 d = textureCatmullRomFast(colortex3, (texel + ivec2(-1,  0)) * MC_RENDER_QUALITY, 0.6);
			vec3 e = result;
			vec3 f = textureCatmullRomFast(colortex3, (texel + ivec2( 1,  0)) * MC_RENDER_QUALITY, 0.6);
			vec3 g = textureCatmullRomFast(colortex3, (texel + ivec2(-1,  1)) * MC_RENDER_QUALITY, 0.6);
			vec3 h = textureCatmullRomFast(colortex3, (texel + ivec2( 0,  1)) * MC_RENDER_QUALITY, 0.6);
			vec3 i = textureCatmullRomFast(colortex3, (texel + ivec2( 1,  1)) * MC_RENDER_QUALITY, 0.6);

			vec3 minColor = minOf(a, b, c, d, e, f, g, h, i);
			vec3 maxColor = maxOf(a, b, c, d, e, f, g, h, i);

			vec3 sharpeningAmount = sqrt(min(1.0 - maxColor, minColor) / maxColor);
			// Апскейленному кадру нужно чуть меньше резкости, чем native, иначе полезут артефакты по краям блоков
			// DLSS_SHARPEN_BOOST компенсирует потерю деталей на более агрессивных пресетах апскейла
			vec3 w = sharpeningAmount * mix(-0.09, -0.15, CAS_STRENGTH) * DLSS_SHARPEN_BOOST;

			result = ((b + d + f + h) * w + e) / (4.0 * w + 1.0);
		#endif

		return result;
	#endif
}

//----------------------------------------------------------------------------//
// Принудительный aspect ratio, режим Letterbox: считаем, вписывается ли
// целевая рамка по ширине или по высоте экрана, и оставляем черные полосы
// (леттербокс сверху/снизу или пилларбокс по бокам) на той оси, где рамка
// "не дотягивает". Возвращает false, если texel попал в полосу — тогда
// рисуем чёрный пиксель и не трогаем основной пайплайн апскейла/CAS вообще.
//----------------------------------------------------------------------------//
#ifdef TARGET_ASPECT
bool RemapAspectRatioLetterbox(inout ivec2 texel) {
	vec2 screenSize = vec2(viewWidth, viewHeight);
	float screenAspect = screenSize.x / screenSize.y;

	vec2 frameSize = screenSize;
	if (screenAspect > TARGET_ASPECT) {
		// экран шире целевой рамки -> рамка на всю высоту, полосы по бокам (пилларбокс)
		frameSize.x = screenSize.y * TARGET_ASPECT;
	} else {
		// экран уже целевой рамки -> рамка на всю ширину, полосы сверху/снизу (леттербокс)
		frameSize.y = screenSize.x / TARGET_ASPECT;
	}

	vec2 barSize = (screenSize - frameSize) * 0.5;

	if (texel.x < barSize.x || texel.x >= screenSize.x - barSize.x ||
	    texel.y < barSize.y || texel.y >= screenSize.y - barSize.y) {
		return false; // попали в чёрную полосу
	}

	// Растягиваем координату из "видимой рамки" обратно на весь буфер,
	// чтобы дальше по пайплайну (апскейл/CAS) картинка бралась без полос
	vec2 local = (vec2(texel) - barSize) / frameSize;
	texel = ivec2(local * screenSize);
	return true;
}

//----------------------------------------------------------------------------//
// Принудительный aspect ratio, режим Stretch: без чёрных полос, картинка
// реально растягивается/сжимается по одной из осей, чтобы вписаться в
// TARGET_ASPECT — как классический "растянутый экран" 4:3 на широком
// мониторе. Пропорции при этом искажаются (круг станет овалом), в отличие
// от Letterbox, который сохраняет пропорции ценой чёрных полос.
//----------------------------------------------------------------------------//
void RemapAspectRatioStretch(inout ivec2 texel) {
	vec2 screenSize = vec2(viewWidth, viewHeight);
	float screenAspect = screenSize.x / screenSize.y;

	// Коэффициент растяжения по каждой оси относительно центра экрана,
	// чтобы контент "сжался"/"растянулся" ровно до TARGET_ASPECT без полос
	vec2 stretch = vec2(1.0);
	if (screenAspect > TARGET_ASPECT) {
		// экран шире цели -> сжимаем по X (контент становится уже, тянется горизонтально при выводе на весь экран)
		stretch.x = TARGET_ASPECT / screenAspect;
	} else {
		// экран уже цели -> сжимаем по Y
		stretch.y = screenAspect / TARGET_ASPECT;
	}

	vec2 center = screenSize * 0.5;
	vec2 local = (vec2(texel) - center) * stretch + center;
	texel = ivec2(local);
}
#endif

//----// MAIN //----------------------------------------------------------------------------------//
void main() {
    ivec2 texel = ivec2(gl_FragCoord.xy);

	#ifdef TARGET_ASPECT
		#if ASPECT_RATIO_STYLE == 1
			RemapAspectRatioStretch(texel);
		#else
			if (!RemapAspectRatioLetterbox(texel)) {
				finalData = vec3(0.0);
				return;
			}
		#endif
	#endif

	#if PIXELATION_ENABLED == 1
		// Снэппим экранную координату к сетке блоков ДО апскейла/CAS,
		// чтобы весь пайплайн ниже работал уже с "пикселизированными" координатами
		texel -= ivec2(mod(vec2(texel), float(PIXELIZATION_STRENGTH)));
	#endif

	#ifdef DEBUG_DRAWBUFFERS
		finalData = texelFetch(colortex4, texel, 0).rgb;
		return;
	#endif

	if (abs(MC_RENDER_QUALITY - 1.0) < 1e-2) {
    	finalData = CASFilter(texel);
	} else {
		finalData = DoUpscale(texel);
	}

	finalData += (bayer16(gl_FragCoord.xy) - 0.5) * rcp(255.0);
}
