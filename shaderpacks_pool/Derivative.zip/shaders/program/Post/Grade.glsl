#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"
uniform vec3 sunPosition;
uniform ivec2 eyeBrightnessSmooth;

// Dirty Lens 
#if DIRT_STYLE > 0
    #if DIRT_STYLE == 1
        uniform sampler2D colortex10;  // astralex
        #define DIRTY_LENS_SAMPLER colortex10
    #elif DIRT_STYLE == 2
        uniform sampler2D colortex11; // bodycam
        #define DIRTY_LENS_SAMPLER colortex11
    #elif DIRT_STYLE == 3
        uniform sampler2D colortex12; // big
        #define DIRTY_LENS_SAMPLER colortex12
    #elif DIRT_STYLE == 4
        uniform sampler2D colortex13; // blink
        #define DIRTY_LENS_SAMPLER colortex13
    #endif
#endif



//--// Internal Settings //---------------------------------------------------//

/*
    const int   colortex0Format             = RGBA16F;
    const int   colortex1Format             = RGBA16F;
    const int   colortex2Format             = RGBA16F;
    const int   colortex3Format             = RGBA16F; // было RGBA16, поднято под HDR (8bit/UNORM не хранит >1 и отрицательные значения)
    const int   colortex4Format             = R11F_G11F_B10F;
    const int   colortex5Format             = RGBA16F;
    const int   colortex6Format             = RGB8;
    const int   colortex7Format             = RGB8;
    const int   colortex8Format             =RGBA16F
    const int   colortex9Format             =RGBA16F


    

    const int colortex29Format = RGBA16F;


    const bool  colortex0Clear              = false;
    const bool  colortex1Clear              = false;
    const bool  colortex2Clear              = false;
    const bool  colortex4Clear              = false;
    const bool  colortex5Clear              = false;
    const bool  colortex7Clear              = true;

    const float shadowIntervalSize          = 2.0;
    const float ambientOcclusionLevel       = 0.05f; // [0.01f 0.02f 0.03f 0.04f 0.05f 0.06f 0.07f 0.08f 0.09f 0.1f 0.2f 0.3f 0.4f 0.5f 0.6f 0.7f 0.8f 0.9f 1.0f]
	const float	sunPathRotation				= -35.0; // [-90.0 -89.0 -88.0 -87.0 -86.0 -85.0 -84.0 -83.0 -82.0 -81.0 -80.0 -79.0 -78.0 -77.0 -76.0 -75.0 -74.0 -73.0 -72.0 -71.0 -70.0 -69.0 -68.0 -67.0 -66.0 -65.0 -64.0 -63.0 -62.0 -61.0 -60.0 -59.0 -58.0 -57.0 -56.0 -55.0 -54.0 -53.0 -52.0 -51.0 -50.0 -49.0 -48.0 -47.0 -46.0 -45.0 -44.0 -43.0 -42.0 -41.0 -40.0 -39.0 -38.0 -37.0 -36.0 -35.0 -34.0 -33.0 -32.0 -31.0 -30.0 -29.0 -28.0 -27.0 -26.0 -25.0 -24.0 -23.0 -22.0 -21.0 -20.0 -19.0 -18.0 -17.0 -16.0 -15.0 -14.0 -13.0 -12.0 -11.0 -10.0 -9.0 -8.0 -7.0 -6.0 -5.0 -4.0 -3.0 -2.0 -1.0 0.0 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0 21.0 22.0 23.0 24.0 25.0 26.0 27.0 28.0 29.0 30.0 31.0 32.0 33.0 34.0 35.0 36.0 37.0 38.0 39.0 40.0 41.0 42.0 43.0 44.0 45.0 46.0 47.0 48.0 49.0 50.0 51.0 52.0 53.0 54.0 55.0 56.0 57.0 58.0 59.0 60.0 61.0 62.0 63.0 64.0 65.0 66.0 67.0 68.0 69.0 70.0 71.0 72.0 73.0 74.0 75.0 76.0 77.0 78.0 79.0 80.0 81.0 82.0 83.0 84.0 85.0 86.0 87.0 88.0 89.0 90.0]
    const float eyeBrightnessHalflife       = 10.0;
    const float wetnessHalflife             = 180.0; // [10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 115 120 125 130 315 140 145 150 155 160 165 170 175 180 185 190 195]
    const float drynessHalflife             = 60.0; // [10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 115 120 125 130 315 140 145 150 155 160 165 170 175 180 185 190 195]
    const bool  shadowHardwareFiltering1    = true;
*/

#ifdef PARALLAX
/*
    const int   colortex7Format             = RGBA8;
*/
#endif

//----------------------------------------------------------------------------//

//#define PURKINJE_SHIFT

#if !defined IS_OVERWORLD
    #undef PURKINJE_SHIFT
#endif
// ==== СРАВНЕНИЕ ТОНМАПОВ (SPLIT-SCREEN) ====
#define TONEMAP_1TO1 0 // [0 1]
#define TONEMAP_LEFT Bliss // [ISA SEUS_PTGI SEUS_RENEWED KUDA AcademyFit AcademyFull AgX_Minimal AgX_Full ReinhardSimple ExtendedReinhard Filmic HableFilmic Uncharted2Filmic Lottes Uchimura Drago PhotographicReinhard HejlDawson JodieReinhard BlueShadowCustom BlueShadowIntense BlueShadowSubtle FakeHDR Bliss IterationT_AgX Frostbite]
#define TONEMAP_RIGHT IterationT_AgX // [ISA SEUS_PTGI SEUS_RENEWED KUDA AcademyFit AcademyFull AgX_Minimal AgX_Full ReinhardSimple ExtendedReinhard Filmic HableFilmic Uncharted2Filmic Lottes Uchimura Drago PhotographicReinhard HejlDawson JodieReinhard BlueShadowCustom BlueShadowIntense BlueShadowSubtle FakeHDR Bliss IterationT_AgX Frostbite]

#define TONEMAP AcademyFit // [Bliss IterationT_AgX Frostbite ISA SEUS_PTGI SEUS_RENEWED KUDA AcademyFit AcademyFull AgX_Minimal AgX_Full ReinhardSimple ExtendedReinhard Filmic HableFilmic Uncharted2Filmic Lottes Uchimura Drago PhotographicReinhard HejlDawson JodieReinhard BlueShadowCustom BlueShadowIntense BlueShadowSubtle FakeHDR]
//#define LENS_FLARE_ENABLED
#define LENS_FLARE_STYLE 4 // [1 2 3 4 5] // 1 = хексагоны (старые, кривая центровка) 2 = BSL-порт 3 = хексагоны с правильной центровкой 4 = BSL-порт v2 (donor: sunFactor на точках, falloff у RingLens) 5 = Shadertoy-порт (glare + orb + ring, MdGSWy)

// ==== СТИЛЬ 5 (Shadertoy glare/orb/ring, https://www.shadertoy.com/view/MdGSWy) ====
#define LENS_GLARE_5_ENABLED   // тумблер glare-компонента внутри стиля 5
#define LENS_FLARE_5_ENABLED   // тумблер orb+ring-компонента внутри стиля 5
#define GLARE_5_BRIGHTNESS 10.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0 2.5 3.0]
#define FLARE_5_BRIGHTNESS 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0 2.5 3.0]

// Полигональная форма блика — применяется к обоим BSL-стилям (2 и 4).
// 0 = обычный круглый блик. N (3..8) = блик рисуется как N-угольник.
#define LENS_FLARE_POLYGON_SHAPE 3 // [0 3 4 5 6 7 8]
#define LENS_FLARE_SHAPE_ROTATION 0.0 // [0.0 10.0 15.0 20.0 30.0 45.0 60.0 90.0] // поворот полигона, градусы

#define FLARE_GHOSTS 8          // [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15]
#define FLARE_DISPERSION 0.015  // [0.010 0.015 0.020 0.025 0.030 0.035 0.040 0.045 0.050 0.055 0.060 0.065 0.070 0.075 0.080 0.085 0.090 0.095 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] 
#define FLARE_SIZE 0.06         // [0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9]
#define STRETCH_AMOUNT 2.0       // [0.0 0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 5.0] Стиль 3: насколько гексагоны вытягиваются к источнику света чем дальше от центра экрана

#define ANAMORPHIC_LENS_FLARE // [0 1]
#define ANAMORPHIC_STYLE 1 // [1 2] // 1 = аналитическая форма (чистая геометрия, как было) 2 = bloom-driven (donor final.glsl, тянет свет из bloom-атласа colortex4 в позиции источника)
#define ANAMORPHIC_STRENGTH 0.35 // [0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define ANAMORPHIC_COLOR_R 0.07
#define ANAMORPHIC_COLOR_G 0.07
#define ANAMORPHIC_COLOR_B 0.07

// Полностью отдельный тумблер: анаморфная полоска от ЛЮБОГО яркого источника
// на экране (факелы, лава, светящиеся блоки и т.д.), а не только от солнца/луны.
// Работает поверх bloom-буфера (colortex4), поэтому "видит" весь блок-лайт.
//#define ANAMORPHIC_UNIVERSAL_LIGHT // Анаморфная полоса от всех источников света (факелы и т.д.)
    #define ANAMORPHIC_UNIVERSAL_STYLE 3 // [1 2 3] // 1 = point-based полоска (наш алгоритм, тянется от каждого яркого пикселя) 2 = donor bloom-smear (final.glsl, размытие блума по горизонтали) 3 = мультитап лучевая полоса с хроматикой (2 LOD + RGB-разъезд)
    #define ANAMORPHIC_UNIVERSAL_STRENGTH 10.4 // [0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0]
    #define ANAMORPHIC_UNIVERSAL_COLOR_R 0.3
    #define ANAMORPHIC_UNIVERSAL_COLOR_G 0.7
    #define ANAMORPHIC_UNIVERSAL_COLOR_B 1.0
    #define ANAMORPHIC_UNIVERSAL_SAMPLES 32 // [8 12 16 20 24 28 32 40 48 64] // только для стиля 2 (donor) — количество семплов блума вдоль полосы
    #define ANAMORPHIC_UNIVERSAL_MIP 4.5 // [1.0 2.0 3.0 3.5 4.0 4.5 5.0 5.5 6.0 7.0] // только для стиля 2 — мип-уровень bloom-буфера

#define ENABLE_HDR_OUTPUT 0 // [0 1]

#if ENABLE_HDR_OUTPUT == 1
    #define HDRTONEMAP_SHOULDERSTART 36.0

    #define HDRTONEMAP_WHITECLIP 10000.0
#endif

//#define CINEMATIC_EFFECT

#define COLOR_GRADING
#define BRIGHTNESS      1.0  // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0]
#define GAMMA           1.0  // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0]
#define CONTRAST        1.0  // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0]
#define SATURATION      1.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0]
#define WHITE_BALANCE   6500 // [2500 3000 3500 4000 4100 4200 4300 4400 4500 4600 4700 4800 4900 5000 5100 5200 5300 5400 5500 5600 5700 5800 5900 6000 6100 6200 6300 6400 6500 6600 6700 6800 6900 7000 7100 7200 7300 7400 7500 7600 7700 7800 7900 8000 8100 8200 8300 8400 8500 8600 8700 8800 8900 9000 9100 9200 9300 9400 9500 9600 9700 9800 9900 10000 10100 10200 10300 10400 10500 10600 10700 10800 10900 11000 11100 11200 11300 11400 11500 11600 11700 11800 11900 12000]

//#define VIGNETTE_ENABLED
#define VIGNETTE_STRENGTH 1.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0 3.5 4.0 5.0]


#define BLOOM_STYLE 1    // [1 2]


#define SOFT_BLOOM_ENABLED 1 // [0 1]
#define SOFT_BLOOM_AMOUNT 0.1 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 3.5 4.0 5.0]
#define SOFT_BLOOM_RADIUS 5.0 // [0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 6.0 7.0 8.0 10.0]
#define SOFT_BLOOM_QUALITY 3 // [1 2 3 4 5] Количество LOD уровней для мягкого блума

#define DONOR_BLOOM_BLENDING_MODE 2  // [0 1 2]  0=additive, 1=mix, 2=tone-preserve
#define DONOR_BLOOM_INTENSITY 3.5    // [0.0 0.01 0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0 3.0 4.0 5.0 7.0 10.0 15.0 20.0]
#define DONOR_BLOOMY_FOG_INTENSITY 2.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.75 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0 3.5 4.0 5.0]

// ==== НАСТРОЙКИ BLUE SHADOW  ====
#define BLUE_SHADOW_STRENGTH 0.35  // [0.0 0.1 0.2 0.3 0.35 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BLUE_SHADOW_HUE_R 0.4      // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BLUE_SHADOW_HUE_G 0.5      // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BLUE_SHADOW_HUE_B 0.9      // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BLUE_SHADOW_RANGE 0.3      // [0.0 0.1 0.2 0.3 0.4 0.5]




#define AXIAL_BLOOM_ENABLED
#define AXIAL_BLOOM_INTENSITY  0.43  // [0.0 0.05 0.1 0.15 0.2 0.23 0.3 0.4 0.5 0.6 0.8 1.0 1.5 2.0]
#define AXIAL_BLOOM_THRESHOLD  0.0   // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define AXIAL_BLOOM_KNEE       0.1   // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.4 0.5]

// ==== FULLSCREEN BLUR ====
//#define FULLSCREEN_BLUR_ENABLED
#define FULLSCREEN_BLUR_INTENSITY 1.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.5 2.0 3.0 4.0 5.0 6.0 8.0 10.0]
//#define DEBUG_COUNTER

//----------------------------------------------------------------------------//

out vec3 sceneColor;

/* DRAWBUFFERS:3 */

in vec2 screenCoord;

//----// FUNCTIONS //-----------------------------------------------------------------------------//

float ScreenToViewSpace(in float depth) {
    depth = depth * 2.0 - 1.0;
    return 1.0 / (depth * gbufferProjectionInverse[2][3] + gbufferProjectionInverse[3][3]);
}




vec4 BicubicTexture(sampler2D tex, vec2 coord, vec2 texSize) {
    vec2 texPixelSize = 1.0 / texSize;
    coord = coord * texSize - 0.5;

    vec2 p = floor(coord);
    vec2 f = coord - p;

    vec2 ff = f * f;
    vec4 w0, w1;
    
    w0.xz = 1.0 - f;
    w0.xz *= w0.xz * w0.xz;
    w1.yw = ff * f;
    w1.xz = 3.0 * w1.yw + 4.0 - 6.0 * ff;
    w0.yw = 6.0 - w1.xz - w1.yw - w0.xz;

    vec4 s = w0 + w1;
    vec4 c = p.xxyy + vec2(-0.5, 1.5).xyxy + w1 / s;
    c *= texPixelSize.xxyy;

    vec2 m = s.xz / (s.xz + s.yw);
    
    return mix(
        mix(textureLod(tex, c.yw, 0.0), textureLod(tex, c.xw, 0.0), m.x),
        mix(textureLod(tex, c.yz, 0.0), textureLod(tex, c.xz, 0.0), m.x),
        m.y
    );
}


vec2 CalculateTileOffset(int lod) {
    vec2 lodMult = floor(lod * 0.5 + vec2(0.0, 0.5));
    vec2 offset = vec2(1.0 / 3.0, 2.0 / 3.0) * (1.0 - exp2(-2.0 * lodMult));
    return lodMult * 16.0 * screenPixelSize + offset;
}


vec3 BloomUpSample(in sampler2D tex, in int lod, in vec2 coord) {
    float scale = exp2(-lod);
    vec2 sampleCoord = coord * scale + CalculateTileOffset(lod - 1);
    return BicubicTexture(tex, sampleCoord, screenSize).rgb;
}

#if BLOOM_STYLE == 2


vec3 DonorBloomGather(in vec2 coord) {
    vec3 bloom = vec3(0.0);
    bloom += BloomUpSample(colortex4, 1, coord);
    bloom += BloomUpSample(colortex4, 2, coord);
    bloom += BloomUpSample(colortex4, 3, coord);
    bloom += BloomUpSample(colortex4, 4, coord);
    bloom += BloomUpSample(colortex4, 5, coord);
    bloom += BloomUpSample(colortex4, 6, coord);
    bloom += BloomUpSample(colortex4, 7, coord);
    return bloom * (1.0 / 7.0);
}

void CombineBloomAndFogDonor(inout vec3 color, in ivec2 texel, in vec2 coord) {
    vec3 bloomData = DonorBloomGather(coord);

    float bloomIntensity = DONOR_BLOOM_INTENSITY * 0.1;

    #ifdef BLOOMY_FOG
        float fogTransmittance = texelFetch(colortex6, texel, 0).x;
        float fogMask = 1.0 - fogTransmittance;
        bloomIntensity = max(bloomIntensity, fogMask * DONOR_BLOOMY_FOG_INTENSITY);
    #endif

    // ---- Dirty Lens ----
    #if DIRT_STYLE > 0
    {
        float newAspectRatio = 1.777777777777778 / aspectRatio;
        vec2 scale = vec2(max(newAspectRatio, 1.0), max(1.0 / newAspectRatio, 1.0));
        vec2 dirtCoord = (coord - 0.5) / scale + 0.5;

        float dirt = texture2D(DIRTY_LENS_SAMPLER, dirtCoord).r;
        float brightness = length(bloomData / (1.0 + bloomData));
        dirt *= brightness * DIRTY_LENS_STRENGTH;

        #ifdef DIRTY_LENS_BLOOM_BOOST
            bloomData *= (dirt * DIRTY_LENS_BLOOM_STRENGTH + 1.0);
        #else
            bloomData *= (dirt * 16.0 + 1.0);
        #endif
    }
    #endif

 
    float exposure = texelFetch(colortex5, ivec2(0), 0).a;
    bloomIntensity /= max(exposure, 1.0) + 1.0;

    #if DONOR_BLOOM_BLENDING_MODE == 0
        color += bloomData * bloomIntensity;
    #elif DONOR_BLOOM_BLENDING_MODE == 1
        color = mix(color, bloomData, bloomIntensity);
    #else
        color = (color + bloomData * bloomIntensity) / (1.0 + bloomIntensity * 0.5);
    #endif


    #if !defined IS_NETHER
        if (isEyeInWater == 0 && wetness > 1e-2) {
            float rain = texelFetch(colortex0, texel, 0).b * 0.35;
            color = color * (1.0 - rain) + bloomData * rain * 1.25;
        }
    #endif
}
#endif


float HexagonDist(vec2 p) {
    p = abs(p);
    float d = dot(p, normalize(vec2(1.0, 1.73205081)));
    return max(d, p.x);
}

// ====================================================================
// СТИЛЬ 1: хексагоны, оригинальная версия (центровка "уезжает" при
// aspectRatio != 1, т.к. умножение на aspect применяется ПОСЛЕ вычитания
// позиции, а значит растягивает само пространство вокруг (0,0), а не
// вокруг pos). Оставлено как есть для сравнения/отката.
// ====================================================================
vec3 GetHexFlareStyle1(vec2 uv, vec2 lightPos, vec3 lightColor, float intensity) {
    vec2 ghostVec = (lightPos - vec2(0.5));
    vec2 ghostDir = normalize(ghostVec);
    vec3 flare = vec3(0.0);

    vec2 rShift = ghostDir * FLARE_DISPERSION;
    vec2 bShift = -ghostDir * FLARE_DISPERSION;

    vec2 aspect = vec2(aspectRatio, 1.0);

    for (int i = 1; i <= FLARE_GHOSTS; ++i) {
        float offset = 1.0 - float(i) * 0.4;
        vec2 pos = lightPos + ghostVec * offset;

        float hexR = smoothstep(FLARE_SIZE, FLARE_SIZE - 0.01, HexagonDist((uv - pos + rShift) * aspect));
        float hexG = smoothstep(FLARE_SIZE, FLARE_SIZE - 0.01, HexagonDist((uv - pos) * aspect));
        float hexB = smoothstep(FLARE_SIZE, FLARE_SIZE - 0.01, HexagonDist((uv - pos + bShift) * aspect));

        float weight = 1.0 / (float(i) + 1.0);
        flare += vec3(hexR, hexG, hexB) * weight;
    }

    return flare * lightColor * intensity;
}

// ====================================================================
// СТИЛЬ 3: те же хексагоны, но с правильной центровкой + вытягивание
// гексагонов вдоль луча "центр экрана -> источник света", как в
// референсных cinematic lens flare (чем дальше блик от центра, тем
// сильнее он растянут вдоль этого луча).
//
// Фикс центровки: работаем в системе координат, центрированной на
// (0,0) = центр экрана, а не на угол (0,0) = угол экрана. Именно
// потеря центрирования (все вычисления шли в координатах [0..1])
// была причиной того, что гексагоны "уезжали" от источника света.
// ====================================================================
vec3 GetHexFlareStyle3(vec2 uv, vec2 lightPos, vec3 lightColor, float intensity) {
    vec2 aspect = vec2(aspectRatio, 1.0);

    // Центрируем UV и позицию источника на (0,0) и переводим в aspect-space.
    vec2 uvC     = (uv - 0.5) * aspect;
    vec2 lightC  = (lightPos - 0.5) * aspect;

    // ghostVec идёт от источника света к центру экрана (0,0) -> блики
    // "нанизаны" на прямую, проходящую через центр и через солнце/луну.
    vec2 ghostVec = lightC;
    float ghostLen = length(ghostVec);
    vec2 ghostDir = ghostLen > 1e-5 ? ghostVec / ghostLen : vec2(0.0, 1.0);

    vec2 rShift = ghostDir * FLARE_DISPERSION * aspect;
    vec2 bShift = -ghostDir * FLARE_DISPERSION * aspect;

    // Ортогональный базис вдоль/поперёк луча к источнику, чтобы растягивать
    // гексагон только по направлению к камере/источнику, а не по всем осям.
    vec2 axisAlong = ghostDir;
    vec2 axisAcross = vec2(-ghostDir.y, ghostDir.x);

    vec3 flare = vec3(0.0);

    for (int i = 1; i <= FLARE_GHOSTS; ++i) {
        float offset = 1.0 - float(i) * 0.4;
        vec2 posC = lightC + ghostVec * offset;

        // Чем дальше блик от центра экрана, тем сильнее он вытянут
        // "вперёд" вдоль луча к источнику (классический stretched ghost).
        float posDist = length(posC);
        float stretch = 1.0 + posDist * STRETCH_AMOUNT;

        vec2 d = uvC - posC;
        // Раскладываем на составляющую вдоль луча и поперёк, сжимаем
        // вдоль-компоненту (что визуально растягивает сам гексагон вдоль луча).
        vec2 dLocal = vec2(dot(d, axisAlong) / stretch, dot(d, axisAcross));

        float hexR = smoothstep(FLARE_SIZE, FLARE_SIZE - 0.01, HexagonDist(dLocal + vec2(dot(rShift, axisAlong) / stretch, dot(rShift, axisAcross))));
        float hexG = smoothstep(FLARE_SIZE, FLARE_SIZE - 0.01, HexagonDist(dLocal));
        float hexB = smoothstep(FLARE_SIZE, FLARE_SIZE - 0.01, HexagonDist(dLocal + vec2(dot(bShift, axisAlong) / stretch, dot(bShift, axisAcross))));

        float weight = 1.0 / (float(i) + 1.0);
        flare += vec3(hexR, hexG, hexB) * weight;
    }

    return flare * lightColor * intensity;
}

// ====================================================================
// СТИЛЬ 2: порт LensFlare.glsl из BSL. Даёт кольца/точки/овербликов
// в духе BSL вместо хексагонов. intensity используется как множитель
// lensFlareFactor, lightColor определяет тинт (день/ночь считается
// через sunVisibility/moonVisibility, доступные из атмосферных юниформ).
// ====================================================================
float fovmultBSL = gbufferProjection[1][1] / 1.37373871;

// ====================================================================
// POLYGON SHAPE HELPER — общий для всех BSL-based стилей (2 и 4).
// Если LENS_FLARE_POLYGON_SHAPE == 0, блики остаются круглыми — эта
// функция просто не влияет на форму (см. BSL_BaseLens ниже).
// ====================================================================
vec2 GetLensFlarePolygonOffset(float angle, int sides, float radius) {
    float rotationRadians = LENS_FLARE_SHAPE_ROTATION * (3.14159265 / 180.0);
    angle += rotationRadians;

    float segmentAngle = 2.0 * 3.14159265 / float(sides);
    float r = cos(3.14159265 / float(sides)) / cos(mod(angle, segmentAngle) - 3.14159265 / float(sides));
    r *= radius;

    return vec2(sin(angle), cos(angle)) * r;
}

// ВАЖНО: uv и lightPos сюда приходят уже ЦЕНТРИРОВАННЫМИ на (0,0) = центр
// экрана (см. GetLensFlareStyle2/4, где это центрирование делается один раз
// на входе). Раньше формула ожидала центрированные координаты, а получала
// [0..1], из-за чего вся конструкция бликов уезжала в сторону от солнца/луны.
float BSL_BaseLens(vec2 lightPos, vec2 uv, float size, float dist, float hardness) {
    vec2 lensCoord = (uv + lightPos * dist) * vec2(aspectRatio, 1.0);

    #if LENS_FLARE_POLYGON_SHAPE >= 3
        float radius = length(lensCoord);
        float angle = atan(lensCoord.y, lensCoord.x);
        float polyRadius = length(GetLensFlarePolygonOffset(angle, LENS_FLARE_POLYGON_SHAPE, 1.0));
        float adjustedRadius = radius / max(polyRadius, 1e-5);
        float lens = clamp(1.0 - adjustedRadius / (size * fovmultBSL), 0.0, 1.0 / hardness) * hardness;
    #else
        float lens = clamp(1.0 - length(lensCoord) / (size * fovmultBSL), 0.0, 1.0 / hardness) * hardness;
    #endif

    lens *= lens; lens *= lens;
    return lens;
}

float BSL_OverlapLens(vec2 lightPos, vec2 uv, float size, float dista, float distb) {
    return BSL_BaseLens(lightPos, uv, size, dista, 2.0) * BSL_BaseLens(lightPos, uv, size, distb, 2.0);
}

float BSL_PointLens(vec2 lightPos, vec2 uv, float size, float dist) {
    return BSL_BaseLens(lightPos, uv, size, dist, 1.5) + BSL_BaseLens(lightPos, uv, size * 4.0, dist, 1.0) * 0.5;
}

float BSL_RingLensTransform(float lensFlare) {
    return pow(1.0 - pow(1.0 - pow(lensFlare, 0.25), 10.0), 5.0);
}
float BSL_RingLens(vec2 lightPos, vec2 uv, float size, float distA, float distB) {
    float lensFlare1 = BSL_RingLensTransform(BSL_BaseLens(lightPos, uv, size, distA, 1.0));
    float lensFlare2 = BSL_RingLensTransform(BSL_BaseLens(lightPos, uv, size, distB, 1.0));

    float lensFlare = clamp(lensFlare2 - lensFlare1, 0.0, 1.0);
    lensFlare *= sqrt(lensFlare);
    return lensFlare;
}

vec3 BSL_RainbowLens(vec2 lightPos, vec2 uv, float size, float dist, float rad) {
    vec2 lensCoord = (uv + lightPos * dist) * vec2(aspectRatio, 1.0);
    float lens = clamp(1.0 - length(lensCoord) / (size * fovmultBSL), 0.0, 1.0);

    vec3 rainbowLens =
        (smoothstep(0.0, rad, lens) - smoothstep(rad, rad * 2.0, lens)) * vec3(1.0, 0.0, 0.0) +
        (smoothstep(rad * 0.5, rad * 1.5, lens) - smoothstep(rad * 1.5, rad * 2.5, lens)) * vec3(0.0, 1.0, 0.0) +
        (smoothstep(rad, rad * 2.0, lens) - smoothstep(rad * 2.0, rad * 3.0, lens)) * vec3(0.0, 0.0, 1.0)
    ;

    return rainbowLens;
}
vec3 GetLensFlareStyle2(vec2 uv, vec2 lightPos, vec3 lightColor, float intensity) {
    // Центрируем один раз на входе: (0,0) = центр экрана.
    vec2 uvC = uv - 0.5;
    vec2 lightC = lightPos - 0.5;

    vec3 lensFlare = vec3(0.0);
    float falloffBase = length(lightC * vec2(aspectRatio, 1.0));
    float falloffIn = pow(clamp(falloffBase * 10.0, 0.0, 1.0), 2.0);
    float falloffOut = clamp(falloffBase * 3.0 - 1.5, 0.0, 1.0);

    if (falloffOut < 0.999) {
        lensFlare = (
            BSL_BaseLens(lightC, uvC, 0.3, -0.45, 1.0) * vec3(2.2, 1.2, 0.1) * 1.07 +
            BSL_BaseLens(lightC, uvC, 0.3,  0.10, 1.0) * vec3(2.2, 0.4, 0.1) * 1.03 +
            BSL_BaseLens(lightC, uvC, 0.3,  0.30, 1.0) * vec3(2.2, 0.2, 0.1) * 1.04 +
            BSL_BaseLens(lightC, uvC, 0.3,  0.50, 1.0) * vec3(2.2, 0.4, 2.5) * 1.05 +
            BSL_BaseLens(lightC, uvC, 0.3,  0.70, 1.0) * vec3(1.8, 0.4, 2.5) * 1.06 +
            BSL_BaseLens(lightC, uvC, 0.3,  0.95, 1.0) * vec3(0.1, 0.2, 2.5) * 1.10 +
            BSL_BaseLens(lightC, uvC, 0.3,  1.15, 1.0) * vec3(0.08, 0.1,2.8) * 1.12 +
            BSL_BaseLens(lightC, uvC, 0.3,  1.35, 1.0) * vec3(0.04, 0.1,3.4) * 1.14 +

            BSL_OverlapLens(lightC, uvC, 0.18, -0.30, -0.41) * vec3(2.5, 1.2, 0.1) * 1.010 +
            BSL_OverlapLens(lightC, uvC, 0.16, -0.18, -0.29) * vec3(2.5, 0.5, 0.1) * 1.020 +
            BSL_OverlapLens(lightC, uvC, 0.15,  0.06,  0.19) * vec3(2.5, 0.2, 0.1) * 1.015 +
            BSL_OverlapLens(lightC, uvC, 0.14,  0.15,  0.28) * vec3(1.8, 0.1, 1.2) * 1.015 +
            BSL_OverlapLens(lightC, uvC, 0.16,  0.24,  0.37) * vec3(1.0, 0.1, 2.5) * 1.015 +

            BSL_PointLens(lightC, uvC, 0.03, -0.55) * vec3(2.5, 1.6, 0.0) * 1.20 +
            BSL_PointLens(lightC, uvC, 0.02, -0.40) * vec3(2.5, 1.0, 0.0) * 1.15 +
            BSL_PointLens(lightC, uvC, 0.04,  0.43) * vec3(2.5, 0.6, 0.6) * 1.20 +
            BSL_PointLens(lightC, uvC, 0.02,  0.60) * vec3(0.2, 0.6, 2.5) * 1.15 +
            BSL_PointLens(lightC, uvC, 0.03,  0.67) * vec3(0.2, 1.6, 2.5) * 1.25 +
            BSL_PointLens(lightC, uvC, 0.03,  0.73) * vec3(0.2, 1.9, 2.5) * 1.35 +

            BSL_RingLens(lightC, uvC, 0.25, 0.43, 0.45) * vec3(0.10, 0.35, 2.50) * 1.5 +
            BSL_RingLens(lightC, uvC, 0.18, 0.98, 0.99) * vec3(0.15, 1.00, 2.55) * 1.5
        ) * (falloffIn - falloffOut) + (
            BSL_RainbowLens(lightC, uvC, 0.525, -1.0, 0.2) * 0.05 +
            BSL_RainbowLens(lightC, uvC, 2.0, 4.0, 0.1) * 0.05
        ) * (1.0 - falloffOut);

        // --- ДОБАВЛЕННЫЙ БЛОК ДЛЯ НОЧИ ---
        // Если это луна (синего канала больше, чем красного)
        if (lightColor.b > lightColor.r) {
            // Вычисляем общую яркость (Luma) жестко прописанных цветных бликов
            float luma = dot(lensFlare, vec3(0.2126, 0.7152, 0.0722));
            
            // Задаем серо-бледно-голубой оттенок (можешь покрутить эти цифры для идеального цвета)
            vec3 nightTint = vec3(0.55, 0.70, 0.85); 
            
            // Применяем оттенок к обесцвеченному блику
            lensFlare = vec3(luma) * nightTint;
            
            // Сбрасываем входящий цвет луны до белого, чтобы избежать 
            // перенасыщения синим при умножении строчкой ниже
            lightColor = vec3(1.0); 
        }
        // ---------------------------------

        lensFlare *= lightColor * intensity;
    }

    return lensFlare;
}

// ====================================================================
// СТИЛЬ 4 — прямой порт донорского BSL lens flare (второй вариант,
// добавлен как отдельный независимый стиль, Style 2 не тронут).
// Отличия от Style 2:
//   - PointLens дополнительно взвешен по sunFactor (мягче у горизонта),
//     если такая переменная объявлена в проекте;
//   - RingLens дополнительно затухает по расстоянию до пикселя;
//   - меньше "ступеней" бликов (упрощённый набор коэффициентов донора);
//   - поддерживает LENS_FLARE_POLYGON_SHAPE через общий BSL_BaseLens
//     (то есть можно сделать полигональные блики и для Style 2, и для Style 4).
// Блендинг в этот раз ОСТАВЛЕН аддитивным (color += ...), как и у
// остальных стилей в этом файле — единообразно с твоим текущим main().
// ====================================================================
float BSL4_PointLens(vec2 lightPos, vec2 uv, float size, float dist) {
    float lens = BSL_BaseLens(lightPos, uv, size, dist, 1.5) + BSL_BaseLens(lightPos, uv, size * 4.0, dist, 1.0) * 0.5;
    #ifdef sunFactor
        lens *= (0.5 + 0.5 * sunFactor);
    #endif
    return lens;
}

float BSL4_RingLens(vec2 lightPos, vec2 uv, float size, float distA, float distB) {
    float lensFlare1 = BSL_RingLensTransform(BSL_BaseLens(lightPos, uv, size, distA, 1.0));
    float lensFlare2 = BSL_RingLensTransform(BSL_BaseLens(lightPos, uv, size, distB, 1.0));

    float lensFlare = clamp(lensFlare2 - lensFlare1, 0.0, 1.0);
    lensFlare *= sqrt(lensFlare);

    // затухание по расстоянию от источника до текущего пикселя (как в доноре)
    lensFlare *= clamp(1.0 - length(uv - lightPos), 0.0, 1.0);
    return lensFlare;
}

vec3 GetLensFlareStyle4(vec2 uv, vec2 lightPos, vec3 lightColor, float intensity) {
    vec2 uvC = uv - 0.5;
    vec2 lightC = lightPos - 0.5;

    vec3 lensFlare = vec3(0.0);
    float falloffBase = length(lightC * vec2(aspectRatio, 1.0));
    float falloffIn = pow(clamp(falloffBase * 8.0, 0.0, 1.0), 2.0);
    float falloffOut = clamp(falloffBase * 3.0 - 1.5, 0.0, 1.0);
    float flareFactor = falloffIn - falloffOut;

    if (falloffOut < 0.999) {
        lensFlare = (
            BSL_BaseLens(lightC, uvC, 0.3, -0.45, 1.0) * vec3(2.2, 1.2, 0.1) * 0.07 +
            BSL_BaseLens(lightC, uvC, 0.3,  0.10, 1.0) * vec3(2.2, 0.4, 0.1) * 0.03 +
            BSL_BaseLens(lightC, uvC, 0.3,  0.30, 1.0) * vec3(2.2, 0.2, 0.1) * 0.04 +
            BSL_BaseLens(lightC, uvC, 0.3,  0.50, 1.0) * vec3(2.2, 0.4, 2.5) * 0.05 +
            BSL_BaseLens(lightC, uvC, 0.3,  0.70, 1.0) * vec3(1.8, 0.4, 2.5) * 0.06 +
            BSL_BaseLens(lightC, uvC, 0.3,  0.90, 1.0) * vec3(0.1, 0.2, 2.5) * 0.07 +

            BSL_OverlapLens(lightC, uvC, 0.08, -0.28, -0.39) * vec3(2.5, 1.2, 0.1) * 0.015 +
            BSL_OverlapLens(lightC, uvC, 0.08, -0.20, -0.31) * vec3(2.5, 0.5, 0.1) * 0.010 +
            BSL_OverlapLens(lightC, uvC, 0.12,  0.06,  0.19) * vec3(2.5, 0.2, 0.1) * 0.020 +
            BSL_OverlapLens(lightC, uvC, 0.12,  0.15,  0.28) * vec3(1.8, 0.1, 1.2) * 0.015 +
            BSL_OverlapLens(lightC, uvC, 0.12,  0.24,  0.37) * vec3(1.0, 0.1, 2.5) * 0.010 +

            BSL4_PointLens(lightC, uvC, 0.03, -0.55) * vec3(2.5, 1.6, 0.0) * 0.06 +
            BSL4_PointLens(lightC, uvC, 0.02, -0.40) * vec3(2.5, 1.0, 0.0) * 0.045 +
            BSL4_PointLens(lightC, uvC, 0.04,  0.43) * vec3(2.5, 0.6, 0.6) * 0.06 +
            BSL4_PointLens(lightC, uvC, 0.02,  0.60) * vec3(0.2, 0.6, 2.5) * 0.045 +
            BSL4_PointLens(lightC, uvC, 0.03,  0.67) * vec3(0.7, 1.1, 3.0) * 0.075 +

            BSL4_RingLens(lightC, uvC, 0.22, 0.44, 0.46) * vec3(0.10, 0.35, 2.50) * 1.5 +
            BSL4_RingLens(lightC, uvC, 0.15, 0.98, 0.99) * vec3(0.15, 0.40, 2.55) * 2.5
        );

        // Ночной тинт для луны — тот же приём, что и в Style 2
        if (lightColor.b > lightColor.r) {
            float luma = dot(lensFlare, vec3(0.2126, 0.7152, 0.0722));
            vec3 nightTint = vec3(0.55, 0.70, 0.85);
            lensFlare = vec3(luma) * nightTint;
            lightColor = vec3(1.0);
        }

        lensFlare *= lightColor * intensity * flareFactor;
    }

    return lensFlare;
}




// ====================================================================
// ANAMORPHIC LENS FLARE — горизонтальная "кино" полоса через источник
// света, характерная для анаморфной оптики. Работает поверх любого из
// стилей выше (тумблер ANAMORPHIC_LENS_FLARE).
// ====================================================================
#ifdef ANAMORPHIC_LENS_FLARE

// --- Style 1: аналитическая полоса (форма через length/pow), как было ---
vec3 GetAnamorphicFlareStyle1(vec2 uv, vec2 lightPos, vec3 lightColor) {
    // растягиваем по X (полоса), почти не даём растяжения по Y
    vec2 lensCoord = abs(uv - lightPos) * vec2(aspectRatio * 0.07, 2.0);
    float lens = clamp(1.0 - length(pow(lensCoord, vec2(0.85))) * 4.0, 0.0, 1.0);
    lens *= lens * lens;

    // лёгкая хроматика по краям полосы для реалистичности
    vec2 lensCoordR = abs(uv - lightPos + vec2(0.0015, 0.0)) * vec2(aspectRatio * 0.07, 2.0);
    vec2 lensCoordB = abs(uv - lightPos - vec2(0.0015, 0.0)) * vec2(aspectRatio * 0.07, 2.0);
    float lensR = clamp(1.0 - length(pow(lensCoordR, vec2(0.85))) * 4.0, 0.0, 1.0); lensR *= lensR * lensR;
    float lensB = clamp(1.0 - length(pow(lensCoordB, vec2(0.85))) * 4.0, 0.0, 1.0); lensB *= lensB * lensB;

    vec3 anamorphic = vec3(lensR, lens, lensB);
    return anamorphic * lightColor * ANAMORPHIC_STRENGTH;
}

// --- Style 2: bloom-driven полоса (donor final.glsl, calcBloomBasedAnamorphicLens) ---
// В отличие от style 1 (чистая аналитическая форма), здесь полоса реально
// "тянет" свет из bloom-атласа (colortex4) вдоль горизонтали от позиции
// источника — так же, как донор растягивал gaux4, но с привязкой к
// конкретному lightPos (солнце/луна), а не по всему экрану.
vec3 GetAnamorphicFlareStyle2(vec2 uv, vec2 lightPos, vec3 lightColor) {
    vec2  aspectCorrect = vec2(1.0, aspectRatio);
    float bloomSample   = 0.0;

    const int uSamples = 24;
    const int uLod     = 3;

    for (int i = 0; i < uSamples; i++) {
        float offset = pow(exp(float(i)), 0.1) * 0.016;

        vec3 sR = BloomUpSample(colortex4, uLod, lightPos + vec2(offset, 0.0) * aspectCorrect);
        vec3 sL = BloomUpSample(colortex4, uLod, lightPos - vec2(offset, 0.0) * aspectCorrect);

        bloomSample += pow(dot(sR, vec3(0.333)), 2.2);
        bloomSample += pow(dot(sL, vec3(0.333)), 2.2);
    }

    bloomSample /= float(uSamples) * 2.0;

    // сама полоса всё ещё должна быть видна только вдоль горизонтали через
    // источник, поэтому маскируем результат аналитической формой по Y
    vec2  lensCoord = abs(uv - lightPos) * vec2(aspectRatio * 0.07, 2.0);
    float mask = clamp(1.0 - length(pow(lensCoord, vec2(0.85))) * 4.0, 0.0, 1.0);
    mask *= mask * mask;

    return lightColor * bloomSample * mask * ANAMORPHIC_STRENGTH * 5.0;
}

vec3 GetAnamorphicFlare(vec2 uv, vec2 lightPos, vec3 lightColor) {
    #if ANAMORPHIC_STYLE == 2
        return GetAnamorphicFlareStyle2(uv, lightPos, lightColor);
    #else
        return GetAnamorphicFlareStyle1(uv, lightPos, lightColor);
    #endif
}
#endif


#ifdef ANAMORPHIC_UNIVERSAL_LIGHT


#if ANAMORPHIC_UNIVERSAL_STYLE == 1
vec3 GetUniversalAnamorphicStyle1(vec2 coord) {
    vec3 result = vec3(0.0);

    const int   uSamples = 24;
    const float uSpread  = 0.05;
    const int   uLod     = 2; // берём менее размытый LOD, чтобы полоска была резче

    vec2 aspectCorrect = vec2(1.0, aspectRatio);


    vec3  centerSample = BloomUpSample(colortex4, uLod, coord);
    float centerLuma   = dot(centerSample, vec3(0.2126, 0.7152, 0.0722));

    for (int i = 1; i <= uSamples; i++) {
        float t = float(i) / float(uSamples);
  
        float falloff = pow(1.0 - t, 4.0);

        float offset = t * uSpread;

        vec3 sR = BloomUpSample(colortex4, uLod, coord + vec2(offset, 0.0) * aspectCorrect);
        vec3 sL = BloomUpSample(colortex4, uLod, coord - vec2(offset, 0.0) * aspectCorrect);

        result += (sR + sL) * falloff;
    }

    result /= float(uSamples);


    result *= centerLuma;

    vec3 tint = vec3(ANAMORPHIC_UNIVERSAL_COLOR_R, ANAMORPHIC_UNIVERSAL_COLOR_G, ANAMORPHIC_UNIVERSAL_COLOR_B);
    return result * tint * ANAMORPHIC_UNIVERSAL_STRENGTH;
}
#endif


#if ANAMORPHIC_UNIVERSAL_STYLE == 2
vec3 GetUniversalAnamorphicStyle2(vec2 coord) {
    vec2  aspectCorrect = vec2(1.0, aspectRatio);
    float bloomSample   = 0.0;

    // ANAMORPHIC_UNIVERSAL_MIP
    const int uLod = int(ANAMORPHIC_UNIVERSAL_MIP);

    for (int i = 0; i < ANAMORPHIC_UNIVERSAL_SAMPLES; i++) {
        float offset = pow(exp(float(i)), 0.1) * 0.016;

        vec3 sR = BloomUpSample(colortex4, uLod, coord + vec2(offset, 0.0) * aspectCorrect);
        vec3 sL = BloomUpSample(colortex4, uLod, coord - vec2(offset, 0.0) * aspectCorrect);

        bloomSample += pow(dot(sR, vec3(0.333)), 2.2);
        bloomSample += pow(dot(sL, vec3(0.333)), 2.2);
    }

    bloomSample /= float(ANAMORPHIC_UNIVERSAL_SAMPLES) * 2.0;

    vec3 tint = vec3(ANAMORPHIC_UNIVERSAL_COLOR_R, ANAMORPHIC_UNIVERSAL_COLOR_G, ANAMORPHIC_UNIVERSAL_COLOR_B);
    return tint * bloomSample * ANAMORPHIC_UNIVERSAL_STRENGTH * 5.0; // *5.0 — как bloomIntensity донора
}
#endif

#if ANAMORPHIC_UNIVERSAL_STYLE == 3
vec3 GetUniversalAnamorphicStyle3(vec2 coord) {
    vec3 result = vec3(0.0);

    const int   uSamples   = 20;
    const float uSpread    = 0.05;
    const float uChromaOff = 0.0025;

    vec2 aspectCorrect = vec2(1.0, aspectRatio);

    vec3  centerSample = BloomUpSample(colortex4, 2, coord);
    float centerLuma   = dot(centerSample, vec3(0.2126, 0.7152, 0.0722));

    for (int i = 1; i <= uSamples; i++) {
        float t = float(i) / float(uSamples);
        float falloff = pow(1.0 - t, 3.0);
        float offset = t * uSpread;


        vec3 sR1 = BloomUpSample(colortex4, 2, coord + vec2(offset, 0.0) * aspectCorrect);
        vec3 sL1 = BloomUpSample(colortex4, 2, coord - vec2(offset, 0.0) * aspectCorrect);
        vec3 sR2 = BloomUpSample(colortex4, 4, coord + vec2(offset, 0.0) * aspectCorrect);
        vec3 sL2 = BloomUpSample(colortex4, 4, coord - vec2(offset, 0.0) * aspectCorrect);

        vec3 smpl = (sR1 + sL1) * 0.6 + (sR2 + sL2) * 0.4;


        float chromaR = 1.0 + uChromaOff;
        float chromaB = 1.0 - uChromaOff;
        smpl.r *= falloff * chromaR;
        smpl.b *= falloff * chromaB;
        smpl.g *= falloff;

        result += smpl;
    }

    result /= float(uSamples);


    result *= centerLuma;

    vec3 tint = vec3(ANAMORPHIC_UNIVERSAL_COLOR_R, ANAMORPHIC_UNIVERSAL_COLOR_G, ANAMORPHIC_UNIVERSAL_COLOR_B);
    return result * tint * ANAMORPHIC_UNIVERSAL_STRENGTH;
}
#endif

vec3 GetUniversalAnamorphicLight(vec2 coord) {
    #if ANAMORPHIC_UNIVERSAL_STYLE == 2
        return GetUniversalAnamorphicStyle2(coord);
    #elif ANAMORPHIC_UNIVERSAL_STYLE == 3
        return GetUniversalAnamorphicStyle3(coord);
    #else
        return GetUniversalAnamorphicStyle1(coord);
    #endif
}
#endif


// ====================================================================
// СТИЛЬ 5 — порт shadertoy-lens flare (MdGSWy: glare + orb + ring).
// В отличие от донора этот вариант не использует внешние uniform'ы
// (colorSunlight/sunVisibility/VFOG_DENSITY/MAIN_OUTPUT_FACTOR) —
// цвет и модуляция берутся так же, как у остальных стилей в этом
// файле: через lightColor/intensity, которые уже приходят из main()
// (тёплый белый для солнца, холодный голубоватый для луны).
// Сигнатура функций такая же, как у стилей 1-4: (uv, lightPos, lightColor, intensity),
// uv и lightPos — в координатах экрана [0..1], центрирование делается внутри.
// ====================================================================

#define ORB_FLARE_5_COUNT   6.0
#define DISTORTION_5_BARREL 1.0

vec2 GetDistOffset5(vec2 uv, vec2 pxoffset) {
    vec2 tocenter = uv.xy;
    vec3 prep = normalize(vec3(tocenter.y, -tocenter.x, 0.0));

    float angle = length(tocenter.xy) * 2.221 * DISTORTION_5_BARREL;
    vec3 oldoffset = vec3(pxoffset, 0.0);

    vec3 rotated = oldoffset * cos(angle) + cross(prep, oldoffset) * sin(angle) + prep * dot(prep, oldoffset) * (1.0 - cos(angle));

    return rotated.xy;
}

vec3 GetFlare5(vec2 uv, vec2 pos, float dist, float chromaOffset, float size) {
    pos = GetDistOffset5(uv, pos);

    float r = max(0.01 - pow(length(uv + (dist - chromaOffset) * pos), 2.4) * (1.0 / (size * 2.0)), 0.0) * 0.85;
    float g = max(0.01 - pow(length(uv +  dist                 * pos), 2.4) * (1.0 / (size * 2.0)), 0.0) * 1.0;
    float b = max(0.01 - pow(length(uv + (dist + chromaOffset) * pos), 2.4) * (1.0 / (size * 2.0)), 0.0) * 1.5;

    return vec3(r, g, b);
}

vec3 GetOrb5(vec2 uv, vec2 pos, float dist, float size) {
    vec3 c = vec3(0.0);

    for (float i = 0.0; i < ORB_FLARE_5_COUNT; i++) {
        float j = i + 1.0;
        float offset = j / (j + 0.1);
        float colOffset = j / ORB_FLARE_5_COUNT * 0.5;

        float ss = size / (j + 1.0);

        c += GetFlare5(uv, pos, dist + offset, ss * 2.0, ss) * vec3(1.0 - colOffset, 1.0, 0.5 + colOffset) * j;
    }

    c += GetFlare5(uv, pos, dist + 0.8, 0.05, 3.0 * size) * 0.5;

    return c;
}

vec3 GetRing5(vec2 uv, vec2 pos, float dist, float chromaOffset, float blur) {
    vec2 uvd = uv * length(uv);

    float r = max(1.0 / (1.0 + 250.0 * pow(length(uvd + (dist - chromaOffset) * pos), blur)), 0.0) * 0.8;
    float g = max(1.0 / (1.0 + 250.0 * pow(length(uvd +  dist                 * pos), blur)), 0.0) * 1.0;
    float b = max(1.0 / (1.0 + 250.0 * pow(length(uvd + (dist + chromaOffset) * pos), blur)), 0.0) * 1.5;

    return vec3(r, g, b);
}

vec3 GetLensFlareStyle5(vec2 uv, vec2 lightPos, vec3 lightColor, float intensity) {
    vec3 lf = vec3(0.0);

    // Центрируем на (0,0) = центр экрана и учитываем aspect, как в доноре.
    vec2 coord  = uv - 0.5;
    vec2 sunPos = lightPos - 0.5;
    coord.x  *= aspectRatio;
    sunPos.x *= aspectRatio;

    float fovFactor = max(gbufferProjection[1][1], 2.0);

    #ifdef LENS_GLARE_5_ENABLED
        vec2  v     = coord - sunPos;
        float dist  = length(v);
        float gDist = dist * 13.0 / fovFactor;
        float phase = atan(v.y, v.x) + 0.131;

        float gl = 2.0 - clamp(gDist, 0.0, 1.0) + sin(phase * 12.0) * clamp(gDist * 2.5 - 0.2, 0.0, 1.0);
        gl = gl * gl;
        gDist = gDist * gDist;
        gl *= 8e-5 / (gDist * gDist);
        gl = min(gl, 200.0);

        lf += vec3(gl * GLARE_5_BRIGHTNESS);
    #endif

    #ifdef LENS_FLARE_5_ENABLED
        float size = 0.5 * fovFactor;
        vec3  fl   = vec3(0.0);

        fl += GetOrb5(coord, sunPos, 0.0, size * 0.01) * 0.1;
        fl += GetRing5(coord, sunPos,  1.0, 0.02, 1.4) * 0.01;
        fl += GetRing5(coord, sunPos, -1.0, 0.02, 1.4) * 0.01;

        fl += GetFlare5(coord, sunPos, -2.00, 0.05, size * 0.05) * 0.5;
        fl += GetFlare5(coord, sunPos, -0.90, 0.02, size * 0.03) * 0.3;
        fl += GetFlare5(coord, sunPos, -0.70, 0.01, size * 0.06) * 0.5;
        fl += GetFlare5(coord, sunPos, -0.55, 0.02, size * 0.02) * 0.2;
        fl += GetFlare5(coord, sunPos, -0.35, 0.02, size * 0.04) * 0.7;
        fl += GetFlare5(coord, sunPos, -0.25, 0.01, size * 0.15) * vec3(0.3, 0.4, 0.38);
        fl += GetFlare5(coord, sunPos, -0.25, 0.02, size * 0.08) * 0.2;
        fl += GetFlare5(coord, sunPos,  0.05, 0.01, size * 0.03) * 0.1;
        fl += GetFlare5(coord, sunPos,  0.30, 0.02, size * 0.20) * vec3(0.2, 0.18, 0.14);
        fl += GetFlare5(coord, sunPos,  1.20, 0.03, size * 0.10) * 0.2;

        lf += fl * (FLARE_5_BRIGHTNESS * 0.3);
    #endif

    // Модуляция цветом/яркостью светила — так же, как у стилей 1-4:
    // берём lightColor и intensity, приходящие из main() (там уже
    // задано тёплое солнце / холодная луна), внешние uniform'ы донора
    // (colorSunlight, sunVisibility, VFOG_DENSITY, MAIN_OUTPUT_FACTOR) не используются.
    lf *= lightColor * intensity;

    return lf;
}


vec3 GetLensFlareUnified(vec2 uv, vec2 lightPos, vec3 lightColor, float intensity) {
    vec3 flare = vec3(0.0);

    #if LENS_FLARE_STYLE == 1
        flare = GetHexFlareStyle1(uv, lightPos, lightColor, intensity);
    #elif LENS_FLARE_STYLE == 2
        flare = GetLensFlareStyle2(uv, lightPos, lightColor, intensity);
    #elif LENS_FLARE_STYLE == 4
        flare = GetLensFlareStyle4(uv, lightPos, lightColor, intensity);
    #elif LENS_FLARE_STYLE == 5
        flare = GetLensFlareStyle5(uv, lightPos, lightColor, intensity);
    #else
        flare = GetHexFlareStyle3(uv, lightPos, lightColor, intensity);
    #endif

    #ifdef ANAMORPHIC_LENS_FLARE
        flare += GetAnamorphicFlare(uv, lightPos, lightColor * vec3(ANAMORPHIC_COLOR_R, ANAMORPHIC_COLOR_G, ANAMORPHIC_COLOR_B)) * intensity;
    #endif

    return flare;
}


vec3 GetHexFlare(vec2 uv, vec2 lightPos, vec3 lightColor, float intensity) {
    return GetLensFlareUnified(uv, lightPos, lightColor, intensity);
}


void CalculateBloomFog(inout vec3 color, in ivec2 texel) {
    vec3 bloomData = vec3(0.0);
    vec3 fogBloom = vec3(0.0);

    // Поддержка дождя 
    #if defined IS_OVERWORLD
        float rainAlpha = clamp(texelFetch(colortex0, texel, 0).a * wetness, 0.0, 1.0);
    #else
        const float rainAlpha = 0.0;
    #endif

    // ================================================================
    // LOD sampling 
    // ================================================================
    
    // LOD 1
    vec3 sampleTile = BloomUpSample(colortex4, 1, screenCoord);
    bloomData += sampleTile;
    fogBloom += sampleTile;

    // LOD 2 
    sampleTile = BloomUpSample(colortex4, 2, screenCoord);
    bloomData += sampleTile * mix(1.0, 0.83333333, rainAlpha);
    fogBloom += sampleTile * 1.5;

    // LOD 3
    sampleTile = BloomUpSample(colortex4, 3, screenCoord);
    bloomData += sampleTile * mix(1.0, 0.69444444, rainAlpha);
    fogBloom += sampleTile * 2.25;

    // LOD 4
    sampleTile = BloomUpSample(colortex4, 4, screenCoord);
    bloomData += sampleTile * mix(1.0, 0.57870370, rainAlpha);
    fogBloom += sampleTile * 3.375;

    // LOD 5
    sampleTile = BloomUpSample(colortex4, 5, screenCoord);
    bloomData += sampleTile * mix(1.0, 0.48225309, rainAlpha);
    fogBloom += sampleTile * 5.0625;

    // LOD 6
    sampleTile = BloomUpSample(colortex4, 6, screenCoord);
    bloomData += sampleTile * mix(1.0, 0.40187757, rainAlpha);
    fogBloom += sampleTile * 7.59375;

    // LOD 7
    sampleTile = BloomUpSample(colortex4, 7, screenCoord);
    bloomData += sampleTile * mix(1.0, 0.33489798, rainAlpha);
    fogBloom += sampleTile * 11.328125;


    bloomData *= mix(0.23118661, 1.4 / 7.0, rainAlpha);
    fogBloom *= 0.03108305;

    // ================================================================
    // soft bloom
    // ================================================================
    
    #ifdef SOFT_BLOOM_ENABLED
        vec3 softBloom = vec3(0.0);
        float totalWeight = 0.0;
        
        #if SOFT_BLOOM_QUALITY >= 1
            float weight1 = 1.0;
            softBloom += BloomUpSample(colortex4, 2, screenCoord) * weight1;
            totalWeight += weight1;
        #endif
        
        #if SOFT_BLOOM_QUALITY >= 2
            float weight2 = 1.2;
            softBloom += BloomUpSample(colortex4, 3, screenCoord) * weight2;
            totalWeight += weight2;
        #endif
        
        #if SOFT_BLOOM_QUALITY >= 3
            float weight3 = 1.5;
            softBloom += BloomUpSample(colortex4, 4, screenCoord) * weight3;
            totalWeight += weight3;
        #endif
        
        #if SOFT_BLOOM_QUALITY >= 4
            float weight4 = 1.8;
            softBloom += BloomUpSample(colortex4, 5, screenCoord) * weight4;
            totalWeight += weight4;
        #endif
        
        #if SOFT_BLOOM_QUALITY >= 5
            float weight5 = 2.0;
            softBloom += BloomUpSample(colortex4, 6, screenCoord) * weight5;
            totalWeight += weight5;
        #endif
        
        softBloom /= totalWeight;
        softBloom *= SOFT_BLOOM_AMOUNT * (SOFT_BLOOM_RADIUS * 0.5);
        
        
        bloomData = mix(bloomData, softBloom, 0.7);
        bloomData += softBloom * 0.3;
    #endif


    
    #if DIRT_STYLE > 0
        float newAspectRatio = 1.777777777777778 / aspectRatio;
        vec2 scale = vec2(max(newAspectRatio, 1.0), max(1.0 / newAspectRatio, 1.0));
        vec2 dirtCoord = (screenCoord - 0.5) / scale + 0.5;

        float dirt = texture2D(DIRTY_LENS_SAMPLER, dirtCoord).r;

        float brightness = length(bloomData / (1.0 + bloomData));
        dirt *= brightness * DIRTY_LENS_STRENGTH;

        #ifdef DIRTY_LENS_BLOOM_BOOST
            bloomData *= (dirt * DIRTY_LENS_BLOOM_STRENGTH + 1.0);
            fogBloom *= (dirt * (DIRTY_LENS_BLOOM_STRENGTH * 0.5) + 1.0);
        #else
            bloomData *= (dirt * 16.0 + 1.0);
            fogBloom *= (dirt * 8.0 + 1.0);
        #endif
    #endif

    fogBloom += bloomData;

    // ================================================================
    // fog bloom
    // ================================================================
    
    #ifdef BLOOMY_FOG
        float fogTransmittance = texelFetch(colortex6, texel, 0).x;
        color = mix(fogBloom * 0.5, color, fogTransmittance);
    #endif

    // ================================================================
    // ПРИМЕНЕНИЕ БЛУМА С АДАПТАЦИЕЙ ПОД ЭКСПОЗИЦИЮ
    // ================================================================
    
    float bloomAmount = BLOOM_AMOUNT * 0.15;

    float exposure = texelFetch(colortex5, ivec2(0), 0).a;
    bloomAmount /= fma(max(exposure, 1.0), 0.7, 0.3);

    color += bloomData * bloomAmount;
    
    // ================================================================
    // ДОПОЛНИТЕЛЬНЫЙ БЛУМ ДЛЯ ДОЖДЯ/СНЕГА
    // ================================================================
    
    #if !defined IS_NETHER
        if (isEyeInWater == 0 && wetness > 1e-2) {
            float rain = texelFetch(colortex0, texel, 0).b * 0.35;
            fogBloom *= 1.0 + weatherSnowySmooth * 2.0;
            color = color * (1.0 - rain) + fogBloom * fma(clamp(exposure, 0.6, 2.0), 0.15, 0.3) * rain;
        }
    #endif
}
#ifdef AXIAL_BLOOM_ENABLED

uniform int worldTime; // Используем точные тики мира вместо углов солнца


float AxialBloomKnee(float luma) {
    #if AXIAL_BLOOM_THRESHOLD == 0.0
        return 1.0;
    #else
        float knee = AXIAL_BLOOM_THRESHOLD * AXIAL_BLOOM_KNEE;
        float rq   = clamp((luma - (AXIAL_BLOOM_THRESHOLD - knee)) / (knee * 2.0), 0.0, 1.0);
        return max(luma - AXIAL_BLOOM_THRESHOLD, rq * rq * knee * 2.0);
    #endif
}

void AxialGaussianBloom(inout vec3 color) {
    
    vec3 bloom = vec3(0.0);

    bloom += BloomUpSample(colortex4, 1, screenCoord) * 1.0;
    bloom += BloomUpSample(colortex4, 2, screenCoord) * 0.83333333;
    bloom += BloomUpSample(colortex4, 3, screenCoord) * 0.69444444;
    bloom += BloomUpSample(colortex4, 4, screenCoord) * 0.57870370;
    bloom += BloomUpSample(colortex4, 5, screenCoord) * 0.48225309;
    bloom += BloomUpSample(colortex4, 6, screenCoord) * 0.40187757;
    bloom += BloomUpSample(colortex4, 7, screenCoord) * 0.33489798;

    bloom *= 0.2774;

    float luma   = GetLuminance(bloom);
    float weight = AxialBloomKnee(luma);

    // Переводим абсолютное время мира в рамки одних суток (0 - 24000 тиков)
    int timeOfDay = worldTime % 24000;
    if (timeOfDay < 0) timeOfDay += 24000; // Страховка от отрицательных значений

    // 1. АБСОЛЮТНО НАДЕЖНЫЙ ФАКТОР НОЧИ
    float nightFactor = 0.0;
    if (timeOfDay >= 13000 && timeOfDay <= 22000) {
        nightFactor = 1.0; // Полная ночь. Блум работает везде на 100%
    } else if (timeOfDay > 12000 && timeOfDay < 13000) {
        nightFactor = float(timeOfDay - 12000) / 1000.0; // Плавное включение во время заката
    } else if (timeOfDay > 22000 && timeOfDay < 23000) {
        nightFactor = 1.0 - float(timeOfDay - 22000) / 1000.0; // Плавное выключение во время рассвета
    }
    
    // 2. КИНЕМАТОГРАФИЧНЫЙ ПЕРЕХОД ДЛЯ ПОМЕЩЕНИЙ
    // eyeBrightnessSmooth.y отвечает за свет неба над головой.
    // Благодаря встроенному сглаживанию Майнкрафта и нашему smoothstep,
    // при выходе из пещеры/дома днем эффект будет таять очень мягко.
    float skyLight = float(eyeBrightnessSmooth.y);
    float roomFactor = 1.0 - smoothstep(40.0, 200.0, skyLight);
    
    // Смешиваем: ночью модификатор всегда равен 1.0 (работает везде).
    // Днем он зависит чисто от того, насколько глубоко в помещении ты находишься.
    float bloomModifier = max(nightFactor, roomFactor);

    color += bloom * weight * AXIAL_BLOOM_INTENSITY * bloomModifier;
}

#endif

#ifdef FULLSCREEN_BLUR_ENABLED

void FullscreenBlur(inout vec3 color, ivec2 texel) {
    const float weights[5] = float[5](0.27343750, 0.21875000, 0.10937500, 0.03125000, 0.00390625);

    int radius = int(clamp(FULLSCREEN_BLUR_INTENSITY * 4.0, 1.0, 16.0));

    vec3  acc    = vec3(0.0);
    float wSum   = 0.0;

    // меня заебало писать коменты в пизду блять 
    vec3 hBlur = vec3(0.0);
    float hSum = 0.0;
    for (int i = -4; i <= 4; ++i) {
        float w = weights[abs(i)];
        int   s = int(float(i) * FULLSCREEN_BLUR_INTENSITY);
        hBlur += texelFetch(colortex5, texel + ivec2(s, 0), 0).rgb * w;
        hSum  += w;
    }
    hBlur /= hSum;

    vec3 vBlur = vec3(0.0);
    float vSum = 0.0;
    for (int i = -4; i <= 4; ++i) {
        float w = weights[abs(i)];
        int   s = int(float(i) * FULLSCREEN_BLUR_INTENSITY);
    
        vBlur += texelFetch(colortex5, texel + ivec2(0, s), 0).rgb * w;
        vSum  += w;
    }
    vBlur /= vSum;

  
    color = (hBlur + vBlur) * 0.5;
}

#endif



const mat3 rgbToXyz = mat3(
    vec3(0.4124564, 0.3575761, 0.1804375),
    vec3(0.2126729, 0.7151522, 0.0721750),
    vec3(0.0193339, 0.1191920, 0.9503041)
);

const mat3 xyzToRgb = mat3(
    vec3(3.2409699419,  -1.5373831776, -0.4986107603),
    vec3(-0.9692436363,  1.8759675015,  0.0415550574),
    vec3(0.0556300797,  -0.2039769589,  1.0569715142)
);

#ifdef PURKINJE_SHIFT
    vec3 PurkinjeShift(in vec3 color) {
        const vec3 rodResponse = vec3(7.15e-5, 4.81e-1, 3.28e-1);
        vec3 xyz = color * rgbToXyz;

        vec3 scotopicLuminance = max0(xyz * (1.33 * (1.0 + (xyz.y + xyz.z) / xyz.x) - 1.68));

        float purkinje = dot(rodResponse, scotopicLuminance * xyzToRgb);
        return mix(color, purkinje * vec3(0.5, 0.7, 1.0), expf(-purkinje * 90.0));
    }
#endif

#if defined COLOR_GRADING && WHITE_BALANCE != 6500
    mat3 ChromaticAdaptationMatrix(vec3 srcXyz, vec3 dstXyz) {
        const mat3 bradfordConeResponse = mat3(
            0.89510, -0.75020,  0.03890,
            0.26640,  1.71350, -0.06850,
            -0.16140,  0.03670,  1.02960
        );

        vec3 srcLms = srcXyz * bradfordConeResponse;
        vec3 dstLms = dstXyz * bradfordConeResponse;
        vec3 quotient = dstLms / srcLms;

        mat3 vonKries = mat3(
            quotient.x, 0.0, 0.0,
            0.0, quotient.y, 0.0,
            0.0, 0.0, quotient.z
        );

        return (bradfordConeResponse * vonKries) * inverse(bradfordConeResponse);
    }

    mat3 WhiteBalanceMatrix() {
        vec3 srcXyz = Blackbody(float(WHITE_BALANCE)) * rgbToXyz;
        vec3 dstXyz = Blackbody(6500.0)               * rgbToXyz;

        return rgbToXyz * ChromaticAdaptationMatrix(srcXyz, dstXyz) * xyzToRgb;
    }
#endif

vec3 Contrast(in vec3 color) {
    const float logMidpoint = log2(0.16);
    color = log2(color + 1e-6) - logMidpoint;
    return max0(exp2(color * CONTRAST + logMidpoint) - 1e-6);
}

#include "/lib/Post/ACES.glsl"
#include "/lib/Post/AgX.glsl"


#if ENABLE_HDR_OUTPUT == 0

#if TONEMAP == ISA
// ISA Tonemap
vec3 ISA(in vec3 color) {
    float a = 2.51;
    float b = 0.03;
    float c = 2.43;
    float d = 0.59;
    float e = 0.14;
    
    vec3 result = saturate((color * (a * color + b)) / (color * (c * color + d) + e));

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(result);
}
#endif

#if TONEMAP == SEUS_RENEWED
// SEUS Renewed Tonemap 
vec3 SEUS_RENEWED(in vec3 color) {
   
    color *= 1.25; 
    
    float A = 0.15; // Shoulder Strength
    float B = 0.50; // Linear Strength
    float C = 0.10; // Linear Angle
    float D = 0.20; // Toe Strength
    float E = 0.02; // Toe Numerator
    float F = 0.30; // Toe Denominator
    vec3 W = vec3(11.2); // Linear White Point
    
    vec3 tonemapped = ((color * (A * color + C * B) + D * E) / (color * (A * color + B) + D * F)) - E / F;
    vec3 white = ((W * (A * W + C * B) + D * E) / (W * (A * W + B) + D * F)) - E / F;
    
    vec3 result = saturate(tonemapped / white);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(result);
}
#endif

#if TONEMAP == KUDA
// KUDA Tonemap 

vec3 KUDA(in vec3 color) {

    color *= 1.15; 
    vec3 x = max(vec3(0.0), color - 0.004);
    

    vec3 result = (x * (6.2 * x + 0.5)) / (x * (6.2 * x + 1.7) + 0.06);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif


    result = pow(result, vec3(2.2));

    return LinearToSRGB(result);
}
#endif

#if TONEMAP == SEUS_PTGI
// SEUS PTGI Tonemap — панчевый кинематографичный контраст
vec3 SEUS_PTGI(in vec3 color) {
    float A = 0.15; // Shoulder Strength
    float B = 0.50; // Linear Strength
    float C = 0.10; // Linear Angle
    float D = 0.20; // Toe Strength
    float E = 0.02; // Toe Numerator
    float F = 0.30; // Toe Denominator
    vec3 W = vec3(11.2); // Linear White Point Value
    
    vec3 tonemapped = ((color * (A * color + C * B) + D * E) / (color * (A * color + B) + D * F)) - E / F;
    vec3 white = ((W * (A * W + C * B) + D * E) / (W * (A * W + B) + D * F)) - E / F;
    
    vec3 result = saturate(tonemapped / white);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(result);
}
#endif

vec3 Bliss(in vec3 color) {
    color *= 1.15; // Легкий буст экспозиции
    
    // Crosstalk (смешивание каналов для пленочного лука)
    mat3 crosstalk = mat3(
        1.0,  0.05, 0.01,
        0.02, 1.0,  0.02,
        0.0,  0.03, 1.0
    );
    color = color * crosstalk;
    
    // Lottes-based curve с глубокими тенями
    float a = 1.6;
    float d = 0.977;
    float hdrMax = 8.0;
    float midIn = 0.18;
    float midOut = 0.22;

    float b = (-pow(midIn, a) + pow(hdrMax, a) * midOut) / ((pow(hdrMax, a * d) - pow(midIn, a * d)) * midOut);
    float c = (pow(hdrMax, a * d) * pow(midIn, a) - pow(hdrMax, a) * pow(midIn, a * d) * midOut) / ((pow(hdrMax, a * d) - pow(midIn, a * d)) * midOut);

    vec3 z = pow(max(color, vec3(0.0)), vec3(a));
    vec3 result = z / (pow(z, vec3(d)) * b + c);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}

// ====================================================================
// IterationT AgX (Punchy Modded)
// ====================================================================
vec3 IterationT_AgX(in vec3 val) {
    const mat3 agx_mat = mat3(
        0.842479062253094, 0.0423282422610123, 0.0423756549057051,
        0.0784335999999992,  0.878468636469772,  0.0784336,
        0.0792237451477643, 0.0791661274605434, 0.879142973793104
    );
    const float min_ev = -8.0;
    const float max_ev = 6.0;

    // IterationT signature pre-exposure punch
    val = agx_mat * val * 9.5; 
    val = clamp(log2(val), min_ev, max_ev);
    val = (val - min_ev) / (max_ev - min_ev);

    // AgX 7th degree contrast approximation
    vec3 x2 = val * val;
    vec3 x4 = x2 * x2;
    val = - 17.86 * x4 * x2 * val + 78.01 * x4 * x2 - 126.7 * x4 * val + 92.06 * x4 - 28.72 * x2 * val + 4.361 * x2 - 0.1718 * val + 0.002857;

    // IterationT CDL (Color Decision List) Look
    vec3 slope = vec3(1.0);
    vec3 power = vec3(1.35); // Жесткий контраст средних тонов
    float sat = 1.35;        // Высокая насыщенность
    
    float luma = dot(val, vec3(0.2126, 0.7152, 0.0722));
    val = pow(max(val * slope, vec3(0.0)), power);
    val = luma + sat * (val - luma);

    #ifdef COLOR_GRADING
        val = Contrast(val * BRIGHTNESS);
        val = pow(val, vec3(rcp(GAMMA)));
        val = ColorSaturation(val, SATURATION);
        #if WHITE_BALANCE != 6500
            val *= WhiteBalanceMatrix();
        #endif
    #endif

    const mat3 agx_mat_inv = mat3(
        1.19687900512017, -0.0528968517574562, -0.0529716355144438,
        -0.0980208811401368, 1.15190312990417, -0.0980434501171241,
        -0.0990297440797205, -0.0989611768448433, 1.15107367264116
    );
    return saturate(agx_mat_inv * val);
}

// ====================================================================
// Frostbite (EA Engine)
// ====================================================================
vec3 Frostbite(in vec3 color) {
    color *= 1.25; 
    
    vec3 x = color;
    vec3 result = (x * (0.22 * x + 0.03)) / (x * (0.22 * x + 0.3) + 0.06);
    
    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}

#if TONEMAP == ReinhardSimple
// Reinhard (2002) — luminance-based, preserves hue by mapping only luma
// Per-channel Reinhard is wrong and oversaturates; this is the correct form.
vec3 ReinhardSimple(in vec3 color) {
    float luma = GetLuminance(color);
    float lumaMapped = luma / (1.0 + luma);
    vec3 result = color * (lumaMapped / max(luma, 1e-6));

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == ExtendedReinhard
// Extended Reinhard — Jodie (2018) variant: blends luminance-mapped and per-channel
// Avoids hue shifts of pure per-channel while keeping color pop of per-channel in highlights
vec3 ExtendedReinhard(in vec3 color) {
    float luma    = GetLuminance(color);
    vec3  tcPerCh = color / (1.0 + color);          // per-channel Reinhard
    float tcLuma  = luma  / (1.0 + luma);           // luminance Reinhard

    // Blend: saturated pixels lean toward per-channel, dark pixels toward luma
    vec3 result = mix(color * (tcLuma / max(luma, 1e-6)), tcPerCh, tcPerCh);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == Filmic
// GT Tonemap — Timothy Lottes (2016), used in many modern engines
// Proper filmic S-curve with independent toe/shoulder control, no magic constants
vec3 Filmic(in vec3 color) {
    const float P  = 1.0;    // max display brightness
    const float a  = 1.0;    // contrast
    const float m  = 0.22;   // toe start (linear portion)
    const float l  = 0.4;    // toe length
    const float c  = 1.33;   // cross-over angle
    const float b  = 0.0;    // black tightness

    // Shoulder
    float l0 = (P - m) * l / a;
    float L0 = m - m / a;
    float L1 = m + (1.0 - m) / a;
    float S0 = m + l0;
    float S1 = m + a * l0;
    float C2 = a * P / (P - S1);
    float CP = -C2 / P;

    vec3 w0 = vec3(1.0 - smoothstep(0.0, m, color));
    vec3 w2 = vec3(step(m + l0, color));
    vec3 w1 = 1.0 - w0 - w2;

    vec3 T = vec3(m * pow(color / m, vec3(c)) + b);                    // toe
    vec3 S = vec3(P - (P - S1) * exp(CP * (color - S0)));              // shoulder
    vec3 L = vec3(m + a * (color - m));                                // linear

    vec3 result = T * w0 + L * w1 + S * w2;

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == HableFilmic
// Hable "Uncharted 2" Filmic — John Hable (2010), classic game industry tonemapper
// Proper white-point normalization so highlights don't clip to wrong value
vec3 HableFilmic(in vec3 color) {
    const float A = 0.15; // shoulder strength
    const float B = 0.50; // linear strength
    const float C = 0.10; // linear angle
    const float D = 0.20; // toe strength
    const float E = 0.02; // toe numerator
    const float F = 0.30; // toe denominator
    const float W = 11.2; // linear white point

    #define HABLE_CURVE(x) (((x) * (A * (x) + C * B) + D * E) / ((x) * (A * (x) + B) + D * F)) - E / F

    vec3 curr = HABLE_CURVE(color * 2.0);
    float whiteNorm = 1.0 / HABLE_CURVE(W);
    vec3 result = curr * whiteNorm;

    #undef HABLE_CURVE

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == Uncharted2Filmic
// Uncharted 2 Filmic — John Hable (2010)

vec3 Uncharted2Filmic(in vec3 color) {
    const float A = 0.22; // shoulder strength
    const float B = 0.30; // linear strength
    const float C = 0.10; // linear angle
    const float D = 0.20; // toe strength
    const float E = 0.01; // toe numerator
    const float F = 0.30; // toe denominator
    const float W = 11.2; // linear white point
    const float ExposureBias = 2.0;

    #define U2_CURVE(x) (((x) * (A * (x) + C * B) + D * E) / ((x) * (A * (x) + B) + D * F)) - E / F

    vec3 curr = U2_CURVE(color * ExposureBias);
    float whiteNorm = 1.0 / U2_CURVE(W);
    vec3 result = curr * whiteNorm;

    #undef U2_CURVE

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == Lottes
// Timothy Lottes (2016) general purpose tonemapper — AMD GPUOpen.

vec3 Lottes(in vec3 color) {
    const float hdrMax   = 16.0;  // максимальная входная яркость, которую держим без клиппинга
    const float contrast = 1.6;   // общий контраст кривой
    const float shoulder  = 0.97; // насколько резко "прижимаются" света к белому
    const float midIn     = 0.18; // входное серое (linear scene-referred)
    const float midOut    = 0.18; // выходное серое (display-referred)

    float b =
        (-pow(midIn, contrast) + pow(hdrMax, contrast) * midOut) /
        ((pow(hdrMax, contrast * shoulder) - pow(midIn, contrast * shoulder)) * midOut);
    float c =
        (pow(hdrMax, contrast * shoulder) * pow(midIn, contrast) - pow(hdrMax, contrast) * pow(midIn, contrast * shoulder) * midOut) /
        ((pow(hdrMax, contrast * shoulder) - pow(midIn, contrast * shoulder)) * midOut);

    vec3 z = pow(max(color, vec3(0.0)), vec3(contrast));
    vec3 result = z / (pow(z, vec3(shoulder)) * b + c);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == Uchimura
// Uchimura / "Gran Turismo" Tonemap — Hajime Uchimura (2017), CEDEC презентация Polyphony Digital.
// Кусочная кривая (линейная середина + toe + shoulder), которая используется в GT Sport
// и многих современных движках как нейтральная альтернатива ACES — меньше desaturation
// в светах, более предсказуемый средний диапазон.
float UchimuraCurve(in float x, in float P, in float a, in float m, in float l, in float c, in float b) {
    float l0 = (P - m) * l / a;
    float L0 = m - m / a;
    float L1 = m + (1.0 - m) / a;
    float S0 = m + l0;
    float S1 = m + a * l0;
    float C2 = a * P / (P - S1);
    float CP = -C2 / P;

    float w0 = 1.0 - smoothstep(0.0, m, x);
    float w2 = step(m + l0, x);
    float w1 = 1.0 - w0 - w2;

    float T = m * pow(x / m, c) + b;
    float S = P - (P - S1) * exp(CP * (x - S0));
    float L = m + a * (x - m);

    return T * w0 + L * w1 + S * w2;
}

vec3 Uchimura(in vec3 color) {
    const float P = 1.0;   // максимальная яркость дисплея
    const float a = 1.0;   // контраст
    const float m = 0.22;  // начало toe (линейный участок)
    const float l = 0.4;   // длина toe
    const float c = 1.33;  // угол перехода
    const float b = 0.0;   // плотность чёрного

    vec3 result = vec3(
        UchimuraCurve(color.r, P, a, m, l, c, b),
        UchimuraCurve(color.g, P, a, m, l, c, b),
        UchimuraCurve(color.b, P, a, m, l, c, b)
    );

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == Drago

vec3 Drago(in vec3 color) {
    const float maxLuminance = 1.0223; 
    const float bias = 0.85;          

    float luma = GetLuminance(color);
    float worldLuma = luma * (1.0 / maxLuminance);

    float logBias = log(bias) / log(0.5);
    float dragoLuma = log(1.0 + worldLuma) /
        ( log(2.0 + 8.0 * pow(worldLuma, logBias)) ) * (1.0 / log(1.0 + maxLuminance));

    float scale = max(dragoLuma, 1e-6) / max(luma, 1e-6);
    vec3 result = saturate(color * scale);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == PhotographicReinhard

vec3 PhotographicReinhard(in vec3 color) {
    const float key = 0.10001; 

    float luma = GetLuminance(color);
    float scaledLuma = luma * (key / max(luma, 1e-6)) * 2.0; 
    float lumaMapped = scaledLuma / (1.0 + scaledLuma);

    vec3 result = color * (lumaMapped / max(luma, 1e-6));

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == HejlDawson
// Khronos PBR Neutral — Khronos Group (2023), designed for physically-based rendering
// Preserves chromaticity in midtones, smooth rolloff into highlights, no sRGB baked in
vec3 HejlDawson(in vec3 color) {
    const float startCompression = 0.8 - 0.04;
    const float desaturation     = 0.15;

    float x = min(color.r, min(color.g, color.b));
    float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
    color -= offset;

    float peak = max(color.r, max(color.g, color.b));
    if (peak < startCompression) {
        vec3 result = color;
        #ifdef COLOR_GRADING
            result = Contrast(result * BRIGHTNESS);
            result = pow(result, vec3(rcp(GAMMA)));
            result = ColorSaturation(result, SATURATION);
            #if WHITE_BALANCE != 6500
                result *= WhiteBalanceMatrix();
            #endif
        #endif
        return LinearToSRGB(saturate(result));
    }

    const float d = 1.0 - startCompression;
    float newPeak = 1.0 - d * d / (peak + d - startCompression);
    color *= newPeak / peak;

    float g = 1.0 - 1.0 / (desaturation * (peak - newPeak) + 1.0);
    vec3 result = mix(color, vec3(newPeak), g);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == JodieReinhard
// Tony McMapface — Tomasz Stachowiak (2022), used in Bevy and other modern engines
// Works in display-referred space after an exposure mapping.
// Better hue preservation than Reinhard, smoother than ACES Fit.
// Approximated here without LUT via rational curve fit.
vec3 JodieReinhard(in vec3 color) {
    // Luminance-weighted blend: per-channel mapped vs luma-only mapped
    // Keeps saturation in midtones, desaturates smoothly in highlights
    float luma = GetLuminance(color);

    // Per-channel and luma-only Reinhard
    vec3  mappedPerCh = color / (1.0 + color);
    float mappedLuma  = luma  / (1.0 + luma);

    // Blend based on per-channel result: bright saturated channels fade to white
    vec3 result = mix(color * (mappedLuma / max(luma, 1e-6)), mappedPerCh, mappedPerCh * mappedPerCh);

    // Soft gamma toe to lift near-blacks slightly (filmic look)
    result = pow(max0(result), vec3(0.96));

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == BlueShadowCustom
vec3 BlueShadowCustom(in vec3 color) {
    color *= 1.15;
    
    float luminance = GetLuminance(color);
    
    float shadowMask = 1.0 - smoothstep(0.0, BLUE_SHADOW_RANGE, luminance);
    shadowMask = pow(shadowMask, 2.2);
    
    vec3 blueTint = vec3(BLUE_SHADOW_HUE_R, BLUE_SHADOW_HUE_G, BLUE_SHADOW_HUE_B);
    
    vec3 colorWithBlueShadows = mix(color, color * blueTint, shadowMask * BLUE_SHADOW_STRENGTH);
    
    vec3 result = colorWithBlueShadows / (1.0 + colorWithBlueShadows);
    
    float deepShadowMask = pow(shadowMask, 3.0);
    result = mix(result, result * vec3(0.5, 0.6, 1.2), deepShadowMask * 0.2);
    
    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif
    
    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == BlueShadowIntense
vec3 BlueShadowIntense(in vec3 color) {
    color *= 1.15;
    
    float luminance = GetLuminance(color);
    float shadowMask = 1.0 - smoothstep(0.0, 0.35, luminance);
    shadowMask = pow(shadowMask, 1.8);
    
    vec3 blueTint = vec3(0.3, 0.45, 1.8);
    float tintStrength = 0.5;
    
    vec3 colorWithBlueShadows = mix(color, color * blueTint, shadowMask * tintStrength);
    vec3 result = colorWithBlueShadows / (1.0 + colorWithBlueShadows);
    
    float deepShadowMask = pow(shadowMask, 2.5);
    result = mix(result, result * vec3(0.4, 0.55, 1.3), deepShadowMask * 0.3);
    
    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif
    
    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == BlueShadowSubtle
vec3 BlueShadowSubtle(in vec3 color) {
    color *= 1.15;
    
    float luminance = GetLuminance(color);
    float shadowMask = 1.0 - smoothstep(0.0, 0.25, luminance);
    shadowMask = pow(shadowMask, 2.8);
    
    vec3 blueTint = vec3(0.55, 0.65, 0.95);
    float tintStrength = 0.2;
    
    vec3 colorWithBlueShadows = mix(color, color * blueTint, shadowMask * tintStrength);
    vec3 result = colorWithBlueShadows / (1.0 + colorWithBlueShadows);
    
    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif
    
    return LinearToSRGB(saturate(result));
}
#endif

#if TONEMAP == FakeHDR

vec3 FakeHDR(in vec3 color) {
   
    color *= 1.2;

 
    const float A = 0.22; // shoulder strength 
    const float B = 0.30;
    const float C = 0.10;
    const float D = 0.20;
    const float E = 0.01;
    const float F = 0.30;
    const float W = 16.0; // дальше, чем обычные 11.2

    #define FAKEHDR_CURVE(x) (((x) * (A * (x) + C * B) + D * E) / ((x) * (A * (x) + B) + D * F)) - E / F

    vec3 curr = FAKEHDR_CURVE(color);
    float whiteNorm = 1.0 / FAKEHDR_CURVE(vec3(W).x);
    vec3 result = curr * whiteNorm;

    float luma = GetLuminance(result);
    float highlightMask = smoothstep(0.55, 1.0, luma);
    result = mix(result, result * result * (3.0 - 2.0 * result), highlightMask * 0.35);

    #undef FAKEHDR_CURVE

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = pow(result, vec3(rcp(GAMMA)));
        result = ColorSaturation(result, SATURATION * 1.05); 
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return LinearToSRGB(saturate(result));
}
#endif

#endif // ENABLE_HDR_OUTPUT == 0

#if ENABLE_HDR_OUTPUT == 1

#if defined(HDR_MOD_INSTALLED) && defined(HDR_ENABLED)
    uniform float HdrGamePeakBrightness;
    uniform float HdrGamePaperWhiteBrightness;
    uniform float HdrGameMinimumBrightness;
    uniform float HdrUIBrightness;
#endif

vec3 HDR_Reinhard(vec3 x, float peak) {
    return x / (x / peak + 1.0);
}

vec3 HDR_ReinhardExtended(vec3 x, float white_max, float peak) {
    return HDR_Reinhard(x, peak) * (1.0 + (peak * x) / (white_max * white_max));
}

float HDR_ComputeReinhardExtendableScale(float w, float p, float m, float x, float y) {
    return p * (w * w * y - (p * x * x)) / (w * w * x * (p - y));
}

vec3 HDR_ReinhardPiecewiseExtended(vec3 x, float white_max, float x_max, float shoulder) {
    const float x_min = 0.0;
    float exposure = HDR_ComputeReinhardExtendableScale(white_max, x_max, x_min, shoulder, shoulder);
    vec3 extended = HDR_ReinhardExtended(x * exposure, white_max * exposure, x_max);
    extended = min(extended, vec3(x_max));
    return mix(x, extended, step(shoulder, x));
}


vec3 HDRTonemap(in vec3 color) {
    #if defined(HDR_MOD_INSTALLED) && defined(HDR_ENABLED)
        float paperWhite = HdrGamePaperWhiteBrightness;
        float peak       = HdrGamePeakBrightness / paperWhite;
        float shoulder   = HDRTONEMAP_SHOULDERSTART / paperWhite;
        float whiteClip  = HDRTONEMAP_WHITECLIP / paperWhite;
    #else

        const float paperWhite = 203.0;
        float peak       = 1000.0 / paperWhite;
        float shoulder   = HDRTONEMAP_SHOULDERSTART / paperWhite;
        float whiteClip  = HDRTONEMAP_WHITECLIP / paperWhite;
    #endif

    vec3 result = HDR_ReinhardPiecewiseExtended(color, whiteClip, peak, shoulder);

    #ifdef COLOR_GRADING
        result = Contrast(result * BRIGHTNESS);
        result = ColorSaturation(result, SATURATION);
        #if WHITE_BALANCE != 6500
            result *= WhiteBalanceMatrix();
        #endif
    #endif

    return result;
}

#endif // ENABLE_HDR_OUTPUT == 1

#ifdef DEBUG_COUNTER
    #include "/lib/Post/PrintFloat.glsl"
#endif

//----// MAIN //----------------------------------------------------------------------------------//
void main() {
    ivec2 texel = ivec2(gl_FragCoord.xy);
    #ifdef MOTION_BLUR
        vec3 color = texelFetch(colortex2, texel, 0).rgb;
    #else
        vec3 color = texelFetch(colortex5, texel, 0).rgb;
    #endif

        #ifdef FULLSCREEN_BLUR_ENABLED
        FullscreenBlur(color, texel);
    #endif

    #ifdef BLOOM_ENABLED
        #if BLOOM_STYLE == 2
            CombineBloomAndFogDonor(color, texel, screenCoord);
        #else
            CalculateBloomFog(color, texel);
        #endif
    #endif

    #ifdef PURKINJE_SHIFT
        color = PurkinjeShift(color);
    #endif

    color *= texelFetch(colortex5, ivec2(0), 0).a; // Exposure

    vec4 sunProj = gbufferProjection * vec4(sunPosition, 1.0);
    vec2 sunScreenPos = (sunProj.xy / sunProj.w) * 0.5 + 0.5;
    
    // Проецируем луну (вектор противоположен солнцу)
    vec4 moonProj = gbufferProjection * vec4(-sunPosition, 1.0);
    vec2 moonScreenPos = (moonProj.xy / moonProj.w) * 0.5 + 0.5;
#ifdef LENS_FLARE_ENABLED
    // --- Рисуем блик от СОЛНЦА ---
    if (sunProj.z > 0.0) {
        // Проверяем, что солнце находится в видимой зоне экрана (не ушло за края)
        if (sunScreenPos.x >= 0.0 && sunScreenPos.x <= 1.0 && sunScreenPos.y >= 0.0 && sunScreenPos.y <= 1.0) {
            
            // Считываем значение глубины в координатах солнца
            float sunDepth = texture(depthtex0, sunScreenPos).r;
            
            // Если глубина почти 1.0, значит перед солнцем нет блоков (только небо)
            if (sunDepth > 0.9999) {
                vec3 sunColor = vec3(1.0, 0.8, 0.5);
                color += GetHexFlare(screenCoord, sunScreenPos, sunColor, 1.5);
            }
        }
    }
    
    // --- Рисуем блик от ЛУНЫ ---
    if (moonProj.z > 0.0) {
        // Проверяем, что луна находится в видимой зоне экрана
        if (moonScreenPos.x >= 0.0 && moonScreenPos.x <= 1.0 && moonScreenPos.y >= 0.0 && moonScreenPos.y <= 1.0) {
            
            // Считываем значение глубины в координатах луны
            float moonDepth = texture(depthtex0, moonScreenPos).r;
            
            // Если блоков нет
            if (moonDepth > 0.9999) {
                vec3 moonColor = vec3(0.4, 0.6, 1.0);
                color += GetHexFlare(screenCoord, moonScreenPos, moonColor, 0.4);
            }
        }
    }
    #endif

    #ifdef ANAMORPHIC_UNIVERSAL_LIGHT
        color += GetUniversalAnamorphicLight(screenCoord);
    #endif

    #ifdef AXIAL_BLOOM_ENABLED
        AxialGaussianBloom(color);
    #endif

    #ifdef VIGNETTE_ENABLED
        color *= expf(-2.0 * dotSelf(screenCoord - 0.5) * VIGNETTE_STRENGTH);
    #endif

  

#if ENABLE_HDR_OUTPUT == 1
        color = HDRTonemap(color);
    #else
        #if TONEMAP_1TO1 == 1
            vec3 colorLeft = TONEMAP_LEFT(color);
            vec3 colorRight = TONEMAP_RIGHT(color);
            
        
            if (screenCoord.x < 0.5) {
                color = colorLeft;
            } else {
                color = colorRight;
            }
            
           
            float splitLine = abs(screenCoord.x - 0.5) < 0.0015 ? 1.0 : 0.0;
            color = mix(color, vec3(1.0), splitLine);
        #else
            color = TONEMAP(color);
        #endif
    #endif

    #ifdef CINEMATIC_EFFECT
        color *= step(abs(screenCoord.y - 0.5) * 2.0, aspectRatio * (9.0 / 21.0)); // 21:9
    #endif

    #ifdef DEBUG_COUNTER
        const float scale = 5.0, size = 1.0 / scale;
        vec2 tCoord = gl_FragCoord.xy * size;

        if (clamp(tCoord, vec2(0.0, 25.0), vec2(40.0, 50.0)) == tCoord) {
            color = min(color * 0.5, 0.8);
        }

        color += PrintFloat(shadowProjection[0].x, vec2(10.0, 35.0) * scale, size);
    #endif


    #if ENABLE_HDR_OUTPUT == 1
        sceneColor = color;
    #else
        sceneColor = saturate(color);
    #endif
}
