in vec2 screenCoord;

//----// OUTPUTS //------------------------------------------------------------//

layout(location = 0) out vec4 reservoirAOut; // colortex8
layout(location = 1) out vec4 reservoirBOut; // colortex9

/* DRAWBUFFERS:89 */

//----// INCLUDES //------------------------------------------------------------//

#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"
#include "/lib/Head/Functions.inc"

uniform sampler2D colortex8;
uniform sampler2D colortex9;

#include "/lib/Lighting/ReSTIR.glsl"

//----// PHOTONICS INTEGRATION //----------------------------------------------//
//
// Photonics — мод для Minecraft, который заполняет воксельный буфер (SSBO)
// данными об излучении блоков в мировых координатах.
//
// КАК ПОДКЛЮЧИТЬ:
//   1. В shaders.properties добавить:
//      buffers.ssbo.0 = photonics_volume
//   2. В Settings.glsl раскомментировать:
//      #define PHOTONICS_ENABLED
//
// КАК РАБОТАЕТ ПРИ ВКЛЮЧЁННОМ МОДЕ:
//   - Когда SS-луч уходит за край экрана или не находит пересечения,
//     мы переводим его в мировые координаты и запускаем воксельный DDA
//     по данным Photonics.
//   - При промахе вокселя функция возвращает false и GI остаётся как обычно.
//
// КАК РАБОТАЕТ БЕЗ МОДА (PHOTONICS_ENABLED не определён):
//   - Весь код в #ifdef блоках компилятор вырезает.
//   - Поведение шейдера идентично оригиналу.
//
//-----------------------------------------------------------------------------//

#ifdef PHOTONICS_ENABLED

// --- Настройки ---
#ifndef PHOTONICS_MAX_STEPS
    #define PHOTONICS_MAX_STEPS 64   // Дальность воксельного трейсинга в блоках
#endif
#ifndef PHOTONICS_EMISSION_SCALE
    #define PHOTONICS_EMISSION_SCALE 12.0  // Яркость фотонных источников
#endif

// SSBO от Photonics. Структура: каждый воксель = 2 uint.
//   uint0: RGB10A2 — packed цвет излучения (R10 G10 B10 + флаг A2)
//   uint1: яркость (float16) в старших 16 битах
//
// Размер буфера и смещение зависят от версии мода.
// Если Photonics обновится — менять только эти константы.
layout(std430, binding = 0) readonly buffer PhotonicsVolume {
    uint photonics_data[];
};

// Размер воксельного чанка от Photonics (обычно 256x256x256 блоков)
#ifndef PHOTONICS_VOLUME_SIZE
    #define PHOTONICS_VOLUME_SIZE 256
#endif

// Читает воксель из буфера Photonics в мировых координатах.
// Возвращает true если блок является источником света.
bool Photonics_ReadVoxel(vec3 worldPos, out vec3 outColor, out float outEmission) {
    // Переводим мировую позицию в локальную воксельную (относительно камеры)
    ivec3 localPos = ivec3(floor(worldPos)) - ivec3(floor(cameraPosition))
                   + ivec3(PHOTONICS_VOLUME_SIZE / 2);

    // Проверяем границы буфера
    if (any(lessThan(localPos, ivec3(0))) ||
        any(greaterThanEqual(localPos, ivec3(PHOTONICS_VOLUME_SIZE)))) {
        outColor    = vec3(0.0);
        outEmission = 0.0;
        return false;
    }

    // Линейный индекс вокселя (X + Y*W + Z*W*H)
    int idx = localPos.x
            + localPos.y * PHOTONICS_VOLUME_SIZE
            + localPos.z * PHOTONICS_VOLUME_SIZE * PHOTONICS_VOLUME_SIZE;

    // Два uint на воксель
    uint raw0 = photonics_data[idx * 2];
    uint raw1 = photonics_data[idx * 2 + 1];

    // Распаковываем цвет (RGB10 — каждый канал 0..1023)
    float r = float((raw0 >>  0u) & 0x3FFu) / 1023.0;
    float g = float((raw0 >> 10u) & 0x3FFu) / 1023.0;
    float b = float((raw0 >> 20u) & 0x3FFu) / 1023.0;

    // Яркость из старших 16 бит второго uint (float16 → float32)
    // unpackHalf2x16 читает два half-float; нам нужен только старший (.y)
    float emission = unpackHalf2x16(raw1).y;

    outColor    = vec3(r, g, b);
    outEmission = emission;

    // Считаем блок источником если есть хоть какое-то излучение
    return emission > 1e-4;
}

// 3D DDA трейсинг по воксельному буферу Photonics в мировых координатах.
// Запускается только когда SS-луч ушёл за экран или ничего не нашёл.
bool Photonics_TraceVoxel(vec3 rayOrigin, vec3 rayDir,
                           out vec3 hitRadiance,
                           out vec3 hitNormal,
                           out float hitDist) {
    // DDA: инициализация
    vec3  mapPos   = floor(rayOrigin);
    vec3  deltaDist = abs(1.0 / max(abs(rayDir), vec3(1e-7))); // защита от деления на 0
    vec3  rayStep  = sign(rayDir);
    vec3  sideDist = (rayStep * (mapPos - rayOrigin) + rayStep * 0.5 + 0.5) * deltaDist;

    vec3 mask = vec3(0.0);

    for (int i = 0; i < PHOTONICS_MAX_STEPS; i++) {
        vec3  voxColor;
        float voxEmission;

        if (Photonics_ReadVoxel(mapPos, voxColor, voxEmission)) {
            // Нормаль — противоположна последнему шагу
            hitNormal    = -mask * rayStep;
            hitRadiance  = voxColor * voxEmission * PHOTONICS_EMISSION_SCALE;

            // Расстояние до точки входа в воксель
            vec3 tEntry  = (mapPos - rayOrigin + 0.5 - rayStep * 0.5) / rayDir;
            hitDist      = max(minOf(tEntry), 0.0);

            return true;
        }

        // Шагаем в сторону ближайшей грани
        mask     = step(sideDist.xyz, min(sideDist.yzx, sideDist.zxy));
        sideDist += mask * deltaDist;
        mapPos   += mask * rayStep;
    }

    hitRadiance = vec3(0.0);
    hitNormal   = vec3(0.0, 1.0, 0.0);
    hitDist     = 0.0;
    return false;
}

#endif // PHOTONICS_ENABLED

//----// HELPERS //-------------------------------------------------------------//

vec3 ReSTIR_CosHemisphere(vec3 normal, vec2 u) {
    float r     = sqrt(u.x);
    float theta = TAU * u.y;

    vec3 up     = abs(normal.y) > 0.99 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
    vec3 tang   = normalize(cross(normal, up));
    vec3 bitan  = cross(normal, tang);

    return tang  * (r * cos(theta))
         + bitan * (r * sin(theta))
         + normal * sqrt(max(0.0, 1.0 - u.x));
}

bool CastRay(vec3 startViewPos, vec3 rayDir,
             out vec3 hitRadiance, out vec3 hitViewNormal, out float hitDist) {

    hitRadiance   = vec3(0.0);
    hitViewNormal = -rayDir;
    hitDist       = 0.0;

    float stepSize   = RESTIR_GI_RADIUS / float(RESTIR_GI_STEPS);
    vec3  rayStep    = rayDir * stepSize;
    float jitter     = fract(RandNextF());
    vec3  currentPos = startViewPos + rayStep * (jitter * 0.5 + 0.5);

    // --- 1. Screen Space трейсинг (оригинальный код, не тронут) ---
    for (int i = 0; i < RESTIR_GI_STEPS; i++) {
        vec3 sScreen = ViewToScreenSpace(currentPos);

        // За границами экрана — прерываем SS и уходим в Photonics (если включён)
        if (clamp(sScreen.xy, 0.0, 1.0) != sScreen.xy || sScreen.z > 1.0) {
#ifdef PHOTONICS_ENABLED
            break; // не return false — хотим попробовать воксели
#else
            return false;
#endif
        }

        float sceneDepth   = texelFetch(depthtex1, ivec2(sScreen.xy * screenSize), 0).x;
        vec3  sceneViewPos = ScreenToViewSpace(vec3(sScreen.xy, sceneDepth));
        float thickness    = currentPos.z - sceneViewPos.z;

        if (thickness > 0.0 && thickness < RESTIR_GI_RADIUS * 0.25) {
            vec2 hitUV = sScreen.xy;

            vec4  lmData = textureLod(colortex7, hitUV, 0);
            float blockLM = lmData.x;
            int   matID   = int(lmData.z * 255.0 + 0.5);

            vec3 albedo = textureLod(colortex6, hitUV, 0).rgb;

            if (matID >= 80 && matID <= 87) {
                hitRadiance = albedo * vec3(1.0, 0.55, 0.25) * 12.0;
            } else if (blockLM > 0.6) {
                float warmth = albedo.r - albedo.b;
                if (albedo.b > (albedo.r + albedo.g) * 0.4 && albedo.b > 0.2) {
                    hitRadiance = vec3(0.15, 0.5, 1.0) * blockLM * 14.0;
                } else if (warmth > 0.12 && albedo.r > 0.35) {
                    hitRadiance = albedo * vec3(1.0, 0.65, 0.2) * blockLM * 16.0;
                } else if (albedo.r > 0.7 && albedo.g > 0.7 && albedo.b > 0.6) {
                    hitRadiance = albedo * vec3(1.0, 0.95, 0.8) * blockLM * 13.0;
                } else if (albedo.r > 0.5 && albedo.g < 0.25 && albedo.b < 0.25) {
                    hitRadiance = vec3(1.0, 0.1, 0.05) * blockLM * 8.0;
                } else {
                    hitRadiance = albedo * blockLM * 10.0;
                }
            } else {
                vec3 bounceLight = textureLod(colortex0, hitUV * 0.5, 0).rgb;
                hitRadiance = bounceLight + albedo * blockLM * 2.0;
            }

            vec3 rawNorm  = DecodeNormal(textureLod(colortex3, hitUV, 0).xy);
            hitViewNormal = mat3(gbufferModelView) * (mat3(gbufferModelViewInverse) * rawNorm);
            hitDist       = distance(startViewPos, sceneViewPos);
            return true;
        }

        currentPos += rayStep;
        rayStep    *= 1.15;
    }

    // --- 2. Photonics воксельный фоллбек ---
    // Включается только когда PHOTONICS_ENABLED определён.
    // SS-луч либо ушёл за экран, либо исчерпал шаги без хита.
#ifdef PHOTONICS_ENABLED
    {
        // Переводим начало луча и направление из View Space в World Space
        vec3 worldRayOrigin = mat3(gbufferModelViewInverse) * startViewPos
                            + cameraPosition;
        vec3 worldRayDir    = normalize(mat3(gbufferModelViewInverse) * rayDir);

        vec3  voxRadiance;
        vec3  voxNormal;
        float voxDist;

        if (Photonics_TraceVoxel(worldRayOrigin, worldRayDir,
                                  voxRadiance, voxNormal, voxDist)) {
            hitRadiance   = voxRadiance;
            // Конвертируем нормаль обратно в View Space
            hitViewNormal = mat3(gbufferModelView) * voxNormal;
            hitDist       = voxDist;
            return true;
        }
    }
#endif // PHOTONICS_ENABLED

    return false;
}

//----// MAIN //---------------------------------------------------------------//

void main() {
    ivec2 texel = ivec2(gl_FragCoord.xy);
    float depth = GetDepth(texel);

    if (depth >= 1.0) {
        reservoirAOut = vec4(0.0);
        reservoirBOut = vec4(0.0);
        return;
    }

    vec3 screenPos   = vec3(screenCoord, depth);
    vec3 viewPos     = ScreenToViewSpace(screenPos);
    vec3 viewNormal  = GetNormals(texel);
    vec3 worldNormal = mat3(gbufferModelViewInverse) * viewNormal;
    viewNormal       = mat3(gbufferModelView) * worldNormal;

    Reservoir r = EmptyReservoir();

    for (int c = 0; c < RESTIR_CANDIDATES; c++) {
        vec2 u = fract(hash2(vec3(gl_FragCoord.xy, float(frameCounter * RESTIR_CANDIDATES + c))));
        vec3 rayDir = ReSTIR_CosHemisphere(viewNormal, u);

        if (dot(rayDir, viewNormal) <= 0.0) rayDir = -rayDir;

        vec3  hitRadiance, hitNormal;
        float hitDist;
        bool  hit = CastRay(viewPos, rayDir, hitRadiance, hitNormal, hitDist);

        if (hit) {
            float lum    = GetLuminance(hitRadiance);
            float pdf    = max(dot(rayDir, viewNormal), 1e-4) * rcp(PI);
            float weight = lum * rcp(max(pdf, 1e-5));
            weight *= rcp(1.0 + hitDist * hitDist * 0.1);

            float rng = fract(RandNextF() + float(c) * 0.6180339887);
            UpdateReservoir(r, hitRadiance, hitNormal, weight, rng);
        }
    }

    // --- Temporal Reuse ---
    vec3 prevScreenPos = Reproject(screenPos);
    vec2 prevCoord     = prevScreenPos.xy;

    bool validHistory = (clamp(prevCoord, 0.0, 1.0) == prevCoord);
    if (validHistory) {
        vec4 prevB      = textureLod(colortex9, prevCoord, 0);
        vec3 prevNormal = DecodeNormal(prevB.xy);
        if (dot(prevNormal, worldNormal) < 0.5) validHistory = false;
    }

    if (validHistory) {
        vec4 histA = textureLod(colortex8, prevCoord, 0);
        vec4 histB = textureLod(colortex9, prevCoord, 0);
        Reservoir histR = UnpackReservoir(histA, histB);
        histR.M = min(histR.M, float(RESTIR_TEMPORAL_MAX));
        float histPdf = GetLuminance(histR.radiance);
        float rng     = fract(RandNextF() + 0.3333333);
        MergeReservoir(r, histR, histPdf, rng);
    }

    // --- Финальный вес резервуара ---
    ComputeReservoirWeight(r, GetLuminance(r.radiance));
    r.W = min(r.W, 32.0);

    reservoirAOut = PackReservoirA(r);
    reservoirBOut = PackReservoirB(r);
}