layout(location = 0) out vec3 colortex7Out;
layout(location = 1) out vec4 reflectionData;
layout(location = 2) out vec4 colortex3Out;

vec3 voxyFaceNormal(uint face) {
    return vec3(uint((face >> 1u) == 2u), uint((face >> 1u) == 0u), uint((face >> 1u) == 1u)) * (float(int(face & 1u)) * 2.0 - 1.0);
}

vec2 voxyEncodeNormal(vec3 normal) {
    if (normal.z <= -0.999) normal.xy = vec2(-1e-12);
    normal.xy /= dot(abs(normal), vec3(1.0));
    normal.xy = normal.z <= 0.0 ? (1.0 - abs(normal.yx)) * sign(normal.xy) : normal.xy;
    return clamp(normal.xy * 0.5 + 0.5, 0.0, 1.0);
}

float voxyPackUnorm2x8(vec2 value) {
    vec2 packedValue = floor(clamp(value, 0.0, 1.0) * 255.0);
    return dot(packedValue, vec2(1.0, 256.0) / 65535.0);
}

vec2 voxyLightMap(vec2 lightMap) {
    return clamp(lightMap / (30.0 / 32.0) - (1.0 / 32.0), 0.0, 1.0);
}

uint voxyMaterial(uint customId, uint minimumId) {
    uint materialId = customId >= 10000u ? customId - 10000u : customId;
    return materialId > 0u ? max(materialId, minimumId) : 0u;
}

void voxy_emitFragment(VoxyFragmentParameters parameters) {
    vec4 albedo = clamp(parameters.sampledColour * parameters.tinting, 0.0, 1.0);
    uint materialId = voxyMaterial(parameters.customId, 16u);
    vec3 normal = normalize(mat3(gbufferModelView) * voxyFaceNormal(parameters.face));
    colortex7Out = vec3(voxyLightMap(parameters.lightMap), (float(materialId) + 0.1) / 255.0);
    colortex3Out = vec4(voxyEncodeNormal(normal), voxyPackUnorm2x8(albedo.rg), voxyPackUnorm2x8(albedo.ba));
    reflectionData = vec4(0.0, 0.0, 0.0, 1.0);
}
