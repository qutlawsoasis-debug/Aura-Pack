layout(location = 0) out vec3 albedoData;
layout(location = 2) out vec4 colortex3Out;

/* DRAWBUFFERS:673 */

#include "/lib/Head/Common.inc"

#ifdef PARALLAX_SHADOW
	layout(location = 1) out vec4 colortex7Out;
#else
	layout(location = 1) out vec3 colortex7Out;
#endif

uniform sampler2D tex;
#ifdef MC_NORMAL_MAP
    uniform sampler2D normals;
#endif
#ifdef MC_SPECULAR_MAP
    uniform sampler2D specular;
#endif

uniform mat4 gbufferModelView;

uniform vec3 cameraPosition;
uniform vec3 worldLightVector;

in vec4 tint;
in vec2 texcoord;
in vec3 minecraftPos;
in vec3 viewPos;

in vec2 lightmap;

flat in mat3 tbnMatrix;

flat in uint materialIDs;

uniform int frameCounter;

#if defined PARALLAX || ANISOTROPIC_FILTER > 0
	in vec2 tileCoord;
	flat in vec2 tileOffset;
	flat in vec2 tileScale;

	vec2 OffsetCoord(in vec2 coord) { return tileOffset + tileScale * fract(coord); }
#endif

float InterleavedGradientNoiseTemporal(in vec2 coord) {
    return fract(52.9829189 * fract(0.06711056 * coord.x + 0.00583715 * coord.y + 0.00623715 * (frameCounter & 63)));
}

#ifdef PARALLAX
	#include "/lib/Surface/Parallax.glsl"
#endif

#if ANISOTROPIC_FILTER > 0
	//https://www.shadertoy.com/view/4lXfzn
	vec3 AnisotropicFilter(in vec2 baseCoord, in mat2 texGrad) {
		mat2 J = inverse(texGrad);
		J = transpose(J) * J;

		float d = determinant(J);
		float t = J[0][0] + J[1][1];

		float D = sqrt(max0(t * t - 4.0 * d));
		float V = (t - D) * 0.5;
		float v = (t + D) * 0.5;
		float l = log2(inversesqrt(v));

		vec2 A = inversesqrt(V) * normalize(vec2(-J[0][1], J[0][0] - V));
		// A = max0(abs(A)) / tileScale;
		A /= tileScale;

		float c = 0.0;
		vec3 albedo = vec3(0.0);

		for (float i = 0.5 / ANISOTROPIC_FILTER - 0.5; i < 0.5; i += 1.0 / ANISOTROPIC_FILTER) {
			vec2 sampleCoord = OffsetCoord(baseCoord + i * A);

			vec4 albedoSample = textureLod(tex, sampleCoord, l);

			if (albedoSample.a > 1e-3) {
				albedo += albedoSample.rgb;
				++c;
			}
		}
		albedo /= max(c, 1.0);

		return albedo;
	}
#endif

//#include "/lib/Surface/ManualTBN.glsl"

// === iPBR System ===
#ifndef IPBR_ENABLED
#define IPBR_ENABLED
#endif
#ifndef IPBR_FORCE_REFLECTIONS
#define IPBR_FORCE_REFLECTIONS
#endif
#ifndef IPBR_STYLE
#define IPBR_STYLE 1 // [1 2 3 4]
#endif
#ifndef IPBR_RESOLUTION
#define IPBR_RESOLUTION 16 // [8 16 32 64 128 256 512 1024]
#endif

vec3 GenerateNormals_Style1(vec2 coord, vec2 texGradX, vec2 texGradY) {
    const float normalStrength = 2.5;
    vec2 baseStep = max(vec2(length(texGradX), length(texGradY)), vec2(1.0 / 4096.0));
    float resScale = float(IPBR_RESOLUTION) / 64.0;
    vec2 step = baseStep * resScale;

    float right = dot(textureGrad(tex, coord + vec2(step.x, 0.0),  texGradX, texGradY).rgb, vec3(0.299, 0.587, 0.114));
    float left  = dot(textureGrad(tex, coord - vec2(step.x, 0.0),  texGradX, texGradY).rgb, vec3(0.299, 0.587, 0.114));
    float up    = dot(textureGrad(tex, coord + vec2(0.0, step.y),   texGradX, texGradY).rgb, vec3(0.299, 0.587, 0.114));
    float down  = dot(textureGrad(tex, coord - vec2(0.0, step.y),   texGradX, texGradY).rgb, vec3(0.299, 0.587, 0.114));

    vec2 gradient = vec2(right - left, up - down) * normalStrength;
    return normalize(vec3(-gradient.x, -gradient.y, 1.0));
}

vec3 GenerateNormals_Style2(vec2 coord, vec2 texGradX, vec2 texGradY) {
    vec2 bias = max(vec2(length(texGradX), length(texGradY)), vec2(1.0 / 4096.0));
    bias *= (16.0 / float(IPBR_RESOLUTION));

    vec4 sampleR = textureGrad(tex, coord + vec2(bias.x, 0.0),  texGradX, texGradY);
    vec4 sampleL = textureGrad(tex, coord - vec2(bias.x, 0.0),  texGradX, texGradY);
    vec4 sampleU = textureGrad(tex, coord + vec2(0.0, bias.y),   texGradX, texGradY);
    vec4 sampleD = textureGrad(tex, coord - vec2(0.0, bias.y),   texGradX, texGradY);

    float heightR = dot(sampleR.rgb, vec3(0.2126, 0.7152, 0.0722)) * sampleR.a;
    float heightL = dot(sampleL.rgb, vec3(0.2126, 0.7152, 0.0722)) * sampleL.a;
    float heightU = dot(sampleU.rgb, vec3(0.2126, 0.7152, 0.0722)) * sampleU.a;
    float heightD = dot(sampleD.rgb, vec3(0.2126, 0.7152, 0.0722)) * sampleD.a;

    float deltaX = (heightL - heightR) * 2.5;
    float deltaY = (heightD - heightU) * 2.5;

    float zStrength = 32.0 / float(IPBR_RESOLUTION);
    return normalize(vec3(deltaX, deltaY, zStrength));
}

vec3 GenerateNormals_Style3(vec2 coord, vec2 texGradX, vec2 texGradY) {
    vec2 baseStep = max(vec2(length(texGradX), length(texGradY)), vec2(1.0 / 4096.0));
    float resScale = float(IPBR_RESOLUTION) / 64.0;
    vec2 step = baseStep * resScale;

    vec3 sR = textureGrad(tex, coord + vec2(step.x, 0.0),  texGradX, texGradY).rgb;
    vec3 sL = textureGrad(tex, coord - vec2(step.x, 0.0),  texGradX, texGradY).rgb;
    vec3 sU = textureGrad(tex, coord + vec2(0.0, step.y),   texGradX, texGradY).rgb;
    vec3 sD = textureGrad(tex, coord - vec2(0.0, step.y),   texGradX, texGradY).rgb;

    const vec3 weights = vec3(0.45, 0.38, 0.17);
    float hR = pow(dot(sR, weights), 1.4);
    float hL = pow(dot(sL, weights), 1.4);
    float hU = pow(dot(sU, weights), 1.4);
    float hD = pow(dot(sD, weights), 1.4);

    float dX = (hL - hR) * 3.2;
    float dY = (hD - hU) * 3.2;
    return normalize(vec3(-dX, -dY, 1.0));
}

vec3 GenerateNormals_Style4(vec2 coord, vec2 texGradX, vec2 texGradY) {
    vec2 baseStep = max(vec2(length(texGradX), length(texGradY)), vec2(1.0 / 4096.0));
    float resScale = float(IPBR_RESOLUTION) / 64.0;
    vec2 s = baseStep * resScale;

    vec4 cR = textureGrad(tex, coord + vec2(s.x, 0.0),  texGradX, texGradY);
    vec4 cL = textureGrad(tex, coord - vec2(s.x, 0.0),  texGradX, texGradY);
    vec4 cU = textureGrad(tex, coord + vec2(0.0, s.y),   texGradX, texGradY);
    vec4 cD = textureGrad(tex, coord - vec2(0.0, s.y),   texGradX, texGradY);


    float hR = dot(cR.rgb, vec3(0.50, 0.30, 0.20)) * (0.7 + 0.3 * cR.a);
    float hL = dot(cL.rgb, vec3(0.50, 0.30, 0.20)) * (0.7 + 0.3 * cL.a);
    float hU = dot(cU.rgb, vec3(0.50, 0.30, 0.20)) * (0.7 + 0.3 * cU.a);
    float hD = dot(cD.rgb, vec3(0.50, 0.30, 0.20)) * (0.7 + 0.3 * cD.a);


    float satR = length(cR.rgb - vec3(dot(cR.rgb, vec3(0.333))));
    float satL = length(cL.rgb - vec3(dot(cL.rgb, vec3(0.333))));
    float satU = length(cU.rgb - vec3(dot(cU.rgb, vec3(0.333))));
    float satD = length(cD.rgb - vec3(dot(cD.rgb, vec3(0.333))));

    float edgeBoostX = 1.0 + abs(satR - satL) * 2.5;
    float edgeBoostY = 1.0 + abs(satU - satD) * 2.5;

    float dX = (hL - hR) * 2.8 * edgeBoostX;
    float dY = (hD - hU) * 2.8 * edgeBoostY;
    return normalize(vec3(-dX, -dY, 1.0));
}

vec3 GenerateNormalsFromAlbedo(vec2 coord, vec2 texGradX, vec2 texGradY) {
    #if IPBR_STYLE == 2
        return GenerateNormals_Style2(coord, texGradX, texGradY);
    #elif IPBR_STYLE == 3
        return GenerateNormals_Style3(coord, texGradX, texGradY);
    #elif IPBR_STYLE == 4
        return GenerateNormals_Style4(coord, texGradX, texGradY);
    #else
        return GenerateNormals_Style1(coord, texGradX, texGradY);
    #endif
}

float detectDetails(vec3 albedo) {
    float brightness = dot(albedo.rgb, vec3(0.299, 0.587, 0.114));
    if (brightness < 0.25) return 1.0;
    if (brightness < 0.35) return 0.7;
    float contrast = abs(brightness - 0.5);
    if (contrast > 0.25 && brightness < 0.4) return 0.5;
    return 0.0;
}

#if defined IS_OVERWORLD
	uniform sampler2D noisetex;
	uniform sampler2D colortex7;

	uniform mat4 gbufferModelViewInverse;
	uniform float frameTimeCounter;
	uniform float wetnessCustom;

	#include "/lib/Surface/RainEffect.glsl"
#endif

void main() {
	vec3 normalData;
	vec4 albedo = tint;

	float dither = InterleavedGradientNoiseTemporal(gl_FragCoord.xy);

	vec2 texGradX = dFdx(texcoord);
	vec2 texGradY = dFdy(texcoord);
	mat2 texGrad = mat2(texGradX, texGradY);
	#ifdef PARALLAX
		#define ReadTexture(tex) textureGrad(tex, parallaxCoord, texGradX, texGradY)

		vec2 parallaxCoord = texcoord;

		#ifdef SMOOTH_PARALLAX
			float sampleHeight = BilinearHeightSample(texcoord);
		#else
			float sampleHeight = ReadTexture(normals).a;
		#endif

		vec3 offsetCoord;
		if (sampleHeight < 0.999) {
			vec3 tangentViewVector = normalize(viewPos.xyz) * tbnMatrix;

			offsetCoord = CalculateParallax(tangentViewVector, texGrad, dither);
			parallaxCoord = OffsetCoord(offsetCoord.xy);
		}

		#ifdef MC_NORMAL_MAP
			normalData = ReadTexture(normals).rgb;
			DecodeNormalTex(normalData);
		#else
			normalData = vec3(0.0, 0.0, 1.0);
		#endif

		if (sampleHeight < 0.999) {
			#ifdef PARALLAX_SHADOW
				if (offsetCoord.z < 0.9999) {
					vec3 viewLightVector = mat3(gbufferModelView) * worldLightVector;
					if (dot(tbnMatrix[2], viewLightVector) > 1e-3) {
						colortex7Out.w = CalculateParallaxShadow(viewLightVector * tbnMatrix, offsetCoord, texGrad, dither);
					}
					#ifdef PARALLAX_BASED_NORMAL
						// else {
							vec2 shift = 1e-2 * tileScale;
							float rD = textureGrad(normals, OffsetCoord(offsetCoord.xy + vec2(shift.x, 0.0)), texGradX, texGradY).a;
							float lD = textureGrad(normals, OffsetCoord(offsetCoord.xy - vec2(shift.x, 0.0)), texGradX, texGradY).a;
							float uD = textureGrad(normals, OffsetCoord(offsetCoord.xy + vec2(0.0, shift.y)), texGradX, texGradY).a;
							float dD = textureGrad(normals, OffsetCoord(offsetCoord.xy - vec2(0.0, shift.y)), texGradX, texGradY).a;
							normalData = vec3((lD - rD), (dD - uD), step(abs(lD - rD) + abs(dD - uD), 1e-3));
						// }
					#endif
				}
			#endif
		}

		#if ANISOTROPIC_FILTER > 0
			if (materialIDs != 15u) {
				albedo.rgb *= AnisotropicFilter((parallaxCoord - tileOffset) / tileScale // Don't use tileCoord or offsetCoord.xy
				, texGrad);
				albedo.a *= ReadTexture(tex).a;
			} else
		#endif
	#else
		#define ReadTexture(tex) texture(tex, texcoord)

		#ifdef MC_NORMAL_MAP
			normalData = ReadTexture(normals).rgb;
        	DecodeNormalTex(normalData);
		#else
			normalData = vec3(0.0, 0.0, 1.0);
		#endif

		#if ANISOTROPIC_FILTER > 0
			if (materialIDs != 15u) {
				albedo.rgb *= AnisotropicFilter(tileCoord, texGrad);
				albedo.a *= ReadTexture(tex).a;
			} else
		#endif
	#endif
	{ albedo *= ReadTexture(tex); }

	if (albedo.a < 0.1) { discard; return; }

	#ifdef WHITE_WORLD
		albedo.rgb = vec3(1.0);
	#endif

	#ifdef MC_SPECULAR_MAP
		vec4 specularData = ReadTexture(specular);
	#else
		vec4 specularData = vec4(0.0);
	#endif

	#ifdef IPBR_ENABLED
		bool isFoliage = (materialIDs >= 1u && materialIDs <= 8u) || materialIDs == 10070u || materialIDs == 88u || materialIDs == 65535u;
		#ifdef MC_NORMAL_MAP
			if (!isFoliage) {
				vec3 generatedNormal = GenerateNormalsFromAlbedo(texcoord, texGradX, texGradY);
				normalData = normalize(normalData * 0.75 + generatedNormal * 0.25);
			}
		#else
			if (!isFoliage) {
				normalData = GenerateNormalsFromAlbedo(texcoord, texGradX, texGradY);
			}
		#endif
	#endif // IPBR_ENABLED

	#ifdef IPBR_FORCE_REFLECTIONS
	if (materialIDs == 190u) {
		float smoothness = 0.85;
		float metalness = 0.95;
		float fresnelStrength = 1.0;
		vec3 metalTint = vec3(1.0, 0.95, 0.85);
		float reflectionSharpness = 0.88;

		float detailMask = detectDetails(albedo.rgb);
		smoothness = mix(smoothness, smoothness * 0.5, detailMask);
		smoothness *= reflectionSharpness;

		specularData.r = smoothness;
		specularData.g = metalness;
		specularData.b = 0.0;
		specularData.a = 0.0;

		albedo.rgb = mix(albedo.rgb, albedo.rgb * metalTint, 0.35);
		albedo.rgb = pow(albedo.rgb, vec3(0.90));

		vec3 viewDir = normalize(viewPos.xyz);
		float fresnel = pow(1.0 - abs(dot(tbnMatrix[2], viewDir)), 2.5);
		vec3 fresnelColor = vec3(0.20, 0.18, 0.15);
		fresnel *= mix(0.4, 1.0, reflectionSharpness);
		albedo.rgb += fresnel * fresnelColor * fresnelStrength * (1.0 - detailMask * 0.5);
	}
	#endif // IPBR_FORCE_REFLECTIONS

	#if defined IS_OVERWORLD
		if (wetnessCustom > 1e-2) {
    		float noise = GetRainWetness(minecraftPos.xz - minecraftPos.y);
			noise *= remap(0.5, 0.9, (mat3(gbufferModelViewInverse) * tbnMatrix[2]).y);
			noise *= saturate(lightmap.y * 10.0 - 9.0);
    		float wetFact = smoothstep(0.54, 0.62, noise);

			#ifdef RAIN_SPLASH_EFFECT
				normalData = mix(normalData.xyz, vec3(GetRainNormal(minecraftPos), 1.0), wetFact * 0.5);
			#else
				normalData = mix(normalData.xyz, vec3(0.0, 0.0, 1.0), wetFact);
			#endif

    		wetFact = sqr(remap(0.35, 0.57, noise));

			#ifdef FORCE_WET_EFFECT
				specularData.r = mix(specularData.r, 1.0, wetFact);
				specularData.g = max(specularData.g, 0.04 * wetFact);
				specularData.rg += (dither - 0.5) * rcp(255.0);
			#endif

			vec3 wetAlbedo = ColorSaturation(albedo.rgb, 0.75) * 0.85;
			#ifdef POROSITY
				float porosity = specularData.b > 64.5 / 255.0 ? 0.0 : remap(specularData.b, 0.0, 64.0 / 255.0) * 0.7;
				wetAlbedo *= oneMinus(porosity) / oneMinus(porosity * wetAlbedo);
			#endif
			albedo.rgb = mix(albedo.rgb, wetAlbedo, sqr(remap(0.3, 0.56, noise)));
		}
	#endif

	#if TEXTURE_FORMAT == 0 && defined MC_SPECULAR_MAP
		#if SUBSERFACE_SCATTERING_MODE == 1
			if (materialIDs == 6u) specularData.b = max(0.45, specularData.b);
			if (materialIDs == 7u || materialIDs == 10u) specularData.b = max(0.7, specularData.b);
		#elif SUBSERFACE_SCATTERING_MODE == 0
			if (materialIDs == 6u) specularData.b = 0.45;
			if (materialIDs == 7u || materialIDs == 10u) specularData.b = 0.7;
		#endif
	#elif SUBSERFACE_SCATTERING_MODE < 2
		specularData.a = 0.0;
		if (materialIDs == 6u) specularData.a = 0.45;
		if (materialIDs == 7u || materialIDs == 10u) specularData.a = 0.7;
	#endif

	normalData = normalize(tbnMatrix * normalData);

	albedoData = albedo.rgb;

	// Фикс для block.20088: убираем отражения и делаем его дефолтным (ID 6u - базовый солид блок)
	uint finalMatID = materialIDs;
	if (finalMatID == 20088u) {
		specularData = vec4(0.0);
		finalMatID = 6u;
	}

	colortex7Out.xy = lightmap + (dither - 0.5) * rcp(255.0);
	colortex7Out.z = float(finalMatID + 0.1) * rcp(255.0);

	colortex3Out.xy = EncodeNormal(normalData);
	colortex3Out.z = PackUnorm2x8(specularData.rg);
	colortex3Out.w = PackUnorm2x8(specularData.ba);
}