layout(location = 0) out vec3 colortex7Out;
layout(location = 1) out vec4 reflectionData;
layout(location = 2) out vec4 colortex3Out;

/* DRAWBUFFERS:723 */

#include "/lib/Head/Common.inc"

uniform sampler2D tex;
#ifdef MC_NORMAL_MAP
    uniform sampler2D normals;
#endif

#include "/lib/Head/Uniforms.inc"

in vec2 texcoord;
in vec2 lightmap;

in vec3 minecraftPos;

in vec4 tint;
in vec4 viewPos;
//in vec3 worldNormal;

flat in mat3 tbnMatrix;

flat in uint materialIDs;

#include "/lib/Atmosphere/Atmosphere.glsl"

#define PHYSICS_OCEAN_SUPPORT

#ifdef PHYSICS_OCEAN
	#define PHYSICS_FRAGMENT
	#include "/lib/Water/PhysicsOceans.glsl"
#endif

#include "/lib/Water/WaterWave.glsl"

#if WATER_TRAIL == 1
	uniform sampler2D trailtex0;
	uniform sampler2D trailtex1;
	// Нужен waterTrailHelper.glsl: grid волны теперь якорится на playerPos
	// (cameraPosition - relativeEyePosition), а не на cameraPosition,
	// чтобы в third-person физика не "уезжала" вслед за камерой.
	uniform vec3 relativeEyePosition;

	#include "/lib/util/waterTrailHelper.glsl"

	// Читаем ping-pong буфер следа с ПРЕДЫДУЩЕГО кадра относительно того,
	// в который писал compute (тот же чётность-свап, что видит FloodFill
	// при чтении lighttex0/1 в остальных пассах — см. materialID/lightimg
	// использование в других .fsh, симметрично здесь).
	//
	// ФИКС (волна рендерится под камерой, а не под игроком, в third-person):
	// раньше здесь вычиталось cameraPosition.xz, что давало смещение точки
	// от КАМЕРЫ. WorldToTrail же теперь центрирует сетку на playerPos
	// (см. waterTrailHelper.glsl) — поэтому на вход ей нужно смещение от
	// ИГРОКА, а не от камеры, иначе вся сетка чтения оказывается сдвинута
	// на relativeEyePosition.xz относительно сетки, в которую пишет
	// compute-пасс (WaterTrail.glsl), и рябь на воде визуально рисуется
	// там, где физически находится камера, а не игрок/лодка.
	float GetTrailHeight(vec3 worldPos) {
		vec2 playerPosXZ = cameraPosition.xz - relativeEyePosition.xz;
		vec2 sampleWorldXZ = worldPos.xz - playerPosXZ;

		// Тип 3 (Pixelated, только форма трейла/сплеша): в отличие от
		// типа 2 (который квантует ВСЮ WorldToTrail-сетку в
		// waterTrailHelper.glsl, включая границы/soft bounds), здесь
		// квантуется только worldspace-координата ПЕРЕД чтением высоты
		// трейла — базовая процедурная гладь воды (WaterWave/waterBump,
		// считается отдельно в main()) остаётся гладкой, "пиксельными"
		// становятся именно кольца следа и всплеска.
		#if WATER_TRAIL_VOXEL_TYPE == 3
			sampleWorldXZ = SnapToTrailPixelGrid(sampleWorldXZ);
		#endif

		vec2 trailPos = WorldToTrail(sampleWorldXZ);

		float bounds = GetTrailSoftBounds(trailPos);
		if (bounds <= 0.0) return 0.0;

		int iFrameMod2 = int(frameCounter) % 2;
		float height = (iFrameMod2 == 0)
			? SampleTrailHeightBilinear(trailtex0, trailPos)
			: SampleTrailHeightBilinear(trailtex1, trailPos);

		// Финальный рубеж защиты на стороне чтения — даже если
		// compute-буфер временно содержит мусор (например, один кадр
		// после переключения шейдера, пока трейл-буфер ещё не
		// инициализирован), не даём этому исказить нормаль воды.
		if (isnan(height) || isinf(height)) return 0.0;
		height = clamp(height, -2.0, 2.0);

		return height * bounds * WATER_TRAIL_HEIGHT;
	}

	// out-параметр trailSteepness — 0 там, где трейл-буфер вообще не
	// вносит наклон (обычная гладь), 1 там, где наклон трейла максимален
	// (край ряби/сплеша). CalculateSpecularReflections использует это,
	// чтобы подставлять fallback-specular ИМЕННО в местах, испорченных
	// трейлом, а не трогать общий Френель для физического океана/обычных
	// процедурных волн (WaterWave/waterBump), которые этот параметр не
	// видят и не используют.
	vec3 GetTrailNormal(vec3 worldPos, out float trailSteepness) {
		float sampleStep = 1.0;
		float hC = GetTrailHeight(worldPos);
		float hX = GetTrailHeight(worldPos + vec3(sampleStep, 0.0, 0.0));
		float hZ = GetTrailHeight(worldPos + vec3(0.0, 0.0, sampleStep));

		vec2 trailNormal = vec2(hC - hX, hC - hZ);

		// ФИКС (чёрные пятна -> "прозрачная" вода без текстуры): прежний
		// кламп [-0.6, 0.6] на xy при z=1.0 всё ещё разрешал наклон до
		// ~31°, чего хватало, чтобы reflect()/NdotV на резких краях
		// ИМЕННО воксельного трейла (не физического океана — тот считает
		// свою нормаль отдельно в PhysicsOceans.glsl, trailNormal только
		// подмешивается к ней) уходили в вырожденную зону. Раньше это
		// давало чистый vec4(0.0) (чёрное пятно); после фикса в
		// CalculateSpecularReflections normal стал "выпрямляться" к
		// viewDir — избавило от черноты, но specular по Френелю в этой же
		// зоне падает почти до 0, а alpha = 1.0 - specular почти до 1.0,
		// из-за чего вода перестаёт давать отражение-подложку и выглядит
		// как голая прозрачная поверхность без текстуры воды.
		// Тугой кламп (втрое ниже) не даёт наклону вообще заходить в эту
		// вырожденную зону, а trailSteepness передаётся отдельно, чтобы
		// ниже можно было подмешать нормальный specular fallback именно
		// на пиках трейла, не трогая общий путь для физического океана.
		vec2 clampedTrailNormal = clamp(trailNormal, vec2(-0.2), vec2(0.2));
		trailSteepness = saturate(length(trailNormal - clampedTrailNormal) * 5.0);

		return vec3(clampedTrailNormal, sampleStep);
	}

	vec3 GetTrailNormal(vec3 worldPos) {
		float unused;
		return GetTrailNormal(worldPos, unused);
	}
#endif

vec2 GetWaterParallaxCoord(in vec3 position, in vec3 tangentViewVector) {
	vec3 stepSize = tangentViewVector * vec3(vec2(0.1 * WATER_WAVE_HEIGHT), 1.0);
    stepSize *= 0.02 / abs(stepSize.z);

    vec3 samplePos = vec3(position.xz - position.y, 1.0) + stepSize;
	float sampleHeight = WaterHeight(samplePos.xy);

	for (uint i = 0u; sampleHeight < samplePos.z && i < 60u; ++i) {
        samplePos += stepSize;
		sampleHeight = WaterHeight(samplePos.xy);
	}

	return samplePos.xy;
}

//#include "/lib/Surface/ManualTBN.glsl"

#include "/lib/Surface/RainEffect.glsl"

#include "/lib/Head/Functions.inc"

#include "/lib/Head/Material.inc"

#include "/lib/Surface/ScreenSpaceReflections.glsl"

vec4 CalculateSpecularReflections(in vec3 normal, in float skylight, in vec3 viewPos) {
	#ifdef GLASS_SHADING
		#ifdef MOD_GLASS_SHADING
			bool isGlassShaded = materialIDs == 16u || materialIDs == 35u;
		#else
			bool isGlassShaded = materialIDs == 16u;
		#endif
	#else
		const bool isGlassShaded = false;
	#endif

	// Фикс: если блок не является стеклом, водой (17) или льдом (18), отключаем стекло-шейдинг и SSR.
	if (!isGlassShaded && materialIDs != 17u && materialIDs != 18u) {
		return vec4(0.0, 0.0, 0.0, 1.0);
	}

	skylight = smoothstep(0.3, 0.8, skylight);
	vec3 viewDir = normalize(viewPos);

	vec3 rayDir = reflect(viewDir, normal);

	// ФИКС (чёрные пятна в трейле): NdotL = dot(normal, reflect(viewDir,
	// normal)) математически равен -dot(normal, viewDir) — то же самое
	// число, что и NdotV ниже, с обратным знаком. Раньше при
	// NdotL < 1e-6 функция сразу возвращала ЧИСТЫЙ ЧЁРНЫЙ (vec4(0.0)) без
	// какого-либо fallback. В обычных волнах это почти никогда не
	// срабатывало (пологие нормали), но трейл-буфер может давать резкие,
	// почти вертикальные пики нормали в узкой полосе кильватерного следа
	// (см. WaterTrail.glsl/GetTrailNormal) — там, где нормаль наклонена
	// достаточно сильно, reflect() уходит "под поверхность" относительно
	// взгляда, и весь пиксель проваливался в чёрный провал вместо мягкого
	// перехода. Теперь вместо обрыва в черноту мы выпрямляем (flatten)
	// нормаль в сторону "смотрящей на камеру" (-viewDir даёт NdotV=1 по
	// построению) пропорционально тому, насколько сильно она вывернута —
	// это гарантированно устраняет отрицательный NdotV/NdotL и даёт
	// плавный переход обратно к нормальному отражению неба вместо дыры,
	// вместо попытки угадать "исходную" геометрическую нормаль (её тут
	// просто нет в этой функции — normal уже view-space после TBN).
	float NdotL = dot(normal, rayDir);
	// flattenAmount запоминаем отдельно: раньше выправление нормали само
	// по себе убирало чёрные пятна, но НИЧЕМ не компенсировало то, что
	// Френель на выправленном (почти face-on) участке даёт specular около
	// 0 — alpha = 1.0 - specular уходит к 1.0, и именно эти тексели потом
	// выглядят как "чистая прозрачность без текстуры воды" вместо ряби.
	// Ниже flattenAmount используется, чтобы гарантировать минимальный
	// specular ИМЕННО там, где нормаль была вывернута этим фиксом — для
	// обычной воды/физического океана (где flatten почти никогда не
	// срабатывает) поведение не меняется вообще.
	float flattenAmount = 0.0;
	if (NdotL < 1e-3) {
		vec3 viewFacingNormal = -viewDir;
		flattenAmount = saturate((1e-3 - NdotL) * 4.0);
		vec3 flattenedNormal = normalize(mix(normal, viewFacingNormal, flattenAmount));
		rayDir = reflect(viewDir, flattenedNormal);
		NdotL = dot(flattenedNormal, rayDir);
		normal = flattenedNormal;
	}
	if (NdotL < 1e-6) return vec4(0.0);

	//float dither = BlueNoiseTemporal(0.447213595);
	float dither = InterleavedGradientNoiseTemporal(gl_FragCoord.xy);
	vec3 screenPos = vec3(gl_FragCoord.xy * screenPixelSize, gl_FragCoord.z);
	
	float NdotV = max(1e-6, dot(normal, -viewDir));
	//#ifdef HQ_TRACING
		bool hit = ScreenSpaceRayTrace(viewPos, rayDir, dither, RAYTRACE_SAMPLES, screenPos);
	//#else
	//	bool hit = ScreenSpaceRayTrace(viewPos, rayDir, dither, RAYTRACE_SAMPLES, screenPos);
	//#endif

	vec3 reflection;
	if (materialIDs == 17u) {
		#ifdef REAL_SKY_REFLECTION
			if (isEyeInWater == 0) {
				if (skylight > 1e-3) {
					vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
					float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
					//float tileSize = floor(min(viewWidth * rcp(3.0), viewHeight * 0.5)) * 0.25;
					vec4 skyboxData = textureBicubic(colortex5, ProjectSky(rayDirWorld) + vec2(0.0, skyCaptureRes.y * screenPixelSize.y));

					vec3 sunmoon = RenderSunReflection(rayDirWorld, worldSunVector);
					sunmoon += RenderMoonReflection(rayDirWorld, worldSunVector);

					reflection = hit ? texelFetch(colortex4, ivec2(screenPos.xy), 0).rgb : skyboxData.rgb * skylight * NdotU;
					reflection += sunmoon * skyboxData.a * skylight * AtmosphereAbsorption(rayDirWorld, AtmosphereExtent);
				}
			} else {
				reflection = hit ? texelFetch(colortex4, ivec2(screenPos.xy), 0).rgb : vec3(0.05, 0.7, 1.0) * 0.3;
			}
		#else
			if (hit) {
				reflection = texelFetch(colortex4, ivec2(screenPos.xy), 0).rgb;
			}
			#if defined IS_OVERWORLD
				else if (skylight > 1e-3) {
					if (isEyeInWater == 0) {
						vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
						float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
						//float tileSize = floor(min(viewWidth * rcp(3.0), viewHeight * 0.5)) * 0.25;
						vec4 skyboxData = textureBicubic(colortex5, ProjectSky(rayDirWorld) + vec2(0.0, skyCaptureRes.y * screenPixelSize.y));

						// vec3 sunmoon = RenderSunReflection(rayDirWorld, worldSunVector);
						// sunmoon += RenderMoonReflection(rayDirWorld, worldSunVector);

						// skyboxData.rgb += sunmoon * skyboxData.a * AtmosphereAbsorption(rayDirWorld, AtmosphereExtent);
						reflection = skyboxData.rgb * skylight * NdotU;
					} else {
						reflection = vec3(0.05, 0.7, 1.0) * 0.25 * (timeNoon + timeMidnight * NIGHT_BRIGHTNESS);
					}
				}
			#elif defined IS_END
				else {
					if (isEyeInWater == 0) {
						vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
						float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
						#ifdef DARK_END
							bool darkEnd = bossBattle == 2 || bossBattle == 3;
						#else
							const bool darkEnd = false;
						#endif
						vec3 sunDisc = RenderSun(rayDirWorld, worldSunVector);
						sunDisc *= vec3(0.99, 0.93, 0.65) * 0.1;
						reflection = mix(vec3(0.396, 0.352, 0.108), vec3(0.04, 0.02, 0.05), float(darkEnd) * 0.9) * 2.0 * exp2(-max0(rayDirWorld.y) * 1.5);	
						if (!darkEnd) reflection += sunDisc;
						reflection *= NdotU;
					} else {
						reflection = vec3(0.05, 0.7, 1.0) * 0.25;
					}
				}
			#endif
		#endif
	} else {
		if (hit) {
			reflection = texelFetch(colortex4, ivec2(screenPos.xy), 0).rgb;
		}
		#if defined IS_OVERWORLD
			else if (skylight > 1e-3) {
				vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
				float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
				//float tileSize = floor(min(viewWidth * rcp(3.0), viewHeight * 0.5)) * 0.25;
				vec4 skyboxData = textureBicubic(colortex5, ProjectSky(rayDirWorld) + vec2(0.0, skyCaptureRes.y * screenPixelSize.y));

				// vec3 sunmoon = RenderSun(rayDirWorld, worldSunVector);
				// sunmoon += RenderMoonReflection(rayDirWorld, worldSunVector);

				// skyboxData.rgb += sunmoon * skyboxData.a * AtmosphereAbsorption(rayDirWorld, AtmosphereExtent);
				reflection = skyboxData.rgb * skylight * NdotU;
			}
		#elif defined IS_END
			else {
				vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
				float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
				#ifdef DARK_END
					bool darkEnd = bossBattle == 2 || bossBattle == 3;
				#else
					const bool darkEnd = false;
				#endif
				vec3 sunDisc = RenderSun(rayDirWorld, worldSunVector);
				sunDisc *= vec3(0.99, 0.93, 0.65) * 0.1;
				reflection = mix(vec3(0.396, 0.352, 0.108), vec3(0.04, 0.02, 0.05), float(darkEnd) * 0.9) * 2.0 * exp2(-max0(rayDirWorld.y) * 1.5);	
				if (!darkEnd) reflection += sunDisc;
				reflection *= NdotU;
			}
		#endif
	}

	float specular;
	if (isEyeInWater == 1) { // 全反射
		//specular = FresnelDielectricN(NdotV, 1.000293 / WATER_REFRACT_IOR);
		specular = FresnelDielectricN(NdotV, 1.0 / WATER_REFRACT_IOR);
	} else {
		float ior = materialIDs == 17u ? WATER_REFRACT_IOR : (isGlassShaded ? GLASS_REFRACT_IOR : 1.31);
		specular = FresnelDielectricN(NdotV, ior);
	}

	// ФИКС (чёрные пятна -> прозрачная вода без текстуры, вторая часть):
	// на выправленной (flattened) нормали NdotV искусственно близок к 1,
	// и Френель честно даёт минимальный specular — но именно в этих
	// текселях (край трейла) должна быть видна ХОТЯ БЫ базовая гладь воды,
	// а не почти-чистая прозрачность (alpha = 1.0 - specular). Подмешиваем
	// небольшой минимальный specular пропорционально flattenAmount — 0
	// при обычной воде (flattenAmount == 0, ничего не меняется), растёт
	// только там, где сам трейл вызвал flatten.
	specular = max(specular, flattenAmount * 0.02);

	return clamp16F(vec4(reflection * specular, 1.0 - specular));
}

void main() {
	vec4 albedo = texture(tex, texcoord) * tint;

    //mat3 tbnMatrix = manualTBN(viewPos.xyz, texcoord);

	vec3 normalData;
	#ifdef PHYSICS_OCEAN
		if (materialIDs == 17u) {
				WavePixelData wave = physics_wavePixel(physics_localPosition.xz, physics_localWaviness, physics_iterationsNormal, physics_gameTime);
				vec3 waveNormal = wave.normal;

				#if WATER_TRAIL == 1
					vec3 trailNormalTS = GetTrailNormal(minecraftPos);
					waveNormal.xy += trailNormalTS.xy * WATER_TRAIL_HEIGHT;
					waveNormal = normalize(waveNormal);
				#endif

				normalData = mat3(gbufferModelView) * waveNormal;
				normalData = isEyeInWater == 1 ? -normalData : normalData;
		} else {
			#ifdef MC_NORMAL_MAP
				normalData = texture(normals, texcoord).rgb;
				DecodeNormalTex(normalData);
			#else
				normalData = vec3(0.0, 0.0, 1.0);
			#endif

			#if defined IS_OVERWORLD
				#ifdef RAIN_SPLASH_EFFECT
					if (wetnessCustom > 1e-2) {
						vec2 rainNormal = GetRainNormal(wetnessCustom, minecraftPos);
						normalData.xy += rainNormal * wetnessCustom * saturate(lightmap.y * 10.0 - 9.0);
					}
				#endif
			#endif

			normalData = normalize(tbnMatrix * normalData);
		}
	#else
		if (materialIDs == 17u) {
			#ifdef WATER_PARALLAX
				vec2 position = GetWaterParallaxCoord(minecraftPos, normalize(viewPos.xyz * tbnMatrix));
				normalData = GetWavesNormal(position);
			#else
				normalData = GetWavesNormal(minecraftPos.xz - minecraftPos.y);
			#endif

			#if WATER_TRAIL == 1
				vec3 trailNormalTS = GetTrailNormal(minecraftPos);
				normalData.xy += trailNormalTS.xy * WATER_TRAIL_HEIGHT;
				normalData = normalize(normalData);
			#endif
		} else {
			#ifdef MC_NORMAL_MAP
				normalData = texture(normals, texcoord).rgb;
				DecodeNormalTex(normalData);
			#else
				normalData = vec3(0.0, 0.0, 1.0);
			#endif
		}

		#if defined IS_OVERWORLD
			#ifdef RAIN_SPLASH_EFFECT
				if (wetnessCustom > 1e-2) {
					vec2 rainNormal = GetRainNormal(minecraftPos);
					normalData.xy += rainNormal * wetnessCustom * saturate(lightmap.y * 10.0 - 9.0);
				}
			#endif
		#endif

		normalData = normalize(tbnMatrix * normalData);
	#endif

	colortex7Out.xy = lightmap + (bayer4(gl_FragCoord.xy) - 0.5) * rcp(255.0);
	colortex7Out.z = float(materialIDs + 0.1) * rcp(255.0);

	colortex3Out.xy = EncodeNormal(normalData);
	colortex3Out.z = PackUnorm2x8(albedo.rg);
	colortex3Out.w = PackUnorm2x8(albedo.ba);

	reflectionData = CalculateSpecularReflections(normalData, cube(lightmap.g), viewPos.xyz);
}