uniform int entityId;
uniform vec2 taaOffset;

//#if MC_VERSION < 11500
//	layout(location = 12) in vec4 at_tangent;
//#else
//	layout(location = 13) in vec4 at_tangent;
//#endif

out vec4 tint;
out vec2 texcoord;
out vec4 viewPos;

out vec2 lightmap;

//flat out mat3 tbnMatrix;

out vec3 flatNormal;

flat out int materialIDs;

#include "/Settings.glsl"

// ─────────────────────────────────────────────────────────────────────────
// Spider Eye Glow — Voxel Flood-Fill Source
//
// Паук (entityId 10015, см. entity.properties) получает красный
// светящийся источник в voxel-грид на позиции "перед мордой", чтобы
// FloodFill.glsl подхватил его так же, как обычный блочный источник
// света (факел и т.п.) — с плавной пропагацией и затуханием.
//
// Геометрия сущностей НЕ вокселизуется в Shadow.vert (см. isTerrain там)
// — иначе моб сам "затыкал" бы дыру в свете своим телом. Поэтому точку
// глаз пишем здесь, напрямую в voxelimg, отдельным imageStore, а не
// через общий проход UpdateVoxelMap.
//
// Направление "вперёд" модели паука берём из третьей строки
// gl_ModelViewMatrix — это стандартный трюк: столбцы 0/1/2 матрицы
// ModelView кодируют повёрнутые локальные оси объекта (X/Y/Z модели) в
// view-пространстве, поэтому третий базисный вектор (локальный +Z модели)
// после домножения на normalMatrix даёт forward-направление моба в мире,
// без необходимости отдельного uniform с yaw сущности.
#if MULTICOLORED_BLOCKLIGHT == 1
	uniform vec3 cameraPosition;
	uniform mat4 shadowModelViewInverse; // не используется тут, зарезервировано
	uniform mat4 gbufferModelViewInverse;

	writeonly uniform uimage3D voxelimg;

	#include "/lib/util/voxelMapHelper.glsl"

	#ifndef SPIDER_EYE_MATERIAL_ID
		#define SPIDER_EYE_MATERIAL_ID 132 // свободный ID: блоки занимают 0-131, WALL=99
	#endif
	#ifndef SPIDER_EYE_FORWARD_OFFSET
		#define SPIDER_EYE_FORWARD_OFFSET 1.0 // блоков вперёд от паука
	#endif
	#ifndef SPIDER_EYE_HEIGHT_OFFSET
		#define SPIDER_EYE_HEIGHT_OFFSET 0.35 // подъём над "ногами" паука к уровню глаз
	#endif
#endif

void main() {
	tint = gl_Color;
	texcoord = gl_MultiTexCoord0.xy;

	lightmap = clamp(gl_MultiTexCoord1.xy * (1.0 / 240.0), 0.0, 1.0);

	flatNormal = normalize(gl_NormalMatrix * gl_Normal);
    //tbnMatrix[2] = normalize(gl_NormalMatrix * gl_Normal);
	//#ifdef MC_NORMAL_MAP
	//	tbnMatrix[0] = normalize(gl_NormalMatrix * at_tangent.xyz);
	//	tbnMatrix[1] = cross(tbnMatrix[0], tbnMatrix[2]) * sign(at_tangent.w);
	//#endif

	viewPos = gl_ModelViewMatrix * gl_Vertex;
	gl_Position = gl_ProjectionMatrix * viewPos;

	#ifdef TAA_ENABLED
		gl_Position.xy += taaOffset * gl_Position.w;
	#endif

	// Если это дропнутый светящийся предмет (13100-13145), сжимаем его в диапазон 150-195
	if (entityId >= 13100 && entityId <= 13145) {
		materialIDs = 150 + (entityId - 13100);
	} else {
		materialIDs = max(entityId - 10000, 0);
	}

	#if MULTICOLORED_BLOCKLIGHT == 1
		// Пишем ровно один раз за entity-меш за кадр (на первой вершине
		// первого квада), а не на каждый вертекс — иначе один и тот же
		// паук писал бы сотни одинаковых imageStore за кадр без пользы.
		if (materialIDs == 15 && gl_VertexID == 0) {
			// Локальное начало координат модели (её "ноги"/якорь) в
			// view-пространстве — умножаем нулевой вектор на ModelView,
			// что равнозначно взятию 4-го столбца матрицы (translation).
			vec3 originView = (gl_ModelViewMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;

			// Forward модели в view-пространстве — локальная +Z ось.
			vec3 forwardView = normalize(mat3(gl_ModelViewMatrix) * vec3(0.0, 0.0, 1.0));

			vec3 eyeViewPos = originView
				+ forwardView * SPIDER_EYE_FORWARD_OFFSET
				+ vec3(0.0, SPIDER_EYE_HEIGHT_OFFSET, 0.0);

			vec3 eyeWorldPos = (gbufferModelViewInverse * vec4(eyeViewPos, 1.0)).xyz;

			vec3 voxelPos = WorldToVoxel(eyeWorldPos);
			if (IsInVoxelMapVolume(voxelPos)) {
				imageStore(voxelimg, ivec3(voxelPos), uvec4(uint(SPIDER_EYE_MATERIAL_ID), 0u, 0u, 0u));
			}
		}
	#endif
}