layout(location = 0) out vec4 albedoData;
layout(location = 1) out vec3 colortex7Out;
layout(location = 2) out vec4 colortex3Out;

/* DRAWBUFFERS:673 */

#include "/lib/Head/Common.inc"

uniform sampler2D tex;
#ifdef MC_NORMAL_MAP
    uniform sampler2D normals;
#endif
#ifdef MC_SPECULAR_MAP
    uniform sampler2D specular;
#endif

uniform float frameTimeCounter;

uniform mat4 gbufferModelViewInverse;

in vec4 tint;
in vec2 texcoord;
in vec3 minecraftPos;
in vec4 viewPos;

in vec2 lightmap;

//flat in mat3 tbnMatrix;

flat in int materialIDs;

#define PROGRAM_GBUFFERS_BLOCK

#ifndef RAIN_SPLASH_EFFECT
	#undef PROGRAM_GBUFFERS_BLOCK
#endif

#include "/lib/Surface/ManualTBN.glsl"

const vec3[] COLORS = vec3[](
    vec3(0.022087, 0.098399, 0.110818),
    vec3(0.011892, 0.095924, 0.089485),
    vec3(0.027636, 0.101689, 0.100326),
    vec3(0.046564, 0.109883, 0.114838),
    vec3(0.064901, 0.117696, 0.097189),
    vec3(0.063761, 0.086895, 0.123646),
    vec3(0.084817, 0.111994, 0.166380),
    vec3(0.097489, 0.154120, 0.091064),
    vec3(0.106152, 0.131144, 0.195191),
    vec3(0.097721, 0.110188, 0.187229),
    vec3(0.133516, 0.138278, 0.148582),
    vec3(0.070006, 0.243332, 0.235792),
    vec3(0.196766, 0.142899, 0.214696),
    vec3(0.047281, 0.315338, 0.321970),
    vec3(0.204675, 0.390010, 0.302066),
    vec3(0.080955, 0.314821, 0.661491)
);

mat2 mat2RotateZ(in float radian) {
	return mat2(
		cos(radian), -sin(radian),
		sin(radian), cos(radian)
	);
}

vec2 endPortalLayer(in vec2 coord, in float layer) {
	vec2 offset = vec2(8.5 / layer, (1.0 + layer / 3.0) * (frameTimeCounter * 0.0015)) + 0.25;

	mat2 rotate = mat2RotateZ(radians(layer * layer * 8642.0 + layer * 18.0));

	return (4.5 - layer / 4.0) * (rotate * coord) + offset;
}

#if defined IS_OVERWORLD
	uniform sampler2D noisetex;
	uniform sampler2D colortex7;

	uniform float wetnessCustom;

	#include "/lib/Surface/RainEffect.glsl"
#endif

float bayer2 (vec2 a) { a = 0.5 * floor(a); return fract(1.5 * fract(a.y) + a.x); }
#define bayer4(a) (bayer2(0.5 * (a)) * 0.25 + bayer2(a))

// === iPBR System ===
#ifndef IPBR_ENABLED
#define IPBR_ENABLED
#endif
#ifndef IPBR_FORCE_REFLECTIONS
#define IPBR_FORCE_REFLECTIONS
#endif
#ifndef IPBR_STYLE
#define IPBR_STYLE 1 // [1 2 3]
#endif
#ifndef IPBR_RESOLUTION
#define IPBR_RESOLUTION 16 // [8 16 32 64 128 256 512 1024]
#endif

// --- Стиль 1: оригинальный Sobel по яркости ---
vec3 GenerateNormals_Style1_B(vec2 coord) {
    const float normalStrength = 2.5;
    vec2 texGradX = dFdx(coord);
    vec2 texGradY = dFdy(coord);
    vec2 baseStep = max(vec2(length(texGradX), length(texGradY)), vec2(1.0 / 4096.0));
    float resScale = float(IPBR_RESOLUTION) / 64.0;
    vec2 step = baseStep * resScale;

    float right = dot(textureGrad(tex, coord + vec2(step.x, 0.0),  texGradX, texGradY).rgb, vec3(0.299, 0.587, 0.114));
    float left  = dot(textureGrad(tex, coord - vec2(step.x, 0.0),  texGradX, texGradY).rgb, vec3(0.299, 0.587, 0.114));
    float up    = dot(textureGrad(tex, coord + vec2(0.0, step.y),   texGradX, texGradY).rgb, vec3(0.299, 0.587, 0.114));
    float down  = dot(textureGrad(tex, coord - vec2(0.0, step.y),   texGradX, texGradY).rgb, vec3(0.299, 0.587, 0.114));

    vec2 gradient = vec2(right - left, up - down) * normalStrength;
    return normalize(vec3(-gradient.x, -gradient.y, 1.0));
}

// --- Стиль 2: Revelation-style ---
vec3 GenerateNormals_Style2_B(vec2 coord) {
    vec2 texGradX = dFdx(coord);
    vec2 texGradY = dFdy(coord);
    vec2 bias = max(vec2(length(texGradX), length(texGradY)), vec2(1.0 / 4096.0));
    bias *= (16.0 / float(IPBR_RESOLUTION));

    vec4 sampleR = textureGrad(tex, coord + vec2(bias.x, 0.0),  texGradX, texGradY);
    vec4 sampleL = textureGrad(tex, coord - vec2(bias.x, 0.0),  texGradX, texGradY);
    vec4 sampleU = textureGrad(tex, coord + vec2(0.0, bias.y),   texGradX, texGradY);
    vec4 sampleD = textureGrad(tex, coord - vec2(0.0, bias.y),   texGradX, texGradY);

    float heightR = dot(sampleR.rgb, vec3(0.2126, 0.7152, 0.0722)) * sampleR.a;
    float heightL = dot(sampleL.rgb, vec3(0.2126, 0.7152, 0.0722)) * sampleL.a;
    float heightU = dot(sampleU.rgb, vec3(0.2126, 0.7152, 0.0722)) * sampleU.a;
    float heightD = dot(sampleD.rgb, vec3(0.2126, 0.7152, 0.0722)) * sampleD.a;

    float deltaX = (heightL - heightR) * 2.5;
    float deltaY = (heightD - heightU) * 2.5;
    float zStrength = 32.0 / float(IPBR_RESOLUTION);
    return normalize(vec3(deltaX, deltaY, zStrength));
}

// --- Стиль 3: Contrast-enhanced ---
vec3 GenerateNormals_Style3_B(vec2 coord) {
    vec2 texGradX = dFdx(coord);
    vec2 texGradY = dFdy(coord);
    vec2 baseStep = max(vec2(length(texGradX), length(texGradY)), vec2(1.0 / 4096.0));
    float resScale = float(IPBR_RESOLUTION) / 64.0;
    vec2 step = baseStep * resScale;

    vec3 sR = textureGrad(tex, coord + vec2(step.x, 0.0),  texGradX, texGradY).rgb;
    vec3 sL = textureGrad(tex, coord - vec2(step.x, 0.0),  texGradX, texGradY).rgb;
    vec3 sU = textureGrad(tex, coord + vec2(0.0, step.y),   texGradX, texGradY).rgb;
    vec3 sD = textureGrad(tex, coord - vec2(0.0, step.y),   texGradX, texGradY).rgb;

    const vec3 weights = vec3(0.45, 0.38, 0.17);
    float hR = pow(dot(sR, weights), 1.4);
    float hL = pow(dot(sL, weights), 1.4);
    float hU = pow(dot(sU, weights), 1.4);
    float hD = pow(dot(sD, weights), 1.4);

    float dX = (hL - hR) * 3.2;
    float dY = (hD - hU) * 3.2;
    return normalize(vec3(-dX, -dY, 1.0));
}

vec3 GenerateNormalsFromAlbedo(vec2 coord) {
    #if IPBR_STYLE == 2
        return GenerateNormals_Style2_B(coord);
    #elif IPBR_STYLE == 3
        return GenerateNormals_Style3_B(coord);
    #else
        return GenerateNormals_Style1_B(coord);
    #endif
}

void main() {
	vec4 albedo = texture(tex, texcoord) * tint;

	#ifdef WHITE_WORLD
		albedo.rgb = vec3(1.0);
	#endif

    mat3 tbnMatrix = manualTBN(viewPos.xyz, texcoord);

	if (albedo.a < 0.1) { discard; return; }

	#ifdef MC_SPECULAR_MAP
		vec4 specularData = texture(specular, texcoord);
	#else
		vec4 specularData = vec4(0.0);
	#endif

    #ifdef MC_NORMAL_MAP
        vec3 normalData = texture(normals, texcoord).rgb;
        DecodeNormalTex(normalData);
    #else
        vec3 normalData = vec3(0.0, 0.0, 1.0);
    #endif

	bool skipNormalGen = (materialIDs == 19);

	#ifdef IPBR_ENABLED
	if (!skipNormalGen) {
		vec3 generatedNormal = GenerateNormalsFromAlbedo(texcoord);
		#ifdef MC_NORMAL_MAP
			normalData = normalize(normalData * 0.75 + generatedNormal * 0.25);
		#else
			normalData = generatedNormal;
		#endif
	}
	#endif

	#ifdef IPBR_FORCE_REFLECTIONS
	if (materialIDs == 190) {
		float smoothness = 0.85;
		float metalness = 0.95;
		float fresnelStrength = 1.0;
		vec3 metalTint = vec3(1.0, 0.95, 0.85);
		float reflectionSharpness = 0.88;

		float brightness = dot(albedo.rgb, vec3(0.299, 0.587, 0.114));
		float detailMask = brightness < 0.25 ? 1.0 : (brightness < 0.35 ? 0.7 : 0.0);
		smoothness = mix(smoothness, smoothness * 0.5, detailMask);
		smoothness *= reflectionSharpness;

		specularData.r = smoothness;
		specularData.g = metalness;
		specularData.b = 0.0;
		specularData.a = 0.0;

		albedo.rgb = mix(albedo.rgb, albedo.rgb * metalTint, 0.35);
		albedo.rgb = pow(albedo.rgb, vec3(0.90));

		vec3 viewDir = normalize(viewPos.xyz);
		float fresnel = pow(1.0 - abs(dot(tbnMatrix[2], viewDir)), 2.5);
		vec3 fresnelColor = vec3(0.20, 0.18, 0.15);
		fresnel *= mix(0.4, 1.0, reflectionSharpness);
		albedo.rgb += fresnel * fresnelColor * fresnelStrength * (1.0 - detailMask * 0.5);
	}
	#endif // IPBR_FORCE_REFLECTIONS

	#if defined IS_OVERWORLD
		if (wetnessCustom > 1e-2) {
    		float noise = GetRainWetness(minecraftPos.xz - minecraftPos.y);
			noise *= remap(0.5, 0.9, (mat3(gbufferModelViewInverse) * tbnMatrix[2]).y);
			noise *= saturate(lightmap.y * 10.0 - 9.0);
    		float wetFact = smoothstep(0.54, 0.62, noise);

			#ifdef RAIN_SPLASH_EFFECT
				normalData = mix(normalData.xyz, vec3(GetRainNormal(minecraftPos), 1.0), wetFact * 0.5);
			#else
				normalData = mix(normalData.xyz, vec3(0.0, 0.0, 1.0), wetFact);
			#endif

    		wetFact = sqr(remap(0.35, 0.57, noise));

			#ifdef FORCE_WET_EFFECT
				specularData.r = mix(specularData.r, 1.0, wetFact);
				specularData.g = max(specularData.g, 0.04 * wetFact);
				specularData.rg += (bayer4(gl_FragCoord.xy) - 0.5) * rcp(255.0);
			#endif

			vec3 wetAlbedo = ColorSaturation(albedo.rgb, 0.75) * 0.85;
			#ifdef POROSITY
				float porosity = specularData.b > 64.5 / 255.0 ? 0.0 : remap(specularData.b, 0.0, 64.0 / 255.0) * 0.7;
				wetAlbedo *= oneMinus(porosity) / oneMinus(porosity * wetAlbedo);
			#endif
			albedo.rgb = mix(albedo.rgb, wetAlbedo, sqr(remap(0.3, 0.56, noise)));
		}
	#endif

	normalData = normalize(tbnMatrix * normalData);

	if (materialIDs == 19) {
		vec3 worldDir = mat3(gbufferModelViewInverse) * normalize(viewPos.xyz);
		vec3 worldDirAbs = abs(worldDir);
		vec3 samplePartAbs = step(maxOf(worldDirAbs), worldDirAbs);
		vec3 samplePart = samplePartAbs * sign(worldDir);
		float intersection = 1.0 / dot(samplePartAbs, worldDirAbs);
		vec3 sampleNDCRaw = samplePart - worldDir * intersection;
		vec2 sampleNDC = sampleNDCRaw.xy * vec2(samplePartAbs.y + samplePart.z, 1.0 - samplePartAbs.y) + sampleNDCRaw.z * vec2(-samplePart.x, samplePartAbs.y);
		vec2 portalCoord = sampleNDC * 0.5 + 0.5;

		vec3 portalColor = texture(tex, portalCoord).rgb * COLORS[0];
		for (int i = 0; i < 16; ++i) {
			portalColor += texture(tex, endPortalLayer(portalCoord, float(i + 1))).rgb * COLORS[i];
		}
		albedo.rgb = portalColor;
		specularData = vec4(1.0, 0.04, vec2(254.0 / 255.0));
	}

	#if TEXTURE_FORMAT == 0 && defined MC_SPECULAR_MAP
		#if SUBSERFACE_SCATTERING_MODE == 1
			if (materialIDs == 9) specularData.b = max(0.65, specularData.b);
		#elif SUBSERFACE_SCATTERING_MODE == 0
			if (materialIDs == 9) specularData.b = 0.65;
		#endif
	#elif SUBSERFACE_SCATTERING_MODE < 2
		specularData.a = 0.0;
		if (materialIDs == 9) specularData.a = 0.65;
	#endif

	albedoData = albedo;

	// Фикс для block.20088: убираем отражения и делаем его дефолтным (ID 6 - базовый солид блок)
	int finalMatID = materialIDs;
	if (finalMatID == 20088) {
		specularData = vec4(0.0);
		finalMatID = 6;
	}

	colortex7Out.xy = lightmap + (bayer4(gl_FragCoord.xy) - 0.5) * rcp(255.0);
	colortex7Out.z = float(finalMatID + 0.1) * rcp(255.0);

	colortex3Out.xy = EncodeNormal(normalData);
	colortex3Out.z = PackUnorm2x8(specularData.rg);
	colortex3Out.w = PackUnorm2x8(specularData.ba);
}