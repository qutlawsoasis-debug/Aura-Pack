#version 450 compatibility

#extension GL_ARB_shader_image_load_store : enable

#define CSH

#include "/lib/Head/Common.inc"
#include "/lib/Lighting/PointShadowVoxelize.glsl"

