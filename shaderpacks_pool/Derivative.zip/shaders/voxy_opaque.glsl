#include "/lib/Head/Common.inc"

layout(location = 0) out vec3 albedoData;
layout(location = 1) out vec4 colortex7Out;
layout(location = 2) out vec4 colortex3Out;
layout(location = 3) out vec4 colortex29Out;

vec3 voxy_face_normal(uint face) {
    return vec3(
        uint((face >> 1) == 2),
        uint((face >> 1) == 0),
        uint((face >> 1) == 1)
    ) * (float(int(face) & 1) * 2.0 - 1.0);
}

float voxy_dither() {
    return fract(
        52.9829189 * fract(
            0.06711056 * gl_FragCoord.x +
            0.00583715 * gl_FragCoord.y +
            0.00623715 * float(frameCounter & 63)
        )
    );
}

uint voxy_material_id(uint customId) {
    uint materialID = customId;
    if (materialID >= 10000u) materialID -= 10000u;
    if (materialID == 65535u) return 6u;
    if (materialID > 0u) materialID = max(materialID, 6u);
    return min(materialID, 255u);
}

vec2 voxy_lightmap(vec2 lightmap) {
    return saturate((lightmap - 0.03125) * 1.06667);
}

void voxy_emitFragment(VoxyFragmentParameters parameters) {
    vec3 albedo = parameters.sampledColour.rgb * parameters.tinting.rgb;
    vec3 normal = normalize(mat3(gbufferModelView) * voxy_face_normal(parameters.face));
    uint materialID = voxy_material_id(parameters.customId);
    vec2 lightmap = voxy_lightmap(parameters.lightMap);
    vec4 specularData = vec4(0.0);

#if TEXTURE_FORMAT == 0
    if (materialID == 6u) specularData.b = 0.45;
    if (materialID == 7u || materialID == 10u) specularData.b = 0.7;
#elif SUBSERFACE_SCATTERING_MODE < 2
    if (materialID == 6u) specularData.a = 0.45;
    if (materialID == 7u || materialID == 10u) specularData.a = 0.7;
#endif

#ifdef WHITE_WORLD
    albedo = vec3(1.0);
#endif

    albedoData = albedo;
    colortex7Out.xy = lightmap + (voxy_dither() - 0.5) * rcp(255.0);
    colortex7Out.z = (float(materialID) + 0.1) * rcp(255.0);
    colortex7Out.w = 0.0;
    colortex3Out.xy = EncodeNormal(normal);
    colortex3Out.z = PackUnorm2x8(specularData.rg);
    colortex3Out.w = PackUnorm2x8(specularData.ba);
    colortex29Out = vec4(0.0);
}
