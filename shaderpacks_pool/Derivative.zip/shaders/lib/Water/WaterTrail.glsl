

#ifdef CSH

#if WATER_TRAIL == 1

#ifndef WATER_TRAIL_STYLE
	#define WATER_TRAIL_STYLE 2 // [1 2]
#endif

layout (local_size_x = 8, local_size_y = 8) in;

#if WATER_TRAIL_SIZE == 64
	const ivec3 workGroups = ivec3(8, 8, 1);
#elif WATER_TRAIL_SIZE == 96
	const ivec3 workGroups = ivec3(12, 12, 1);
#elif WATER_TRAIL_SIZE == 128
	const ivec3 workGroups = ivec3(16, 16, 1);
#elif WATER_TRAIL_SIZE == 192
	const ivec3 workGroups = ivec3(24, 24, 1);
#elif WATER_TRAIL_SIZE == 256
	const ivec3 workGroups = ivec3(32, 32, 1);
#endif

//Uniforms//
uniform int frameCounter;

uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
uniform vec3 relativeEyePosition;
uniform sampler2D trailtex0;
uniform sampler2D trailtex1;
uniform usampler2D waterpresencetex;
writeonly uniform image2D trailimg0;
writeonly uniform image2D trailimg1;
uniform sampler2D playerpostex;
writeonly uniform image2D playerposimg;

//Includes//
#include "/lib/util/waterTrailHelper.glsl"

//Program//
void main() {
	int iFrameMod2 = int(frameCounter) % 2;
	vec3 playerPos = cameraPosition - relativeEyePosition;
	vec3 previousPlayerPos = texelFetch(playerpostex, ivec2(0), 0).xyz;
	if (all(equal(previousPlayerPos, vec3(0.0)))) previousPlayerPos = playerPos;

	ivec2 pos = ivec2(gl_GlobalInvocationID.xy);
	ivec2 prevPos = pos + ivec2(floor(playerPos.xz) - floor(previousPlayerPos.xz));

	vec2 self;
	if (iFrameMod2 == 0) {
		self = IsInTrailVolume(vec2(prevPos)) ? texelFetch(trailtex1, prevPos, 0).rg : vec2(0.0);
	} else {
		self = IsInTrailVolume(vec2(prevPos)) ? texelFetch(trailtex0, prevPos, 0).rg : vec2(0.0);
	}

	if (any(isnan(self)) || any(isinf(self))) self = vec2(0.0);

	float height   = self.r;
	float velocity = self.g;

	ivec2 offsets[4] = ivec2[4](
		ivec2(1, 0), ivec2(-1, 0),
		ivec2(0, 1), ivec2(0, -1)
	);

	float neighborSum = 0.0;
	float neighborCount = 0.0;

	for (int i = 0; i < 4; i++) {
		ivec2 neighborPosPrev = prevPos + offsets[i];
		if (!IsInTrailVolume(vec2(neighborPosPrev))) continue;

		float neighborHeight;
		if (iFrameMod2 == 0) {
			neighborHeight = texelFetch(trailtex1, neighborPosPrev, 0).r;
		} else {
			neighborHeight = texelFetch(trailtex0, neighborPosPrev, 0).r;
		}

		if (isnan(neighborHeight) || isinf(neighborHeight)) continue;

		neighborSum += neighborHeight;
		neighborCount += 1.0;
	}

	float avgNeighborHeight = (neighborCount > 0.5) ? neighborSum * rcp(neighborCount) : height;

	// CFL-safe
	float waveCoeff = mix(0.12, 0.24, saturate(WATER_TRAIL_SPEED * 0.5));
	velocity += (avgNeighborHeight - height) * waveCoeff;
	velocity *= WATER_TRAIL_DAMPING;
	height += velocity;
	height *= WATER_TRAIL_HEIGHT_DECAY;
	vec2 playerDeltaXZ = playerPos.xz - previousPlayerPos.xz;
	float cameraSpeed = length(playerDeltaXZ);

	// Deadzone 
	const float speedDeadzone = 0.002;


	vec2 playerTrailPos = WorldToTrail(vec2(0.0));
	ivec2 playerCell = ivec2(floor(playerTrailPos));
	ivec2 playerCellClamped = clamp(playerCell, ivec2(0), ivec2(WATER_TRAIL_SIZE - 1));

	#ifndef WATER_TRAIL_MAX_VDIST
		#define WATER_TRAIL_MAX_VDIST 1.5
	#endif

	uint presenceRaw = texelFetch(waterpresencetex, playerCellClamped, 0).r;
	bool waterHere;
	float waterY = DecodeWaterY(presenceRaw, waterHere);
	bool playerOnWater = waterHere && abs(playerPos.y - waterY) < WATER_TRAIL_MAX_VDIST;

	ivec2 selfToPlayer = pos - playerCell;
	float distToPlayer = length(vec2(selfToPlayer));
	vec2 heading = (cameraSpeed > 1e-5) ? playerDeltaXZ * rcp(cameraSpeed) : vec2(0.0, 1.0);
	const float bowLead = 1.4;
	vec2 bowCellF = vec2(playerCell) + heading * bowLead;
	ivec2 selfToBow = pos - ivec2(round(bowCellF));
	float distToBow = length(vec2(selfToBow));

	if (playerOnWater && cameraSpeed > speedDeadzone) {
		float clampedSpeed = min(cameraSpeed, 0.5);

		#if WATER_TRAIL_STYLE == 1
			// ── Стиль 1 (Default)
			const float injectRadius = 0.9;
			if (distToPlayer < injectRadius) {
				float falloff = saturate(1.0 - distToPlayer * rcp(injectRadius));
				height -= clampedSpeed * WATER_TRAIL_STRENGTH * falloff;
			}
		#elif WATER_TRAIL_STYLE == 2 || WATER_TRAIL_STYLE == 3
			// ── Стиль 2 (Smooth Wake)
			vec2 heading = playerDeltaXZ * rcp(cameraSpeed); 
			vec2 headingPerp = vec2(-heading.y, heading.x);

			vec2 toSelf = vec2(selfToPlayer);
			float along = -dot(toSelf, heading);   
			float across = dot(toSelf, headingPerp);
			const float wakeLength   = 14.0;
			const float baseWidth    = 0.9;   // полуширина канала у игрока
			const float widthGrowth  = 0.05;  // прирост полуширины на 1 блок along
			const float edgeSoftness = 0.25;  // ширина сглаженной каёмки (текселей)

			if (along > -0.5) {
				float alongClamped = max(along, 0.0);

				// alongFalloff 
				float alongFalloff = saturate(1.0 - alongClamped * rcp(wakeLength));
				alongFalloff = alongFalloff * alongFalloff; 

				float halfWidth = baseWidth + alongClamped * widthGrowth;
				float edgeDist = halfWidth - abs(across); // >0 внутри канала
				float channelMask = smoothstep(-edgeSoftness, edgeSoftness, edgeDist);

				float wakeShape = channelMask;

				#if WATER_TRAIL_STYLE == 2
					const float waveFreqAcross = 3.6;
					const float waveFreqAlong  = 0.9;
					const float wavePhaseSpeed = 0.35;

					float wavePhase = across * waveFreqAcross
					                 - alongClamped * waveFreqAlong * 0.15
					                 + float(frameCounter) * wavePhaseSpeed;
					float innerWave = sin(wavePhase) * 0.5 + 0.5; // [0,1]


					wakeShape *= mix(0.55, 1.0, innerWave);
				#endif


				wakeShape *= alongFalloff;

				height -= clampedSpeed * WATER_TRAIL_STRENGTH * wakeShape;
			}

			if (along <= 0.3) {

				const float bowRadius = 0.7;
				float bowEdge = bowRadius - distToPlayer;
				float bowMask = smoothstep(-edgeSoftness, edgeSoftness, bowEdge);
				height -= clampedSpeed * WATER_TRAIL_STRENGTH * bowMask * 0.6;
			}
		#endif
	}


	float playerDeltaY = previousPlayerPos.y - playerPos.y;
	bool isJumpSplash = playerOnWater && playerDeltaY > WATER_TRAIL_SPLASH_THRESHOLD;

	if (isJumpSplash) {
		const float splashRadius = 3.5;
		float distSplash = distToPlayer;

		if (distSplash < splashRadius) {

			float fallFactor = saturate(playerDeltaY * rcp(WATER_TRAIL_SPLASH_THRESHOLD * 4.0));
			float splashFalloff = saturate(1.0 - distSplash * rcp(splashRadius));
			height -= fallFactor * WATER_TRAIL_SPLASH_STRENGTH * splashFalloff;
		}
	}

	vec2 result = vec2(height, velocity);

	if (any(isnan(result)) || any(isinf(result))) {
		result = vec2(0.0);
	}

	result = clamp(result, vec2(-2.0), vec2(2.0));

	if (iFrameMod2 == 0) {
		imageStore(trailimg0, pos, vec4(result, 0.0, 0.0));
	} else {
		imageStore(trailimg1, pos, vec4(result, 0.0, 0.0));
	}

	if (pos == ivec2(0)) {
		imageStore(playerposimg, ivec2(0), vec4(playerPos, 0.0));
	}
}

#endif // WATER_TRAIL == 1

#endif // CSH

