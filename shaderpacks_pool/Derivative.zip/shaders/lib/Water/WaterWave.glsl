

#ifndef WATER_WAVE_STYLE
	#define WATER_WAVE_STYLE 1 // [0 1 2 3]
#endif

const vec2 wave_size[3] = vec2[](
	vec2(48.0, 12.0),
	vec2(12.0, 48.0),
	vec2(32.0, 32.0)
);

const float waveRotationAngle = 2.39996; // ~137.5°

#ifndef PATCHY_WAVE_BLEND
	#define PATCHY_WAVE_BLEND 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] 
#endif

#ifndef WAVES_A_RADIUS
	#define WAVES_A_RADIUS 0.025 // [0.01 0.015 0.02 0.025 0.03 0.04 0.05] 
#endif

#ifndef WAVES_B_RADIUS
	#define WAVES_B_RADIUS 0.08 // [0.04 0.05 0.06 0.08 0.1 0.12 0.15] 
#endif

// ── Style 0 (Default) ──
float getWaterHeightmap0(vec2 posxz, in float largeWaves, in float largeWavesCurved) {
	vec2 pos = posxz;

	float movement = frameTimeCounter * 0.035 * WATER_WAVE_SPEED;

	mat2 rotationMatrix = mat2(
		vec2(cos(waveRotationAngle), -sin(waveRotationAngle)),
		vec2(sin(waveRotationAngle),  cos(waveRotationAngle))
	);

	float heightSum = 0.0;
	for (int i = 0; i < 3; i++) {
		pos = rotationMatrix * pos;
		heightSum += texture(noisetex, pos / wave_size[i] + largeWavesCurved * 0.5 + movement).b;
	}

	return (heightSum / 4.5) * max(largeWavesCurved, 0.3);
}

// ── Style 1 (BSL) ──

float getWaterHeightmap1(vec2 posxz, in float largeWaves, in float largeWavesCurved) {
	vec2 pos = posxz;


	float movement = frameTimeCounter * 0.012 * WATER_WAVE_SPEED;

	mat2 rotationMatrix = mat2(
		vec2(cos(waveRotationAngle), -sin(waveRotationAngle)),
		vec2(sin(waveRotationAngle),  cos(waveRotationAngle))
	);

	float heightSum = 0.0;
	for (int i = 0; i < 3; i++) {
		pos = rotationMatrix * pos;
		heightSum += texture(noisetex, pos / wave_size[i] + largeWavesCurved * 0.5 + movement).b;
	}


	const float bslHeightScale = 0.55;
	return (heightSum / 4.5) * max(largeWavesCurved, 0.3) * bslHeightScale;
}

// ── Style 2
#ifndef WATER_WAVE_STYLE2_SPEED_MULT
	#define WATER_WAVE_STYLE2_SPEED_MULT 0.5 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8]
#endif
#ifndef WATER_WAVE_STYLE2_HEIGHT_MULT
	#define WATER_WAVE_STYLE2_HEIGHT_MULT 0.7 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9] 
#endif

float getWaterHeightmap2(vec2 posxz, in float largeWaves, in float largeWavesCurved) {
	vec2 pos = posxz;
	float movement = frameTimeCounter * 0.035 * WATER_WAVE_STYLE2_SPEED_MULT * WATER_WAVE_SPEED;
	mat2 rotationMatrix = mat2(
		vec2(cos(waveRotationAngle), -sin(waveRotationAngle)),
		vec2(sin(waveRotationAngle),  cos(waveRotationAngle))
	);

	float heightSum = 0.0;
	for (int i = 0; i < 3; i++) {
		pos = rotationMatrix * pos;
		heightSum += texture(noisetex, pos / wave_size[i] + largeWavesCurved * 0.5 + movement).b;
	}
	return (heightSum / 4.5) * max(largeWavesCurved, 0.3) * WATER_WAVE_STYLE2_HEIGHT_MULT;
}

// ── Style 3 (совмещение Default + BSL) ──
float getWaterHeightmap3(vec2 posxz, in float largeWaves, in float largeWavesCurved) {
	float heightDefault = getWaterHeightmap0(posxz, largeWaves, largeWavesCurved);
	float heightBSL      = getWaterHeightmap1(posxz, largeWaves, largeWavesCurved);

	return (heightDefault + heightBSL) * 0.5;
}

float getWaterHeightmap(vec2 posxz, in float largeWaves, in float largeWavesCurved) {
	#if WATER_WAVE_STYLE == 3
		return getWaterHeightmap3(posxz, largeWaves, largeWavesCurved);
	#elif WATER_WAVE_STYLE == 2
		return getWaterHeightmap2(posxz, largeWaves, largeWavesCurved);
	#elif WATER_WAVE_STYLE == 1
		return getWaterHeightmap1(posxz, largeWaves, largeWavesCurved);
	#else
		return getWaterHeightmap0(posxz, largeWaves, largeWavesCurved);
	#endif
}

float WaterHeight(in vec2 p) {
	float largeWaves = texture(noisetex, p / 600.0).b;
	float largeWavesCurved = pow(1.0 - pow(1.0 - largeWaves, 2.5), 4.5);
	largeWavesCurved = mix(1.0 - largeWavesCurved, largeWavesCurved, PATCHY_WAVE_BLEND);

	return getWaterHeightmap(p, largeWaves, largeWavesCurved);
}
float waterCaustics(vec3 worldPos, vec3 sunVec, float surfacePos) {
	vec3 projectedPos = worldPos + (sunVec / abs(sunVec.y)) * surfacePos;
	vec2 pos = projectedPos.xz;

	float movement = frameTimeCounter * 0.035 * WATER_WAVE_SPEED;

	mat2 rotationMatrix = mat2(
		vec2(cos(waveRotationAngle), -sin(waveRotationAngle)),
		vec2(sin(waveRotationAngle),  cos(waveRotationAngle))
	);

	float largeWaves = texture(noisetex, pos / 600.0).b;
	float largeWavesCurved = pow(1.0 - pow(1.0 - largeWaves, 2.5), 4.5);
	largeWavesCurved = mix(1.0 - largeWavesCurved, largeWavesCurved, PATCHY_WAVE_BLEND);

	float heightSum = 0.0;
	for (int i = 0; i < 3; i++) {
		pos = rotationMatrix * pos;
		heightSum += pow(abs(abs(texture(noisetex, pos / wave_size[i] + largeWavesCurved * 0.5 + movement).b * 2.0 - 1.0) * 2.0 - 1.0), 1.0 + largeWavesCurved);
	}

	return exp((1.0 + 5.0 * sqrt(largeWavesCurved)) * (heightSum / 3.0 - 0.5));
}

vec3 getWaveNormalRaw(vec3 waterPos, vec3 playerpos) {
	float largeWaves = texture(noisetex, waterPos.xy / 600.0).b;
	float largeWavesCurved = pow(1.0 - pow(1.0 - largeWaves, 2.5), 4.5);
	largeWavesCurved = mix(1.0 - largeWavesCurved, largeWavesCurved, PATCHY_WAVE_BLEND);

	#ifdef HYPER_DETAILED_WAVES
		float deltaPos = 0.025;
	#else
		float deltaPos = mix(WAVES_A_RADIUS, WAVES_B_RADIUS, largeWavesCurved);

		float range = min(length(playerpos) / (16.0 * 24.0), 3.0);
		deltaPos += range;
	#endif

	vec2 coord = waterPos.xy;

	float h0 = getWaterHeightmap(coord, largeWaves, largeWavesCurved);
	float h1 = getWaterHeightmap(coord + vec2(deltaPos, 0.0), largeWaves, largeWavesCurved);
	float h3 = getWaterHeightmap(coord + vec2(0.0, deltaPos), largeWaves, largeWavesCurved);

	float xDelta = (h1 - h0) / deltaPos;
	float yDelta = (h3 - h0) / deltaPos;

	return normalize(vec3(xDelta, yDelta, 1.0 - pow(abs(xDelta + yDelta), 2.0)));
}

vec3 GetWavesNormal(in vec2 position, in float distanceToPlayer) {
	vec3 wave = getWaveNormalRaw(vec3(position, 0.0), vec3(distanceToPlayer, 0.0, 0.0));
	return normalize(vec3(wave.xy * WATER_WAVE_HEIGHT, wave.z));
}

vec3 GetWavesNormal(in vec2 position) {
	return GetWavesNormal(position, 0.0);
}