
#ifndef INCLUDE_WAVE_SIMULATION
#define INCLUDE_WAVE_SIMULATION
vec2 GetWaveSimGridSnappedCenter(vec3 cameraPos) {
	float texelSize = 1.0 / WATER_SIM_NORMAL_SCALE;
	return floor(cameraPos.xz / texelSize + 0.5) * texelSize;
}
ivec2 WaveSimWorldToTexel(vec2 worldXZ, vec2 gridCenterWorld) {
	vec2 rel = (worldXZ - gridCenterWorld) * WATER_SIM_NORMAL_SCALE;
	return ivec2(floor(rel + float(WATER_SIM_RESOLUTION) * 0.5));
}

bool WaveSimInBounds(ivec2 texel) {
	return texel.x >= 0 && texel.y >= 0
		&& texel.x < WATER_SIM_RESOLUTION && texel.y < WATER_SIM_RESOLUTION;
}

#endif // INCLUDE_WAVE_SIMULATION
