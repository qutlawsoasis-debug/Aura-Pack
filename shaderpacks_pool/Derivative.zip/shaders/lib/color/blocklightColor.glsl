vec3 blocklightColSqrt = vec3(BLOCKLIGHT_R, BLOCKLIGHT_G, BLOCKLIGHT_B) * BLOCKLIGHT_I / 255.0;
vec3 blocklightCol = blocklightColSqrt * blocklightColSqrt;

// Block colors defined in lib/color/blocklightColor.glsl
// lightColorsRGB[50] - Contains color palette for blocklight (lines 5-61)
// Index 0-11: Bright warm colors (orange to cyan)
// Index 12-23: Medium intensity colors
// Index 24: White (4.00, 4.00, 4.00)
// Index 25-35: Dim warm colors
// Index 36-47: Dim cool colors
// Index 48: White (1.00, 1.00, 1.00)

#if MULTICOLORED_BLOCKLIGHT == 1 || defined MCBL_SS
#define MCBL_TO_FLOAT(x) (float(x) * (1.0 / 255.0))


#define MCBL_FF_COLOR(NAME) (vec3(MCBL_TO_FLOAT(NAME##_R), MCBL_TO_FLOAT(NAME##_G), MCBL_TO_FLOAT(NAME##_B)) * NAME##_I)

// Forward declaration — определена ниже, используется в GetVoxelEmission.
vec3 GetGlassEmission(int materialID);

vec3 GetVoxelEmission(int materialID) {
	switch (materialID) {
		case 20: case 36: // Total/partial glowing (emerald_block — нейтральный тёплый белый)
		case 33:
			return vec3(3.2, 2.8, 2.2);
		case 86: // Ochre froglight
			return MCBL_FF_COLOR(FF_OCHRE_FROGLIGHT);
		case 87: // Verdant froglight
			return MCBL_FF_COLOR(FF_VERDANT_FROGLIGHT);
		case 88: // Pearlescent froglight
			return MCBL_FF_COLOR(FF_PEARLESCENT_FROGLIGHT);
		case 89: // End rod — розовато-белый
			return MCBL_FF_COLOR(FF_END_ROD);
		// Свечи (lit) — раньше все 16 цветов были одним case 99 с общим
		// FF_CANDLE. Теперь свой materialID и свой FF_CANDLE_<COLOR> на
		// каждый цвет (см. block.10037-10054 в block.properties), плюс
		// их candle_cake версии (block.10055-10069,10100,10117-10118)
		// переиспользуют ту же палитру цветов.
		case 37: case 55: // Candle
			return MCBL_FF_COLOR(FF_CANDLE);
		case 38: case 56: // White Candle
			return MCBL_FF_COLOR(FF_CANDLE_WHITE);
		case 39: case 57: // Orange Candle
			return MCBL_FF_COLOR(FF_CANDLE_ORANGE);
		case 41: case 59: // Magenta Candle
			return MCBL_FF_COLOR(FF_CANDLE_MAGENTA);
		case 42: case 60: // Light Blue Candle
			return MCBL_FF_COLOR(FF_CANDLE_LIGHT_BLUE);
		case 43: case 61: // Yellow Candle
			return MCBL_FF_COLOR(FF_CANDLE_YELLOW);
		case 44: case 62: // Lime Candle
			return MCBL_FF_COLOR(FF_CANDLE_LIME);
		case 45: case 63: // Pink Candle
			return MCBL_FF_COLOR(FF_CANDLE_PINK);
		case 46: case 64: // Gray Candle
			return MCBL_FF_COLOR(FF_CANDLE_GRAY);
		case 47: case 65: // Light Gray Candle
			return MCBL_FF_COLOR(FF_CANDLE_LIGHT_GRAY);
		case 48: case 66: // Cyan Candle
			return MCBL_FF_COLOR(FF_CANDLE_CYAN);
		case 49: case 67: // Purple Candle
			return MCBL_FF_COLOR(FF_CANDLE_PURPLE);
		case 50: case 68: // Blue Candle
			return MCBL_FF_COLOR(FF_CANDLE_BLUE);
		case 51: case 69: // Brown Candle
			return MCBL_FF_COLOR(FF_CANDLE_BROWN);
		case 52: case 100: // Green Candle
			return MCBL_FF_COLOR(FF_CANDLE_GREEN);
		case 53: case 117: // Red Candle
			return MCBL_FF_COLOR(FF_CANDLE_RED);
		case 54: case 118: // Black Candle
			return MCBL_FF_COLOR(FF_CANDLE_BLACK);
		case 21: // Torch like
			return MCBL_FF_COLOR(FF_TORCH);
		case 22: case 15: // Fire
			return MCBL_FF_COLOR(FF_LAVA);
		case 23: // Glowstone like
			return MCBL_FF_COLOR(FF_GLOWSTONE);
		// Jack o'lantern (128 north, 129 south, 130 east, 131 west) — вынесена
		// из общего case 23, но свечение (для flood-fill) остаётся тем же
		// glowstone-like тёплым светом, что и раньше. Facing нужен только
		// для проекции лица (PumpkinFaceProjection.glsl), не для цвета.
		case 128: case 129: case 130: case 131:
			return MCBL_FF_COLOR(FF_GLOWSTONE);
		case 24: // Sea lantern like
			return MCBL_FF_COLOR(FF_SEA_LANTERN);
		case 25: // Redstone
			return MCBL_FF_COLOR(FF_REDSTONE);
		case 26: // Soul fire
			return MCBL_FF_COLOR(FF_SOUL_TORCH);
		case 27: // Amethyst
			return MCBL_FF_COLOR(FF_AMETHYST);
		case 28: // Glowberry
			return vec3(1.00, 0.85, 0.55) * 2.5;
		case 29: // Rails (powered/detector — слабый красноватый)
			return vec3(2.1, 0.9, 0.9) * 0.5;
		case 30: // Beacon core
			return MCBL_FF_COLOR(FF_BEACON);
		case 31: // Sculk
			return MCBL_FF_COLOR(FF_SCULK);
		case 32: // Glow lichen
			return MCBL_FF_COLOR(FF_GLOW_LICHEN);
		case 34: // Middle glowing (шроглайт-подобные)
			return MCBL_FF_COLOR(FF_SHROOMLIGHT);
		case 35: // Lapis block — отдельный синий флудфил
			return MCBL_FF_COLOR(FF_LAPIS);
		case 90: // Copper torch — не окисляется, всегда зеленоватый
			return MCBL_FF_COLOR(FF_COPPER_TORCH);
		case 91: // Copper lantern (обычная медь)
		case 95: // Copper bulb (обычная медь, lit)
			return MCBL_FF_COLOR(FF_COPPER_NORMAL);
		case 92: // Exposed copper lantern
		case 96: // Exposed copper bulb (lit)
			return MCBL_FF_COLOR(FF_COPPER_EXPOSED);
		case 93: // Weathered copper lantern
		case 97: // Weathered copper bulb (lit)
			return MCBL_FF_COLOR(FF_COPPER_WEATHERED);
		case 94: // Oxidized copper lantern
		case 98: // Oxidized copper bulb (lit)
			return MCBL_FF_COLOR(FF_COPPER_OXIDIZED);

		// Руда (121-127) — приглушённое IPBR-emissive свечение цветом
		// самого металла/самоцвета, character "намёк" от вкраплений в
		// камне, а не полноценный источник вроде факела. Раньше все 7
		// типов руды были одним ID 57 без case здесь вообще — эмиссия
		// отсутствовала. gildedBlackstone светится вместе с золотой рудой.
		case 121: // Iron ore — тускло-ржавый
			return vec3(0.85, 0.55, 0.40) * 0.35;
		case 122: // Copper ore — оранжево-медный
			return vec3(0.95, 0.55, 0.30) * 0.35;
		case 123: // Gold ore (+ gilded_blackstone) — тёплый жёлтый
			return vec3(1.00, 0.80, 0.25) * 0.4;
		case 124: // Redstone ore — красный
			return vec3(1.00, 0.15, 0.10) * 0.45;
		case 125: // Lapis ore — синий
			return vec3(0.20, 0.40, 0.95) * 0.4;
		case 126: // Emerald ore — зелёный
			return vec3(0.15, 0.95, 0.40) * 0.4;
		case 127: // Diamond ore — голубовато-белый
			return vec3(0.55, 0.95, 1.00) * 0.4;

		// Nether ores (58) — nether_gold_ore и nether_quartz_ore сведены
		// в один ID, оба тёплые/светлые по природе исходного блока.
		case 58:
			return vec3(1.00, 0.75, 0.45) * 0.35;

		// Spider Eye Glow (132) — источник, который Entities.vert пишет
		// в voxelimg перед мордой паука (см. SPIDER_EYE_MATERIAL_ID).
		// Не привязан к реальному блоку, поэтому фиксированный насыщенный
		// красный, отдельно от палитры остальных блоков.
		case 132:
			return vec3(3.0, 0.05, 0.05);
	}

	// Цветное стекло (70-85 полный блок, 101-116 панель) — светится своим
	// цветом как маленький декоративный источник. Вынесено из switch
	// выше, т.к. использует отдельную функцию с сдвигом диапазона панелей.
	if ((materialID >= 70 && materialID <= 85) || (materialID >= 101 && materialID <= 116)) {
		return GetGlassEmission(materialID);
	}

	return vec3(0.0);
}


#define DROPPED_ITEM_VOXEL_ID_BASE 150

// currentRenderedItemId -> компактный voxel-код (150-199). 0 = не светящийся
// предмет / не item-геометрия вовсе (не трогать voxelimg в этом случае).
int EncodeDroppedItemVoxelID(int currentRenderedItemId) {
	if (currentRenderedItemId < 13100 || currentRenderedItemId > 13145) return 0;
	return DROPPED_ITEM_VOXEL_ID_BASE + (currentRenderedItemId - 13100);
}

// Обратное преобразование, только для читаемости кейсов ниже.
#define DROPPED_ITEM_CASE(offset) (DROPPED_ITEM_VOXEL_ID_BASE + offset)

vec3 GetDroppedItemVoxelEmission(int voxelID) {
	switch (voxelID) {
		case DROPPED_ITEM_CASE(0): // Torch
			return MCBL_FF_COLOR(FF_TORCH);
		case DROPPED_ITEM_CASE(1): // Redstone torch
			return MCBL_FF_COLOR(FF_REDSTONE);
		case DROPPED_ITEM_CASE(2): // Soul torch
			return MCBL_FF_COLOR(FF_SOUL_TORCH);
		case DROPPED_ITEM_CASE(3): // Glowstone
			return MCBL_FF_COLOR(FF_GLOWSTONE);
		case DROPPED_ITEM_CASE(4): // Sea lantern
			return MCBL_FF_COLOR(FF_SEA_LANTERN);
		case DROPPED_ITEM_CASE(5): // Shroomlight
			return MCBL_FF_COLOR(FF_SHROOMLIGHT);
		case DROPPED_ITEM_CASE(6): // Jack o'lantern
			return MCBL_FF_COLOR(FF_GLOWSTONE);
		case DROPPED_ITEM_CASE(7): // End rod
			return MCBL_FF_COLOR(FF_END_ROD);
		case DROPPED_ITEM_CASE(8): // Lantern
			return MCBL_FF_COLOR(FF_TORCH);
		case DROPPED_ITEM_CASE(9): // Soul lantern
			return MCBL_FF_COLOR(FF_SOUL_TORCH);
		case DROPPED_ITEM_CASE(10): // Amethyst cluster/buds
			return MCBL_FF_COLOR(FF_AMETHYST);
		case DROPPED_ITEM_CASE(11): // Ochre froglight
			return MCBL_FF_COLOR(FF_OCHRE_FROGLIGHT);
		case DROPPED_ITEM_CASE(12): // Verdant froglight
			return MCBL_FF_COLOR(FF_VERDANT_FROGLIGHT);
		case DROPPED_ITEM_CASE(13): // Pearlescent froglight
			return MCBL_FF_COLOR(FF_PEARLESCENT_FROGLIGHT);
		case DROPPED_ITEM_CASE(14): // Glow berries
			return vec3(1.00, 0.85, 0.55) * 2.5;
		case DROPPED_ITEM_CASE(15): // Redstone dust/block
			return MCBL_FF_COLOR(FF_REDSTONE);
		case DROPPED_ITEM_CASE(16): // Lava bucket / magma block
			return MCBL_FF_COLOR(FF_LAVA);
		case DROPPED_ITEM_CASE(17): // Nether star / beacon
			return MCBL_FF_COLOR(FF_BEACON);
		case DROPPED_ITEM_CASE(18): // Glow lichen
			return MCBL_FF_COLOR(FF_GLOW_LICHEN);
		case DROPPED_ITEM_CASE(19): // Sculk family
			return MCBL_FF_COLOR(FF_SCULK);
		case DROPPED_ITEM_CASE(20): case DROPPED_ITEM_CASE(24): // Copper bulb / torch (свежая медь)
			return MCBL_FF_COLOR(FF_COPPER_TORCH);
		case DROPPED_ITEM_CASE(21): // Exposed copper bulb
			return MCBL_FF_COLOR(FF_COPPER_EXPOSED);
		case DROPPED_ITEM_CASE(22): // Weathered copper bulb
			return MCBL_FF_COLOR(FF_COPPER_WEATHERED);
		case DROPPED_ITEM_CASE(23): // Oxidized copper bulb
			return MCBL_FF_COLOR(FF_COPPER_OXIDIZED);
		case DROPPED_ITEM_CASE(25): // Copper lantern (normal)
			return MCBL_FF_COLOR(FF_COPPER_NORMAL);
		case DROPPED_ITEM_CASE(26): // Exposed copper lantern
			return MCBL_FF_COLOR(FF_COPPER_EXPOSED);
		case DROPPED_ITEM_CASE(27): // Weathered copper lantern
			return MCBL_FF_COLOR(FF_COPPER_WEATHERED);
		case DROPPED_ITEM_CASE(28): // Oxidized copper lantern
			return MCBL_FF_COLOR(FF_COPPER_OXIDIZED);
		case DROPPED_ITEM_CASE(29): // Candle
			return MCBL_FF_COLOR(FF_CANDLE);
		case DROPPED_ITEM_CASE(30): // White candle
			return MCBL_FF_COLOR(FF_CANDLE_WHITE);
		case DROPPED_ITEM_CASE(31): // Orange candle
			return MCBL_FF_COLOR(FF_CANDLE_ORANGE);
		case DROPPED_ITEM_CASE(32): // Magenta candle
			return MCBL_FF_COLOR(FF_CANDLE_MAGENTA);
		case DROPPED_ITEM_CASE(33): // Light blue candle
			return MCBL_FF_COLOR(FF_CANDLE_LIGHT_BLUE);
		case DROPPED_ITEM_CASE(34): // Yellow candle
			return MCBL_FF_COLOR(FF_CANDLE_YELLOW);
		case DROPPED_ITEM_CASE(35): // Lime candle
			return MCBL_FF_COLOR(FF_CANDLE_LIME);
		case DROPPED_ITEM_CASE(36): // Pink candle
			return MCBL_FF_COLOR(FF_CANDLE_PINK);
		case DROPPED_ITEM_CASE(37): // Gray candle
			return MCBL_FF_COLOR(FF_CANDLE_GRAY);
		case DROPPED_ITEM_CASE(38): // Light gray candle
			return MCBL_FF_COLOR(FF_CANDLE_LIGHT_GRAY);
		case DROPPED_ITEM_CASE(39): // Cyan candle
			return MCBL_FF_COLOR(FF_CANDLE_CYAN);
		case DROPPED_ITEM_CASE(40): // Purple candle
			return MCBL_FF_COLOR(FF_CANDLE_PURPLE);
		case DROPPED_ITEM_CASE(41): // Blue candle
			return MCBL_FF_COLOR(FF_CANDLE_BLUE);
		case DROPPED_ITEM_CASE(42): // Brown candle
			return MCBL_FF_COLOR(FF_CANDLE_BROWN);
		case DROPPED_ITEM_CASE(43): // Green candle
			return MCBL_FF_COLOR(FF_CANDLE_GREEN);
		case DROPPED_ITEM_CASE(44): // Red candle
			return MCBL_FF_COLOR(FF_CANDLE_RED);
		case DROPPED_ITEM_CASE(45): // Black candle
			return MCBL_FF_COLOR(FF_CANDLE_BLACK);
	}

	return vec3(0.0);
}

bool IsDroppedItemVoxel(int voxelID) {
	return voxelID >= DROPPED_ITEM_VOXEL_ID_BASE && voxelID <= (DROPPED_ITEM_VOXEL_ID_BASE + 45);
}

float GetDroppedItemVoxelRange(int itemID) {
	return 6.0;
}

vec3 GetGlassEmission(int materialID) {
	// Панели (101-116) используют ту же палитру, что и полные блоки
	// (70-85) — просто сдвигаем в общий диапазон перед switch.
	if (materialID >= 101 && materialID <= 116) materialID -= 31;

	const float glassEmissionIntensity = 0.8;

	switch (materialID) {
		case 70: return vec3(0.95, 0.95, 0.95) * glassEmissionIntensity; // White
		case 71: return vec3(1.00, 0.55, 0.15) * glassEmissionIntensity; // Orange
		case 72: return vec3(0.90, 0.35, 0.90) * glassEmissionIntensity; // Magenta
		case 73: return vec3(0.45, 0.65, 1.00) * glassEmissionIntensity; // Light Blue
		case 74: return vec3(1.00, 0.95, 0.25) * glassEmissionIntensity; // Yellow
		case 75: return vec3(0.55, 1.00, 0.25) * glassEmissionIntensity; // Lime
		case 76: return vec3(1.00, 0.60, 0.75) * glassEmissionIntensity; // Pink
		case 77: return vec3(0.45, 0.45, 0.45) * glassEmissionIntensity; // Gray
		case 78: return vec3(0.70, 0.70, 0.70) * glassEmissionIntensity; // Light Gray
		case 79: return vec3(0.25, 0.80, 0.80) * glassEmissionIntensity; // Cyan
		case 80: return vec3(0.60, 0.25, 0.80) * glassEmissionIntensity; // Purple
		case 81: return vec3(0.25, 0.35, 0.90) * glassEmissionIntensity; // Blue
		case 82: return vec3(0.55, 0.35, 0.20) * glassEmissionIntensity; // Brown
		case 83: return vec3(0.35, 0.55, 0.20) * glassEmissionIntensity; // Green
		case 84: return vec3(0.85, 0.20, 0.20) * glassEmissionIntensity; // Red
		case 85: return vec3(0.10, 0.10, 0.10) * glassEmissionIntensity; // Black
		default:
			return vec3(0.0);
	}
}

// ─────────────────────────────────────────────────────────────────────────
// Стартовый "запас дальности" в блоках для MCBL_LIGHTMAP_MODE == 1.
// Используется только когда включён режим "Vanilla radius" — задаёт,
// сколько блоков flood-fill свет реально пролетит от источника, вне
// зависимости от его яркости (в отличие от режима 0, где дальность
// определяется только тем, насколько ярким был исходный источник).
// Значения подобраны по аналогии с ванильным block-light lightmap
// (0..15) конкретного источника. materialID 20 (emerald_block/end_rod) и
// materialID 29 (redstone_block/rails) — "чисто белые/нейтральные"
// источники, радиус НЕ трогаем, оставляем как дефолт. lapis_block вынесен
// в отдельный materialID 35 (свой синий цвет), но по дальности тоже
// остаётся на дефолтном полном радиусе — не трогаем.
// ─────────────────────────────────────────────────────────────────────────
float GetVoxelRange(int materialID) {
	switch (materialID) {
		case 25: // Redstone (факел/провод/повторитель/компаратор)
			return 4.0;   // ~3-4 блока, как в ванили
		case 26: // Soul fire (soul-факел в ванили тоже даёт 10)
			return 10.0;
		case 21: // Torch like
		case 23: // Glowstone like
		case 24: // Sea lantern like
		case 28: // Glowberry (cave vines — ванильно 14)
		case 30: // Beacon core
			return 15.0;  // полный ванильный радиус (0..15)
		case 90: // Copper torch (ванильный лайт-левел 14)
			return 14.0;
		case 91: // Copper lantern — не теряет яркость с окислением (ванильно 15 всегда)
		case 92:
		case 93:
		case 94:
			return 15.0;
		// Copper bulb — В ОТЛИЧИЕ от лантерна, у бульба яркость реально
		// падает с окислением (ванильный light level: 15 -> 12 -> 8 -> 4),
		// поэтому и запас дальности flood-fill убывает так же.
		case 95: // Copper bulb (normal, lit)
			return 15.0;
		case 96: // Exposed copper bulb (lit)
			return 12.0;
		case 97: // Weathered copper bulb (lit)
			return 8.0;
		case 98: // Oxidized copper bulb (lit)
			return 4.0;
		default:
			return 15.0;  // включая materialID 20, 29, 35 (lapis), 86-89 (froglight/end_rod)
			              // и 37-54/55-69,100,117-118 (свечи и candle_cake, все цвета) —
			              // полный ванильный радиус, не трогаем, дефолт
	}
}

int GetBlockColorIndex(int blockId) {
	if (blockId == 50) return 0;
	if (blockId == 123) return 1;
	if (blockId == 169) return 2;
	if (blockId == 200) return 3;
	if (blockId == 208) return 4;
	if (blockId == 10 || blockId == 11) return 5;
	if (blockId == 138) return 6;
	if (blockId == 214) return 7;
	if (blockId == 117) return 8;
	if (blockId == 218) return 9;
	if (blockId == 90) return 10;
	if (blockId == 252) return 11;
	return -1;
}

vec3 GetFloodfillColor(int colorIndex) {
	if (colorIndex == 0) return vec3(MCBL_TO_FLOAT(FF_TORCH_R),           MCBL_TO_FLOAT(FF_TORCH_G),           MCBL_TO_FLOAT(FF_TORCH_B))           * FF_TORCH_I;
	if (colorIndex == 1) return vec3(MCBL_TO_FLOAT(FF_GLOWSTONE_R),         MCBL_TO_FLOAT(FF_GLOWSTONE_G),         MCBL_TO_FLOAT(FF_GLOWSTONE_B))         * FF_GLOWSTONE_I;
	if (colorIndex == 2) return vec3(MCBL_TO_FLOAT(FF_SEA_LANTERN_R),     MCBL_TO_FLOAT(FF_SEA_LANTERN_G),     MCBL_TO_FLOAT(FF_SEA_LANTERN_B))     * FF_SEA_LANTERN_I;
	if (colorIndex == 3) return vec3(MCBL_TO_FLOAT(FF_END_ROD_R),         MCBL_TO_FLOAT(FF_END_ROD_G),         MCBL_TO_FLOAT(FF_END_ROD_B))         * FF_END_ROD_I;
	if (colorIndex == 4) return vec3(MCBL_TO_FLOAT(FF_SOUL_TORCH_R),      MCBL_TO_FLOAT(FF_SOUL_TORCH_G),      MCBL_TO_FLOAT(FF_SOUL_TORCH_B))      * FF_SOUL_TORCH_I;
	if (colorIndex == 5) return vec3(MCBL_TO_FLOAT(FF_LAVA_R),           MCBL_TO_FLOAT(FF_LAVA_G),           MCBL_TO_FLOAT(FF_LAVA_B))           * FF_LAVA_I;
	if (colorIndex == 6) return vec3(MCBL_TO_FLOAT(FF_BEACON_R),         MCBL_TO_FLOAT(FF_BEACON_G),         MCBL_TO_FLOAT(FF_BEACON_B))         * FF_BEACON_I;
	if (colorIndex == 7) return vec3(MCBL_TO_FLOAT(FF_SHROOMLIGHT_R),       MCBL_TO_FLOAT(FF_SHROOMLIGHT_G),       MCBL_TO_FLOAT(FF_SHROOMLIGHT_B))       * FF_SHROOMLIGHT_I;
	if (colorIndex == 8) return vec3(MCBL_TO_FLOAT(FF_BREWING_STAND_R),    MCBL_TO_FLOAT(FF_BREWING_STAND_G),    MCBL_TO_FLOAT(FF_BREWING_STAND_B))    * FF_BREWING_STAND_I;
	if (colorIndex == 9) return vec3(MCBL_TO_FLOAT(FF_JACK_O_LANTERN_R),  MCBL_TO_FLOAT(FF_JACK_O_LANTERN_G),  MCBL_TO_FLOAT(FF_JACK_O_LANTERN_B))  * FF_JACK_O_LANTERN_I;
	if (colorIndex == 10) return vec3(MCBL_TO_FLOAT(FF_NETHER_PORTAL_R),    MCBL_TO_FLOAT(FF_NETHER_PORTAL_G),    MCBL_TO_FLOAT(FF_NETHER_PORTAL_B))    * FF_NETHER_PORTAL_I;
	if (colorIndex == 11) return vec3(MCBL_TO_FLOAT(FF_AMETHYST_R),        MCBL_TO_FLOAT(FF_AMETHYST_G),        MCBL_TO_FLOAT(FF_AMETHYST_B))        * FF_AMETHYST_I;
	return vec3(0.0);
}

vec3[50] lightColorsRGB = vec3[50] (
	vec3(4.00, 1.00, 1.00),
	vec3(4.00, 2.50, 1.00),
	vec3(4.00, 4.00, 1.00),
	vec3(2.50, 4.00, 1.00),
	vec3(1.00, 4.00, 1.00),
	vec3(1.00, 4.00, 2.50),
	vec3(1.00, 4.00, 4.00),
	vec3(1.00, 2.50, 4.00),
	vec3(1.00, 1.00, 4.00),
	vec3(2.50, 1.00, 4.00),
	vec3(4.00, 1.00, 4.00),
	vec3(4.00, 1.00, 2.50),
    
	vec3(4.00, 2.67, 2.67),
	vec3(4.00, 3.33, 2.67),
	vec3(4.00, 4.00, 2.67),
	vec3(3.33, 4.00, 2.67),
	vec3(2.67, 4.00, 2.67),
	vec3(2.67, 4.00, 3.33),
	vec3(2.67, 4.00, 4.00),
	vec3(2.67, 3.33, 4.00),
	vec3(2.67, 2.67, 4.00),
	vec3(3.33, 2.67, 4.00),
	vec3(4.00, 2.67, 4.00),
	vec3(4.00, 2.67, 3.33),

	vec3(4.00, 4.00, 4.00),
	
	vec3(1.00, 0.25, 0.25),
	vec3(1.00, 0.63, 0.25),
	vec3(1.00, 1.00, 0.25),
	vec3(0.63, 1.00, 0.25),
	vec3(0.25, 1.00, 0.25),
	vec3(0.25, 1.00, 0.63),
	vec3(0.25, 1.00, 1.00),
	vec3(0.25, 0.63, 1.00),
	vec3(0.25, 0.25, 1.00),
	vec3(0.63, 0.25, 1.00),
	vec3(1.00, 0.25, 1.00),
	vec3(1.00, 0.25, 0.63),
    
	vec3(1.00, 0.67, 0.67),
	vec3(1.00, 0.83, 0.67),
	vec3(1.00, 1.00, 0.67),
	vec3(0.83, 1.00, 0.67),
	vec3(0.67, 1.00, 0.67),
	vec3(0.67, 1.00, 0.83),
	vec3(0.67, 1.00, 1.00),
	vec3(0.67, 0.83, 1.00),
	vec3(0.67, 0.67, 1.00),
	vec3(0.83, 0.67, 1.00),
	vec3(1.00, 0.67, 1.00),
	vec3(1.00, 0.67, 0.83),

	vec3(1.00, 1.00, 1.00)
);

vec3[25] tintColorsRGB = vec3[25] (
	vec3(1.00, 0.50, 0.50),
	vec3(1.00, 0.75, 0.50),
	vec3(1.00, 1.00, 0.50),
	vec3(0.75, 1.00, 0.50),
	vec3(0.50, 1.00, 0.50),
	vec3(0.50, 1.00, 0.75),
	vec3(0.50, 1.00, 1.00),
	vec3(0.50, 0.75, 1.00),
	vec3(0.50, 0.50, 1.00),
	vec3(0.75, 0.50, 1.00),
	vec3(1.00, 0.50, 1.00),
	vec3(1.00, 0.50, 0.75),
    
	vec3(1.00, 0.75, 0.75),
	vec3(1.00, 0.88, 0.75),
	vec3(1.00, 1.00, 0.75),
	vec3(0.88, 1.00, 0.75),
	vec3(0.75, 1.00, 0.75),
	vec3(0.75, 1.00, 0.88),
	vec3(0.75, 1.00, 1.00),
	vec3(0.75, 0.88, 1.00),
	vec3(0.75, 0.75, 1.00),
	vec3(0.88, 0.75, 1.00),
	vec3(1.00, 0.75, 1.00),
	vec3(1.00, 0.75, 0.88),

	vec3(0.01, 0.01, 0.01)
);

#ifdef INCLUDE_LIGHTING_FLOODFILL_COLORS

vec3[31] floodfillColorsRGB = vec3[31] (
	vec3(FF_TO_FLOAT(FF_TORCH_R),           FF_TO_FLOAT(FF_TORCH_G),           FF_TO_FLOAT(FF_TORCH_B))           * FF_TORCH_I,
	vec3(FF_TO_FLOAT(FF_GLOWSTONE_R),         FF_TO_FLOAT(FF_GLOWSTONE_G),         FF_TO_FLOAT(FF_GLOWSTONE_B))         * FF_GLOWSTONE_I,
	vec3(FF_TO_FLOAT(FF_SEA_LANTERN_R),     FF_TO_FLOAT(FF_SEA_LANTERN_G),     FF_TO_FLOAT(FF_SEA_LANTERN_B))     * FF_SEA_LANTERN_I,
	vec3(FF_TO_FLOAT(FF_END_ROD_R),         FF_TO_FLOAT(FF_END_ROD_G),         FF_TO_FLOAT(FF_END_ROD_B))         * FF_END_ROD_I,
	vec3(FF_TO_FLOAT(FF_SOUL_TORCH_R),      FF_TO_FLOAT(FF_SOUL_TORCH_G),      FF_TO_FLOAT(FF_SOUL_TORCH_B))      * FF_SOUL_TORCH_I,
	vec3(FF_TO_FLOAT(FF_LAVA_R),           FF_TO_FLOAT(FF_LAVA_G),           FF_TO_FLOAT(FF_LAVA_B))           * FF_LAVA_I,
	vec3(FF_TO_FLOAT(FF_BEACON_R),         FF_TO_FLOAT(FF_BEACON_G),         FF_TO_FLOAT(FF_BEACON_B))         * FF_BEACON_I,
	vec3(FF_TO_FLOAT(FF_SHROOMLIGHT_R),       FF_TO_FLOAT(FF_SHROOMLIGHT_G),       FF_TO_FLOAT(FF_SHROOMLIGHT_B))       * FF_SHROOMLIGHT_I,
	vec3(FF_TO_FLOAT(FF_BREWING_STAND_R),    FF_TO_FLOAT(FF_BREWING_STAND_G),    FF_TO_FLOAT(FF_BREWING_STAND_B))    * FF_BREWING_STAND_I,
	vec3(FF_TO_FLOAT(FF_JACK_O_LANTERN_R),  FF_TO_FLOAT(FF_JACK_O_LANTERN_G),  FF_TO_FLOAT(FF_JACK_O_LANTERN_B))  * FF_JACK_O_LANTERN_I,
	vec3(FF_TO_FLOAT(FF_NETHER_PORTAL_R),    FF_TO_FLOAT(FF_NETHER_PORTAL_G),    FF_TO_FLOAT(FF_NETHER_PORTAL_B))    * FF_NETHER_PORTAL_I,
	vec3(FF_TO_FLOAT(FF_AMETHYST_R),        FF_TO_FLOAT(FF_AMETHYST_G),        FF_TO_FLOAT(FF_AMETHYST_B))        * FF_AMETHYST_I,
	vec3(FF_TO_FLOAT(FF_ENCHANTING_TABLE_R),FF_TO_FLOAT(FF_ENCHANTING_TABLE_G),FF_TO_FLOAT(FF_ENCHANTING_TABLE_B))* FF_ENCHANTING_TABLE_I,
	vec3(FF_TO_FLOAT(FF_SCULK_R),          FF_TO_FLOAT(FF_SCULK_G),          FF_TO_FLOAT(FF_SCULK_B))          * FF_SCULK_I,
	vec3(FF_TO_FLOAT(FF_SCULK_ACTIVE_R),FF_TO_FLOAT(FF_SCULK_ACTIVE_G),FF_TO_FLOAT(FF_SCULK_ACTIVE_B))* FF_SCULK_ACTIVE_I,
	vec3(FF_TO_FLOAT(FF_CALIBRATED_SCULK_R),FF_TO_FLOAT(FF_CALIBRATED_SCULK_G),FF_TO_FLOAT(FF_CALIBRATED_SCULK_B))* FF_CALIBRATED_SCULK_I,
	vec3(FF_TO_FLOAT(FF_SPAWNER_R),        FF_TO_FLOAT(FF_SPAWNER_G),        FF_TO_FLOAT(FF_SPAWNER_B))        * FF_SPAWNER_I,
	vec3(FF_TO_FLOAT(FF_SEA_PICKLE_R),    FF_TO_FLOAT(FF_SEA_PICKLE_G),    FF_TO_FLOAT(FF_SEA_PICKLE_B))    * FF_SEA_PICKLE_I,
	vec3(FF_TO_FLOAT(FF_CAVE_BERRIES_R),   FF_TO_FLOAT(FF_CAVE_BERRIES_G),   FF_TO_FLOAT(FF_CAVE_BERRIES_B))   * FF_CAVE_BERRIES_I,
	vec3(FF_TO_FLOAT(FF_GLOW_LICHEN_R),    FF_TO_FLOAT(FF_GLOW_LICHEN_G),    FF_TO_FLOAT(FF_GLOW_LICHEN_B))    * FF_GLOW_LICHEN_I,
	vec3(FF_TO_FLOAT(FF_REDSTONE_R),       FF_TO_FLOAT(FF_REDSTONE_G),       FF_TO_FLOAT(FF_REDSTONE_B))       * FF_REDSTONE_I,
	vec3(FF_TO_FLOAT(FF_REDSTONE_BLOCK_R),FF_TO_FLOAT(FF_REDSTONE_BLOCK_G),FF_TO_FLOAT(FF_REDSTONE_BLOCK_B))* FF_REDSTONE_BLOCK_I,
	vec3(FF_TO_FLOAT(FF_NETHER_PLANTS_R),FF_TO_FLOAT(FF_NETHER_PLANTS_G), FF_TO_FLOAT(FF_NETHER_PLANTS_B)) * FF_NETHER_PLANTS_I,
	vec3(FF_TO_FLOAT(FF_CANDLE_R),         FF_TO_FLOAT(FF_CANDLE_G),         FF_TO_FLOAT(FF_CANDLE_B))         * FF_CANDLE_I,
	vec3(FF_TO_FLOAT(FF_OCHRE_FROGLIGHT_R),FF_TO_FLOAT(FF_OCHRE_FROGLIGHT_G),FF_TO_FLOAT(FF_OCHRE_FROGLIGHT_B))* FF_OCHRE_FROGLIGHT_I,
	vec3(FF_TO_FLOAT(FF_VERDANT_FROGLIGHT_R),FF_TO_FLOAT(FF_VERDANT_FROGLIGHT_G),FF_TO_FLOAT(FF_VERDANT_FROGLIGHT_B))* FF_VERDANT_FROGLIGHT_I,
	vec3(FF_TO_FLOAT(FF_PEARLESCENT_FROGLIGHT_R),FF_TO_FLOAT(FF_PEARLESCENT_FROGLIGHT_G),FF_TO_FLOAT(FF_PEARLESCENT_FROGLIGHT_B))* FF_PEARLESCENT_FROGLIGHT_I,
	vec3(FF_TO_FLOAT(FF_COPPER_TORCH_R),  FF_TO_FLOAT(FF_COPPER_TORCH_G),  FF_TO_FLOAT(FF_COPPER_TORCH_B))  * FF_COPPER_TORCH_I,
	vec3(FF_TO_FLOAT(FF_COPPER_BULB_R), FF_TO_FLOAT(FF_COPPER_BULB_G), FF_TO_FLOAT(FF_COPPER_BULB_B)) * FF_COPPER_BULB_I,
	vec3(FF_TO_FLOAT(FF_END_PORTAL_FRAME_R),FF_TO_FLOAT(FF_END_PORTAL_FRAME_G),FF_TO_FLOAT(FF_END_PORTAL_FRAME_B))* FF_END_PORTAL_FRAME_I,
	vec3(FF_TO_FLOAT(FF_EYEBLOSSOM_R),    FF_TO_FLOAT(FF_EYEBLOSSOM_G),    FF_TO_FLOAT(FF_EYEBLOSSOM_B))    * FF_EYEBLOSSOM_I
);

int GetFloodfillColorValue(int blockId) {
	if (blockId == 50) return 0;
	if (blockId == 123) return 1;
	if (blockId == 169) return 2;
	if (blockId == 200) return 3;
	if (blockId == 208) return 4;
	if (blockId == 11 || blockId == 10) return 5;
	if (blockId == 138) return 6;
	if (blockId == 214) return 7;
	if (blockId == 117) return 8;
	if (blockId == 218) return 9;
	if (blockId == 90) return 10;
	if (blockId == 252) return 11;
	if (blockId == 197) return 12;
	if (blockId == 218) return 13;
	if (blockId == 218) return 14;
	if (blockId == 218) return 15;
	if (blockId == 199) return 16;
	if (blockId == 222) return 17;
	if (blockId == 224) return 18;
	if (blockId == 226) return 19;
	if (blockId == 173) return 20;
	if (blockId == 152) return 21;
	if (blockId == 220) return 22;
	if (blockId == 92) return 23;
	if (blockId == 270) return 24;
	if (blockId == 270) return 25;
	if (blockId == 270) return 26;
	if (blockId == 204) return 27;
	if (blockId == 204) return 28;
	if (blockId == 199) return 29;
	if (blockId == 284) return 30;
	return -1;
}
#endif
#endif

/*
vec3[50] lightColorsHSV = vec3[50] (
	vec3(0.000, 0.75, 4.00),
	vec3(0.083, 0.75, 4.00),
	vec3(0.167, 0.75, 4.00),
	vec3(0.250, 0.75, 4.00),
	vec3(0.333, 0.75, 4.00),
	vec3(0.417, 0.75, 4.00),
	vec3(0.500, 0.75, 4.00),
	vec3(0.583, 0.75, 4.00),
	vec3(0.667, 0.75, 4.00),
	vec3(0.750, 0.75, 4.00),
	vec3(0.833, 0.75, 4.00),
	vec3(0.917, 0.75, 4.00),

	vec3(0.000, 0.33, 4.00),
	vec3(0.083, 0.33, 4.00),
	vec3(0.167, 0.33, 4.00),
	vec3(0.250, 0.33, 4.00),
	vec3(0.333, 0.33, 4.00),
	vec3(0.417, 0.33, 4.00),
	vec3(0.500, 0.33, 4.00),
	vec3(0.583, 0.33, 4.00),
	vec3(0.667, 0.33, 4.00),
	vec3(0.750, 0.33, 4.00),
	vec3(0.833, 0.33, 4.00),
	vec3(0.917, 0.33, 4.00),

	vec3(0.000, 0.00, 4.00),
	
	vec3(0.000, 0.75, 1.00),
	vec3(0.083, 0.75, 1.00),
	vec3(0.167, 0.75, 1.00),
	vec3(0.250, 0.75, 1.00),
	vec3(0.333, 0.75, 1.00),
	vec3(0.417, 0.75, 1.00),
	vec3(0.500, 0.75, 1.00),
	vec3(0.583, 0.75, 1.00),
	vec3(0.667, 0.75, 1.00),
	vec3(0.750, 0.75, 1.00),
	vec3(0.833, 0.75, 1.00),
	vec3(0.917, 0.75, 1.00),

	vec3(0.000, 0.33, 1.00),
	vec3(0.083, 0.33, 1.00),
	vec3(0.167, 0.33, 1.00),
	vec3(0.250, 0.33, 1.00),
	vec3(0.333, 0.33, 1.00),
	vec3(0.417, 0.33, 1.00),
	vec3(0.500, 0.33, 1.00),
	vec3(0.583, 0.33, 1.00),
	vec3(0.667, 0.33, 1.00),
	vec3(0.750, 0.33, 1.00),
	vec3(0.833, 0.33, 1.00),
	vec3(0.917, 0.33, 1.00),

	vec3(0.000, 0.00, 1.00)
);

vec3[25] tintColorsHSV = vec3[25] (
	vec3(0.000, 0.50, 1.00),
	vec3(0.083, 0.50, 1.00),
	vec3(0.167, 0.50, 1.00),
	vec3(0.250, 0.50, 1.00),
	vec3(0.333, 0.50, 1.00),
	vec3(0.417, 0.50, 1.00),
	vec3(0.500, 0.50, 1.00),
	vec3(0.583, 0.50, 1.00),
	vec3(0.667, 0.50, 1.00),
	vec3(0.750, 0.50, 1.00),
	vec3(0.833, 0.50, 1.00),
	vec3(0.917, 0.50, 1.00),

	vec3(0.000, 0.25, 1.00),
	vec3(0.083, 0.25, 1.00),
	vec3(0.167, 0.25, 1.00),
	vec3(0.250, 0.25, 1.00),
	vec3(0.333, 0.25, 1.00),
	vec3(0.417, 0.25, 1.00),
	vec3(0.500, 0.25, 1.00),
	vec3(0.583, 0.25, 1.00),
	vec3(0.667, 0.25, 1.00),
	vec3(0.750, 0.25, 1.00),
	vec3(0.833, 0.25, 1.00),
	vec3(0.917, 0.25, 1.00),
	vec3(0.000, 0.00, 0.01)
);
*/