

#ifndef INCLUDE_VOXEL_ALBEDO
#define INCLUDE_VOXEL_ALBEDO

// GL_ARB_shader_image_load_store
writeonly uniform image3D voxelalbedoimg;

// worldPos
void UpdateVoxelAlbedo(vec3 minecraftPosAbsolute, vec3 cameraPos, vec3 albedo) {
	vec3 worldPos = minecraftPosAbsolute - cameraPos;
	vec3 voxelPos = WorldToVoxel(worldPos);

	if (!IsInVoxelMapVolume(voxelPos)) return;

	imageStore(voxelalbedoimg, ivec3(voxelPos), vec4(albedo, 1.0));
}

#endif // INCLUDE_VOXEL_ALBEDO
