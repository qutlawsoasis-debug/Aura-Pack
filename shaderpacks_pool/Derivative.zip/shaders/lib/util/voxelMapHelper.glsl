

#ifndef INCLUDE_VOXEL_MAP_HELPER
#define INCLUDE_VOXEL_MAP_HELPER

#if MCBL_DITHER_SMOOTHING == 1 && !defined INCLUDE_DITHER_BAYER
	#define INCLUDE_DITHER_BAYER
	#include "/lib/util/dither.glsl"
#endif

#ifndef MCBL_DISTANCE
	#define MCBL_DISTANCE 128 // [128 192 256 384 512]
#endif

#define VOXEL_WALL 99u

const vec3 voxelMapSize = vec3(MCBL_DISTANCE);

// LOD
const vec3 voxelLodMapSize = voxelMapSize / 4.0;

bool IsInVoxelLodMapVolume(vec3 voxelLodPos) {
	vec3 clampedVoxelLodPos = clamp(voxelLodPos, vec3(0.0), voxelLodMapSize);
	return voxelLodPos == clampedVoxelLodPos;
}


vec3 WorldToVoxel(vec3 worldPos) {
	return worldPos + fract(cameraPosition) + voxelMapSize * 0.5;
}

bool IsInVoxelMapVolume(vec3 voxelPos) {
	vec3 clampedVoxelPos = clamp(voxelPos, vec3(0.0), voxelMapSize);
	return voxelPos == clampedVoxelPos;
}


float GetVoxelMapSoftBounds(vec3 voxelPos) {
	const float borderDistance = 8.0;
	vec3 halfVoxelMapSize = voxelMapSize * 0.5;

	vec3 centeredAbsVoxelPos = abs(voxelPos - halfVoxelMapSize);
	vec3 centerToBorderStart = halfVoxelMapSize - vec3(borderDistance);

	vec3 border3D = centeredAbsVoxelPos - centerToBorderStart;
	float border = maxOf(border3D) * rcp(borderDistance);
	border = saturate(1.0 - border);

	return border;
}

vec3 SampleVoxelLightTrilinear(sampler3D lighttex, usampler3D voxeltexRef, vec3 voxelPos, vec2 ditherCoord) {
	#if MCBL_DITHER_SMOOTHING == 1
		float ditherNoise = Bayer8(ditherCoord) - 0.5;
		voxelPos += ditherNoise * MCBL_DITHER_STRENGTH;
	#endif

	vec3 basePos = voxelPos - 0.5; 
	vec3 floorPos = floor(basePos);
	vec3 fractPos = basePos - floorPos;

	vec3 result = vec3(0.0);
	float weightSum = 0.0;

	for (int i = 0; i < 8; i++) {
		vec3 offset = vec3(i & 1, (i >> 1) & 1, (i >> 2) & 1);
		vec3 samplePos = floorPos + offset;

		
		if (!IsInVoxelMapVolume(samplePos)) continue;

		uint voxelData = texelFetch(voxeltexRef, ivec3(samplePos), 0).r;
		if (voxelData == VOXEL_WALL) continue;

		vec3 weight3D = mix(1.0 - fractPos, fractPos, offset);
		float weight = weight3D.x * weight3D.y * weight3D.z;

		vec3 sampleLight = texelFetch(lighttex, ivec3(samplePos), 0).rgb;
		if (any(isnan(sampleLight)) || any(isinf(sampleLight))) continue;

		result += sampleLight * weight;
		weightSum += weight;
	}

	return (weightSum > 1e-5) ? result * rcp(weightSum) : vec3(0.0);
}

// Player Self-Reflection Voxel Grid

#ifndef PLAYER_VOXEL_SIZE_XZ
	#define PLAYER_VOXEL_SIZE_XZ 24 // блоков по X/Z
#endif
#ifndef PLAYER_VOXEL_SIZE_Y
	#define PLAYER_VOXEL_SIZE_Y 32 // блоков по Y
#endif

#ifndef PLAYER_VOXEL_SUBDIV
	#define PLAYER_VOXEL_SUBDIV 8
#endif

const vec3 playerVoxelMapSize = vec3(
	PLAYER_VOXEL_SIZE_XZ * PLAYER_VOXEL_SUBDIV,
	PLAYER_VOXEL_SIZE_Y * PLAYER_VOXEL_SUBDIV,
	PLAYER_VOXEL_SIZE_XZ * PLAYER_VOXEL_SUBDIV
);

vec3 WorldToPlayerVoxel(vec3 worldPos) {
	return worldPos * float(PLAYER_VOXEL_SUBDIV) + fract(cameraPosition) * float(PLAYER_VOXEL_SUBDIV) + playerVoxelMapSize * 0.5;
}

bool IsInPlayerVoxelVolume(vec3 voxelPos) {
	vec3 clampedVoxelPos = clamp(voxelPos, vec3(0.0), playerVoxelMapSize);
	return voxelPos == clampedVoxelPos;
}

float VoxelMapShadowTrace(in vec3 rayOrigin, in vec3 rayTarget, in float dither, in usampler3D voxeltexRef) {
	vec3 toTarget = rayTarget - rayOrigin;
	float maxDist = length(toTarget);
	if (maxDist < 1e-2) return 1.0;
	vec3 rayDir = toTarget * rcp(maxDist);
	vec3 voxelPosF = WorldToVoxel(rayOrigin + rayDir * (0.6 + dither));
	if (!IsInVoxelMapVolume(voxelPosF)) return 1.0;
	ivec3 voxel = ivec3(floor(voxelPosF));
	vec3 rayDirSafe = rayDir + vec3(equal(rayDir, vec3(0.0))) * 1e-6;
	ivec3 rayStep = ivec3(sign(rayDirSafe));
	vec3 tDelta = abs(rcp(rayDirSafe));

	vec3 nextBoundary = vec3(voxel) + max(vec3(rayStep), vec3(0.0));
	vec3 tMax = (nextBoundary - voxelPosF) * rcp(rayDirSafe);
	int maxSteps = int(min(maxDist * 1.8, 160.0)) + 2;

	for (int i = 0; i < maxSteps; ++i) {
		if (!IsInVoxelMapVolume(vec3(voxel))) return 1.0;

		uint voxelData = texelFetch(voxeltexRef, voxel, 0).r;
		if (voxelData == VOXEL_WALL) return 0.0;

		if (tMax.x < tMax.y) {
			if (tMax.x < tMax.z) {
				if (tMax.x >= maxDist) break;
				voxel.x += rayStep.x; tMax.x += tDelta.x;
			} else {
				if (tMax.z >= maxDist) break;
				voxel.z += rayStep.z; tMax.z += tDelta.z;
			}
		} else {
			if (tMax.y < tMax.z) {
				if (tMax.y >= maxDist) break;
				voxel.y += rayStep.y; tMax.y += tDelta.y;
			} else {
				if (tMax.z >= maxDist) break;
				voxel.z += rayStep.z; tMax.z += tDelta.z;
			}
		}
	}

	return 1.0;
}

#endif // INCLUDE_VOXEL_MAP_HELPER
