

#ifndef INCLUDE_SHADOW_VOXEL_GRID
#define INCLUDE_SHADOW_VOXEL_GRID


#ifndef SHADOW_VOXEL_DISTANCE
	#define SHADOW_VOXEL_DISTANCE 24 // [12 16 20 24 32 48]
#endif


#ifndef SHADOW_VOXEL_SUBDIV
	#define SHADOW_VOXEL_SUBDIV 2 // [1 2 3 4 6 8]
#endif

const int shadowVoxelRadiusBlocks = SHADOW_VOXEL_DISTANCE + 4; // небольшой запас на границу
const ivec3 shadowVoxelMapSizeI = ivec3((shadowVoxelRadiusBlocks * 2) * SHADOW_VOXEL_SUBDIV);
const vec3 shadowVoxelMapSize = vec3(shadowVoxelMapSizeI);


vec3 WorldToShadowVoxel(vec3 worldPos) {
	return worldPos * float(SHADOW_VOXEL_SUBDIV)
		+ fract(cameraPosition) * float(SHADOW_VOXEL_SUBDIV)
		+ shadowVoxelMapSize * 0.5;
}

bool IsInShadowVoxelVolume(vec3 voxelPos) {
	vec3 clampedVoxelPos = clamp(voxelPos, vec3(0.0), shadowVoxelMapSize);
	return voxelPos == clampedVoxelPos;
}

#endif // INCLUDE_SHADOW_VOXEL_GRID
