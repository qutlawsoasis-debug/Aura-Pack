

#ifndef INCLUDE_VOXEL_GEOMETRIC_DETAIL
#define INCLUDE_VOXEL_GEOMETRIC_DETAIL

#ifndef INCLUDE_VOXEL_MAP_HELPER
	#include "/lib/util/voxelMapHelper.glsl"
#endif

#ifndef VGDE_ENABLED
	#define VGDE_ENABLED 1 // [0 1]
#endif

#ifndef VGDE_MAX_DISTANCE
	#define VGDE_MAX_DISTANCE 12.0 // [4.0 6.0 8.0 12.0 16.0 24.0 32.0] дальность прохода за пределы блока, в блоках
#endif

#ifndef VGDE_MAX_STEPS
	#define VGDE_MAX_STEPS 48 // [24 32 48 64 96] лимит шагов DDA, страховка от долгих трасс по пустоте на краю voxelimg
#endif

#ifndef VGDE_AO_STRENGTH
	#define VGDE_AO_STRENGTH 0.15 // [0.0 0.05 0.1 0.15 0.2 0.3 0.5] сила дешёвого затемнения по hitDistance (см. GetVGDEOcclusion)
#endif

struct VGDEResult {
	bool hit;
	float hitDistance;   // расстояние от точки выхода из блока (не от камеры!)
	vec3 hitWorldPos;    // camera-relative, та же конвенция что и exitWorldPos на входе
	vec3 hitNormal;      // нормаль грани вокселя, на которую наткнулись (осевая, ±X/±Y/±Z)
};

// exitWorldPos  — camera-relative мировая позиция точки, где offsetCoord.z
//                 обычного POM впервые ушёл <= 0 (дно карты высот блока).
// worldRayDir   — направление взгляда (tangentViewVector), переведённое в
//                 мировое пространство (не обязательно нормализовано).
// dither        — тот же дизеринг-шум, что в CalculateParallax, сглаживает
//                 первый шаг DDA
// voxeltexRef   — usampler3D voxelte
VGDEResult TraceVoxelGeometricDetail(in vec3 exitWorldPos, in vec3 worldRayDir, in float dither, in usampler3D voxeltexRef) {
	VGDEResult result;
	result.hit = false;
	result.hitDistance = VGDE_MAX_DISTANCE;
	result.hitWorldPos = exitWorldPos;
	result.hitNormal = vec3(0.0);

	#if VGDE_ENABLED == 0
		return result;
	#endif

	
	float dirLenSq = dot(worldRayDir, worldRayDir);
	if (dirLenSq < 1e-10) return result;
	vec3 rayDir = worldRayDir * inversesqrt(dirLenSq);

	vec3 voxelPosF = WorldToVoxel(exitWorldPos + rayDir * dither * 0.5);
	if (!IsInVoxelMapVolume(voxelPosF)) return result;

	ivec3 voxel = ivec3(floor(voxelPosF));
	vec3 rayDirSafe = rayDir + vec3(equal(rayDir, vec3(0.0))) * 1e-6;
	ivec3 rayStep = ivec3(sign(rayDirSafe));
	vec3 tDelta = abs(rcp(rayDirSafe));

	vec3 nextBoundary = vec3(voxel) + max(vec3(rayStep), vec3(0.0));
	vec3 tMax = (nextBoundary - voxelPosF) * rcp(rayDirSafe);


	ivec3 axisMask = ivec3(0);

	int maxSteps = min(int(VGDE_MAX_DISTANCE * 1.8) + 2, VGDE_MAX_STEPS);

	for (int i = 0; i < maxSteps; ++i) {
		if (!IsInVoxelMapVolume(vec3(voxel))) break;

		uint voxelData = texelFetch(voxeltexRef, voxel, 0).r;
		if (voxelData == VOXEL_WALL) {
			result.hit = true;
			result.hitNormal = -vec3(axisMask) * vec3(rayStep);


			float enterT = (axisMask.x == 1) ? tMax.x - tDelta.x
				: (axisMask.y == 1) ? tMax.y - tDelta.y
				: (axisMask.z == 1) ? tMax.z - tDelta.z
				: 0.0;

			result.hitDistance = clamp(enterT, 0.0, VGDE_MAX_DISTANCE);
			result.hitWorldPos = exitWorldPos + rayDir * result.hitDistance;
			return result;
		}

		axisMask = ivec3(0);
		if (tMax.x < tMax.y) {
			if (tMax.x < tMax.z) {
				if (tMax.x >= VGDE_MAX_DISTANCE) break;
				voxel.x += rayStep.x; tMax.x += tDelta.x; axisMask.x = 1;
			} else {
				if (tMax.z >= VGDE_MAX_DISTANCE) break;
				voxel.z += rayStep.z; tMax.z += tDelta.z; axisMask.z = 1;
			}
		} else {
			if (tMax.y < tMax.z) {
				if (tMax.y >= VGDE_MAX_DISTANCE) break;
				voxel.y += rayStep.y; tMax.y += tDelta.y; axisMask.y = 1;
			} else {
				if (tMax.z >= VGDE_MAX_DISTANCE) break;
				voxel.z += rayStep.z; tMax.z += tDelta.z; axisMask.z = 1;
			}
		}
	}


	return result;
}

float GetVGDEOcclusion(in VGDEResult vgde) {
	if (!vgde.hit) return 1.0;
	return saturate(1.0 - vgde.hitDistance * VGDE_AO_STRENGTH);
}

#endif // INCLUDE_VOXEL_GEOMETRIC_DETAIL
