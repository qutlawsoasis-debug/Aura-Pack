
#ifndef INCLUDE_WATER_TRAIL_HELPER
#define INCLUDE_WATER_TRAIL_HELPER

#ifndef WATER_TRAIL_SIZE
	#define WATER_TRAIL_SIZE 128 // [64 96 128 192 256]
#endif

#ifndef WATER_TRAIL_VOXEL_TYPE
	#define WATER_TRAIL_VOXEL_TYPE 1 // [1 2 3]
#endif

#ifndef WATER_TRAIL_PIXELS_PER_BLOCK
	#define WATER_TRAIL_PIXELS_PER_BLOCK 16 // [2 4 8 16 32]
#endif

vec2 SnapToTrailPixelGrid(vec2 worldPosXZ) {
	float pixelsPerBlock = float(WATER_TRAIL_PIXELS_PER_BLOCK);
	return floor(worldPosXZ * pixelsPerBlock + 0.5) * rcp(pixelsPerBlock);
}

const vec2 waterTrailSize = vec2(WATER_TRAIL_SIZE);

vec2 WorldToTrail(vec2 worldPosXZ) {
	vec2 playerPosXZ = cameraPosition.xz - relativeEyePosition.xz;

	#if WATER_TRAIL_VOXEL_TYPE == 2
		worldPosXZ = SnapToTrailPixelGrid(worldPosXZ);
	#endif

	return worldPosXZ + fract(playerPosXZ) + waterTrailSize * 0.5;
}

bool IsInTrailVolume(vec2 trailPos) {
	vec2 clampedTrailPos = clamp(trailPos, vec2(0.0), waterTrailSize);
	return trailPos == clampedTrailPos;
}

float GetTrailSoftBounds(vec2 trailPos) {
	const float borderDistance = 12.0;
	vec2 halfTrailSize = waterTrailSize * 0.5;

	vec2 centeredAbsTrailPos = abs(trailPos - halfTrailSize);
	vec2 centerToBorderStart = halfTrailSize - vec2(borderDistance);

	vec2 border2D = centeredAbsTrailPos - centerToBorderStart;
	float border = max(border2D.x, border2D.y) * rcp(borderDistance);
	border = saturate(1.0 - border);

	return border;
}

float SampleTrailHeightBilinear(sampler2D trailtex, vec2 trailPos) {
	vec2 basePos = trailPos - 0.5;
	vec2 floorPos = floor(basePos);
	vec2 fractPos = basePos - floorPos;

	float result = 0.0;
	float weightSum = 0.0;

	for (int i = 0; i < 4; i++) {
		vec2 offset = vec2(i & 1, (i >> 1) & 1);
		vec2 samplePos = floorPos + offset;

		if (!IsInTrailVolume(samplePos)) continue;

		vec2 weight2D = mix(1.0 - fractPos, fractPos, offset);
		float weight = weight2D.x * weight2D.y;

		float sampleHeight = texelFetch(trailtex, ivec2(samplePos), 0).r;
		if (isnan(sampleHeight) || isinf(sampleHeight)) continue;

		result += sampleHeight * weight;
		weightSum += weight;
	}

	return (weightSum > 1e-5) ? result * rcp(weightSum) : 0.0;
}


const float WATER_Y_ENCODE_RANGE = 512.0;

uint EncodeWaterY(float worldY) {
	float playerPosY = cameraPosition.y - relativeEyePosition.y;
	float relativeY = worldY - playerPosY;
	float normalized = saturate((relativeY + WATER_Y_ENCODE_RANGE) * rcp(WATER_Y_ENCODE_RANGE * 2.0));
	uint encoded = uint(normalized * 65534.0) + 1u; // +1u: избегаем 0u (= "нет воды")
	return encoded;
}


float DecodeWaterY(uint presenceRaw, out bool hasWater) {
	hasWater = presenceRaw > 0u;
	if (!hasWater) return 0.0;

	float playerPosY = cameraPosition.y - relativeEyePosition.y;
	float normalized = float(presenceRaw - 1u) * rcp(65534.0);
	return normalized * (WATER_Y_ENCODE_RANGE * 2.0) - WATER_Y_ENCODE_RANGE + playerPosY;
}

#endif // INCLUDE_WATER_TRAIL_HELPER
