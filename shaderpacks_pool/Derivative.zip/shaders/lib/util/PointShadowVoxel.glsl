
#ifndef INCLUDE_POINT_SHADOW_VOXEL
#define INCLUDE_POINT_SHADOW_VOXEL

#ifndef POINT_SHADOW_VOXEL_SUBDIV
	#define POINT_SHADOW_VOXEL_SUBDIV 2 // [1 2 4 8]
#endif

#ifndef POINT_SHADOW_VOXEL_DISTANCE
	#define POINT_SHADOW_VOXEL_DISTANCE 32 // [16 24 32 48 64]
#endif

#define VOXEL_WALL_FINE 255u

const vec3 pointShadowVoxelMapSize = vec3(
	float(POINT_SHADOW_VOXEL_DISTANCE * POINT_SHADOW_VOXEL_SUBDIV)
);


vec3 WorldToPointShadowVoxel(vec3 worldPos) {
	return worldPos * float(POINT_SHADOW_VOXEL_SUBDIV)
		+ fract(cameraPosition) * float(POINT_SHADOW_VOXEL_SUBDIV)
		+ pointShadowVoxelMapSize * 0.5;
}

bool IsInPointShadowVoxelVolume(vec3 voxelPos) {
	vec3 clampedVoxelPos = clamp(voxelPos, vec3(0.0), pointShadowVoxelMapSize);
	return voxelPos == clampedVoxelPos;
}

#endif // INCLUDE_POINT_SHADOW_VOXEL
