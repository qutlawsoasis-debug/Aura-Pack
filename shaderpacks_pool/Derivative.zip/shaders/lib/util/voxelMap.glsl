
void UpdateVoxelMap(int vertexID, int materialID, bool isWaterBlock) {
	if (vertexID % 4 != 0) return;

	if (isWaterBlock || materialID == 40 || materialID == 189) {
		vec3 feetPosAir = gl_Vertex.xyz + at_midBlock / 64.0;
		vec3 viewPosAir = transMAD(gl_ModelViewMatrix, feetPosAir);
		vec3 worldPosAir = transMAD(shadowModelViewInverse, viewPosAir);

		vec3 voxelPosAir = WorldToVoxel(worldPosAir);
		if (!IsInVoxelMapVolume(voxelPosAir)) return;

		imageStore(voxelimg, ivec3(voxelPosAir), uvec4(0u, 0u, 0u, 0u));
		return;
	}

	// at_midBlock даёт смещение к центру блока в 1/64 блока.
	vec3 feetPos = gl_Vertex.xyz + at_midBlock / 64.0;
	vec3 viewPos = transMAD(gl_ModelViewMatrix, feetPos);
	vec3 worldPos = transMAD(shadowModelViewInverse, viewPos);

	vec3 voxelPos = WorldToVoxel(worldPos);
	if (!IsInVoxelMapVolume(voxelPos)) return;

	
bool isLightSource = (materialID >= 20 && materialID <= 35)
	|| (materialID >= 37 && materialID <= 69)
	|| (materialID == 100)
	|| (materialID >= 70 && materialID <= 85)
	|| (materialID >= 86 && materialID <= 89) 
	|| (materialID >= 90 && materialID <= 98)
	|| (materialID >= 101 && materialID <= 116)
	|| (materialID == 117) || (materialID == 118)
	|| (materialID >= 121 && materialID <= 127)
	|| (materialID >= 128 && materialID <= 131);

	uint voxelValue = VOXEL_WALL;
	if (isLightSource) voxelValue = uint(materialID);

	imageStore(voxelimg, ivec3(voxelPos), uvec4(voxelValue, 0u, 0u, 0u));

	imageStore(voxellodimg, ivec3(voxelPos) / 4, uvec4(1u, 0u, 0u, 0u));
}
