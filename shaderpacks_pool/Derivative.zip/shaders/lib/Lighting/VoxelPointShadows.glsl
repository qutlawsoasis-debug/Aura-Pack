// ─────────────────────────────────────────────────────────────────────────
// Voxel Point-Light Shadows
//
//
//      (voxelData != 0 && voxelData != VOXEL_WALL).
//
//
// ─────────────────────────────────────────────────────────────────────────

#ifndef INCLUDE_VOXEL_POINT_SHADOWS
#define INCLUDE_VOXEL_POINT_SHADOWS

#ifndef VOXEL_POINT_SHADOWS
	#define VOXEL_POINT_SHADOWS 0
#endif
#ifndef SHADOW_STYLE
	#define SHADOW_STYLE 0
#endif
#ifndef SHADOW_MAX_LIGHTS
	#define SHADOW_MAX_LIGHTS 4
#endif
#ifndef SHADOW_SEARCH_RADIUS
	#define SHADOW_SEARCH_RADIUS 12
#endif
#ifndef SHADOW_SOFTNESS_MODE
	#define SHADOW_SOFTNESS_MODE 0
#endif
#ifndef SHADOW_SOFT_SAMPLES
	#define SHADOW_SOFT_SAMPLES 4
#endif
#ifndef SHADOW_JITTER_RADIUS
	#define SHADOW_JITTER_RADIUS 0.35
#endif
#ifndef SHADOW_BRIGHTNESS
	#define SHADOW_BRIGHTNESS 1.0
#endif
#ifndef SHADOW_MAX_DISTANCE
	#define SHADOW_MAX_DISTANCE 32
#endif
#ifndef SHADOW_DISTANCE_FADE
	#define SHADOW_DISTANCE_FADE 6.0
#endif
#ifndef SHADOW_CORNER_SAMPLES
	#define SHADOW_CORNER_SAMPLES 4
#endif
#ifndef SHADOW_CORNER_DISTANCE
	#define SHADOW_CORNER_DISTANCE 3.0
#endif
#ifndef SHADOW_CORNER_STRENGTH
	#define SHADOW_CORNER_STRENGTH 0.7
#endif
#ifndef SHADOW_OPT_SEARCH_RADIUS
	#define SHADOW_OPT_SEARCH_RADIUS 4
#endif

// ─────────────────────────────────────────────────────────────────────────
// 3D DDA voxel raymarch (Amanatides & Woo).
//
// ─────────────────────────────────────────────────────────────────────────
bool VoxelRayVisible(usampler3D voxeltexRef, vec3 rayStartVoxel, vec3 rayEndVoxel, int maxSteps) {
	vec3 rayDir = rayEndVoxel - rayStartVoxel;
	float rayLength = length(rayDir);
	if (rayLength < 1e-4) return true;

	rayDir /= rayLength;

	ivec3 voxelPos = ivec3(floor(rayStartVoxel));
	ivec3 endVoxelPos = ivec3(floor(rayEndVoxel));

	ivec3 step_ = ivec3(sign(rayDir));

	vec3 tDelta = vec3(
		abs(rayDir.x) > 1e-6 ? abs(1.0 / rayDir.x) : 1e30,
		abs(rayDir.y) > 1e-6 ? abs(1.0 / rayDir.y) : 1e30,
		abs(rayDir.z) > 1e-6 ? abs(1.0 / rayDir.z) : 1e30
	);

	vec3 voxelBoundary = vec3(voxelPos) + max(vec3(step_), vec3(0.0));

	vec3 tMax = vec3(
		step_.x != 0 ? (voxelBoundary.x - rayStartVoxel.x) / rayDir.x : 1e30,
		step_.y != 0 ? (voxelBoundary.y - rayStartVoxel.y) / rayDir.y : 1e30,
		step_.z != 0 ? (voxelBoundary.z - rayStartVoxel.z) / rayDir.z : 1e30
	);

	ivec3 volumeMax = ivec3(voxelMapSize);

	for (int i = 0; i < maxSteps; i++) {
		if (voxelPos == endVoxelPos) return true;

		if (any(lessThan(voxelPos, ivec3(0))) || any(greaterThan(voxelPos, volumeMax))) return false;

		if (i > 0) {
			uint voxelData = texelFetch(voxeltexRef, voxelPos, 0).r;
			if (voxelData == VOXEL_WALL) return false;
		}

		if (tMax.x < tMax.y && tMax.x < tMax.z) {
			voxelPos.x += step_.x;
			tMax.x += tDelta.x;
		} else if (tMax.y < tMax.z) {
			voxelPos.y += step_.y;
			tMax.y += tDelta.y;
		} else {
			voxelPos.z += step_.z;
			tMax.z += tDelta.z;
		}
	}

	return voxelPos == endVoxelPos;
}

// ─────────────────────────────────────────────────────────────────────────
//
//
// ─────────────────────────────────────────────────────────────────────────
#define MAX_LIGHTS_HARD_CAP 32

int FindNearbyLights(usampler3D voxeltexRef, ivec3 basePos, int r, out ivec3 lightPos[MAX_LIGHTS_HARD_CAP], out float lightDistSq[MAX_LIGHTS_HARD_CAP]) {
	int found = 0;

	{
		uint voxelData = texelFetch(voxeltexRef, basePos, 0).r;
		if (voxelData != 0u && voxelData != VOXEL_WALL) {
			lightPos[0] = basePos;
			lightDistSq[0] = 0.0;
			found = 1;
		}
	}

	for (int shell = 1; shell <= r; shell++) {
		for (int dz = -shell; dz <= shell; dz++) {
		for (int dy = -shell; dy <= shell; dy++) {
			bool edge = (dz == -shell || dz == shell || dy == -shell || dy == shell);

			for (int dx = -shell; dx <= shell; dx++) {
				if (!edge && dx != -shell && dx != shell) continue;

				ivec3 samplePos = basePos + ivec3(dx, dy, dz);
				if (!IsInVoxelMapVolume(vec3(samplePos))) continue;

				uint voxelData = texelFetch(voxeltexRef, samplePos, 0).r;
				if (voxelData == 0u || voxelData == VOXEL_WALL) continue;

				float distSq = float(dx * dx + dy * dy + dz * dz);

				int insertAt = found;
				for (int k = 0; k < found && k < SHADOW_MAX_LIGHTS; k++) {
					if (distSq < lightDistSq[k]) { insertAt = k; break; }
				}

				if (found < SHADOW_MAX_LIGHTS) {
					for (int k = found; k > insertAt; k--) {
						lightPos[k] = lightPos[k - 1];
						lightDistSq[k] = lightDistSq[k - 1];
					}
					lightPos[insertAt] = samplePos;
					lightDistSq[insertAt] = distSq;
					found++;
				} else if (insertAt < SHADOW_MAX_LIGHTS) {
					for (int k = SHADOW_MAX_LIGHTS - 1; k > insertAt; k--) {
						lightPos[k] = lightPos[k - 1];
						lightDistSq[k] = lightDistSq[k - 1];
					}
					lightPos[insertAt] = samplePos;
					lightDistSq[insertAt] = distSq;
				}
			}
		}}

		if (found >= SHADOW_MAX_LIGHTS) break;
	}

	return found;
}

// ─────────────────────────────────────────────────────────────────────────
//
// SEARCH_RADIUS).
// ─────────────────────────────────────────────────────────────────────────
vec3 GetVoxelPointShadows_DDA(vec3 worldPos, vec3 worldNormal, usampler3D voxeltexRef, float dither, int searchRadius) {
	vec3 voxelPosF = WorldToVoxel(worldPos);
	if (!IsInVoxelMapVolume(voxelPosF)) return vec3(0.0);

	ivec3 basePos = ivec3(floor(voxelPosF));

	ivec3 lightPos[MAX_LIGHTS_HARD_CAP];
	float lightDistSq[MAX_LIGHTS_HARD_CAP];
	int lightCount = FindNearbyLights(voxeltexRef, basePos, searchRadius, lightPos, lightDistSq);

	if (lightCount == 0) return vec3(0.0);

	vec3 rayStartWorld = worldPos + worldNormal * 0.6;

	const float MIN_CONTRIBUTION = 1.0 / 4096.0;

	vec3 totalLight = vec3(0.0);

	for (int i = 0; i < lightCount; i++) {
		float distToLight = sqrt(lightDistSq[i]) + 1.0;
		float maxPossibleAttenuation = rcp(distToLight * distToLight);
		if (maxPossibleAttenuation < MIN_CONTRIBUTION) continue;

		uint voxelData = texelFetch(voxeltexRef, lightPos[i], 0).r;
		int materialID = int(voxelData);

		vec3 sourceColor = GetVoxelEmission(materialID);
		if (sourceColor == vec3(0.0)) continue;

		vec3 sourceWorldCenter = vec3(lightPos[i]) - fract(cameraPosition) - voxelMapSize * 0.5 + 0.5;

		vec3 toSource = normalize(sourceWorldCenter - worldPos);
		float NdotL = max(dot(worldNormal, toSource), 0.0);
		if (NdotL < 1e-4) continue;

		int maxSteps = int(ceil(distToLight)) * 2 + 4;

		float visibility = 0.0;

	#if SHADOW_SOFTNESS_MODE == 1
		for (int s = 0; s < SHADOW_SOFT_SAMPLES; s++) {
			float angle = (float(s) + dither) * (6.28318 / float(SHADOW_SOFT_SAMPLES));
			vec2 diskOffset = vec2(cos(angle), sin(angle)) * SHADOW_JITTER_RADIUS * (0.3 + 0.7 * dither);

			vec3 jitter = vec3(diskOffset.x, diskOffset.y * 0.6, diskOffset.x * 0.4);
			vec3 targetWorld = sourceWorldCenter + jitter;

			vec3 rayStartVoxel = WorldToVoxel(rayStartWorld);
			vec3 rayEndVoxel = WorldToVoxel(targetWorld);

			if (VoxelRayVisible(voxeltexRef, rayStartVoxel, rayEndVoxel, maxSteps)) {
				visibility += 1.0 / float(SHADOW_SOFT_SAMPLES);
			}
		}
	#else
		vec3 rayStartVoxel = WorldToVoxel(rayStartWorld);
		vec3 rayEndVoxel = WorldToVoxel(sourceWorldCenter);

		visibility = VoxelRayVisible(voxeltexRef, rayStartVoxel, rayEndVoxel, maxSteps) ? 1.0 : 0.0;
	#endif

		if (visibility < 1e-4) continue;

		totalLight += sourceColor * visibility * maxPossibleAttenuation * NdotL;
	}

	return totalLight * SHADOW_BRIGHTNESS;
}

// ─────────────────────────────────────────────────────────────────────────
//
//
// ─────────────────────────────────────────────────────────────────────────
float GetVoxelCornerShadowMask(vec3 worldPos, vec3 worldNormal, usampler3D voxeltexRef, float dither) {
	#if SHADOW_MAX_DISTANCE > 0
		float pixelDistance = length(worldPos);
		if (pixelDistance > float(SHADOW_MAX_DISTANCE)) return 1.0;
	#endif

	vec3 voxelPosF = WorldToVoxel(worldPos);
	if (!IsInVoxelMapVolume(voxelPosF)) return 1.0;

	vec3 rayStartWorld = worldPos + worldNormal * 0.6;
	vec3 rayStartVoxel = WorldToVoxel(rayStartWorld);

	vec3 upHint = abs(worldNormal.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
	vec3 tangent = normalize(cross(worldNormal, upHint));
	vec3 bitangent = cross(worldNormal, tangent);

	int wallHits = 0;

	for (int s = 0; s < SHADOW_CORNER_SAMPLES; s++) {
		float angle = (float(s) + dither) * (6.28318 / float(SHADOW_CORNER_SAMPLES));

		vec3 diagonalDir = normalize(worldNormal * 0.5 + tangent * cos(angle) + bitangent * sin(angle));

		vec3 sampleWorld = rayStartWorld + diagonalDir * SHADOW_CORNER_DISTANCE;
		vec3 sampleVoxel = WorldToVoxel(sampleWorld);

		if (!IsInVoxelMapVolume(sampleVoxel)) continue;

		uint voxelData = texelFetch(voxeltexRef, ivec3(floor(sampleVoxel)), 0).r;
		if (voxelData == VOXEL_WALL) wallHits++;
	}

	float wallRatio = float(wallHits) / float(SHADOW_CORNER_SAMPLES);
	return 1.0 - wallRatio * SHADOW_CORNER_STRENGTH;
}

// ─────────────────────────────────────────────────────────────────────────
//
//
// ─────────────────────────────────────────────────────────────────────────
vec3 GetVoxelPointShadows(vec3 worldPos, vec3 worldNormal, usampler3D voxeltexRef, float dither) {
#if VOXEL_POINT_SHADOWS == 1
	#if SHADOW_STYLE == 0 || SHADOW_STYLE == 2
		float pixelDistance = length(worldPos);
		float distanceFade = 1.0;

		#if SHADOW_MAX_DISTANCE > 0
			if (pixelDistance > float(SHADOW_MAX_DISTANCE)) return vec3(0.0);

			#if SHADOW_DISTANCE_FADE > 0.0
				distanceFade = 1.0 - smoothstep(float(SHADOW_MAX_DISTANCE) - SHADOW_DISTANCE_FADE, float(SHADOW_MAX_DISTANCE), pixelDistance);
				if (distanceFade < 1e-4) return vec3(0.0);
			#endif
		#endif
	#endif

	#if SHADOW_STYLE == 0
		return GetVoxelPointShadows_DDA(worldPos, worldNormal, voxeltexRef, dither, SHADOW_SEARCH_RADIUS) * distanceFade;
	#elif SHADOW_STYLE == 2
		return GetVoxelPointShadows_DDA(worldPos, worldNormal, voxeltexRef, dither, SHADOW_OPT_SEARCH_RADIUS) * distanceFade;
	#else
		return vec3(0.0);
	#endif
#else
	return vec3(0.0);
#endif
}

#endif // INCLUDE_VOXEL_POINT_SHADOWS
