// ═══════════════════════════════════════════════════════════════════════
// SSPT — Screen-Space Point-Light Shadow Tracing
//
//
//
// ═══════════════════════════════════════════════════════════════════════

#ifndef SSPT_ENABLED
	#define SSPT_ENABLED 1 // [0 1]
#endif

#ifndef SSPT_SOURCE_THRESHOLD
	#define SSPT_SOURCE_THRESHOLD 0.72 // [0.4 0.5 0.6 0.65 0.7 0.72 0.75 0.8 0.85 0.9]
#endif

#ifndef SSPT_SEARCH_RADIUS
	#define SSPT_SEARCH_RADIUS 24 // [8 12 16 20 24 32 40 48]
#endif

#ifndef SSPT_SEARCH_STEP
	#define SSPT_SEARCH_STEP 3 // [1 2 3 4 5 6]
#endif

#ifndef SSPT_MAX_STEPS
	#define SSPT_MAX_STEPS 24 // [12 16 20 24 32 48 64]
#endif

#ifndef SSPT_THICKNESS
	#define SSPT_THICKNESS 0.5
#endif

#ifndef SSPT_STRENGTH
	#define SSPT_STRENGTH 1.0 // [0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.5 2.0 3.0]
#endif

#ifndef SSPT_MAX_DISTANCE
	#define SSPT_MAX_DISTANCE 20.0
#endif

// ─────────────────────────────────────────────────────────────────────────
//
// ─────────────────────────────────────────────────────────────────────────
bool SSPT_FindBrightestSource(ivec2 centerTexel, out ivec2 bestTexel, out float bestBrightness) {
	bestTexel = ivec2(-1);
	bestBrightness = SSPT_SOURCE_THRESHOLD;
	bool found = false;

	const int R = SSPT_SEARCH_RADIUS;
	const int STEP = SSPT_SEARCH_STEP;

	for (int dy = -R; dy <= R; dy += STEP) {
		for (int dx = -R; dx <= R; dx += STEP) {
			ivec2 sampleTexel = centerTexel + ivec2(dx, dy);

			if (clamp(sampleTexel, ivec2(0), ivec2(screenSize) - 1) != sampleTexel) continue;

			float brightness = texelFetch(colortex7, sampleTexel, 0).x;

			if (brightness > bestBrightness) {
				bestBrightness = brightness;
				bestTexel = sampleTexel;
				found = true;
			}
		}
	}

	return found;
}

// ─────────────────────────────────────────────────────────────────────────
//
// ─────────────────────────────────────────────────────────────────────────
float SSPT_TraceVisibility(vec3 viewPos, vec3 viewSourcePos, float dither) {
	vec3 toSource = viewSourcePos - viewPos;
	float rayLength = length(toSource);
	if (rayLength < 1e-4) return 1.0;

	vec3 rayDir = toSource / rayLength;

	float stepSize = rayLength / float(SSPT_MAX_STEPS);
	float travelled = stepSize * (0.5 + dither);

	for (int i = 0; i < SSPT_MAX_STEPS; i++) {
		if (travelled >= rayLength) break;

		vec3 currentViewPos = viewPos + rayDir * travelled;
		vec3 sScreen = ViewToScreenSpace(currentViewPos);

		if (clamp(sScreen.xy, 0.0, 1.0) != sScreen.xy || sScreen.z > 1.0) break;

		float sceneDepth = texelFetch(depthtex1, ivec2(sScreen.xy * screenSize), 0).x;

		if (sceneDepth < 1.0) {
			vec3 sceneViewPos = ScreenToViewSpace(vec3(sScreen.xy, sceneDepth));

			float thickness = currentViewPos.z - sceneViewPos.z;
			if (thickness > 0.0 && thickness < SSPT_THICKNESS) {
				return 0.0;
			}
		}

		travelled += stepSize;
	}

	return 1.0;
}

// ─────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────
vec3 SSPT_Calculate(vec3 viewPos, vec3 viewNormal, ivec2 screenTexel, float dither) {
#if SSPT_ENABLED == 1
	ivec2 bestTexel;
	float bestBrightness;
	bool foundSource = SSPT_FindBrightestSource(screenTexel, bestTexel, bestBrightness);
	if (!foundSource) return vec3(0.0);

	float sourceDepth = texelFetch(depthtex1, bestTexel, 0).x;
	if (sourceDepth >= 1.0) return vec3(0.0);

	vec2 sourceUV = (vec2(bestTexel) + 0.5) / screenSize;
	vec3 viewSourcePos = ScreenToViewSpace(vec3(sourceUV, sourceDepth));

	float distToSource = distance(viewPos, viewSourcePos);
	if (distToSource > SSPT_MAX_DISTANCE) return vec3(0.0);

	vec3 toSource = (viewSourcePos - viewPos) / max(distToSource, 1e-4);
	float NdotL = max(dot(viewNormal, toSource), 0.0);
	if (NdotL < 1e-4) return vec3(0.0);

	vec3 rayStartViewPos = viewPos + viewNormal * 0.05;

	float visibility = SSPT_TraceVisibility(rayStartViewPos, viewSourcePos, dither);
	if (visibility < 1e-4) return vec3(0.0);

	vec3 sourceAlbedo = texelFetch(colortex6, bestTexel, 0).rgb;
	float sourceBrightness = bestBrightness;

	float falloff = 1.0 / (1.0 + distToSource * distToSource * 0.1);

	return sourceAlbedo * sourceBrightness * falloff * NdotL * visibility * SSPT_STRENGTH;
#else
	return vec3(0.0);
#endif
}
