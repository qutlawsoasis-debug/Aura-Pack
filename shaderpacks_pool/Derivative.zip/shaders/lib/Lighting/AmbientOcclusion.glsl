#ifndef AMBIENT_OCCLUSION_GLSL
#define AMBIENT_OCCLUSION_GLSL

#ifdef MCBL_ON
	#ifndef INCLUDE_VOXEL_MAP_HELPER
		#include "/lib/util/voxelMapHelper.glsl"
	#endif
#endif

#define SSAO_ENABLED // [0 1]
#define SSAO_SAMPLES 16 // [4 8 16 32]
#define SSAO_STRENGTH 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0 4.0 5.0 7.0 10.0]

//#define UE4_AO_ENABLED // [0 1]
#define UE4_AO_SAMPLES 16 // [4 8 16 32 64]
#define UE4_AO_RADIUS 1.5 // [1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0]
#define UE4_AO_INTENSITY 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0 4.0 5.0 7.0 10.0]

//#define DEPTH_AO_ENABLED // [0 1]
#define DEPTH_AO_SAMPLES 8 // [4 8 16 32]
#define DEPTH_AO_RADIUS 2.0 // [1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0]
#define DEPTH_AO_INTENSITY 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0 4.0 5.0 7.0 10.0]

//#define VANILLA_AO_ENABLED // [0 1]
#define VANILLA_AO_INTENSITY 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0 4.0 5.0 7.0 10.0]

//#define HBAO_ENABLED // [0 1]
#define HBAO_SAMPLES 16 // [4 8 16 32 64]
#define HBAO_RADIUS 2.0 // [1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0]
#define HBAO_INTENSITY 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0 4.0 5.0 7.0 10.0]

#define GTAO_ENABLED // [0 1]
#define GTAO_SAMPLES 32 // [4 8 16 32 64]
#define GTAO_RADIUS 15.0 // [1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0]
#define GTAO_INTENSITY 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0 4.0 5.0 7.0 10.0]

//#define VXAO_ENABLED // [0 1]
#define VXAO_SAMPLES 8  // [4 8 16 32]
#define VXAO_STEPS 12
#define VXAO_RADIUS  1.5 // [0.5 1.0 1.5 2.0 3.0 4.0 5.0]
#define VXAO_INTENSITY 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0]

// ================================================================================================= //

#ifdef SSAO_ENABLED
float SpiralAO(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither) {
    float rSteps = 1.0 / float(SSAO_SAMPLES);
    float maxSqLen = sqr(viewPos.z) * 0.25;
    vec2 radius = vec2(0.0);
    vec2 rayStep = vec2(0.6 / aspectRatio, 0.6) / max((far - near) * -viewPos.z / far + near, 5.0) * gbufferProjection[1][1];
    const float goldenAngle = TAU / (PHI1 + 1.0);
    const mat2 goldenRotate = mat2(cos(goldenAngle), -sin(goldenAngle), sin(goldenAngle), cos(goldenAngle));
    vec2 rot = sincos(dither * TAU) * rSteps;
    float total = 0.0;
    for (uint i = 0u; i < SSAO_SAMPLES; ++i, rot *= goldenRotate) {
        radius += rayStep;
        vec3 diff = ScreenToViewSpace(coord + rot * radius) - viewPos;
        float diffSqLen = dotSelf(diff);
        if (diffSqLen > 1e-5 && diffSqLen < maxSqLen) {
            float NdotL = saturate(dot(normal, diff * inversesqrt(diffSqLen)));
            total += NdotL * saturate(1.0 - diffSqLen / maxSqLen);
        }
        diff = ScreenToViewSpace(coord - rot * radius) - viewPos;
        diffSqLen = dotSelf(diff);
        if (diffSqLen > 1e-5 && diffSqLen < maxSqLen) {
            float NdotL = saturate(dot(normal, diff * inversesqrt(diffSqLen)));
            total += NdotL * saturate(1.0 - diffSqLen / maxSqLen);
        }
    }
    total = max0(1.0 - total * rSteps * SSAO_STRENGTH);
    return total * sqrt(total);
}

#if defined DISTANT_HORIZONS || defined VOXY
float SpiralAO_DH(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither) {
    float rSteps = 1.0 / float(SSAO_SAMPLES);
    float maxSqLen = sqr(viewPos.z) * 0.25;
    vec2 radius = vec2(0.0);
    vec2 rayStep = vec2(0.6 / aspectRatio, 0.6) / max((far - near) * -viewPos.z / far + near, 5.0) * gbufferProjection[1][1];
    const float goldenAngle = TAU / (PHI1 + 1.0);
    const mat2 goldenRotate = mat2(cos(goldenAngle), -sin(goldenAngle), sin(goldenAngle), cos(goldenAngle));
    vec2 rot = sincos(dither * TAU) * rSteps;
    float total = 0.0;
    for (uint i = 0u; i < SSAO_SAMPLES; ++i, rot *= goldenRotate) {
        radius += rayStep;
        vec3 diff = ScreenToViewSpaceDH(coord + rot * radius) - viewPos;
        float diffSqLen = dotSelf(diff);
        if (diffSqLen > 1e-5 && diffSqLen < maxSqLen) {
            float NdotL = saturate(dot(normal, diff * inversesqrt(diffSqLen)));
            total += NdotL * saturate(1.0 - diffSqLen / maxSqLen);
        }
        diff = ScreenToViewSpaceDH(coord - rot * radius) - viewPos;
        diffSqLen = dotSelf(diff);
        if (diffSqLen > 1e-5 && diffSqLen < maxSqLen) {
            float NdotL = saturate(dot(normal, diff * inversesqrt(diffSqLen)));
            total += NdotL * saturate(1.0 - diffSqLen / maxSqLen);
        }
    }
    total = max0(1.0 - total * rSteps * SSAO_STRENGTH);
    return total * sqrt(total);
}
#endif
#endif

#ifdef UE4_AO_ENABLED
float UE4AO(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither) {
    float rSteps = 1.0 / float(UE4_AO_SAMPLES);
    float maxSqLen = sqr(viewPos.z) * UE4_AO_RADIUS;
    vec2 rayStep = vec2(1.0 / aspectRatio, 1.0) * (UE4_AO_RADIUS / -viewPos.z) * gbufferProjection[1][1];
    float total = 0.0;
    vec2 rot = sincos(dither * TAU);
    const mat2 rotMat = mat2(cos(2.39996), -sin(2.39996), sin(2.39996), cos(2.39996));
    for (uint i = 0u; i < UE4_AO_SAMPLES; ++i) {
        rot *= rotMat;
        vec2 offset = rot * (float(i) + dither) * rSteps * rayStep;
        vec3 samplePos = ScreenToViewSpace(coord + offset);
        vec3 diff = samplePos - viewPos;
        float diffSqLen = dotSelf(diff);
        if (diffSqLen > 1e-4 && diffSqLen < maxSqLen) {
            float NdotL = max0(dot(normal, diff * inversesqrt(diffSqLen)) - 0.1);
            total += NdotL * max0(1.0 - diffSqLen / maxSqLen);
        }
    }
    return saturate(1.0 - (total * rSteps * UE4_AO_INTENSITY * 2.0));
}
#endif

#ifdef DEPTH_AO_ENABLED
float DepthAO(in vec2 coord, float currentDepth) {
    float ao = 0.0;
    vec2 texelSize = 1.0 / screenSize;
    float rSteps = 1.0 / float(DEPTH_AO_SAMPLES);
    for(uint i = 0u; i < DEPTH_AO_SAMPLES; i++) {
        vec2 offset = vec2(cos(float(i)), sin(float(i))) * texelSize * DEPTH_AO_RADIUS;
        float sampleDepth = texelFetch(depthtex0, ivec2((coord + offset) * screenSize), 0).x;
        float depthDiff = currentDepth - sampleDepth;
        if(depthDiff > 1e-6 && depthDiff < 0.001) {
            ao += 1.0;
        }
    }
    return saturate(1.0 - (ao * rSteps * DEPTH_AO_INTENSITY));
}
#endif

#ifdef VANILLA_AO_ENABLED
float VanillaAO(in vec3 normal, in vec3 viewPos) {
    vec3 absN = abs(normal);
    float corner = 1.0 - max(max(absN.x, absN.y), absN.z);
    return saturate(1.0 - corner * VANILLA_AO_INTENSITY);
}
#endif

#ifdef HBAO_ENABLED
float HBAO(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither) {
    float ao = 0.0;
    float rSteps = 1.0 / float(HBAO_SAMPLES);
    vec2 stepSize = vec2(1.0 / aspectRatio, 1.0) * (HBAO_RADIUS / -viewPos.z) * gbufferProjection[1][1];

    float baseAngle = dither * TAU;
    float angleStep = TAU / float(HBAO_SAMPLES);

    for (uint i = 0u; i < HBAO_SAMPLES; i++) {
        float angle = baseAngle + float(i) * angleStep;
        vec2 dir = vec2(cos(angle), sin(angle)) * stepSize;

        vec3 samplePos = ScreenToViewSpace(coord + dir);
        vec3 diff = samplePos - viewPos;
        float distSq = dotSelf(diff);
        if (distSq < sqr(HBAO_RADIUS) && distSq > 1e-4) {
            float NdotV = dot(normal, diff) * inversesqrt(distSq);
            ao += max0(NdotV - 0.1) * max0(1.0 - distSq / sqr(HBAO_RADIUS));
        }
    }
    return saturate(1.0 - ao * rSteps * HBAO_INTENSITY);
}
#endif

#ifdef GTAO_ENABLED
float GTAO(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither) {
    float ao = 0.0;
    float rSteps = 1.0 / float(GTAO_SAMPLES);
    vec2 stepSize = vec2(1.0 / aspectRatio, 1.0) * (GTAO_RADIUS / -viewPos.z) * gbufferProjection[1][1];

    float maxR = 0.12;
    stepSize = min(stepSize, vec2(maxR / aspectRatio, maxR));

    float angleStep = TAU / float(GTAO_SAMPLES);
    float baseAngle = dither * TAU; 

    for (uint i = 0u; i < GTAO_SAMPLES; i++) {

        float angle = baseAngle + float(i) * angleStep;
        vec2 dir = vec2(cos(angle), sin(angle));

        float stepFrac = (float(i) + dither) * rSteps;
        vec2 offset = dir * stepSize * (stepFrac + 0.1);

        vec3 samplePos = ScreenToViewSpace(coord + offset);
        vec3 diff = samplePos - viewPos;
        float distSq = dotSelf(diff);

        if (distSq < sqr(GTAO_RADIUS) && distSq > 1e-5) {
            vec3 vDir = normalize(diff);
            float NdotV = dot(normal, vDir);
         
            ao += max0(NdotV) * max0(1.0 - sqrt(distSq) / GTAO_RADIUS);
        }
    }

    return saturate(1.0 - ao * rSteps * GTAO_INTENSITY * 2.0);
}
#endif

#ifdef VXAO_ENABLED
// ─────────────────────────────────────────────────────────────────────────
//
//
//
#ifdef MCBL_ON

struct DDAState {
	ivec3 voxel;
	ivec3 stepDir;
	vec3  tMax;
	vec3  tDelta;
};

DDAState DDA_Init(vec3 origin, vec3 dir) {
	DDAState s;
	s.voxel = ivec3(floor(origin));

	vec3 invDir = 1.0 / max(abs(dir), vec3(1e-6));
	s.stepDir = ivec3(sign(dir));
	s.tDelta = invDir;

	vec3 voxelBound = vec3(s.voxel) + max(sign(dir), vec3(0.0));
	s.tMax = (voxelBound - origin) * sign(dir) * invDir;

	return s;
}

float DDA_Step(inout DDAState s) {
	float t;
	if (s.tMax.x < s.tMax.y && s.tMax.x < s.tMax.z) {
		t = s.tMax.x;
		s.voxel.x += s.stepDir.x;
		s.tMax.x += s.tDelta.x;
	} else if (s.tMax.y < s.tMax.z) {
		t = s.tMax.y;
		s.voxel.y += s.stepDir.y;
		s.tMax.y += s.tDelta.y;
	} else {
		t = s.tMax.z;
		s.voxel.z += s.stepDir.z;
		s.tMax.z += s.tDelta.z;
	}
	return t;
}

float TraceVoxelAO(vec3 voxelOrigin, vec3 dir, float maxSteps) {
	DDAState s = DDA_Init(voxelOrigin, dir);

	for (float i = 0.0; i < maxSteps; i += 1.0) {
		DDA_Step(s);

		vec3 voxelPos = vec3(s.voxel);
		if (!IsInVoxelMapVolume(voxelPos)) return 0.0;

		uint voxelData = texelFetch(voxeltex, ivec3(voxelPos), 0).r;
		if (voxelData == VOXEL_WALL) {
			return 1.0 - (i / maxSteps);
		}
	}
	return 0.0;
}

float VXAO(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither) {
	float rSteps = 1.0 / float(VXAO_SAMPLES);

	vec3 worldPos = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
	vec3 worldNormal = mat3(gbufferModelViewInverse) * normal;

	vec3 voxelOrigin = WorldToVoxel(worldPos);

	float bounds = GetVoxelMapSoftBounds(voxelOrigin);
	if (bounds <= 0.0) return 1.0;

	voxelOrigin += worldNormal * 0.75;

	vec3 up = abs(worldNormal.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
	vec3 tangent   = normalize(cross(up, worldNormal));
	vec3 bitangent = cross(worldNormal, tangent);

	const float goldenAngle = TAU / (PHI1 + 1.0);
	float fi = dither * TAU;

	float maxSteps = min(float(VXAO_STEPS), VXAO_RADIUS * float(VXAO_SAMPLES));

	float ao = 0.0;
	for (uint i = 0u; i < VXAO_SAMPLES; ++i, fi += goldenAngle) {
		float t = (float(i) + dither) * rSteps;
		float cosTheta = sqrt(1.0 - t);
		float sinTheta = sqrt(t);

		vec3 sampleDir = tangent   * (sinTheta * cos(fi))
		               + bitangent * (sinTheta * sin(fi))
		               + worldNormal * cosTheta;

		ao += TraceVoxelAO(voxelOrigin, sampleDir, maxSteps);
	}

	float result = saturate(1.0 - ao * rSteps * VXAO_INTENSITY);
	return mix(1.0, result, bounds);
}

#else
float VXAO(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither) {
	float ao = 0.0;
	float rSteps = 1.0 / float(VXAO_SAMPLES);
	vec2 stepSize = vec2(1.0 / aspectRatio, 1.0) * (VXAO_RADIUS / -viewPos.z) * gbufferProjection[1][1];

	float angleStep = TAU / float(VXAO_SAMPLES);
	float baseAngle = dither * TAU;

	for (uint i = 0u; i < VXAO_SAMPLES; i++) {
		float angle = baseAngle + float(i) * angleStep;
		vec2 dir = vec2(cos(angle), sin(angle));
		float stepFrac = (float(i) + dither) * rSteps;
		vec2 offset = dir * stepSize * (stepFrac + 0.1);

		vec3 samplePos = ScreenToViewSpace(coord + offset);
		vec3 diff = samplePos - viewPos;
		float distSq = dotSelf(diff);

		if (distSq < sqr(VXAO_RADIUS) && distSq > 1e-5) {
			float NdotV = max0(dot(normal, normalize(diff)));
			ao += NdotV * max0(1.0 - sqrt(distSq) / VXAO_RADIUS);
		}
	}
	return saturate(1.0 - ao * rSteps * VXAO_INTENSITY * 2.0);
}
#endif // MCBL_ON
#endif // VXAO_ENABLED

float CalculateCombinedAO(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither, float depth) {
    float finalAO = 1.0;
    
    #ifdef SSAO_ENABLED
        #if defined DISTANT_HORIZONS || defined VOXY
        if (depth >= 1.0) finalAO *= SpiralAO_DH(coord, viewPos, normal, dither);
        else
        #endif
        finalAO *= SpiralAO(coord, viewPos, normal, dither);
    #endif

    #ifdef UE4_AO_ENABLED
        finalAO *= UE4AO(coord, viewPos, normal, dither);
    #endif

    #ifdef DEPTH_AO_ENABLED
        finalAO *= DepthAO(coord, depth);
    #endif

    #ifdef VANILLA_AO_ENABLED
        finalAO *= VanillaAO(normal, viewPos);
    #endif

    #ifdef HBAO_ENABLED
        finalAO *= HBAO(coord, viewPos, normal, dither);
    #endif

    #ifdef GTAO_ENABLED
        finalAO *= GTAO(coord, viewPos, normal, dither);
    #endif

	    #ifdef VXAO_ENABLED
        finalAO *= VXAO(coord, viewPos, normal, dither);
    #endif

    return finalAO;
}

#endif