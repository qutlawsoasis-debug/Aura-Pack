// ─────────────────────────────────────────────────────────────────────────
// Point-Shadow Voxelize — Compute Pass (shadowcomp1)
//
//
//
// ─────────────────────────────────────────────────────────────────────────

#ifdef CSH

#if MULTICOLORED_BLOCKLIGHT == 1 && POINT_LIGHT_SHADOWS == 1 && POINT_SHADOW_TRACE_MODE == 2

uniform usampler3D voxeltex;
uniform vec3 cameraPosition;

#ifdef MCBL_DITHER_SMOOTHING
	#undef MCBL_DITHER_SMOOTHING
#endif
#define MCBL_DITHER_SMOOTHING 0

#include "/lib/util/voxelMapHelper.glsl"
#include "/lib/util/PointShadowVoxel.glsl"

layout (local_size_x = 4, local_size_y = 4, local_size_z = 4) in;

#if POINT_SHADOW_VOXEL_DISTANCE == 16
	const ivec3 workGroups = ivec3(4, 4, 4);
#elif POINT_SHADOW_VOXEL_DISTANCE == 24
	const ivec3 workGroups = ivec3(6, 6, 6);
#elif POINT_SHADOW_VOXEL_DISTANCE == 32
	const ivec3 workGroups = ivec3(8, 8, 8);
#elif POINT_SHADOW_VOXEL_DISTANCE == 48
	const ivec3 workGroups = ivec3(12, 12, 12);
#elif POINT_SHADOW_VOXEL_DISTANCE == 64
	const ivec3 workGroups = ivec3(16, 16, 16);
#endif

writeonly uniform uimage3D pointshadowvoxelimg;

void main() {
	ivec3 coarseLocalPos = ivec3(gl_GlobalInvocationID);

	ivec3 coarseVoxelPos = coarseLocalPos + ivec3((voxelMapSize - vec3(float(POINT_SHADOW_VOXEL_DISTANCE))) * 0.5);

	uint coarseVoxelData = VOXEL_WALL;
	bool coarseInVolume = IsInVoxelMapVolume(vec3(coarseVoxelPos));
	if (coarseInVolume) {
		coarseVoxelData = texelFetch(voxeltex, coarseVoxelPos, 0).r;
	}

	bool isWall = coarseInVolume && (coarseVoxelData == VOXEL_WALL);
	uint fineValue = isWall ? VOXEL_WALL_FINE : 0u;

	ivec3 fineBase = coarseLocalPos * POINT_SHADOW_VOXEL_SUBDIV;
	for (int dz = 0; dz < POINT_SHADOW_VOXEL_SUBDIV; dz++) {
	for (int dy = 0; dy < POINT_SHADOW_VOXEL_SUBDIV; dy++) {
	for (int dx = 0; dx < POINT_SHADOW_VOXEL_SUBDIV; dx++) {
		ivec3 finePos = fineBase + ivec3(dx, dy, dz);
		imageStore(pointshadowvoxelimg, finePos, uvec4(fineValue, 0u, 0u, 0u));
	}}}
}

#else
	layout (local_size_x = 1, local_size_y = 1, local_size_z = 1) in;
	const ivec3 workGroups = ivec3(1, 1, 1);

	void main() {}
#endif

#endif // CSH
