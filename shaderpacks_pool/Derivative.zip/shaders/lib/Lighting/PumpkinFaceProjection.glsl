// ─────────────────────────────────────────────────────────────────────────
//
//
//
// ─────────────────────────────────────────────────────────────────────────

#ifndef INCLUDE_PUMPKIN_FACE_PROJECTION
#define INCLUDE_PUMPKIN_FACE_PROJECTION

#ifndef PUMPKIN_FACE_PROJECTION
	#define PUMPKIN_FACE_PROJECTION 1
#endif
#ifndef PUMPKIN_FACE_FADE_START
	#define PUMPKIN_FACE_FADE_START 5.0
#endif
#ifndef PUMPKIN_FACE_FADE_END
	#define PUMPKIN_FACE_FADE_END 8.0
#endif
#ifndef PUMPKIN_FACE_BRIGHTNESS
	#define PUMPKIN_FACE_BRIGHTNESS 1.5
#endif
#ifndef PUMPKIN_FACE_BASE_SIZE
	#define PUMPKIN_FACE_BASE_SIZE 0.6
#endif
#ifndef PUMPKIN_FACE_SPREAD
	#define PUMPKIN_FACE_SPREAD 0.55
#endif

bool IsPumpkinMaterial(uint voxelData) {
	return voxelData >= 128u && voxelData <= 131u;
}

void GetPumpkinFacingBasis(uint voxelData, out vec3 faceNormal, out vec3 faceRight, out vec3 faceUp) {
	faceUp = vec3(0.0, 1.0, 0.0);
	if (voxelData == 128u) {
		faceNormal = vec3(0.0, 0.0, -1.0);
		faceRight  = vec3(-1.0, 0.0, 0.0);
	} else if (voxelData == 129u) { // south -> +Z
		faceNormal = vec3(0.0, 0.0, 1.0);
		faceRight  = vec3(1.0, 0.0, 0.0);
	} else if (voxelData == 130u) { // east -> +X
		faceNormal = vec3(1.0, 0.0, 0.0);
		faceRight  = vec3(0.0, 0.0, -1.0);
	} else {                        // west -> -X
		faceNormal = vec3(-1.0, 0.0, 0.0);
		faceRight  = vec3(0.0, 0.0, 1.0);
	}
}

// ─────────────────────────────────────────────────────────────────────────
//
// ─────────────────────────────────────────────────────────────────────────

float BoxMask(vec2 uv, vec2 center, vec2 halfSize) {
	vec2 d = abs(uv - center) - halfSize;
	return step(max(d.x, d.y), 0.0);
}

float EyeMask(vec2 uv, float eyeCenterX) {
	float eye = BoxMask(uv, vec2(eyeCenterX, 0.35), vec2(0.26, 0.22));

	float notchSign = sign(eyeCenterX);
	float notch = BoxMask(uv, vec2(eyeCenterX - notchSign * 0.13, 0.17), vec2(0.13, 0.09));

	return saturate(eye - notch);
}

float MouthMask(vec2 uv) {
	float mouth = BoxMask(uv, vec2(0.0, -0.32), vec2(0.62, 0.16));

	float notches = 0.0;
	for (int i = 0; i < 5; i++) {
		float x = mix(-0.46, 0.46, float(i) / 4.0);
		notches = max(notches, BoxMask(uv, vec2(x, -0.22), vec2(0.05, 0.07)));
	}

	return saturate(mouth - notches);
}

float PumpkinFaceMask(vec2 uv) {
	float leftEye  = EyeMask(uv, -0.34);
	float rightEye = EyeMask(uv,  0.34);
	float mouth    = MouthMask(uv);

	return saturate(leftEye + rightEye + mouth);
}

// ─────────────────────────────────────────────────────────────────────────
//
// ─────────────────────────────────────────────────────────────────────────
vec3 GetPumpkinFaceProjection(vec3 worldPos, vec3 worldNormal, usampler3D voxeltexRef) {
#if PUMPKIN_FACE_PROJECTION == 1
	vec3 voxelPos = WorldToVoxel(worldPos);
	if (!IsInVoxelMapVolume(voxelPos)) return vec3(0.0);

	ivec3 basePos = ivec3(voxelPos);

	const int searchSteps = int(PUMPKIN_FACE_FADE_END) + 1;

	vec3 searchDir = -worldNormal;
	if (dotSelf(searchDir) < 1e-4) return vec3(0.0);

	for (int i = 1; i <= searchSteps; i++) {
		ivec3 samplePos = basePos + ivec3(round(searchDir * float(i)));
		if (!IsInVoxelMapVolume(vec3(samplePos))) break;

		uint voxelData = texelFetch(voxeltexRef, samplePos, 0).r;
		if (!IsPumpkinMaterial(voxelData)) continue;

		vec3 faceNormal, faceRight, faceUp;
		GetPumpkinFacingBasis(voxelData, faceNormal, faceRight, faceUp);

		vec3 pumpkinWorldPos = vec3(samplePos) - fract(cameraPosition) - voxelMapSize * 0.5 + 0.5;

		vec3 toSurface = worldPos - pumpkinWorldPos;
		float travelDist = dot(toSurface, faceNormal);

		if (travelDist <= 0.05) continue;

		if (dot(worldNormal, faceNormal) > -0.15) continue;

		if (travelDist > PUMPKIN_FACE_FADE_END) continue;

		float u = dot(toSurface, faceRight);
		float v = dot(toSurface, faceUp);

		float coneHalfSize = PUMPKIN_FACE_BASE_SIZE + travelDist * PUMPKIN_FACE_SPREAD;
		vec2 uv = vec2(u, v) * rcp(max(coneHalfSize, 1e-3));

		if (maxOf(abs(uv)) > 1.0) continue;

		float mask = PumpkinFaceMask(uv);
		if (mask < 1e-3) continue;

		float fade = 1.0 - smoothstep(PUMPKIN_FACE_FADE_START, PUMPKIN_FACE_FADE_END, travelDist);

		return blocklightColor * mask * fade * PUMPKIN_FACE_BRIGHTNESS;
	}

	return vec3(0.0);
#else
	return vec3(0.0);
#endif
}

#endif // INCLUDE_PUMPKIN_FACE_PROJECTION
