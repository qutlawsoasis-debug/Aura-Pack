// ─────────────────────────────────────────────────────────────────────────
//
//
//
//
// ─────────────────────────────────────────────────────────────────────────

#ifndef INCLUDE_POINT_LIGHT_SHADOWS
#define INCLUDE_POINT_LIGHT_SHADOWS

#ifndef POINT_LIGHT_SHADOWS
	#define POINT_LIGHT_SHADOWS 0 // [0 1]
#endif

#ifndef POINT_SHADOW_TRACE_MODE
	#define POINT_SHADOW_TRACE_MODE 0 // [0 1 2]  0 = Screen-Space, 1 = Voxel DDA, 2 = Subdivided Voxel DDA
#endif

#if POINT_SHADOW_TRACE_MODE == 2
	#include "/lib/util/PointShadowVoxel.glsl"

	uniform usampler3D pointshadowvoxeltex;
#endif

#ifndef POINT_SHADOW_APPLY_MODE
	#define POINT_SHADOW_APPLY_MODE 2 // [1 2]
#endif

#ifndef POINT_SHADOW_MAX_SOURCES
	#define POINT_SHADOW_MAX_SOURCES 1 // [1 2 3 4]
#endif

#ifndef POINT_SHADOW_SEARCH_RADIUS
	#define POINT_SHADOW_SEARCH_RADIUS 6 // [4 6 8 10 12 16 20]
#endif

// Emitter extent jitter.
#ifndef POINT_SHADOW_SOFT_SAMPLES
	#define POINT_SHADOW_SOFT_SAMPLES 2 // [1 2 3 4 6 8]
#endif
#ifndef POINT_SHADOW_JITTER_RADIUS
	#define POINT_SHADOW_JITTER_RADIUS 0.4 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.8 1.0 1.5 2.0]
#endif

#ifndef POINT_SHADOW_INTENSITY
	#define POINT_SHADOW_INTENSITY 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#endif

#ifndef POINT_SHADOW_MAX_DISTANCE
	#define POINT_SHADOW_MAX_DISTANCE 24.0 // [8.0 12.0 16.0 20.0 24.0 32.0 48.0 64.0]
#endif

// ─────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────
vec2 PointShadowDiskSample(int index, int sampleCount, float dither) {
	float angle = (float(index) + dither) * (6.28318530718 / float(sampleCount));
	float radius = sqrt((float(index) + dither) / float(sampleCount));
	return vec2(cos(angle), sin(angle)) * radius;
}

// ─────────────────────────────────────────────────────────────────────────
//
//
// ─────────────────────────────────────────────────────────────────────────
float PointShadowScreenSpace(vec3 viewPos, vec3 lightViewPos, vec3 rayPosScreen, vec3 jitterViewOffset, float dither) {
	vec3 targetViewPos = lightViewPos + jitterViewOffset;

	if (targetViewPos.z >= 0.0) return 1.0;

	vec3 targetScreenPos = ViewToScreenSpace(targetViewPos);

	//
	vec3 startPos = rayPosScreen;
	startPos.xy *= screenSize;

	vec3 endPos = targetScreenPos;
	endPos.xy *= screenSize;

	vec3 rayDir = endPos - startPos;
	float rayDist = length(rayDir.xy);
	if (rayDist < 1e-5) return 1.0;

	if (clamp(endPos.xy, -screenSize * 0.5, screenSize * 1.5) != endPos.xy) return 1.0;

	const int STEPS = 8;
	vec3 rayStep = rayDir * rcp(float(STEPS));

	vec3 rayPos = startPos;

	rayPos += rayStep * (0.5 + dither * 0.5);

	//
	const float DEPTH_TOLERANCE = 0.02;
	const float DEPTH_TOLERANCE_MIN = 0.05;

	for (int i = 0; i < STEPS; i++, rayPos += rayStep) {
		if (clamp(rayPos.xy, vec2(0.0), screenSize) != rayPos.xy) break;
		if (rayPos.z >= 1.0) break;

		float sceneDepth = texelFetch(depthtex0, ivec2(rayPos.xy), 0).x;
		if (sceneDepth < rayPos.z) {
			float sceneLinear = GetDepthLinear(sceneDepth);
			float rayLinear = GetDepthLinear(rayPos.z);

			float tolerance = max(DEPTH_TOLERANCE * rayLinear, DEPTH_TOLERANCE_MIN);
			if (rayLinear - sceneLinear > tolerance) {
				return 0.0;
			}
		}
	}

	return 1.0;
}

// ─────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────
bool PointShadowVoxelRayVisible(usampler3D voxeltexRef, vec3 rayStartVoxel, vec3 rayEndVoxel) {
	vec3 rayDir = rayEndVoxel - rayStartVoxel;
	float rayLength = length(rayDir);
	if (rayLength < 1e-4) return true;
	rayDir /= rayLength;

	ivec3 voxelPos = ivec3(floor(rayStartVoxel));
	ivec3 endVoxelPos = ivec3(floor(rayEndVoxel));

	ivec3 stepDir = ivec3(sign(rayDir));

	vec3 tDelta = vec3(
		abs(rayDir.x) > 1e-6 ? abs(1.0 / rayDir.x) : 1e30,
		abs(rayDir.y) > 1e-6 ? abs(1.0 / rayDir.y) : 1e30,
		abs(rayDir.z) > 1e-6 ? abs(1.0 / rayDir.z) : 1e30
	);

	vec3 voxelBoundary = vec3(voxelPos) + max(vec3(stepDir), vec3(0.0));
	vec3 tMax = vec3(
		stepDir.x != 0 ? (voxelBoundary.x - rayStartVoxel.x) / rayDir.x : 1e30,
		stepDir.y != 0 ? (voxelBoundary.y - rayStartVoxel.y) / rayDir.y : 1e30,
		stepDir.z != 0 ? (voxelBoundary.z - rayStartVoxel.z) / rayDir.z : 1e30
	);

	int maxSteps = int(ceil(rayLength)) * 2 + 4;
	ivec3 volumeMax = ivec3(voxelMapSize);

	for (int i = 0; i < maxSteps; i++) {
		if (voxelPos == endVoxelPos) return true;
		if (any(lessThan(voxelPos, ivec3(0))) || any(greaterThan(voxelPos, volumeMax))) return false;

		if (i > 0) {
			if (texelFetch(voxeltexRef, voxelPos, 0).r == VOXEL_WALL) return false;
		}

		if (tMax.x < tMax.y && tMax.x < tMax.z) {
			voxelPos.x += stepDir.x;
			tMax.x += tDelta.x;
		} else if (tMax.y < tMax.z) {
			voxelPos.y += stepDir.y;
			tMax.y += tDelta.y;
		} else {
			voxelPos.z += stepDir.z;
			tMax.z += tDelta.z;
		}
	}

	return voxelPos == endVoxelPos;
}

// ─────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────
#if POINT_SHADOW_TRACE_MODE == 2
bool PointShadowFineVoxelRayVisible(usampler3D fineVoxeltexRef, vec3 rayStartWorld, vec3 rayEndWorld) {
	vec3 rayStartVoxel = WorldToPointShadowVoxel(rayStartWorld);
	vec3 rayEndVoxel = WorldToPointShadowVoxel(rayEndWorld);

	vec3 rayDir = rayEndVoxel - rayStartVoxel;
	float rayLength = length(rayDir);
	if (rayLength < 1e-4) return true;
	rayDir /= rayLength;

	ivec3 voxelPos = ivec3(floor(rayStartVoxel));
	ivec3 endVoxelPos = ivec3(floor(rayEndVoxel));

	ivec3 stepDir = ivec3(sign(rayDir));

	vec3 tDelta = vec3(
		abs(rayDir.x) > 1e-6 ? abs(1.0 / rayDir.x) : 1e30,
		abs(rayDir.y) > 1e-6 ? abs(1.0 / rayDir.y) : 1e30,
		abs(rayDir.z) > 1e-6 ? abs(1.0 / rayDir.z) : 1e30
	);

	vec3 voxelBoundary = vec3(voxelPos) + max(vec3(stepDir), vec3(0.0));
	vec3 tMax = vec3(
		stepDir.x != 0 ? (voxelBoundary.x - rayStartVoxel.x) / rayDir.x : 1e30,
		stepDir.y != 0 ? (voxelBoundary.y - rayStartVoxel.y) / rayDir.y : 1e30,
		stepDir.z != 0 ? (voxelBoundary.z - rayStartVoxel.z) / rayDir.z : 1e30
	);

	int maxSteps = int(ceil(rayLength)) * 2 + 4;
	ivec3 volumeMax = ivec3(pointShadowVoxelMapSize);

	for (int i = 0; i < maxSteps; i++) {
		if (voxelPos == endVoxelPos) return true;
		if (any(lessThan(voxelPos, ivec3(0))) || any(greaterThan(voxelPos, volumeMax))) return false;

		if (i > 0) {
			if (texelFetch(fineVoxeltexRef, voxelPos, 0).r == VOXEL_WALL_FINE) return false;
		}

		if (tMax.x < tMax.y && tMax.x < tMax.z) {
			voxelPos.x += stepDir.x;
			tMax.x += tDelta.x;
		} else if (tMax.y < tMax.z) {
			voxelPos.y += stepDir.y;
			tMax.y += tDelta.y;
		} else {
			voxelPos.z += stepDir.z;
			tMax.z += tDelta.z;
		}
	}

	return voxelPos == endVoxelPos;
}
#endif

// ─────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────
int FindNearestLightSources(usampler3D voxeltexRef, ivec3 basePos, int searchRadius,
							 out ivec3 outLightPos[POINT_SHADOW_MAX_SOURCES],
							 out float outDistSq[POINT_SHADOW_MAX_SOURCES]) {
	int found = 0;
	for (int k = 0; k < POINT_SHADOW_MAX_SOURCES; k++) outDistSq[k] = 1e30;

	for (int shell = 0; shell <= searchRadius; shell++) {
		for (int dz = -shell; dz <= shell; dz++) {
		for (int dy = -shell; dy <= shell; dy++) {
			bool onShellEdge = (shell == 0) || (abs(dz) == shell || abs(dy) == shell);
			for (int dx = -shell; dx <= shell; dx++) {
				if (shell > 0 && !onShellEdge && abs(dx) != shell) continue;

				ivec3 samplePos = basePos + ivec3(dx, dy, dz);
				if (!IsInVoxelMapVolume(vec3(samplePos))) continue;

				uint voxelData = texelFetch(voxeltexRef, samplePos, 0).r;
				if (voxelData == 0u || voxelData == VOXEL_WALL) continue;

				vec3 emission = GetVoxelEmission(int(voxelData));
				if (emission == vec3(0.0)) continue;

				float distSq = float(dx * dx + dy * dy + dz * dz);

				int worstIdx = 0;
				float worstDist = outDistSq[0];
				for (int k = 1; k < POINT_SHADOW_MAX_SOURCES; k++) {
					if (outDistSq[k] > worstDist) { worstDist = outDistSq[k]; worstIdx = k; }
				}

				if (distSq < worstDist) {
					outDistSq[worstIdx] = distSq;
					outLightPos[worstIdx] = samplePos;
					found = min(found + 1, POINT_SHADOW_MAX_SOURCES);
				}
			}
		}}

		if (found >= POINT_SHADOW_MAX_SOURCES) {
			float maxDist = 0.0;
			for (int k = 0; k < POINT_SHADOW_MAX_SOURCES; k++) maxDist = max(maxDist, outDistSq[k]);
			if (maxDist <= float(shell * shell)) break;
		}
	}

	return found;
}

// ─────────────────────────────────────────────────────────────────────────
//
// ─────────────────────────────────────────────────────────────────────────
float GetPointLightShadowMask(vec3 worldPos, vec3 viewPos, vec3 worldNormal, usampler3D voxeltexRef, float dither) {
#if POINT_LIGHT_SHADOWS == 1
	#if POINT_SHADOW_MAX_DISTANCE > 0.0
		float pixelDistance = length(worldPos);
		if (pixelDistance > POINT_SHADOW_MAX_DISTANCE) return 1.0;
		float distanceFade = 1.0 - smoothstep(POINT_SHADOW_MAX_DISTANCE * 0.75, POINT_SHADOW_MAX_DISTANCE, pixelDistance);
		if (distanceFade < 1e-4) return 1.0;
	#else
		float distanceFade = 1.0;
	#endif

	vec3 voxelPosF = WorldToVoxel(worldPos);
	if (!IsInVoxelMapVolume(voxelPosF)) return 1.0;

	ivec3 basePos = ivec3(floor(voxelPosF));

#if POINT_SHADOW_TRACE_MODE == 1 || POINT_SHADOW_TRACE_MODE == 2
	const int effectiveSearchRadius = POINT_SHADOW_SEARCH_RADIUS;
#else
	const int effectiveSearchRadius = min(POINT_SHADOW_SEARCH_RADIUS, 3);
#endif

	ivec3 lightPos[POINT_SHADOW_MAX_SOURCES];
	float lightDistSq[POINT_SHADOW_MAX_SOURCES];
	int lightCount = FindNearestLightSources(voxeltexRef, basePos, effectiveSearchRadius, lightPos, lightDistSq);

	if (lightCount == 0) return 1.0;

	vec3 rayStartWorld = worldPos + worldNormal * 0.6;

	#if POINT_SHADOW_TRACE_MODE == 0
		vec3 rayStartScreenPos = ViewToScreenSpace(viewPos);
	#endif

	float totalShadow = 0.0;
	float totalWeight = 0.0;

	for (int i = 0; i < lightCount; i++) {
		float distToLight = sqrt(lightDistSq[i]);
		float weight = 1.0 / (1.0 + lightDistSq[i]);
		totalWeight += weight;

		vec3 sourceWorldCenter = vec3(lightPos[i]) - fract(cameraPosition) - voxelMapSize * 0.5 + 0.5;

		float visibility = 0.0;

		vec3 toLightDir = normalize(sourceWorldCenter - rayStartWorld);
		vec3 jitterUp = abs(toLightDir.y) < 0.999 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
		vec3 jitterTangent = normalize(cross(jitterUp, toLightDir));
		vec3 jitterBitangent = cross(toLightDir, jitterTangent);

		for (int s = 0; s < POINT_SHADOW_SOFT_SAMPLES; s++) {
			vec2 diskOffset = PointShadowDiskSample(s, POINT_SHADOW_SOFT_SAMPLES, dither) * POINT_SHADOW_JITTER_RADIUS;
			vec3 jitterWorld = jitterTangent * diskOffset.x + jitterBitangent * diskOffset.y;

			#if POINT_SHADOW_TRACE_MODE == 1
				vec3 targetWorld = sourceWorldCenter + jitterWorld;
				vec3 rayStartVoxel = WorldToVoxel(rayStartWorld);
				vec3 rayEndVoxel = WorldToVoxel(targetWorld);

				if (PointShadowVoxelRayVisible(voxeltexRef, rayStartVoxel, rayEndVoxel)) {
					visibility += 1.0;
				}
			#elif POINT_SHADOW_TRACE_MODE == 2
				vec3 targetWorldFine = sourceWorldCenter + jitterWorld;
				vec3 fineStartVoxel = WorldToPointShadowVoxel(rayStartWorld);
				vec3 fineEndVoxel = WorldToPointShadowVoxel(targetWorldFine);

				if (IsInPointShadowVoxelVolume(fineStartVoxel) && IsInPointShadowVoxelVolume(fineEndVoxel)) {
					if (PointShadowFineVoxelRayVisible(pointshadowvoxeltex, rayStartWorld, targetWorldFine)) {
						visibility += 1.0;
					}
				} else {
					vec3 rayStartVoxelCoarse = WorldToVoxel(rayStartWorld);
					vec3 rayEndVoxelCoarse = WorldToVoxel(targetWorldFine);
					if (PointShadowVoxelRayVisible(voxeltexRef, rayStartVoxelCoarse, rayEndVoxelCoarse)) {
						visibility += 1.0;
					}
				}
			#else
				vec3 lightViewPos = mat3(gbufferModelView) * (sourceWorldCenter - worldPos) + viewPos;
				vec3 jitterViewOffset = mat3(gbufferModelView) * jitterWorld;

				visibility += PointShadowScreenSpace(viewPos, lightViewPos, rayStartScreenPos, jitterViewOffset, dither);
			#endif
		}

		visibility /= float(POINT_SHADOW_SOFT_SAMPLES);
		totalShadow += visibility * weight;
	}

	if (totalWeight < 1e-6) return 1.0;

	float shadowMask = totalShadow / totalWeight;

	shadowMask = mix(1.0, shadowMask, distanceFade);

	shadowMask = clamp(shadowMask, 0.0, 1.0);

	return mix(1.0, shadowMask, POINT_SHADOW_INTENSITY);
#else
	return 1.0;
#endif
}

#endif // INCLUDE_POINT_LIGHT_SHADOWS 
