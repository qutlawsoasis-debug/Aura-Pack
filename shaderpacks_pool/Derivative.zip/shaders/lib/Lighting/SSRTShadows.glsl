// ═══════════════════════════════════════════════════════════════════════
// SSRT Shadows — Screen-Space Ray Traced Point-Light Shadows
//
//
//
// ═══════════════════════════════════════════════════════════════════════

#ifndef INCLUDE_SSRT_SHADOWS
#define INCLUDE_SSRT_SHADOWS

// ─── Source detection ────────────────────────────────────────────────────
#ifndef SSRT_SOURCE_THRESHOLD
	#define SSRT_SOURCE_THRESHOLD 0.72 // [0.4 0.5 0.6 0.65 0.7 0.72 0.75 0.8 0.85 0.9]
#endif

#ifndef SSRT_SEARCH_RADIUS
	#define SSRT_SEARCH_RADIUS 24
#endif

#ifndef SSRT_SEARCH_STEP
	#define SSRT_SEARCH_STEP 3 // [1 2 3 4 5 6]
#endif

#ifndef SSRT_MAX_DISTANCE
	#define SSRT_MAX_DISTANCE 20.0
#endif

// ─── Trace ────────────────────────────────────────────────────────────────
#ifndef SHADOW_SS_STEPS
	#define SHADOW_SS_STEPS 16
#endif
#ifndef SHADOW_SS_SEARCH_RADIUS
	#define SHADOW_SS_SEARCH_RADIUS 24
#endif
#ifndef SHADOW_SS_THICKNESS
	#define SHADOW_SS_THICKNESS 0.5
#endif

#ifndef SSRT_REFINE_STEPS
	#define SSRT_REFINE_STEPS 5
#endif

#ifndef SSRT_STRENGTH
	#define SSRT_STRENGTH 1.0 // [0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.5 2.0 3.0]
#endif

// ─── Temporal accumulation ─────────────────────────────────────────────────
#ifndef SHADOW_TEMPORAL_BLEND
	#define SHADOW_TEMPORAL_BLEND 0.92
#endif

#ifndef SSRT_MAX_HISTORY_FRAMES
	#define SSRT_MAX_HISTORY_FRAMES 32.0
#endif

#ifndef SSRT_DISOCCLUSION_DEPTH_TOLERANCE
	#define SSRT_DISOCCLUSION_DEPTH_TOLERANCE 0.1
#endif

#ifndef SSRT_DISOCCLUSION_NORMAL_THRESHOLD
	#define SSRT_DISOCCLUSION_NORMAL_THRESHOLD 0.5
#endif

#ifndef SSRT_VARIANCE_CLIP_GAMMA
	#define SSRT_VARIANCE_CLIP_GAMMA 1.25
#endif

#ifndef SSRT_SPATIAL_SAMPLES
	#define SSRT_SPATIAL_SAMPLES 8 // [4 6 8 12 16]
#endif

#ifndef SSRT_SPATIAL_RADIUS
	#define SSRT_SPATIAL_RADIUS 3.0
#endif

// ─────────────────────────────────────────────────────────────────────────
// SOURCE DETECTION
// ─────────────────────────────────────────────────────────────────────────
bool SSRT_FindBrightestSource(ivec2 centerTexel, out ivec2 bestTexel, out float bestBrightness) {
	bestTexel = ivec2(-1);
	bestBrightness = SSRT_SOURCE_THRESHOLD;
	bool found = false;

	const int R = SSRT_SEARCH_RADIUS;
	const int STEP = SSRT_SEARCH_STEP;

	for (int dy = -R; dy <= R; dy += STEP) {
		for (int dx = -R; dx <= R; dx += STEP) {
			ivec2 sampleTexel = centerTexel + ivec2(dx, dy);
			if (clamp(sampleTexel, ivec2(0), ivec2(screenSize) - 1) != sampleTexel) continue;

			float brightness = texelFetch(colortex7, sampleTexel, 0).x;
			if (brightness > bestBrightness) {
				bestBrightness = brightness;
				bestTexel = sampleTexel;
				found = true;
			}
		}
	}

	return found;
}

// ─────────────────────────────────────────────────────────────────────────
//
//
// ─────────────────────────────────────────────────────────────────────────
float SSRT_TraceVisibility(vec3 viewPos, vec3 viewSourcePos, float dither) {
	vec3 toSource = viewSourcePos - viewPos;
	float rayLength = length(toSource);
	if (rayLength < 1e-4) return 1.0;

	vec3 rayDir = toSource / rayLength;
	float stepSize = rayLength / float(SHADOW_SS_STEPS);

	float prevTravelled = 0.0;
	float travelled = stepSize * (0.5 + dither);

	bool hit = false;
	float hitLo = 0.0;
	float hitHi = 0.0;

	for (int i = 0; i < SHADOW_SS_STEPS; i++) {
		if (travelled >= rayLength) break;

		vec3 currentViewPos = viewPos + rayDir * travelled;
		vec3 sScreen = ViewToScreenSpace(currentViewPos);

		// screen-space fallback).
		if (clamp(sScreen.xy, 0.0, 1.0) != sScreen.xy || sScreen.z > 1.0) return 1.0;

		float sceneDepth = texelFetch(depthtex1, ivec2(sScreen.xy * screenSize), 0).x;

		if (sceneDepth < 1.0) {
			vec3 sceneViewPos = ScreenToViewSpace(vec3(sScreen.xy, sceneDepth));
			float thickness = currentViewPos.z - sceneViewPos.z;

			if (thickness > 0.0 && thickness < SHADOW_SS_THICKNESS) {
				hit = true;
				hitLo = prevTravelled;
				hitHi = travelled;
				break;
			}
		}

		prevTravelled = travelled;
		travelled += stepSize;
	}

	if (!hit) return 1.0;

	for (int i = 0; i < SSRT_REFINE_STEPS; i++) {
		float mid = (hitLo + hitHi) * 0.5;
		vec3 midViewPos = viewPos + rayDir * mid;
		vec3 sScreen = ViewToScreenSpace(midViewPos);

		if (clamp(sScreen.xy, 0.0, 1.0) != sScreen.xy || sScreen.z > 1.0) {
			hitHi = mid;
			continue;
		}

		float sceneDepth = texelFetch(depthtex1, ivec2(sScreen.xy * screenSize), 0).x;
		if (sceneDepth >= 1.0) {
			hitLo = mid;
			continue;
		}

		vec3 sceneViewPos = ScreenToViewSpace(vec3(sScreen.xy, sceneDepth));
		float thickness = midViewPos.z - sceneViewPos.z;

		if (thickness > 0.0) {
			hitHi = mid;
		} else {
			hitLo = mid;
		}
	}

	return 0.0;
}

// ─────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────
vec4 SSRT_Trace(vec3 viewPos, vec3 viewNormal, ivec2 screenTexel, float dither) {
	ivec2 bestTexel;
	float bestBrightness;
	bool foundSource = SSRT_FindBrightestSource(screenTexel, bestTexel, bestBrightness);
	if (!foundSource) return vec4(0.0);

	float sourceDepth = texelFetch(depthtex1, bestTexel, 0).x;
	if (sourceDepth >= 1.0) return vec4(0.0);

	vec2 sourceUV = (vec2(bestTexel) + 0.5) / screenSize;
	vec3 viewSourcePos = ScreenToViewSpace(vec3(sourceUV, sourceDepth));

	float distToSource = distance(viewPos, viewSourcePos);
	if (distToSource > SSRT_MAX_DISTANCE) return vec4(0.0);

	vec3 toSource = (viewSourcePos - viewPos) / max(distToSource, 1e-4);
	float NdotL = max(dot(viewNormal, toSource), 0.0);
	if (NdotL < 1e-4) return vec4(0.0);

	vec3 rayStartViewPos = viewPos + viewNormal * 0.05;
	float visibility = SSRT_TraceVisibility(rayStartViewPos, viewSourcePos, dither);

	vec3 sourceAlbedo = texelFetch(colortex6, bestTexel, 0).rgb;
	float falloff = 1.0 / (1.0 + distToSource * distToSource * 0.1);

	vec3 result = sourceAlbedo * bestBrightness * falloff * NdotL * visibility * SSRT_STRENGTH;
	return vec4(result, 1.0);
}

// ─────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────
const ivec2 ssrtCheckerOffset[4] = ivec2[4](
	ivec2(0, 0), ivec2(1, 0), ivec2(0, 1), ivec2(1, 1)
);

vec4 SSRT_Trace_Dispatch(vec3 viewPos, vec3 viewNormal, ivec2 screenTexel, float dither) {
	ivec2 activeOffset = ssrtCheckerOffset[frameCounter % 4];
	if ((screenTexel & 1) != activeOffset) {
		vec4 held = imageLoad(shadowhistoryimg, screenTexel);
		return held;
	}

	return SSRT_Trace(viewPos, viewNormal, screenTexel, dither);
}

// ─────────────────────────────────────────────────────────────────────────
// ACCUMULATE — spatiotemporal denoise.
//
//
// ─────────────────────────────────────────────────────────────────────────
vec3 SSRT_Accumulate(vec4 currTrace, vec3 viewPos, vec3 viewNormal, float depth, ivec2 screenTexel, vec2 screenCoord, float dither) {

	vec3 prevScreen = Reproject(vec3(screenCoord, depth));
	vec2 prevCoord = prevScreen.xy * 0.5 + 0.5;

	bool validReprojection = clamp(prevCoord, screenPixelSize, 1.0 - screenPixelSize) == prevCoord && !worldTimeChanged;

	vec4 history = vec4(0.0);
	float disocclusionWeight = 0.0;

	if (validReprojection) {
		ivec2 prevTexel = ivec2(prevCoord * screenSize);
		history = imageLoad(shadowhistoryimg, prevTexel);

		float currDist = length(viewPos);
		float cameraMovement = distance(cameraPosition, previousCameraPosition);
		float movementGate = step(cameraMovement, currDist * SSRT_DISOCCLUSION_DEPTH_TOLERANCE + 0.5);
		disocclusionWeight = movementGate;
	}

	float historyCount = validReprojection ? history.a : 0.0;
	historyCount = min(historyCount * disocclusionWeight, SSRT_MAX_HISTORY_FRAMES);

	vec3 currColor = currTrace.rgb;

	float currLum = dot(currColor, vec3(0.2126, 0.7152, 0.0722));
	float histLum = dot(history.rgb, vec3(0.2126, 0.7152, 0.0722));
	float lumTolerance = max(currLum, histLum) * SSRT_VARIANCE_CLIP_GAMMA + 0.05;
	if (abs(currLum - histLum) > lumTolerance) {
		historyCount = 0.0;
	}

	float blendWeight = historyCount > 0.5 ? (SHADOW_TEMPORAL_BLEND * min(historyCount / 8.0, 1.0)) : 0.0;
	vec3 blended = mix(currColor, history.rgb, blendWeight);

	float newHistoryCount = min(historyCount + 1.0, SSRT_MAX_HISTORY_FRAMES);

	float fadeToSpatial = 1.0 - saturate(newHistoryCount / 6.0);
	vec3 finalColor = blended;

	if (fadeToSpatial > 1e-3) {
		vec3 spatialSum = blended;
		float spatialWeightSum = 1.0;

		float goldenAngle = 2.39996323;
		for (int i = 0; i < SSRT_SPATIAL_SAMPLES; i++) {
			float angle = float(i) * goldenAngle + dither * 6.28318;
			float radius = SSRT_SPATIAL_RADIUS * sqrt((float(i) + 0.5) / float(SSRT_SPATIAL_SAMPLES));
			vec2 offset = vec2(cos(angle), sin(angle)) * radius;

			ivec2 sampleTexel = screenTexel + ivec2(offset);
			if (clamp(sampleTexel, ivec2(0), ivec2(screenSize) - 1) != sampleTexel) continue;

			float sampleDepthRaw = texelFetch(depthtex1, sampleTexel, 0).x;
			if (sampleDepthRaw >= 1.0) continue;

			vec3 sampleViewPos = ScreenToViewSpace(vec3((vec2(sampleTexel) + 0.5) / screenSize, sampleDepthRaw));
			float depthDiff = abs(length(sampleViewPos) - length(viewPos));
			float depthWeight = exp(-depthDiff * depthDiff * 0.5);
			if (depthWeight < 0.05) continue;

			vec4 sampleTrace = imageLoad(shadowhistoryimg, sampleTexel);
			spatialSum += sampleTrace.rgb * depthWeight;
			spatialWeightSum += depthWeight;
		}

		vec3 spatialResult = spatialSum / max(spatialWeightSum, 1e-4);
		finalColor = mix(finalColor, spatialResult, fadeToSpatial);
	}

	if (any(isnan(finalColor)) || any(isinf(finalColor))) {
		finalColor = vec3(0.0);
		newHistoryCount = 0.0;
	}

	imageStore(shadowhistoryimg, screenTexel, vec4(finalColor, newHistoryCount));

	return finalColor;
}

// ─────────────────────────────────────────────────────────────────────────
//
// ─────────────────────────────────────────────────────────────────────────
vec3 SSRT_Calculate(vec3 worldPos, vec3 worldNormal, vec3 viewPos, vec3 viewNormal, float depth, ivec2 screenTexel, vec2 screenCoordSigned, float dither) {
	vec4 trace = SSRT_Trace_Dispatch(viewPos, viewNormal, screenTexel, dither);
	return SSRT_Accumulate(trace, viewPos, viewNormal, depth, screenTexel, screenCoordSigned, dither);
}

// ─────────────────────────────────────────────────────────────────────────
//
//   #elif SHADOW_STYLE == 5
//
//
//   #elif SHADOW_STYLE == 5
//       vec3 ssrtShadow = SSRT_Calculate(worldPos, worldNormal, viewPos,
//           mat3(gbufferModelView) * worldNormal, depth, texel,
//           screenCoord * 2.0 - 1.0, dither);
//       sceneData += ssrtShadow * ao;
//
// ─────────────────────────────────────────────────────────────────────────

#endif // INCLUDE_SSRT_SHADOWS
