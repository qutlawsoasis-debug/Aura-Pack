// ─────────────────────────────────────────────────────────────────────────
// Flood-Fill Voxel Blocklight — Compute Pass
//
//
//
// MCBL_LIGHTMAP_MODE:
// ─────────────────────────────────────────────────────────────────────────

#ifdef CSH

// WATER_TRAIL/shadowcomp_a.csh).
#if MULTICOLORED_BLOCKLIGHT == 1

layout (local_size_x = 8, local_size_y = 8, local_size_z = 8) in;

#if MCBL_DISTANCE == 128
	const ivec3 workGroups = ivec3(16, 16, 16);
#elif MCBL_DISTANCE == 192
	const ivec3 workGroups = ivec3(24, 24, 24);
#elif MCBL_DISTANCE == 256
	const ivec3 workGroups = ivec3(32, 32, 32);
#elif MCBL_DISTANCE == 384
	const ivec3 workGroups = ivec3(48, 48, 48);
#elif MCBL_DISTANCE == 512
	const ivec3 workGroups = ivec3(64, 64, 64);
#endif

#ifndef MCBL_LIGHTMAP_MODE
	#define MCBL_LIGHTMAP_MODE 0 // [0 1 2]
#endif

#define GLASS_PROPAGATION_INTENSITY 2.5 // [1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0]

// ─────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────

#ifndef MCBL_SMOOTHING
	#define MCBL_SMOOTHING 0.6 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#endif

#ifndef MCBL_FLOODFILL_RANGE
	#define MCBL_FLOODFILL_RANGE 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0]
#endif

#ifndef MCBL_MAX_SOURCES
	#define MCBL_MAX_SOURCES 0 // [0 8 16 32 64 128 256 512]
#endif

float HashVoxelPos(ivec3 p) {
	uint h = uint(p.x) * 374761393u + uint(p.y) * 668265263u + uint(p.z) * 2246822519u;
	h = (h ^ (h >> 13u)) * 1274126177u;
	h = h ^ (h >> 16u);
	return float(h) * (1.0 / 4294967296.0);
}

//Uniforms//
uniform int frameCounter;

uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;

uniform usampler3D voxeltex;
uniform sampler3D lighttex0;
uniform sampler3D lighttex1;

writeonly uniform image3D lightimg0;
writeonly uniform image3D lightimg1;

//Includes//
#include "/lib/util/voxelMapHelper.glsl"
#include "/lib/color/blocklightColor.glsl"

//Functions//

//
//
const ivec3 AXIS_OFFSETS[6] = ivec3[6](
	ivec3( 1, 0, 0), ivec3(-1, 0, 0),
	ivec3( 0, 1, 0), ivec3( 0,-1, 0),
	ivec3( 0, 0, 1), ivec3( 0, 0,-1)
);

#if MCBL_LIGHTMAP_MODE == 2
const ivec3 DIAGONAL_OFFSETS[20] = ivec3[20](
	ivec3( 1, 1, 0), ivec3( 1,-1, 0), ivec3(-1, 1, 0), ivec3(-1,-1, 0),
	ivec3( 1, 0, 1), ivec3( 1, 0,-1), ivec3(-1, 0, 1), ivec3(-1, 0,-1),
	ivec3( 0, 1, 1), ivec3( 0, 1,-1), ivec3( 0,-1, 1), ivec3( 0,-1,-1),
	ivec3( 1, 1, 1), ivec3( 1, 1,-1), ivec3( 1,-1, 1), ivec3( 1,-1,-1),
	ivec3(-1, 1, 1), ivec3(-1, 1,-1), ivec3(-1,-1, 1), ivec3(-1,-1,-1)
);

bool IsDiagonalUnobstructed(usampler3D voxeltexRef, ivec3 posCurrent, ivec3 offset) {
	bool anyOpen = false;
	if (offset.x != 0) {
		ivec3 p = posCurrent + ivec3(offset.x, 0, 0);
		if (IsInVoxelMapVolume(vec3(p)) && texelFetch(voxeltexRef, p, 0).r != VOXEL_WALL) anyOpen = true;
	}
	if (offset.y != 0) {
		ivec3 p = posCurrent + ivec3(0, offset.y, 0);
		if (IsInVoxelMapVolume(vec3(p)) && texelFetch(voxeltexRef, p, 0).r != VOXEL_WALL) anyOpen = true;
	}
	if (offset.z != 0) {
		ivec3 p = posCurrent + ivec3(0, 0, offset.z);
		if (IsInVoxelMapVolume(vec3(p)) && texelFetch(voxeltexRef, p, 0).r != VOXEL_WALL) anyOpen = true;
	}
	return anyOpen;
}
#endif

vec4 GetLightFromNeighbors(sampler3D lighttex, usampler3D voxeltexRef, ivec3 pos, ivec3 prevPos) {
	vec3 rgbSum = vec3(0.0);
	float validCount = 0.0;

	float maxRange = 0.0;
	bool hasRange = false;

	for (int i = 0; i < 6; i++) {
		ivec3 neighborPosCurrent = pos + AXIS_OFFSETS[i];
		ivec3 neighborPosPrev = prevPos + AXIS_OFFSETS[i];

		if (!IsInVoxelMapVolume(vec3(neighborPosCurrent))) continue;
		if (texelFetch(voxeltexRef, neighborPosCurrent, 0).r == VOXEL_WALL) continue;

		if (!IsInVoxelMapVolume(vec3(neighborPosPrev))) continue;

		vec4 n = texelFetch(lighttex, neighborPosPrev, 0);
		rgbSum += n.rgb;
		validCount += 1.0;

#if MCBL_LIGHTMAP_MODE == 1 || MCBL_LIGHTMAP_MODE == 2
		maxRange = hasRange ? max(maxRange, n.a) : n.a;
		hasRange = true;
#endif
	}

#if MCBL_LIGHTMAP_MODE == 2
	if (MCBL_SMOOTHING > 0.0) {
		for (int i = 0; i < 20; i++) {
			ivec3 offset = DIAGONAL_OFFSETS[i];
			ivec3 neighborPosCurrent = pos + offset;
			ivec3 neighborPosPrev = prevPos + offset;

			if (!IsInVoxelMapVolume(vec3(neighborPosCurrent))) continue;
			if (texelFetch(voxeltexRef, neighborPosCurrent, 0).r == VOXEL_WALL) continue;

			if (!IsDiagonalUnobstructed(voxeltexRef, pos, offset)) continue;

			if (!IsInVoxelMapVolume(vec3(neighborPosPrev))) continue;

			vec4 n = texelFetch(lighttex, neighborPosPrev, 0);
			rgbSum += n.rgb * MCBL_SMOOTHING;
			validCount += MCBL_SMOOTHING;

			maxRange = hasRange ? max(maxRange, n.a) : n.a;
			hasRange = true;
		}
	}
#endif

	vec3 rgb = (validCount > 0.5) ? rgbSum * rcp(validCount) : vec3(0.0);

#if MCBL_LIGHTMAP_MODE == 1
	maxRange -= 1.0;

	rgb *= step(0.0, maxRange);
	return vec4(rgb, max(maxRange, 0.0));
#elif MCBL_LIGHTMAP_MODE == 2
	maxRange -= 1.0;

	rgb *= step(0.0, maxRange);
	return vec4(rgb, max(maxRange, 0.0));
#else
	rgb *= 0.75;
	return vec4(rgb, 0.0);
#endif
}

//Program//
//Program//
void main() {
	int iFrameMod2 = int(frameCounter) % 2;

	ivec3 pos = ivec3(gl_GlobalInvocationID);
	uint voxelData = texelFetch(voxeltex, pos, 0).r;

	bool isWall = (voxelData == VOXEL_WALL);

	int materialID = int(voxelData);

	bool isGlass = (materialID >= 70 && materialID <= 85) || (materialID >= 101 && materialID <= 116);

	ivec3 prevPos = pos + ivec3(floor(cameraPosition) - floor(previousCameraPosition));

	vec4 light = vec4(0.0);

	if (isGlass) {
		ivec3 offsets[6] = ivec3[6](
			ivec3( 1, 0, 0), ivec3(-1, 0, 0),
			ivec3( 0, 1, 0), ivec3( 0,-1, 0),
			ivec3( 0, 0, 1), ivec3( 0, 0,-1)
		);

		bool hasNearbyLight = false;
		for (int i = 0; i < 6; i++) {
			ivec3 neighborPos = pos + offsets[i];
			if (!IsInVoxelMapVolume(vec3(neighborPos))) continue;

			uint neighborVoxel = texelFetch(voxeltex, neighborPos, 0).r;
			if (neighborVoxel == VOXEL_WALL) continue;

			int neighborMaterialID = int(neighborVoxel);

			bool neighborIsGlass = (neighborMaterialID >= 70 && neighborMaterialID <= 85)
				|| (neighborMaterialID >= 101 && neighborMaterialID <= 116);
			if (neighborIsGlass) continue;

			vec3 neighborEmission = IsDroppedItemVoxel(neighborMaterialID) ? 
									GetDroppedItemVoxelEmission(neighborMaterialID) : 
									GetVoxelEmission(neighborMaterialID);

			if (neighborEmission != vec3(0.0)) {
				hasNearbyLight = true;
				break;
			}
		}

		bool sourceAllowed = true;
#if MCBL_MAX_SOURCES > 0
		sourceAllowed = HashVoxelPos(pos) < (float(MCBL_MAX_SOURCES) / 4096.0);
#endif

		vec3 emission = (hasNearbyLight && sourceAllowed) ? (GetVoxelEmission(materialID) * GLASS_PROPAGATION_INTENSITY) : vec3(0.0);

		float startRange = (hasNearbyLight && sourceAllowed) ? (GetVoxelRange(materialID) * MCBL_FLOODFILL_RANGE) : 0.0;

		vec4 result = vec4(emission, startRange);

		if (any(isnan(result.rgb)) || isnan(result.a) || any(isinf(result.rgb)) || isinf(result.a)) {
			result = vec4(0.0);
		}
		result.rgb = clamp(result.rgb, vec3(0.0), vec3(1e3));
		result.a = clamp(result.a, 0.0, 15.0 * MCBL_FLOODFILL_RANGE);

		if (iFrameMod2 == 0) {
			imageStore(lightimg0, pos, result);
		} else {
			imageStore(lightimg1, pos, result);
		}
		return;
	}

	vec3 emission = vec3(0.0);
	if (!isWall) {
		emission = IsDroppedItemVoxel(materialID) ? 
				   GetDroppedItemVoxelEmission(materialID) : 
				   GetVoxelEmission(materialID);
	}

	if (!isWall && emission == vec3(0.0)) {
		if (iFrameMod2 == 0) {
			light = GetLightFromNeighbors(lighttex1, voxeltex, pos, prevPos);
		} else {
			light = GetLightFromNeighbors(lighttex0, voxeltex, pos, prevPos);
		}
	}

	bool sourceAllowed = true;
#if MCBL_MAX_SOURCES > 0
	sourceAllowed = HashVoxelPos(pos) < (float(MCBL_MAX_SOURCES) / 4096.0);
#endif

	float startRange = light.a;
	vec3 sourceEmission = emission;
	if (emission != vec3(0.0)) {
		if (sourceAllowed) {
			startRange = (IsDroppedItemVoxel(materialID) ? 
						 GetDroppedItemVoxelRange(materialID) : 
						 GetVoxelRange(materialID)) * MCBL_FLOODFILL_RANGE;
		} else {
			startRange = 0.0;
			sourceEmission = vec3(0.0);
		}
	}

	vec4 result = vec4(sourceEmission + light.rgb, startRange);

	if (any(isnan(result.rgb)) || isnan(result.a) || any(isinf(result.rgb)) || isinf(result.a)) {
		result = vec4(0.0);
	}
	result.rgb = clamp(result.rgb, vec3(0.0), vec3(1e3));
	result.a = clamp(result.a, 0.0, 15.0 * MCBL_FLOODFILL_RANGE);

	if (iFrameMod2 == 0) {
		imageStore(lightimg0, pos, result);
	} else {
		imageStore(lightimg1, pos, result);
	}
}

#endif // MULTICOLORED_BLOCKLIGHT == 1

#endif // CSH