

#ifndef RSM_DEBUG_MODE
    #define RSM_DEBUG_MODE 0
#endif





vec4 RSM_Calculate4(vec3 viewPos, vec3 worldNormal, float dither, float receiverRoughness, float receiverF0) {
    vec4 result = CalculateRSM4(viewPos, worldNormal, dither, receiverRoughness, receiverF0);

    #if GI_RSM == 1
        result.rgb += CalculateRSM_Far(viewPos, worldNormal, fract(dither + 0.5));
    #endif

    return result;
}


