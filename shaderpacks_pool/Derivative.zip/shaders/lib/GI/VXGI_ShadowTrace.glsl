

#ifndef VXGI_SHADOWTRACE
	#define VXGI_SHADOWTRACE 1 // [0 1]
#endif

#ifndef SHADOWTRACE_MAX_SOURCES
	#define SHADOWTRACE_MAX_SOURCES 4 // [1 2 3 4]
#endif

#ifndef SHADOWTRACE_SEARCH_RADIUS
	#define SHADOWTRACE_SEARCH_RADIUS 10 // [3 4 5 6 8 10 12]
#endif

#ifndef SHADOWTRACE_MAX_DISTANCE
	#define SHADOWTRACE_MAX_DISTANCE 20.0 // [8.0 12.0 16.0 20.0 24.0 32.0]
#endif

#ifndef SHADOWTRACE_MAX_STEPS
	#define SHADOWTRACE_MAX_STEPS 32 // [16 24 32 48 64]
#endif

#ifndef SHADOWTRACE_STRENGTH
	#define SHADOWTRACE_STRENGTH 10.0 // [0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.5 2.0 3.0]
#endif

#ifndef SHADOWTRACE_GLASS_ABSORPTION
	#define SHADOWTRACE_GLASS_ABSORPTION 0.6 // [0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#endif

bool ShadowTrace_IsColoredGlass(int materialID) {
	return (materialID >= 70 && materialID <= 85) || (materialID >= 101 && materialID <= 116);
}

bool ShadowTrace_IsEmissive(int materialID, out vec3 emissionColor) {
	emissionColor = GetVoxelEmission(materialID);
	return emissionColor != vec3(0.0);
}

vec3 ShadowTrace_CastRay(vec3 startVoxelPos, vec3 targetVoxelPos) {
	vec3 toTarget = targetVoxelPos - startVoxelPos;
	float maxDist = length(toTarget);
	if (maxDist < 1e-3) return vec3(1.0);

	vec3 rayDir = toTarget * rcp(maxDist);
	vec3 rayDirSafe = rayDir + vec3(equal(rayDir, vec3(0.0))) * 1e-6;

	ivec3 voxel = ivec3(floor(startVoxelPos));
	ivec3 rayStep = ivec3(sign(rayDirSafe));
	vec3 tDelta = abs(rcp(rayDirSafe));

	vec3 nextBoundary = vec3(voxel) + max(vec3(rayStep), vec3(0.0));
	vec3 tMax = (nextBoundary - startVoxelPos) * rcp(rayDirSafe);

	vec3 transmittance = vec3(1.0);
	float glassPathLength = 0.0;
	float travelled = 0.0;

	int maxSteps = min(int(maxDist * 1.8) + 2, SHADOWTRACE_MAX_STEPS);

	for (int i = 0; i < maxSteps; ++i) {
		if (!IsInVoxelMapVolume(vec3(voxel))) return transmittance;
		if (travelled >= maxDist) break;

		uint voxelData = texelFetch(voxeltex, voxel, 0).r;

		if (i > 0 && voxelData == VOXEL_WALL) {
			return vec3(0.0);
		}

		int matID = int(voxelData);
		vec3 tintColor = vec3(0.0);
		bool isTintingMedium = false;

		if (matID > 0 && ShadowTrace_IsColoredGlass(matID)) {
			tintColor = GetGlassEmission(matID);
			isTintingMedium = true;
		} else if (matID > 0) {

			vec3 emission;
			if (ShadowTrace_IsEmissive(matID, emission)) {
				tintColor = emission;
				isTintingMedium = true;
			}
		}

		if (isTintingMedium) {
			float tintLum = max(maxOf(tintColor), 1e-4);
			vec3 tint = tintColor * rcp(tintLum);

			float stepDist;
			if (tMax.x < tMax.y) stepDist = (tMax.x < tMax.z) ? tMax.x : tMax.z;
			else stepDist = (tMax.y < tMax.z) ? tMax.y : tMax.z;
			float segmentLen = max(stepDist - travelled, 0.0);

			glassPathLength += segmentLen;
			float absorb = exp2(-glassPathLength * SHADOWTRACE_GLASS_ABSORPTION);
			transmittance = tint * absorb;
		}

		if (tMax.x < tMax.y) {
			if (tMax.x < tMax.z) {
				travelled = tMax.x;
				voxel.x += rayStep.x; tMax.x += tDelta.x;
			} else {
				travelled = tMax.z;
				voxel.z += rayStep.z; tMax.z += tDelta.z;
			}
		} else {
			if (tMax.y < tMax.z) {
				travelled = tMax.y;
				voxel.y += rayStep.y; tMax.y += tDelta.y;
			} else {
				travelled = tMax.z;
				voxel.z += rayStep.z; tMax.z += tDelta.z;
			}
		}
	}

	return transmittance;
}

vec3 VXGI_ShadowTraceDirect(vec3 worldPos, vec3 worldNormal, float dither) {
	vec3 voxelPosF = WorldToVoxel(worldPos) + worldNormal * 0.51;
	if (!IsInVoxelMapVolume(voxelPosF)) return vec3(0.0);

	ivec3 originVoxel = ivec3(floor(voxelPosF));

	ivec3 bestVoxel[SHADOWTRACE_MAX_SOURCES];
	float bestDist[SHADOWTRACE_MAX_SOURCES];

	for (int i = 0; i < SHADOWTRACE_MAX_SOURCES; ++i) {
		bestDist[i] = 1e6;
		bestVoxel[i] = ivec3(-1000000);
	}

	const int R = SHADOWTRACE_SEARCH_RADIUS;

	for (int dz = -R; dz <= R; ++dz) {
	for (int dy = -R; dy <= R; ++dy) {
	for (int dx = -R; dx <= R; ++dx) {
		ivec3 samplePos = originVoxel + ivec3(dx, dy, dz);
		if (!IsInVoxelMapVolume(vec3(samplePos))) continue;

		uint voxelData = texelFetch(voxeltex, samplePos, 0).r;
		if (voxelData == VOXEL_WALL || voxelData == 0u) continue;

		int matID = int(voxelData);
		if (ShadowTrace_IsColoredGlass(matID)) continue;

		vec3 emission = GetVoxelEmission(matID);
		if (emission == vec3(0.0)) continue;

		float d2 = float(dx * dx + dy * dy + dz * dz);
		if (d2 < 1e-3) continue;

		for (int slot = 0; slot < SHADOWTRACE_MAX_SOURCES; ++slot) {
			if (d2 < bestDist[slot]) {
				for (int shift = SHADOWTRACE_MAX_SOURCES - 1; shift > slot; --shift) {
					bestDist[shift] = bestDist[shift - 1];
					bestVoxel[shift] = bestVoxel[shift - 1];
				}
				bestDist[slot] = d2;
				bestVoxel[slot] = samplePos;
				break;
			}
		}
	}}}

	vec3 result = vec3(0.0);

	for (int i = 0; i < SHADOWTRACE_MAX_SOURCES; ++i) {
		if (bestVoxel[i].x == -1000000) continue;

		uint voxelData = texelFetch(voxeltex, bestVoxel[i], 0).r;
		int matID = int(voxelData);
		vec3 emission = GetVoxelEmission(matID);
		if (emission == vec3(0.0)) continue;

		vec3 targetPos = vec3(bestVoxel[i]) + 0.5;
		vec3 jitter = (vec3(dither, fract(dither * 13.7), fract(dither * 41.3)) - 0.5) * 0.6;

		vec3 tint = ShadowTrace_CastRay(voxelPosF, targetPos + jitter);
		if (tint == vec3(0.0)) continue;

		float dist = sqrt(bestDist[i]);
		float falloff = rcp(1.0 + dist * dist * 0.15);

		float NdotL = VXGI_WrapCos(dot(worldNormal, normalize(targetPos - voxelPosF)));

		result += emission * tint * falloff * NdotL * SHADOWTRACE_STRENGTH;
	}

	if (any(isnan(result)) || any(isinf(result))) result = vec3(0.0);
	return clamp(result, vec3(0.0), vec3(8.0 * SHADOWTRACE_STRENGTH));
}