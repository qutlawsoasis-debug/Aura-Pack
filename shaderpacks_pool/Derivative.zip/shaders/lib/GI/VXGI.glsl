
#ifndef VXGI_SOURCE
	#define VXGI_SOURCE 2 // [1 2 3]
#endif


#ifndef VXGI_TRACE_MODE
	#define VXGI_TRACE_MODE 1 // [1 2 3]
#endif

#ifndef VXGI_STRENGTH
	#define VXGI_STRENGTH 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0 5.0 10.0 15.0]
#endif


#ifndef VXGI_MAX_DISTANCE
	#define VXGI_MAX_DISTANCE 24.0 // [8.0 12.0 16.0 20.0 24.0 32.0 40.0 48.0]
#endif


#ifndef VXGI_MAX_STEPS
	#define VXGI_MAX_STEPS 48 // [16 24 32 48 64 96 128]
#endif


#ifndef VXGI_STEP_START
	#define VXGI_STEP_START 0.5 // [0.5 0.75 1.0 1.25 1.5]
#endif
#ifndef VXGI_STEP_GROWTH
	#define VXGI_STEP_GROWTH 1.35 // [1.05 1.1 1.15 1.2 1.25 1.3 1.35 1.4 1.5 1.6]
#endif


#ifndef VXGI_CONE_COUNT
	#define VXGI_CONE_COUNT 4 // [3 4 5 6]
#endif
#ifndef VXGI_CONE_ANGLE
	#define VXGI_CONE_ANGLE 45.0 // [30.0 35.0 40.0 45.0 50.0 55.0 60.0]
#endif


#ifndef VXGI_DITHER_SAMPLES
	#define VXGI_DITHER_SAMPLES 6 // [1 2 3 4 6 8]
#endif

// Только для VXGI_TRACE_MODE == 3 (TRILINEAR). Число сэмплов вдоль нормали.
#ifndef VXGI_TRILINEAR_TAPS
	#define VXGI_TRILINEAR_TAPS 3 // [2 3 4 5 6]
#endif
#ifndef VXGI_TRILINEAR_STEP
	#define VXGI_TRILINEAR_STEP 2.0 // [1.0 1.5 2.0 2.5 3.0 4.0] Расстояние между сэмплами, в блоках.
#endif


#ifndef VXGI_SUN_COLOR
	#define VXGI_SUN_COLOR vec3(1.0, 0.95, 0.85)
#endif
#ifndef VXGI_SUN_STRENGTH
	#define VXGI_SUN_STRENGTH 1.0 // [0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.5 2.0 3.0]
#endif


#ifndef VXGI_SUN_PROXY_SCALE
	#define VXGI_SUN_PROXY_SCALE 0.35 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.5 0.6 0.7 0.8 1.0]
#endif

#ifndef VXGI_WRAP
	#define VXGI_WRAP 0.5 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#endif
float VXGI_WrapCos(float NdotL) {
	return saturate(NdotL * (1.0 - VXGI_WRAP) + VXGI_WRAP);
}


vec3 VXGI_SampleVoxelRadiance(ivec3 voxelPos, vec3 hitNormal, float receiverSkylight) {
	uint voxelData = texelFetch(voxeltex, voxelPos, 0).r;
	vec3 radiance = vec3(0.0);

	#if VXGI_SOURCE == 2 || VXGI_SOURCE == 3

		int materialID = int(voxelData);
		radiance += GetVoxelEmission(materialID) * VXGI_STRENGTH;
	#endif

	#if VXGI_SOURCE == 1 || VXGI_SOURCE == 3

		if (voxelData == VOXEL_WALL && receiverSkylight > 1e-4) {
			ivec3 upPos = voxelPos + ivec3(0, 1, 0);
			bool openAbove = IsInVoxelMapVolume(vec3(upPos))
				&& texelFetch(voxeltex, upPos, 0).r != VOXEL_WALL;


			float upFacing = saturate(hitNormal.y);

			if (openAbove && upFacing > 0.1) {

				bool hasNearbyBlockLight = false;
				for (int nz = -1; nz <= 1 && !hasNearbyBlockLight; ++nz) {
				for (int ny = -1; ny <= 1 && !hasNearbyBlockLight; ++ny) {
				for (int nx = -1; nx <= 1 && !hasNearbyBlockLight; ++nx) {
					ivec3 nPos = voxelPos + ivec3(nx, ny, nz);
					if (!IsInVoxelMapVolume(vec3(nPos))) continue;

					uint nData = texelFetch(voxeltex, nPos, 0).r;
					if (nData == VOXEL_WALL || nData == 0u) continue;

					if (GetVoxelEmission(int(nData)) != vec3(0.0)) {
						hasNearbyBlockLight = true;
					}
				}}}

				if (hasNearbyBlockLight) {
					radiance += VXGI_SUN_COLOR * VXGI_SUN_STRENGTH * upFacing * VXGI_SUN_PROXY_SCALE * receiverSkylight;
				}
			}
		}
	#endif

	return radiance;
}


vec3 VXGI_TraceRay(vec3 startVoxelPos, vec3 dir, float dither, float receiverSkylight) {
	float stepSize = VXGI_STEP_START * (1.0 + dither * 0.5);
	float travelled = 0.0;

	ivec3 lastVoxel = ivec3(-1000000);

	for (int i = 0; i < VXGI_MAX_STEPS; i++) {
		travelled += stepSize;
		if (travelled > VXGI_MAX_DISTANCE) break;

		vec3 samplePos = startVoxelPos + dir * travelled;
		ivec3 voxelPos = ivec3(floor(samplePos));

		if (!IsInVoxelMapVolume(vec3(voxelPos))) break;


		if (voxelPos != lastVoxel) {
			lastVoxel = voxelPos;

			uint voxelData = texelFetch(voxeltex, voxelPos, 0).r;
			bool isOpaque = (voxelData == VOXEL_WALL) || (int(voxelData) > 0);

			if (isOpaque) {

				vec3 hitNormal = -sign(dir) * step(vec3(maxOf(abs(dir))), abs(dir));

				vec3 radiance = VXGI_SampleVoxelRadiance(voxelPos, hitNormal, receiverSkylight);
				if (radiance == vec3(0.0)) return vec3(0.0);

				float falloff = 1.0 / (1.0 + travelled * travelled);
				return radiance * falloff;
			}
		}

		stepSize *= VXGI_STEP_GROWTH;
	}

	return vec3(0.0);
}


void VXGI_BuildBasis(vec3 n, out vec3 t, out vec3 b) {
	vec3 up = abs(n.y) < 0.999 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
	t = normalize(cross(up, n));
	b = cross(n, t);
}


vec3 VXGI_TraceMultiCone(vec3 startVoxelPos, vec3 worldNormal, float dither, float receiverSkylight) {
	vec3 total = VXGI_TraceRay(startVoxelPos, worldNormal, dither, receiverSkylight);
	float totalWeight = 1.0;

	vec3 tangent, bitangent;
	VXGI_BuildBasis(worldNormal, tangent, bitangent);

	float coneAngleRad = radians(VXGI_CONE_ANGLE);
	float sinA = sin(coneAngleRad);
	float cosA = cos(coneAngleRad);

	for (int i = 0; i < VXGI_CONE_COUNT; i++) {
		float azimuth = (float(i) + dither) * TAU * rcp(float(VXGI_CONE_COUNT));
		vec3 dir = normalize(
			worldNormal * cosA +
			(tangent * cos(azimuth) + bitangent * sin(azimuth)) * sinA
		);

		float NdotL = VXGI_WrapCos(dot(worldNormal, dir));
		if (NdotL < 1e-4) continue;

		total += VXGI_TraceRay(startVoxelPos, dir, fract(dither + float(i) * 0.37), receiverSkylight) * NdotL;
		totalWeight += NdotL;
	}

	return total * rcp(max(totalWeight, 1e-4)) * float(VXGI_CONE_COUNT + 1);
}

vec3 VXGI_TraceStochastic(vec3 startVoxelPos, vec3 worldNormal, float dither, float receiverSkylight) {
	vec3 tangent, bitangent;
	VXGI_BuildBasis(worldNormal, tangent, bitangent);


	float r1 = dither;
	float r2 = fract(Bayer8(gl_FragCoord.xy) + float(frameCounter) * 0.618034);

	float phi = TAU * r1;
	float cosTheta = sqrt(1.0 - r2);
	float sinTheta = sqrt(r2);

	vec3 dir = normalize(
		tangent * (cos(phi) * sinTheta) +
		bitangent * (sin(phi) * sinTheta) +
		worldNormal * cosTheta
	);

	return VXGI_TraceRay(startVoxelPos, dir, fract(r1 + r2), receiverSkylight);
}


vec3 VXGI_TraceTrilinear(vec3 startVoxelPos, vec3 worldNormal, float dither) {
	vec3 total = vec3(0.0);
	float totalWeight = 0.0;

	for (int i = 0; i < VXGI_TRILINEAR_TAPS; i++) {
		float dist = (float(i) + 1.0 + dither * 0.5) * VXGI_TRILINEAR_STEP;
		if (dist > VXGI_MAX_DISTANCE) break;

		vec3 samplePos = startVoxelPos + worldNormal * dist;
		if (!IsInVoxelMapVolume(samplePos)) break;

		vec3 sampleLight = (frameCounter % 2 == 0)
			? SampleVoxelLightTrilinear(lighttex0, voxeltex, samplePos, gl_FragCoord.xy)
			: SampleVoxelLightTrilinear(lighttex1, voxeltex, samplePos, gl_FragCoord.xy);

		float weight = 1.0 / (1.0 + dist * dist);
		total += sampleLight * weight;
		totalWeight += weight;
	}

	return (totalWeight > 1e-5) ? total * VXGI_STRENGTH : vec3(0.0);
}


vec3 VXGI_CalculateSingle(vec3 worldPos, vec3 worldNormal, float dither, float receiverSkylight) {
	vec3 voxelPos = WorldToVoxel(worldPos);
	if (!IsInVoxelMapVolume(voxelPos)) return vec3(0.0);


	vec3 startVoxelPos = voxelPos + worldNormal * 0.51;

	vec3 result;
	#if VXGI_TRACE_MODE == 1
		result = VXGI_TraceMultiCone(startVoxelPos, worldNormal, dither, receiverSkylight);
	#elif VXGI_TRACE_MODE == 3
		result = VXGI_TraceTrilinear(startVoxelPos, worldNormal, dither);
	#else
		result = VXGI_TraceStochastic(startVoxelPos, worldNormal, dither, receiverSkylight);
	#endif

	result *= GetVoxelMapSoftBounds(voxelPos);

	if (any(isnan(result)) || any(isinf(result))) result = vec3(0.0);


	return clamp(result, vec3(0.0), vec3(8.0 * VXGI_STRENGTH));
}


vec3 VXGI_Calculate(vec3 worldPos, vec3 worldNormal, float dither, float receiverSkylight) {
	#if VXGI_DITHER_SAMPLES <= 1
		return VXGI_CalculateSingle(worldPos, worldNormal, dither, receiverSkylight);
	#else
		vec3 total = vec3(0.0);

		float phase = dither;
		for (int i = 0; i < VXGI_DITHER_SAMPLES; ++i) {
			total += VXGI_CalculateSingle(worldPos, worldNormal, phase, receiverSkylight);
			phase = fract(phase + 0.6180339887);
		}
		return total * rcp(float(VXGI_DITHER_SAMPLES));
	#endif
}
