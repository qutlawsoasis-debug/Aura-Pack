/*
================================================================================
  GI_ReSTIR_Shadow.glsl  —  ReSTIR-based Screen-Space Point-Light Shadows
  ==========================================================================

  ЗАЧЕМ ЭТОТ ФАЙЛ ОТДЕЛЬНО ОТ GI_ReSTIR_Advanced.glsl:
  В том файле есть режим RESTIR_ADV_MODE == 1/2 ("DI" — direct light
  resampling), который ВЫГЛЯДИТ как ReSTIR-тень, но таковой не является:
  RSTR_DI_TargetPDF() там считает вес кандидата ТОЛЬКО по NdotL и
  "близости к центру экрана" — БЕЗ единого теста видимости (нет
  depth-compare с shadow map, нет screen-space raymarch к источнику).
  Он не может убрать/добавить тень, потому что вообще не проверяет,
  перекрыт пиксель геометрией или нет. Чинить его в рамках этого файла
  НЕ пытаемся (см. отдельное обсуждение) — вместо этого этот файл
  реализует честный ReSTIR с РЕАЛЬНЫМ visibility-тестом в target PDF,
  специально под point-light источники (факелы/лампы и т.п. из
  voxeltex/MULTICOLORED_BLOCKLIGHT), а не под солнце.

  Алгоритм (RIS + temporal reuse, тот же паттерн, что ReSTIR GI):
    1. Кандидаты — до RESTIR_SHADOW_CANDIDATES ближайших voxel-источников
       вокруг пикселя (переиспользуем FindNearbyLights-style поиск).
    2. Target PDF кандидата = яркость источника (до учёта тени) *
       честный screen-space visibility test (0 или 1, короткий раймарч
       по depth-буферу от пикселя к источнику — та же идея, что
       ScreenSpaceShadow() в SunLighting.glsl, но к конкретной точке,
       а не к бесконечно удалённому солнцу).
    3. RIS выбирает ОДИН источник взвешенно по target PDF — это и даёт
       "честную" тень: заслонённые источники получают target PDF ~0 и
       почти никогда не выбираются, видимые — выбираются пропорционально
       яркости.
    4. Temporal reuse через reservoir history в отдельном colortex —
       уменьшает шум без размытия тени (в отличие от blur-денойзеров).

  ВАЖНО: visibility-тест — это САМАЯ дорогая часть (raymarch), поэтому
  он выполняется РОВНО ОДИН РАЗ на кандидата (не 12+ раз, как в
  ReSTIR GI Advanced, где ещё и RSM fallback на каждый промах) — здесь
  нет RSM fallback вообще, если луч ушёл за экран, кандидат просто
  считается видимым (см. комментарий в RSTR_Shadow_Visibility) —
  дешевле и для теней от блочных источников (обычно рядом, на экране)
  это не даёт заметных артефактов.
================================================================================
*/

#include "/lib/GI/GI_Common.inc"
#include "/lib/util/voxelMapHelper.glsl"
#include "/lib/color/blocklightColor.glsl"

// ── Defaults ──────────────────────────────────────────────────────────────────

#ifndef RESTIR_SHADOW_CANDIDATES
    #define RESTIR_SHADOW_CANDIDATES 4 // сколько ближайших источников рассматриваем как кандидатов RIS
#endif
#ifndef RESTIR_SHADOW_SEARCH_RADIUS
    #define RESTIR_SHADOW_SEARCH_RADIUS 10 // радиус поиска voxel-источников (блоков), тот же принцип, что SHADOW_SEARCH_RADIUS
#endif
#ifndef RESTIR_SHADOW_SS_STEPS
    #define RESTIR_SHADOW_SS_STEPS 12 // шагов screen-space раймарча visibility-теста
#endif
#ifndef RESTIR_SHADOW_SS_THICKNESS
    #define RESTIR_SHADOW_SS_THICKNESS 0.5 // допуск по глубине (блоков), см. VoxelPointShadows.glsl style 4
#endif
#ifndef RESTIR_SHADOW_TEMPORAL_MAX
    #define RESTIR_SHADOW_TEMPORAL_MAX 16.0 // M-clamp — те же соображения, что RESTIR_ADV_TEMPORAL_MAX
#endif
#ifndef RESTIR_SHADOW_BRIGHTNESS
    #define RESTIR_SHADOW_BRIGHTNESS 1.0
#endif

// ─────────────────────────────────────────────────────────────────────────────
// Поиск ближайших voxel-источников — тот же shell-by-shell подход, что
// FindNearbyLights() в VoxelPointShadows.glsl (см. комментарий там же про
// то, почему именно расширяющиеся слои, а не сплошной куб).
// ─────────────────────────────────────────────────────────────────────────────

#define RESTIR_SHADOW_MAX_CANDIDATES_HARD_CAP 8

int RSTR_Shadow_FindLights(usampler3D voxeltexRef, ivec3 basePos, int r,
                            out ivec3 lightPos[RESTIR_SHADOW_MAX_CANDIDATES_HARD_CAP],
                            out float lightDistSq[RESTIR_SHADOW_MAX_CANDIDATES_HARD_CAP])
{
    int found = 0;

    for (int shell = 0; shell <= r; shell++) {
        for (int dz = -shell; dz <= shell; dz++) {
        for (int dy = -shell; dy <= shell; dy++) {
            bool edge = (dz == -shell || dz == shell || dy == -shell || dy == shell);
            for (int dx = -shell; dx <= shell; dx++) {
                if (shell > 0 && !edge && dx != -shell && dx != shell) continue;

                ivec3 samplePos = basePos + ivec3(dx, dy, dz);
                if (!IsInVoxelMapVolume(vec3(samplePos))) continue;

                uint voxelData = texelFetch(voxeltexRef, samplePos, 0).r;
                if (voxelData == 0u || voxelData == VOXEL_WALL) continue;

                float distSq = float(dx * dx + dy * dy + dz * dz);

                int insertAt = found;
                for (int k = 0; k < found && k < RESTIR_SHADOW_CANDIDATES; k++) {
                    if (distSq < lightDistSq[k]) { insertAt = k; break; }
                }

                if (found < RESTIR_SHADOW_CANDIDATES) {
                    for (int k = found; k > insertAt; k--) {
                        lightPos[k] = lightPos[k - 1];
                        lightDistSq[k] = lightDistSq[k - 1];
                    }
                    lightPos[insertAt] = samplePos;
                    lightDistSq[insertAt] = distSq;
                    found++;
                } else if (insertAt < RESTIR_SHADOW_CANDIDATES) {
                    for (int k = RESTIR_SHADOW_CANDIDATES - 1; k > insertAt; k--) {
                        lightPos[k] = lightPos[k - 1];
                        lightDistSq[k] = lightDistSq[k - 1];
                    }
                    lightPos[insertAt] = samplePos;
                    lightDistSq[insertAt] = distSq;
                }
            }
        }}

        if (found >= RESTIR_SHADOW_CANDIDATES) break;
    }

    return found;
}

// ─────────────────────────────────────────────────────────────────────────────
// ЧЕСТНЫЙ visibility-тест: короткий screen-space raymarch от пикселя к
// МИРОВОЙ позиции конкретного источника, сравнение с depth-буфером —
// это и есть "SSPT-тень" в узком смысле (в отличие от сломанного DI
// выше, здесь реально проверяется перекрытие).
//
// Возвращает 1.0 если источник виден, 0.0 если перекрыт. Луч, ушедший
// за пределы экрана БЕЗ перекрытия по пути — считается видимым (нет
// возможности проверить дальше, честнее не гасить свет, чем гасить
// его ложно только потому что не хватило экрана).
// ─────────────────────────────────────────────────────────────────────────────

float RSTR_Shadow_Visibility(vec3 viewPos, vec3 targetWorldPos, float dither) {
    vec3 rayStartView = viewPos;
    vec3 rayEndView = (gbufferModelView * vec4(targetWorldPos, 1.0)).xyz;

    vec3 rayStep = (rayEndView - rayStartView) / float(RESTIR_SHADOW_SS_STEPS);
    vec3 rayPos = rayStartView + rayStep * (0.3 + 0.7 * dither);

    for (int i = 1; i < RESTIR_SHADOW_SS_STEPS; i++) {
        vec3 sampleScreen = ViewToScreenSpaceRaw(rayPos);

        if (clamp(sampleScreen.xy, vec2(0.002), vec2(0.998)) != sampleScreen.xy) {
            return 1.0; // луч ушёл за экран — см. комментарий выше
        }

        float sceneDepth = textureLod(depthtex0, sampleScreen.xy, 0.0).x;
        if (sceneDepth >= 1.0) { rayPos += rayStep; continue; } // небо

        vec3 sceneVP = ScreenToViewSpaceRaw(vec3(sampleScreen.xy, sceneDepth));

        float rayZ = -rayPos.z;
        float sceneZ = -sceneVP.z;

        if (rayZ > sceneZ && (rayZ - sceneZ) < RESTIR_SHADOW_SS_THICKNESS) {
            return 0.0; // перекрыто
        }

        rayPos += rayStep;
    }

    return 1.0;
}

// ─────────────────────────────────────────────────────────────────────────────
// Target PDF кандидата: яркость источника (с учётом расстояния и NdotL,
// но БЕЗ учёта видимости) * реальный visibility-тест. Заслонённые
// источники получают ~0 и почти никогда не выбираются RIS-ом — это и
// есть механизм, которого не хватало сломанному DI выше.
// ─────────────────────────────────────────────────────────────────────────────

float RSTR_Shadow_TargetPDF(vec3 worldPos, vec3 worldNormal, vec3 viewPos,
                             ivec3 lightVoxelPos, uint lightMaterial,
                             float dither, out vec3 outRadiance, out vec3 outSourceWorldPos)
{
    outRadiance = vec3(0.0);
    outSourceWorldPos = worldPos;

    vec3 sourceColor = GetVoxelEmission(int(lightMaterial));
    if (sourceColor == vec3(0.0)) return 0.0;

    vec3 sourceWorldCenter = vec3(lightVoxelPos) - fract(cameraPosition) - voxelMapSize * 0.5 + 0.5;
    outSourceWorldPos = sourceWorldCenter;

    vec3 toSource = sourceWorldCenter - worldPos;
    float distSq = dot(toSource, toSource);
    if (distSq < 1e-4) { outRadiance = sourceColor; return GI_Luma(sourceColor); }

    float dist = sqrt(distSq);
    vec3 dirToSource = toSource / dist;

    float NdotL = max(dot(worldNormal, dirToSource), 0.0);
    if (NdotL < 1e-4) return 0.0;

    float attenuation = rcp(distSq + 1.0);

    // Честный visibility-тест — единственное место в этом файле, где
    // тратится дорогой raymarch, и делается это РОВНО РАЗ на кандидата.
    float visibility = RSTR_Shadow_Visibility(viewPos, sourceWorldCenter, dither);
    if (visibility < 1e-4) return 0.0;

    outRadiance = sourceColor * attenuation * NdotL;
    return GI_Luma(outRadiance);
}

// ─────────────────────────────────────────────────────────────────────────────
// Главная функция — RIS по кандидатам-источникам с temporal reuse.
//
// historyReservoir — упакованный reservoir с прошлого кадра (читается/
// пишется вызывающим кодом через отдельный colortex, см. патч для
// Deferred-прохода). Передаётся как vec4(radiance.rgb, packed) — см.
// GI_PackShadowReservoir/GI_UnpackShadowReservoir ниже для точного
// формата упаковки.
// ─────────────────────────────────────────────────────────────────────────────

vec4 GI_PackShadowReservoir(in GI_Reservoir r) {
    // W и M пакуются вместе через log-encode в один канал, чтобы влезть
    // в vec4 без второго render target — radiance.rgb + packed(W,M).
    // W обычно в разумном диапазоне (0..~50 после clamp), M в 0..TEMPORAL_MAX.
    float packed = floor(clamp(r.W, 0.0, 4095.0)) + fract(clamp(r.M / RESTIR_SHADOW_TEMPORAL_MAX, 0.0, 0.999));
    return vec4(r.radiance, packed);
}

GI_Reservoir GI_UnpackShadowReservoir(vec4 packed, vec3 hitPosWorld) {
    GI_Reservoir r = GI_ReservoirCreate();
    r.radiance = packed.rgb;
    r.W = floor(packed.a);
    r.M = fract(packed.a) * RESTIR_SHADOW_TEMPORAL_MAX;
    r.targetPdf = max(GI_Luma(packed.rgb), 1e-6);
    r.hitPos = hitPosWorld;
    return r;
}

vec3 CalculateReSTIR_Shadow(vec3 worldPos, vec3 worldNormal, vec3 viewPos,
                             usampler3D voxeltexRef, float dither,
                             vec4 historyPacked, bool hasHistory,
                             out vec4 outPacked)
{
    outPacked = vec4(0.0);

    vec3 voxelPosF = WorldToVoxel(worldPos);
    if (!IsInVoxelMapVolume(voxelPosF)) return vec3(0.0);

    ivec3 basePos = ivec3(floor(voxelPosF));

    ivec3 lightPos[RESTIR_SHADOW_MAX_CANDIDATES_HARD_CAP];
    float lightDistSq[RESTIR_SHADOW_MAX_CANDIDATES_HARD_CAP];
    int lightCount = RSTR_Shadow_FindLights(voxeltexRef, basePos, RESTIR_SHADOW_SEARCH_RADIUS, lightPos, lightDistSq);

    GI_Reservoir r = GI_ReservoirCreate();

    // ── RIS по кандидатам-источникам ──────────────────────────────────────────
    // pSource = 1/N (uniform) — все найденные источники равновероятны как
    // "предложение", RIS сам довзвешивает по реальной яркости+видимости.
    float pSource = 1.0 / max(float(lightCount), 1.0);

    for (int i = 0; i < lightCount; i++) {
        uint voxelData = texelFetch(voxeltexRef, lightPos[i], 0).r;

        float candD = fract(dither + float(i) * 0.2360679);

        vec3 candRadiance;
        vec3 candSourcePos;
        float pHat = RSTR_Shadow_TargetPDF(worldPos, worldNormal, viewPos, lightPos[i], voxelData, candD, candRadiance, candSourcePos);

        float w_i = pHat / max(pSource, 1e-8);
        float xi_accept = fract(candD * 41.7 + float(i) * 11.3);

        if (GI_ReservoirUpdate(r, w_i, candRadiance, candSourcePos, worldNormal, xi_accept)) {
            r.targetPdf = pHat;
        }
    }

    // ── Temporal reuse ─────────────────────────────────────────────────────────
    // Простой merge с историей ЭТОГО ЖЕ пикселя (reprojected снаружи —
    // hasHistory/historyPacked уже проверены и репроецированы вызывающим
    // кодом, см. точку вызова в deferred-проходе). Настоящий spatial
    // reuse (по соседям) намеренно НЕ делаем в первой версии — для теней
    // (в отличие от GI) spatial reuse размывает резкость тени по соседям
    // с разной видимостью, это чаще заметный артефакт, чем польза; можно
    // добавить отдельно, если после теста честного temporal-only варианта
    // шум всё ещё будет мешать.
    if (hasHistory) {
        GI_Reservoir hist = GI_UnpackShadowReservoir(historyPacked, r.hitPos);
        hist.M = min(hist.M, RESTIR_SHADOW_TEMPORAL_MAX);

        float xi_merge = fract(dither * 0.7548776 + 0.234);
        GI_ReservoirMerge(r, hist, xi_merge);
    }

    r.M = min(r.M, RESTIR_SHADOW_TEMPORAL_MAX);

    outPacked = GI_PackShadowReservoir(r);

    float W = GI_ReservoirFinalW(r);
    if (W < 1e-6) return vec3(0.0);

    return GI_Clamp16F(r.radiance * W * RESTIR_SHADOW_BRIGHTNESS);
}
