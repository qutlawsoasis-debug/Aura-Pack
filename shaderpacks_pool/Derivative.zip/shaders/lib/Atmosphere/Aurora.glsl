
#if !defined AURORA_GLSL
#define AURORA_GLSL

#include "/lib/Atmosphere/SkyEffectsCommon.glsl"


float auroraPow1_5(float x) { return x * sqrt(x); }

//----// SETTINGS //-------------------------------------------------------------------------------//

#define AURORA_COLOR_PRESET 2 //[-1 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14] // 0 ручной пресет (по умолчанию), -1 случайный набор цветов, 1..14 фиксированные пресеты

#define AURORA_UP_R 112 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 104 108 112 116 120 124 128 132 136 140 144 148 152 156 160 164 168 172 176 180 184 188 192 196 200 204 208 212 216 220 224 228 232 236 240 244 248 252 255]
#define AURORA_UP_G 36 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 104 108 112 116 120 124 128 132 136 140 144 148 152 156 160 164 168 172 176 180 184 188 192 196 200 204 208 212 216 220 224 228 232 236 240 244 248 252 255]
#define AURORA_UP_B 192 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 104 108 112 116 120 124 128 132 136 140 144 148 152 156 160 164 168 172 176 180 184 188 192 196 200 204 208 212 216 220 224 228 232 236 240 244 248 252 255]
#define AURORA_UP_I 33 //[0 3 5 8 10 13 15 18 20 23 25 28 30 33 35 38 40 43 45 48 50 53 55 58 60 63 65 68 70 73 75 78 80 83 85 88 90 93 95 98 100]

#define AURORA_DOWN_R 96 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 104 108 112 116 120 124 128 132 136 140 144 148 152 156 160 164 168 172 176 180 184 188 192 196 200 204 208 212 216 220 224 228 232 236 240 244 248 252 255]
#define AURORA_DOWN_G 255 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 104 108 112 116 120 124 128 132 136 140 144 148 152 156 160 164 168 172 176 180 184 188 192 196 200 204 208 212 216 220 224 228 232 236 240 244 248 252 255]
#define AURORA_DOWN_B 192 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 104 108 112 116 120 124 128 132 136 140 144 148 152 156 160 164 168 172 176 180 184 188 192 196 200 204 208 212 216 220 224 228 232 236 240 244 248 252 255]
#define AURORA_DOWN_I 33 //[0 3 5 8 10 13 15 18 20 23 25 28 30 33 35 38 40 43 45 48 50 53 55 58 60 63 65 68 70 73 75 78 80 83 85 88 90 93 95 98 100]

#define AURORA_SIZE 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00 2.05 2.10 2.15 2.20 2.25 2.30 2.35 2.40 2.45 2.50 2.55 2.60 2.65 2.70 2.75 2.80 2.85 2.90 2.95 3.00]

// Высота "полотна" авроры над миром, в блоках. Можно и отрицательную
// (например -100), и большую положительную (например 200).
#define AURORA_HEIGHT 200 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500]
// Насколько сильно высота сдвигает видимую полосу авроры по небу.
// 0 — эффект высоты выключен (как было раньше).
#define AURORA_HEIGHT_SCALE 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00 4.00 5.00]

#define AURORA_STYLE 0 //[0 1] // 0 плавная (по умолчанию), 1 кубическая/воксельная (как в доноре)

//#define RGB_AURORA

#define AURORA_NOISE_SCALE 1.00 //[0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00 2.05 2.10 2.15 2.20 2.25 2.30 2.35 2.40 2.45 2.50 2.55 2.60 2.65 2.70 2.75 2.80 2.85 2.90 2.95 3.00 3.05 3.10 3.15 3.20 3.25 3.30 3.35 3.40 3.45 3.50 3.55 3.60 3.65 3.70 3.75 3.80 3.85 3.90 3.95 4.00 4.05 4.10 4.15 4.20 4.25 4.30 4.35 4.40 4.45 4.50 4.55 4.60 4.65 4.70 4.75 4.80 4.85 4.90 4.95 5.00]
#define AURORA_PATTERN_WARP 0 //[0 1 2 3 4 5 6 7 8 9 10]
#define AURORA_SATURATION 10 //[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20]
#define AURORA_COLOR_MIX_POWER 2.0 //[0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0]

#define AURORA_CONDITION 2 //[-1 0 1 2 3 4] // 0 всегда, 1 только в полнолуние-эффекте(по фазе), 2 только в снежных биомах, 3 снег+луна, 4 снег или луна, -1 всегда кроме новолуния
#define AURORA_DRAW_DISTANCE 2.65 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]

//----// COLOR PRESETS //---------------------------------------------------------------------------//

vec3 auroraUpA[] = vec3[](
	vec3(112.0, 36.0, 192.0),   // [1] [2] Complementary
	vec3(112.0, 80.0, 255.0),   // [3] Legacy Complementary
	vec3(168.0, 36.0, 88.0),    // [4] Permafrost
	vec3(255.0, 68.0, 124.0),   // [5] Blossoming Lights (Pink)
	vec3(72.0, 96.0, 192.0),    // [6] Nebula
	vec3(24.0, 255.0, 140.0),   // [7] Celestial Dance
	vec3(255.0, 220.0, 255.0),  // [8] Green Flash
	vec3(64.0, 255.0, 255.0),   // [9] Ethereal Lights
	vec3(0.0, 20.0, 60.0),      // [10] Glacial Blessing
	vec3(132.0, 0.0, 200.0),    // [11] Mythical Lights
	vec3(120.0, 212.0, 56.0),   // [12] Watermelon
	vec3(0.0, 255.0, 255.0),    // [13] Blood Bath
	vec3(255.0, 80.0, 112.0)    // [14] Ghost
);
vec3 auroraDownA[] = vec3[](
	vec3(96.0, 255.0, 192.0),
	vec3(80.0, 255.0, 180.0),
	vec3(60.0, 184.0, 152.0),
	vec3(160.0, 96.0, 255.0),
	vec3(172.0, 44.0, 88.0),
	vec3(108.0, 72.0, 255.0),
	vec3(68.0, 255.0, 72.0),
	vec3(128.0, 64.0, 128.0),
	vec3(0.0, 24.0, 36.0),
	vec3(56.0, 168.0, 255.0),
	vec3(176.0, 88.0, 72.0),
	vec3(180.0, 0.0, 0.0),
	vec3(80.0, 255.0, 180.0)
);

//----// VISIBILITY //-------------------------------------------------------------------------------//


float GetAuroraVisibility(in float VdotU, float VdotUAmount) {
	float moonPhaseNorm = abs(moonPhase - 4) / 4.0; // 0 = полнолуние, 1 = новолуние
	float moonPhaseGate = 1.0 - moonPhaseNorm;      // 1 = полнолуние (гасим), 0 = новолуние

	float visibility = sqrt1(clamp01(mix(1.0, VdotU, VdotUAmount) * (AURORA_DRAW_DISTANCE * 1.125 + 0.75) - 0.225));
	visibility -= wetness;
	visibility *= 1.0 - VdotU * 0.9 * VdotUAmount;

	#if AURORA_CONDITION == 1 || AURORA_CONDITION == 3
		visibility -= moonPhaseGate;
	#endif
	#if AURORA_CONDITION == 2 || AURORA_CONDITION == 3
		visibility *= weatherSnowySmooth;
	#endif
	#if AURORA_CONDITION == 4
		visibility = max(visibility * weatherSnowySmooth, visibility - moonPhaseGate);
	#endif
	#if AURORA_CONDITION == -1
		visibility *= clamp01(max(moonPhase, 1) % 4);
	#endif

	return visibility;
}

//----// COLOR //-------------------------------------------------------------------------------------//

vec2 warpAuroraCoords(vec2 coord, float warpAmount) {
	float angle = texture2D(noisetex, coord * 0.5).r * 6.28318 * warpAmount;
	float strength = texture2D(noisetex, coord * 0.7 + 0.5).r * warpAmount;
	vec2 offset = vec2(cos(angle), sin(angle)) * strength;
	return coord + offset;
}

void GetAuroraColor(in vec2 wpos, out vec3 auroraUp, out vec3 auroraDown) {
	#if AURORA_COLOR_PRESET == 0
		auroraUp = vec3(AURORA_UP_R, AURORA_UP_G, AURORA_UP_B);
		auroraDown = vec3(AURORA_DOWN_R, AURORA_DOWN_G, AURORA_DOWN_B);
	#elif AURORA_COLOR_PRESET == -1
		// Нет worldDay-uniform'а в этом паке — используем медленный
		// временной сдвиг по frameTimeCounter вместо смены "по дням".
		float randomValue = hash11(floor(frameTimeCounter * 0.0005));
		randomValue = pow(randomValue, 0.7);
		float transitionsPerNight = min(randomValue * 2.0, 1.75);
		float idx, frac = modf(timeMidnight * transitionsPerNight, idx);

		int colorsCount = auroraUpA.length();
		int i0 = int(idx) % colorsCount;
		int i1 = (i0 + 1) % colorsCount;

		vec3 oklabUp0 = rgb2oklab(auroraUpA[i0] / 255.0);
		vec3 oklabUp1 = rgb2oklab(auroraUpA[i1] / 255.0);
		vec3 oklabDown0 = rgb2oklab(auroraDownA[i0] / 255.0);
		vec3 oklabDown1 = rgb2oklab(auroraDownA[i1] / 255.0);

		auroraUp = oklab2rgb(mix(oklabUp0, oklabUp1, frac)) * 255.0;
		auroraDown = oklab2rgb(mix(oklabDown0, oklabDown1, frac)) * 255.0;
	#else
		const int p = AURORA_COLOR_PRESET - 2;
		auroraUp = auroraUpA[p];
		auroraDown = auroraDownA[p];
	#endif

	auroraUp = max(auroraUp, vec3(0.001));
	auroraDown = max(auroraDown, vec3(0.001));

	auroraUp *= (AURORA_UP_I * 0.093 + 3.1) / GetLuminance(auroraUp);
	auroraDown *= (AURORA_DOWN_I * 0.245 + 8.15) / GetLuminance(auroraDown);

	#if AURORA_SATURATION != 10
		auroraUp = rgb2hsv(auroraUp);
		auroraUp.g *= AURORA_SATURATION * 0.1;
		auroraUp = hsv2rgb(auroraUp);

		auroraDown = rgb2hsv(auroraDown);
		auroraDown.g *= AURORA_SATURATION * 0.1;
		auroraDown = hsv2rgb(auroraDown);
	#endif
}

//----// RENDER //------------------------------------------------------------------------------------//

// worldDir — направление луча в мировых координатах (уже нормализовано вызывающей стороной).
// VdotU — dot(worldDir, up).
// dither — шум 0..1 для развала полос по семплам.
vec3 GetAuroraBorealis(in vec3 worldDir, in float VdotU, in float dither) {
	float visibility = GetAuroraVisibility(VdotU, 1.0);

	if (visibility > 0.0) {
		vec3 aurora = vec3(0.0);

		vec3 wpos = worldDir;

		// Сдвиг псевдо-плоскости авроры по высоте относительно игрока.
		float auroraHeightBias = (cameraPosition.y - float(AURORA_HEIGHT)) * 0.0015 * AURORA_HEIGHT_SCALE;
		wpos.xz /= max(wpos.y + auroraHeightBias, 1e-3);

		vec2 cameraPositionM = cameraPosition.xz * 0.0075;
		cameraPositionM.x += worldTimeCounter * 0.04;

		const int sampleCount = 16;
		const int sampleCountP = sampleCount + 8;

		float ditherM = dither + 5.0;
		float auroraAnimate = frameTimeCounter * 0.001;

		vec3 auroraUp, auroraDown;
		GetAuroraColor(wpos.xz, auroraUp, auroraDown);

		for (int i = 0; i < sampleCount; i++) {
			float current = pow2((i + ditherM) / sampleCountP);

			vec2 planePos = wpos.xz * (AURORA_SIZE * 0.8 + current) * 11.0 * AURORA_NOISE_SCALE + cameraPositionM;

			#if AURORA_STYLE == 1
				// Кубический/воксельный стиль: округляем координаты до floor ДО
				// перевода в текстурное пространство — соседние мировые точки
				// попадают в одну ячейку шума, отсюда "блочный" вид как у вокселей.
				planePos = floor(planePos) * 0.0007;

				#if AURORA_PATTERN_WARP > 0
					planePos = warpAuroraCoords(planePos, AURORA_PATTERN_WARP * 0.0057);
				#endif

				float noise = texture2DLod(noisetex, planePos, 0.0).b;
				noise = pow2(pow2(pow2(pow2(1.0 - 2.0 * abs(noise - 0.5)))));

				noise *= auroraPow1_5(texture2DLod(noisetex, planePos * 100.0 + auroraAnimate, 0.0).b);
			#else
				planePos *= 0.0007;

				#if AURORA_PATTERN_WARP > 0
					planePos = warpAuroraCoords(planePos, AURORA_PATTERN_WARP * 0.0082);
				#endif

				float noise = texture2DLod(noisetex, planePos, 0.0).r;
				noise = pow2(pow2(pow2(pow2(1.0 - 2.0 * abs(noise - 0.5)))));

				noise *= texture2DLod(noisetex, planePos * 3.0 + auroraAnimate, 0.0).b;
				noise *= texture2DLod(noisetex, planePos * 5.0 - auroraAnimate, 0.0).b;
			#endif

			float currentM = 1.0 - current;

			aurora += noise * currentM * mix(auroraUp, auroraDown, pow(pow2(currentM), AURORA_COLOR_MIX_POWER));
		}

		#if AURORA_STYLE == 1
			aurora *= 1.3;
		#else
			aurora *= 1.8;
		#endif

		return aurora * visibility / float(sampleCount);
	}

	return vec3(0.0);
}

#endif
