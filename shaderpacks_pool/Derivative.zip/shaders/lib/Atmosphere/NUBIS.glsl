

	uniform sampler3D colortex15;
uniform sampler3D colortex16; 




// У вас нет fsqrt (быстрый inverse-sqrt трюк) в Common.inc — он есть только
// в файлах донора (Utilities.glsl). Определяем локально, если его ещё нет.
#ifndef fsqrt
	#define fsqrt(x) intBitsToFloat(0x1fbd1df5 + (floatBitsToInt(x) >> 1))
#endif

// Донор использует remapSaturate(value, low, high); ваш remap(e0, e1, x)
// делает то же самое, но с другим порядком аргументов и уже включает
// saturate внутри. Оборачиваем, чтобы не переписывать все вызовы вручную.
float remapSaturate(float value, float low, float high){
	return remap(low, high, value);
}

#ifndef NUBIS_DEFINES
	#define NUBIS_DEFINES

	#define CLOUD_BASE_NOISE_SCALE     4e-4  // [1e-4 2e-4 3e-4 4e-4 5e-4 6e-4 8e-4 1e-3]
	#define CLOUD_DETAILED_NOISE_SCALE 2e-3  // [5e-4 1e-3 1.5e-3 2e-3 2.5e-3 3e-3 4e-3]
	#define CLOUD_DETAILED_NOISE_STRENGTH 1.0 // [0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0]
	#define CLOUD_COVERAGE_NOISE_OFFSET vec3(0.0, 0.0, 0.0)

	#define CLOUD_CLEAR_COVERY  1.0  // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
	#define CLOUD_RAIN_COVERY   0.85 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

	#define CLOUD_CLEAR_SCALE   1.0  // [0.5 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.5]
	#define CLOUD_RAIN_SCALE    1.1  // [0.5 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.5]

	#define CLOUD_CLEAR_DENSITY 1.0  // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0]
	#define CLOUD_RAIN_DENSITY  1.4  // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0]

	#define CLOUD_CLEAR_SUNLIGHTING 1.0 // [0.1 0.3 0.5 0.7 0.9 1.0 1.1 1.3 1.5 1.7 2.0]
	#define CLOUD_RAIN_SUNLIGHTING  0.3 // [0.1 0.3 0.5 0.7 0.9 1.0 1.1 1.3 1.5 1.7 2.0]

	#define CLOUD_CLEAR_SKYLIGHTING 1.0 // [0.1 0.3 0.5 0.7 0.9 1.0 1.1 1.3 1.5 1.7 2.0]
	#define CLOUD_RAIN_SKYLIGHTING  0.4 // [0.1 0.3 0.5 0.7 0.9 1.0 1.1 1.3 1.5 1.7 2.0]

	#define CLOUD_BOTTOM_BRIGHTNESS 0.5   // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
	#define CLOUD_OUTSCATTER_FACTOR 0.5   // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

	#define CLOUD_QUALITY 1.0 // [0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.5]

	#define NUBIS_CLOUD_ALTITUDE  1000 // [400 600 800 1000 1200 1500 2000 3000]
	#define NUBIS_CLOUD_THICKNESS 1200 // [400 600 800 1000 1200 1500 2000 3000]

	#define CLOUD_SHADOW_RANGE     2000.0 // [1000.0 1500.0 2000.0 3000.0 4000.0]
	#define CLOUD_SHADOWTEX_SIZE   512    // [256 384 512 768 1024]
#endif

float HenyeyGreenstein(float inCosAngle, float inG){
	float num = 1.0 - inG * inG;
	float denom = 1.0 + inG * inG - 2.0 * inG * inCosAngle;
	float rsqrt_denom = inversesqrt(denom);
	return num * rsqrt_denom * rsqrt_denom * rsqrt_denom * (0.25 / PI);
}

float NubisCurveTop(float x){
	x = x - 1.0;
	return 1.0 - x * x;
}

vec2 NubisSampleDensity(vec4 cloudPos, vec3 windDirection, bool sampleDetail){
	//Base Noise
		vec4 baseNoise = textureLod(colortex15, cloudPos.xyz * CLOUD_BASE_NOISE_SCALE + windDirection * 10.0, 0.0);

		float baseDensity = baseNoise.y * 0.4 + baseNoise.z * 0.4 + baseNoise.w * 0.2;
		baseDensity = remapSaturate(baseNoise.x, baseDensity - 1.0, 1.0);

		float shapeCurve = NubisCurveTop(saturate(1.0 - cloudPos.w)) * 0.5;
		shapeCurve += curve(saturate(1.15 - cloudPos.w * 1.43)) * 0.5;
		baseDensity *= shapeCurve;
		baseDensity *= fsqrt(saturate(cloudPos.w * 2.5)) * 0.2 + 0.8;
		baseDensity *= mix(1.0, NubisCurveTop(saturate(cloudPos.w * 3.0)), wetness);

	//Coverage
		float coverageNoise = textureLod(colortex15, cloudPos.xyz * vec3(8.5e-5, -1e-5, 8.5e-5) + windDirection + CLOUD_COVERAGE_NOISE_OFFSET, 0.0).x;

		float coverage = mix(CLOUD_CLEAR_COVERY, CLOUD_RAIN_COVERY, wetness);
		coverage = remapSaturate(1.0 - coverageNoise, coverage * 0.2, coverage);

		baseDensity = remapSaturate(baseDensity, coverage, 1.0);

	//Density Control
		baseDensity *= curve(saturate(cloudPos.w * 1.8 - 0.8)) * 2.0 + 1.0;
		baseDensity *= NubisCurveTop(saturate(cloudPos.w * 1.8));

		baseDensity = saturate(baseDensity);


	float detailedDensity = 0.0;

	if(baseDensity > 1e-6 && sampleDetail){
		//Curl Noise
			float curlNoise = textureLod(noisetex, cloudPos.xy * 0.0001, 0.0).w;
			cloudPos.xy += curlNoise * (100.0 - cloudPos.w * 100.0);

		//Detailed Noise
			vec3 detailedNoise = textureLod(colortex16, cloudPos.xyz * CLOUD_DETAILED_NOISE_SCALE + windDirection * 140.0, 0.0).xyz;
			detailedDensity = 1.0 - detailedNoise.x * 0.625 - detailedNoise.y * 0.25 - detailedNoise.z * 0.125;
			detailedDensity *= (0.21 - wetness * 0.11) * CLOUD_DETAILED_NOISE_STRENGTH;

			detailedDensity = remapSaturate(baseDensity, detailedDensity, 1.0);
	}else{
		detailedDensity = baseDensity;
	}

	return vec2(baseDensity, detailedDensity);
}


vec4 NubisSetCloudPos(vec3 marchingPos, vec2 cloudAltitude, float cloudScale, vec3 windDirection){
	vec4 cloudPos = vec4(marchingPos, 0.0);
	cloudPos.y = length(cloudPos.xyz + vec3(0.0, planetRadius, 0.0)) - planetRadius;
	cloudPos.w = remapSaturate(cloudPos.y, cloudAltitude.x, cloudAltitude.y);
	cloudPos.xyz = cloudPos.xyz * cloudScale + vec3(30.0 * cloudPos.w, 0.0, -12.0 * cloudPos.w);
	return cloudPos;
}


vec3 NubisCloudLighting(vec3 marchingPos, vec2 cloudAltitude, float cloudScale, vec2 lightingStrength, vec2 cloudDensity, vec4 cloudPos, vec3 windDirection, float noise, float VdotL, vec3 sunOrMoonIlluminance){
	float stepLength = 28.0;
	float lightingDensity = 0.0;

	for (int i = 0; i < 5; i++, stepLength *= 1.5){
		vec4 checkPos = NubisSetCloudPos(marchingPos + worldLightVector * stepLength * noise, cloudAltitude, cloudScale, windDirection);

		lightingDensity += NubisSampleDensity(checkPos, windDirection, i < 3).y * stepLength;

		marchingPos += worldLightVector * stepLength;
	}

	//Direct Scattering
		float hg = HenyeyGreenstein(VdotL, 0.7);

		float directScattering = exp2(-lightingDensity * (cloudPos.w * 0.15 + 0.05)) * (hg + 0.02) * (1.0 - wetness * 0.8);
		directScattering += (1.0 / (lightingDensity * 0.2 + 1.0)) * (HenyeyGreenstein(VdotL, 0.2) + 0.1);

		directScattering *= hg * 2.0 + 1.0;
		directScattering *= mix(CLOUD_BOTTOM_BRIGHTNESS, 0.005 + pow(cloudDensity.y, CLOUD_OUTSCATTER_FACTOR), curve(saturate(cloudPos.w * 3.333 - 0.333)));
		directScattering *= pow(max(cloudPos.w, 0.05), 0.75);

		// ИСПРАВЛЕНО: было * 1.8, у донора * 36.0 (colorShadowlight там был в
		// других единицах, чем sunIlluminance/moonIlluminance здесь).
		vec3 cloudColor = sunOrMoonIlluminance * (directScattering * lightingStrength.x * 36.0);

	//Ambient Scattering
		float ambientScattering = 1.0 - cloudDensity.x;
		ambientScattering *= fsqrt(cloudPos.w);

		cloudColor += skyIlluminance * (ambientScattering * lightingStrength.y * 0.35);

	return cloudColor;
}


// Возвращает vec4(scattering, transmittance) — тот же контракт, что и ваш
// существующий cloudsData в RenderSkybox: итоговый цвет неба потом
// собирается как `skyRadiance * cloudsData.a + cloudsData.rgb`, поэтому
// scattering здесь — это ТОЛЬКО вклад облаков (без skyRadiance*T внутри).
vec4 NubisCumulus(vec3 worldDir, vec3 skyRadiance){
	const vec2 cloudAltitude = vec2(NUBIS_CLOUD_ALTITUDE, NUBIS_CLOUD_ALTITUDE + NUBIS_CLOUD_THICKNESS);

	vec3 windDirection = wind; // уже объявлен в VolumetricClouds.glsl: vec3(2e-3,2e-4,1e-3)*worldTimeCounter*CLOUDS_SPEED

	//Marching Setup
		vec3 rayStartPos = vec3(0.0, planetRadius + eyeAltitude, 0.0);
		vec2 iBottom = RaySphereIntersection(rayStartPos, worldDir, planetRadius + cloudAltitude.x);
		vec2 iTop = RaySphereIntersection(rayStartPos, worldDir, planetRadius + cloudAltitude.y);

		vec2 iMarching = eyeAltitude > cloudAltitude.y ? vec2(iTop.x, iBottom.x) : vec2(iBottom.y, iTop.y);
		vec3 marchingStart = iMarching.x * worldDir;
		vec3 marchingEnd = iMarching.y * worldDir;

		float inCloud = (1.0 - saturate((eyeAltitude - cloudAltitude.y) * 0.005)) *
						(1.0 - saturate((cloudAltitude.x - eyeAltitude) * 0.005));

		float iInner = iBottom.y >= 0.0 && eyeAltitude > cloudAltitude.x ? iBottom.x : iTop.y;
		iInner = min(iInner, 5000.0);

		marchingStart = marchingStart * (1.0 - inCloud) + cameraPosition;
		marchingEnd = mix(marchingEnd, iInner * worldDir, inCloud) + cameraPosition;

		float noiseX = R1(frameCounter, texelFetch(noisetex, ivec2(gl_FragCoord.xy) & 255, 0).a); // = BlueNoiseTemporal()
		float noiseY = InterleavedGradientNoise(gl_FragCoord.xy);

		float marchingSteps = 20.0 - saturate(fsqrt(abs(worldDir.y)) * 1.4 - 0.4) * 8.0;
		marchingSteps = floor(marchingSteps * CLOUD_QUALITY);

		if (marchingSteps < 1.0) return vec4(0.0, 0.0, 0.0, 1.0);

		float marchingStepSize = 1.0 / marchingSteps;

		vec3 marchingIncrement = (marchingEnd - marchingStart) * marchingStepSize;
		vec3 marchingPos = marchingStart + marchingIncrement * noiseX;
		float marchingLength = length(marchingIncrement);


	//Cloud Properties
		vec2 lightingStrength = vec2(mix(CLOUD_CLEAR_SUNLIGHTING, CLOUD_RAIN_SUNLIGHTING, wetness),
									 mix(CLOUD_CLEAR_SKYLIGHTING, CLOUD_RAIN_SKYLIGHTING, wetness));
		float cloudScale = 			 mix(CLOUD_CLEAR_SCALE,       CLOUD_RAIN_SCALE,       wetness);
		float cloudDensityMul = 	 mix(CLOUD_CLEAR_DENSITY,     CLOUD_RAIN_DENSITY,     wetness);
		cloudDensityMul *= (cloudAltitude.y - cloudAltitude.x) * marchingStepSize;

		float VdotL = dot(worldDir, worldLightVector);

		bool moonlit = worldSunVector.y < -0.04;
		vec3 sunOrMoonIlluminance = moonlit ? moonIlluminance : sunIlluminance;


	//Marching
		vec3 cloudAccum = vec3(0.0, 0.0, 0.0);
		float cloudTransmittance = 1.0;
		vec3 rayHitPos = vec3(0.0);
		float sumTransmit = 0.0;

		for (int i = 0; i < int(marchingSteps); i++, marchingPos += marchingIncrement){
			vec4 cloudPos = NubisSetCloudPos(marchingPos, cloudAltitude, cloudScale, windDirection);

			vec2 cloudDensity = NubisSampleDensity(cloudPos, windDirection, true);

			if (cloudDensity.y < 1e-6) continue;

			vec3 cloudColor = NubisCloudLighting(marchingPos, cloudAltitude, cloudScale, lightingStrength, cloudDensity, cloudPos, windDirection, noiseY, VdotL, sunOrMoonIlluminance);
			float absorption = exp2(-cloudDensity.y * cloudDensityMul);

			cloudAccum += cloudColor * (cloudTransmittance - absorption * cloudTransmittance);

			rayHitPos += marchingPos * cloudTransmittance;
			sumTransmit += cloudTransmittance;

			cloudTransmittance *= absorption;
			if (cloudTransmittance < 0.0001) break;
		}

	//Aerial Perspective (упрощено под вашу сигнатуру GetSkyRadianceToPoint —
	// без стартовой точки камеры, только directional transmittance к точке)
	// Собираем в том же виде, что и родной блок VOLUMETRIC_CLOUDS:
	// cloudsData.rgb = "чистый" вклад облаков (без skyRadiance*transmittance),
	// cloudsData.a   = transmittance. Итог потом: skyRadiance*a + rgb.
		if (cloudTransmittance >= 1.0 - minTransmittance){
			return vec4(0.0, 0.0, 0.0, 1.0);
		}

		rayHitPos /= max(sumTransmit, 1e-6);
		rayHitPos -= cameraPosition;

		vec3 scattering = cloudAccum;

		#ifdef FULL_AERIAL_PERSPECTIVE
			vec3 airTransmittance;
			vec3 aerialPerspective = 20.0 * GetSkyRadianceToPoint(atmosphereModel, rayHitPos, worldSunVector, airTransmittance);
			scattering *= airTransmittance;
			scattering += aerialPerspective * oneMinus(cloudTransmittance);
			float atmosFade = expf(-length(rayHitPos) * (0.1 + 0.1 * wetness) * 1e-4);
		#else
			float atmosFade = expf(-length(rayHitPos) * (0.2 + 0.1 * wetness) * 1e-4);
		#endif
		scattering = scattering * atmosFade + skyRadiance * oneMinus(cloudTransmittance) * oneMinus(atmosFade);

		return vec4(scattering, cloudTransmittance);
}


// ---- Cloud shadow (для CLOUDS_SHADOW / deferred5.fsh) ----

float NubisCloudShadowTex(vec2 coord){
	const vec2 cloudAltitude = vec2(NUBIS_CLOUD_ALTITUDE, NUBIS_CLOUD_ALTITUDE + NUBIS_CLOUD_THICKNESS);
	vec3 windDirection = wind;

	coord = coord * CLOUD_SHADOW_RANGE - (CLOUD_SHADOW_RANGE * 0.5);
	vec4 checkPos = vec4(coord.x + cameraPosition.x, 0.0, coord.y + cameraPosition.z, 0.0);
	float thickness = cloudAltitude.y - cloudAltitude.x;

	checkPos += vec4(worldLightVector * ((cloudAltitude.x + thickness * 0.25) / worldLightVector.y), 0.25);
	float cloudDensity = NubisSampleDensity(checkPos, windDirection, false).y;

	checkPos += vec4(worldLightVector * ((thickness * 0.25) / worldLightVector.y), 0.25);
	cloudDensity = max(cloudDensity, NubisSampleDensity(checkPos, windDirection, false).y);

	return exp2(-cloudDensity * 20.0);
}
