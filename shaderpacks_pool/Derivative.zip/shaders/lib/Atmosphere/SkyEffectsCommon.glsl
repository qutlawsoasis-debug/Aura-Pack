#if !defined SKY_EFFECTS_COMMON_GLSL
#define SKY_EFFECTS_COMMON_GLSL

// Общие вспомогательные функции для авроры / радуги / падающих звёзд.
// Портировано из донорского пака (Complementary-style), адаптировано
// под именование этого шейдера (rcp, oneMinus, saturate уже есть в Common.inc).

float pow2(float x)   { return x * x; }
vec2  pow2(vec2 x)    { return x * x; }
vec3  pow2(vec3 x)    { return x * x; }

float pow1_5(float x) { return x * sqrt(x); }

float min1(float x)   { return min(x, 1.0); }
float sqrt1(float x)  { return sqrt(max0(x)); }

float clamp01(float x) { return saturate(x); }
vec2  clamp01(vec2 x)  { return clamp(x, 0.0, 1.0); }
vec3  clamp01(vec3 x)  { return clamp(x, 0.0, 1.0); }

mat2 rotate(float a) {
	float c = cos(a), s = sin(a);
	return mat2(c, -s, s, c);
}

float hash11(float p) {
	p = fract(p * 0.1031);
	p *= p + 33.33;
	p *= p + p;
	return fract(p);
}

float hash12(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}

// rgb2hsv / hsv2rgb — нужны для настройки насыщенности авроры.
vec3 rgb2hsv(vec3 c) {
	vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
	vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
	vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));

	float d = q.x - min(q.w, q.y);
	float e = 1.0e-10;
	return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

vec3 hsv2rgb(vec3 c) {
	vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
	vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
	return c.z * mix(K.xxx, clamp01(p - K.xxx), c.y);
}

// Простое OKLab-приближение (для плавных цветовых переходов авроры).
vec3 rgb2oklab(vec3 c) {
	float l = 0.4122214708 * c.r + 0.5363325363 * c.g + 0.0514459929 * c.b;
	float m = 0.2119034982 * c.r + 0.6806995451 * c.g + 0.1073969566 * c.b;
	float s = 0.0883024619 * c.r + 0.2817188376 * c.g + 0.6299787005 * c.b;

	float l_ = pow(max0(l), 1.0 / 3.0);
	float m_ = pow(max0(m), 1.0 / 3.0);
	float s_ = pow(max0(s), 1.0 / 3.0);

	return vec3(
		0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_,
		1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_,
		0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_
	);
}

vec3 oklab2rgb(vec3 c) {
	float l_ = c.x + 0.3963377774 * c.y + 0.2158037573 * c.z;
	float m_ = c.x - 0.1055613458 * c.y - 0.0638541728 * c.z;
	float s_ = c.x - 0.0894841775 * c.y - 1.2914855480 * c.z;

	float l = l_ * l_ * l_;
	float m = m_ * m_ * m_;
	float s = s_ * s_ * s_;

	return vec3(
		 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
		-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
		-0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s
	);
}

vec3 saturateColors(vec3 color, float sat) {
	float lum = GetLuminance(color);
	return mix(vec3(lum), color, sat);
}

#endif
