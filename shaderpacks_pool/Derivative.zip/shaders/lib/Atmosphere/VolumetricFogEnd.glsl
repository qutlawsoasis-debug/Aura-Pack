//#define RAY_STAINED_GLASS_TINT

#define UW_VOLUMETRIC_LIGHT_STRENGTH 1.1 // [0.01 0.015 0.02 0.03 0.05 0.075 0.1 0.15 0.2 0.3 0.5 0.75 1.0 1.5 2.0 3.0 5.0 7.5 10.0 15.0 20.0 30.0 50.0 75.0 100.0]
#define UW_VOLUMETRIC_LIGHT_LENGTH 100.0 // [10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 80.0 100.0 120.0 150 200.0 300.0]
#define END_FOG_SAMPLES 200 // [8 10 12 14 16 18 20 22 24 26 30 35 40 50 60 70 80 100 150 200]


//------------------------------------------------------------------------------------------------//

#include "/lib/Lighting/ShadowDistortion.glsl"

vec3 WorldPosToShadowPos(in vec3 worldPos) {
	vec3 shadowClipPos = transMAD(shadowModelView, worldPos);
	shadowClipPos = projMAD(shadowProjection, shadowClipPos);
	shadowClipPos.z *= 0.2;

	return shadowClipPos * 0.5 + 0.5;
}

vec2 DistortShadowSpace(in vec2 shadowClipPos) {
	shadowClipPos = shadowClipPos * 2.0 - 1.0;
	shadowClipPos.xy *= rcp(DistortionFactor(shadowClipPos.xy));

	return shadowClipPos * 0.5 + 0.5;
}


#define END_LIGHT_COLOR_R 110 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_LIGHT_COLOR_G 65 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_LIGHT_COLOR_B 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]

#define END_LIGHT_BRIGHTNESS 100.0 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.25 2.50 2.75 3.00 3.50 4.00 4.50 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]

#define END_LIGHT_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#define END_FOG_MAX_BRIGHTNESS 3.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00 3.50 4.00 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]

#define END_FOG_COLOR_R 100 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_FOG_COLOR_G 60 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_FOG_COLOR_B 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]

#define END_FOG_DENSITY 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00 4.00 5.00]
// Насколько гасится/темнеет дымка во время боя с драконом.
#define END_FOG_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Вертикальный диапазон тумана: от какой высоты до какой он "живёт".
// Например -20 и 110 — туман будет только в этом слое по высоте мира.
#define END_FOG_HEIGHT_START -20 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200]
#define END_FOG_HEIGHT_END 110 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500]
// Мягкость краёв перехода (в блоках) — чем больше, тем плавнее туман
// исчезает у верхней/нижней границы вместо резкого обреза.
#define END_FOG_HEIGHT_EDGE 20.0 //[0.0 5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0 60.0 80.0 100.0]

// Покрытие: насколько "дырявый" туман. Больше значение — меньше сплошной
// пелены и больше отдельных облачков с чистым небом между ними.
#define END_FOG_COVERAGE 0.58 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80]
// Резкость краёв облачков: больше — чётче/плотнее клочки, меньше — мягче
// и более размыто (ближе к дымке).
#define END_FOG_SHARPNESS 100.0 //[10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 60.0 70.0 80.0 90.0 100.0 120.0 150.0]

// Маска вокруг центрального острова: туман есть только рядом с островом,
// в пустоте вокруг него (за радиусом) тумана не будет вообще. Раскомментируй,
// чтобы включить, закомментируй define — чтобы полностью выключить (туман
// снова будет всюду, как раньше, независимо от расстояния до центра).
//#define END_FOG_ISLAND_MASK

#ifdef END_FOG_ISLAND_MASK
	// Координаты центра острова в мировых координатах (обычно 0,0 — центр
	// End-острова с порталом, но если у тебя кастомный спавн — поправь).
	#define END_FOG_ISLAND_CENTER_X 0.0
	#define END_FOG_ISLAND_CENTER_Z 0.0
	// Радиус вокруг центра, в котором туман ещё полностью есть.
	#define END_FOG_ISLAND_RADIUS 120.0 //[20.0 40.0 60.0 80.0 100.0 120.0 140.0 160.0 180.0 200.0 250.0 300.0 350.0 400.0 500.0]
	// Ширина мягкого перехода за радиусом, где туман плавно сходит на нет.
	#define END_FOG_ISLAND_EDGE 60.0 //[0.0 10.0 20.0 30.0 40.0 50.0 60.0 80.0 100.0 120.0 150.0 200.0]
#endif

// Свой sunPathRotation для Энда — независимый от общего sunPathRotation из
// shaders.properties (тот крутит солнце Оверворлда, тут он End'а вообще не
// касается, поскольку в Энде дня/ночи нет). Управляет направлением, откуда
// "бьют" god rays и подсветка тумана/облаков — чисто визуально.
// ВАЖНО: САМА тень (какие блоки затеняют туман) всё равно берётся из
// реальной shadow map движка — её направление этот define не меняет, меняется
// только направление рассеивания/god rays. Закомментируй define, чтобы
// вернуть направление света на обычный worldLightVector движка.
//#define END_CUSTOM_SUN_ROTATION

#ifdef END_CUSTOM_SUN_ROTATION
	// Высота "солнца" над горизонтом: 0 — у горизонта, 90 — в зените.
	#define END_SUN_PATH_ROTATION 35.0 //[0.0 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0]
	// Азимут "солнца" (направление по кругу, 0-360).
	#define END_SUN_AZIMUTH 45.0 //[0.0 15.0 30.0 45.0 60.0 75.0 90.0 105.0 120.0 135.0 150.0 165.0 180.0 195.0 210.0 225.0 240.0 255.0 270.0 285.0 300.0 315.0 330.0 345.0]

	vec3 endWorldLightVector = normalize(vec3(
		cos(radians(END_SUN_PATH_ROTATION)) * sin(radians(END_SUN_AZIMUTH)),
		sin(radians(END_SUN_PATH_ROTATION)),
		cos(radians(END_SUN_PATH_ROTATION)) * cos(radians(END_SUN_AZIMUTH))
	));
#else
	#define endWorldLightVector worldLightVector
#endif

#ifdef DARK_END
	float darkEnd = float(bossBattle == 2 || bossBattle == 3);
#else
	const float darkEnd = 0.0;
#endif

const int shadowMapResolution = 2048;  // Shadowmap resolution [1024 2048 4096 8192 16384 32768]
const float realShadowMapRes = shadowMapResolution * MC_SHADOW_QUALITY;

vec3 fogWind = vec3(1.0, 0.3, 0.6) * worldTimeCounter * (0.006 + darkEnd * 0.02);

float CalculateFogDensity(in vec3 rayPosition) {
	float lowerFade = smoothstep(float(END_FOG_HEIGHT_START) - END_FOG_HEIGHT_EDGE, float(END_FOG_HEIGHT_START), rayPosition.y);
	float upperFade = 1.0 - smoothstep(float(END_FOG_HEIGHT_END), float(END_FOG_HEIGHT_END) + END_FOG_HEIGHT_EDGE, rayPosition.y);
	float falloff = lowerFade * upperFade;

	#ifdef END_FOG_ISLAND_MASK
		// Считаем ДО масштабирования rayPosition ниже — тут это ещё реальные
		// мировые координаты. Горизонтальное (XZ) расстояние до центра острова.
		// max(EDGE, 0.001) — защита: smoothstep с edge0==edge1 (EDGE=0) даёт
		// NaN на большинстве драйверов, и весь туман просто пропадает.
		float islandDist = length(rayPosition.xz - vec2(END_FOG_ISLAND_CENTER_X, END_FOG_ISLAND_CENTER_Z));
		float islandMask = 1.0 - smoothstep(END_FOG_ISLAND_RADIUS, END_FOG_ISLAND_RADIUS + max(END_FOG_ISLAND_EDGE, 0.001), islandDist);
		falloff *= islandMask;
	#endif

	rayPosition *= 0.015;
	rayPosition += fogWind;
	float noise = Get3DNoiseSmooth(rayPosition) * 0.5;
		rayPosition += fogWind;
	noise += Get3DNoiseSmooth(rayPosition * 3.6) * 0.25;
		rayPosition += fogWind;
	noise += Get3DNoiseSmooth(rayPosition * 12.0) * 0.125;
		rayPosition += fogWind;
	noise += Get3DNoiseSmooth(rayPosition * 56.0) * 0.0625;

	return saturate(falloff * (noise - END_FOG_COVERAGE + darkEnd) * END_FOG_SHARPNESS) * 0.2 * END_FOG_DENSITY;
}

// Дымка/облачка тумана снова на месте, плюс god rays через тени поверх неё.
// У обеих составляющих теперь свой RGB и своя яркость через дефайны выше.
// Максимальная дальность марша тумана. Раньше было жёстко зашито 1000 —
// луч в сторону неба летел так далеко, что статистически почти всегда
// набирал одинаковую суммарную плотность и облачка сливались в сплошную
// пелену. Меньшее значение = клочки видны и на фоне неба/тумана, а не
// только на фоне блоков.
#define END_FOG_MAX_DISTANCE 500.0 //[50.0 75.0 100.0 125.0 150.0 175.0 200.0 250.0 300.0 350.0 400.0 500.0 600.0 700.0 800.0 1000.0 1200.0 1500.0 2000.0 2500.0 3000.0 4000.0 5000.0 6000.0 8000.0 10000.0]

// Затухание плотности тумана с расстоянием от игрока. Без него дальние
// лучи (например смотрящие в открытое небо) просто накапливают всё больше
// плотности и сливаются в сплошную пелену без структуры. Больше значение —
// туман тает быстрее с дистанцией, клочки остаются читаемыми и вдалеке.
#define END_FOG_DISTANCE_FALLOFF 1.50 //[0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00 6.00 8.00 10.00]

//----// CENTER LIGHT VOLUMETRICS (Энд) //--------------------------------------------------------//
// Тот же самый точечный "фейковый" свет в центре острова, что заливает
// поверхности блоков в BlockLighting.glsl (CENTER_LIGHTING) — здесь он же,
// но теперь ЕЩЁ и рассеивается в дымке/тумане, давая видимый луч/сияние
// вокруг себя (как в Bliss Shaders на скриншоте-референсе). Позиция и цвет
// продублированы теми же именами defines: если меняешь координаты света —
// меняй в обоих файлах, чтобы совпадало.
#ifdef CENTER_LIGHTING
	// voxeltex уже может быть объявлен где-то ещё (BlockLighting/FloodFill
	// в этом же пайплайне) — используем тот же guard-паттерн, что и в
	// deferred5.fsh (MCBL_UNIFORMS_DECLARED), чтобы не задвоить uniform.
	#if !defined MCBL_UNIFORMS_DECLARED
		#define MCBL_UNIFORMS_DECLARED
		uniform usampler3D voxeltex;
	#endif

	#include "/lib/util/voxelMapHelper.glsl"

	#ifndef CENTER_LIGHT_X
		#define CENTER_LIGHT_X 0.5
		#define CENTER_LIGHT_Y 96.0
		#define CENTER_LIGHT_Z 0.5
	#endif
	#ifndef CENTER_LIGHT_COLOR_R
		#define CENTER_LIGHT_COLOR_R 200
		#define CENTER_LIGHT_COLOR_G 140
		#define CENTER_LIGHT_COLOR_B 255
	#endif

	// Яркость и радиус именно ЛУЧА в тумане — отдельно от CENTER_LIGHT_BRIGHTNESS
	// (та отвечает за подсветку стен), т.к. в объёме воспринимается иначе.
	#define CENTER_LIGHT_VOLUMETRIC_STRENGTH 1.50 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00 4.00 5.00 6.00 8.00 10.00 12.00 15.00 20.00]
	// За пределами этого радиуса от света луч не считаем вообще — дёшево.
	#define CENTER_LIGHT_VOLUMETRIC_RADIUS 64.0 //[16.0 24.0 32.0 40.0 48.0 56.0 64.0 80.0 96.0 112.0 128.0]
	// worldPos здесь — camera-relative (как в BlockLighting.glsl), а не
	// абсолютные координаты, в отличие от rayPosition в марше тумана ниже.
	// Использует тот же точный voxel DDA (VoxelMapShadowTrace), что и
	// затенение поверхностей в BlockLighting.glsl — один источник правды,
	// колонны перекрывают луч в тумане ровно так же чётко, как и на земле.
	float CenterLightVolumetricShadow(in vec3 worldPos, in vec3 lightWorldPos, in float dither) {
		return VoxelMapShadowTrace(worldPos, lightWorldPos, dither);
	}

	// Добавка от центрального света для ОДНОГО шага марша тумана.
	// rayPositionAbs — АБСОЛЮТНЫЕ мировые координаты текущего шага (как
	// rayPosition в CalculateVolumetricFog), density — плотность тумана в
	// этой точке, transmittance — во сколько раз луч уже ослаблен туманом
	// ДО этой точки, worldDir — направление взгляда (для фазовой функции).
	vec3 CenterLightVolumetricSample(in vec3 rayPositionAbs, in float density, in float transmittance, in vec3 worldDir, in float dither) {
		if (density < 1e-5) return vec3(0.0);

		vec3 rayPosRelCamera = rayPositionAbs - cameraPosition;
		vec3 centerLightRelCamera = vec3(CENTER_LIGHT_X, CENTER_LIGHT_Y, CENTER_LIGHT_Z) - cameraPosition;
		vec3 toCenterLight = centerLightRelCamera - rayPosRelCamera;
		float distSq = dotSelf(toCenterLight);

		if (distSq > CENTER_LIGHT_VOLUMETRIC_RADIUS * CENTER_LIGHT_VOLUMETRIC_RADIUS) return vec3(0.0);

		float dist = sqrt(distSq);
		vec3 lightDir = toCenterLight * rcp(max(dist, 1e-3));

		float falloff = rcp(distSq * 0.02 + 1.0);
		float LdotV = dot(lightDir, worldDir);
		float phase = HenyeyGreensteinPhase(LdotV, 0.4) + HenyeyGreensteinPhase(LdotV, -0.2);

		float shadow = CenterLightVolumetricShadow(rayPosRelCamera, centerLightRelCamera, dither);
		if (shadow < 1e-4) return vec3(0.0);

		vec3 centerLightColor = vec3(CENTER_LIGHT_COLOR_R, CENTER_LIGHT_COLOR_G, CENTER_LIGHT_COLOR_B) / 255.0;

		return centerLightColor * falloff * phase * shadow * transmittance * density * CENTER_LIGHT_VOLUMETRIC_STRENGTH;
	}
#endif

vec4 CalculateVolumetricFog(in vec3 worldPos, in vec3 worldDir, in float dither) {
	float rayLength = min(END_FOG_MAX_DISTANCE, length(worldPos));

	#if defined DISTANT_HORIZONS || defined VOXY
		uint steps = END_FOG_SAMPLES;
	#else
		uint steps = uint(END_FOG_SAMPLES * 0.4 + rayLength * 0.1);
		     steps = min(steps, END_FOG_SAMPLES);
	#endif

	float rSteps = 1.0 / float(steps);
	float stepLength = rayLength * rSteps;

	float transmittance = 1.0;
	float LdotV = dot(endWorldLightVector, worldDir);
	float LdotV01 = LdotV * 0.5 + 0.5;
	float skylightSample = 0.0;

	float airDensity = RayleighPhase(LdotV) * 0.4 * exp2(-worldDir.y * 2.0) / far;

	vec3 rayStep = worldDir * stepLength,
		 rayPosition = rayStep * dither + gbufferModelViewInverse[3].xyz + cameraPosition;

	vec3 shadowStart = WorldPosToShadowPos(gbufferModelViewInverse[3].xyz),
		 shadowEnd = WorldPosToShadowPos(rayStep + gbufferModelViewInverse[3].xyz);

	vec3 shadowStep = shadowEnd - shadowStart,
		 shadowPosition = shadowStep * dither + shadowStart;
	vec3 sunlightSample = vec3(0.0);

	float phases1 = (HenyeyGreensteinPhase(LdotV, 0.5) 		   + HenyeyGreensteinPhase(LdotV, -0.3))		 * 0.5,
		  phases2 = (HenyeyGreensteinPhase(LdotV * 0.5, 0.5)   + HenyeyGreensteinPhase(LdotV * 0.5, -0.3))   * 0.25,
		  phases3 = (HenyeyGreensteinPhase(LdotV * 0.25, 0.5)  + HenyeyGreensteinPhase(LdotV * 0.25, -0.3))  * 0.125,
		  phases4 = (HenyeyGreensteinPhase(LdotV * 0.125, 0.5) + HenyeyGreensteinPhase(LdotV * 0.125, -0.3)) * 0.0625;

	#ifdef CENTER_LIGHTING
		vec3 centerLightAccum = vec3(0.0);
	#endif

	uint i = 0u;
	while (++i < steps) {
		rayPosition += rayStep, shadowPosition += shadowStep;

		vec2 shadowProjPos = DistortShadowSpace(shadowPosition.xy);
		if (saturate(shadowProjPos) != shadowProjPos) continue;
		ivec2 shadowTexel = ivec2(shadowProjPos * realShadowMapRes);

		float fogDensity = airDensity;
		float density = CalculateFogDensity(rayPosition);
		density *= exp2(-distance(rayPosition, cameraPosition) * END_FOG_DISTANCE_FALLOFF * 0.001);
		fogDensity += density;

		if (fogDensity < 1e-5) continue;
		fogDensity *= stepLength;

		vec3 shadow = texelFetch(shadowtex1, shadowTexel, 0).xxx;
		shadow = step(shadowPosition.z, shadow);
		#ifdef RAY_STAINED_GLASS_TINT
			float translucentShadow = step(shadowPosition.z, texelFetch(shadowtex0, shadowTexel, 0).x);
			if (shadow.x != translucentShadow) {
				vec3 shadowColorSample = pow4(texelFetch(shadowcolor0, shadowTexel, 0).rgb);
				shadow = shadowColorSample * (shadow - translucentShadow) + vec3(translucentShadow);
			}
		#endif

		if (density > 1e-5) {
			float stepLength = 5.0, sunlightOD = 0.0;
			vec3 checkPos = rayPosition;
			for (uint i = 0u; i < 4u; ++i, checkPos += endWorldLightVector * stepLength) {
				float density = CalculateFogDensity(checkPos);
				if (density < 1e-5) continue;
				sunlightOD += density * stepLength;
				stepLength *= 1.5;
			}

			float scatteringSun = oneMinus(expf(-sunlightOD * 3.0)) * oneMinus(LdotV01) + LdotV01;
			scatteringSun *= expf(-sunlightOD * 4.0) * phases1
						+ expf(-sunlightOD * 2.0)  	* phases2
						+ expf(-sunlightOD * 1.0)  	* phases3
						+ expf(-sunlightOD * 0.5) 	* phases4;

			shadow *= scatteringSun * 4.0;
		}

		float stepTransmittance = expf(-fogDensity);

		float powder = rcp(fogDensity * 0.3 + 0.15) * fogDensity;
		powder = powder * oneMinus(LdotV01) + LdotV01;
		float fogSample = powder * transmittance * oneMinus(stepTransmittance);
		sunlightSample += shadow * fogSample;
		skylightSample += fogSample;

		#ifdef CENTER_LIGHTING
			centerLightAccum += CenterLightVolumetricSample(rayPosition, density, transmittance, worldDir, dither) * stepLength;
		#endif

		transmittance *= stepTransmittance;

		if (transmittance < 1e-3) break;
	}

	vec3 endLightColor = vec3(END_LIGHT_COLOR_R, END_LIGHT_COLOR_G, END_LIGHT_COLOR_B) / 255.0;
	vec3 endFogColor = vec3(END_FOG_COLOR_R, END_FOG_COLOR_G, END_FOG_COLOR_B) / 255.0;

	vec3 fogSunColor = endLightColor * (1.0 - darkEnd * END_LIGHT_DARK_END_FADE) * sunlightSample * END_LIGHT_BRIGHTNESS;
	vec3 fogSkyColor = endFogColor * (1.0 - darkEnd * END_FOG_DARK_END_FADE) * 0.04 * skylightSample;

	vec3 fogColor = fogSunColor + fogSkyColor;

	#ifdef CENTER_LIGHTING
		fogColor += centerLightAccum;
	#endif

	// Жёсткий потолок яркости: без него свет/туман легко перескакивает
	// порог блума и вся сцена заливается бледным сиянием ("свет землю
	// блумом в туман"). Понижай END_FOG_MAX_BRIGHTNESS, если всё ещё светит.
	// clamp (а не min) — отрицательная яркость аккуратно уходит в честный
	// чёрный, а не в мусорные значения где-то дальше по пайплайну.
	fogColor = clamp(fogColor, vec3(0.0), vec3(END_FOG_MAX_BRIGHTNESS));

	return vec4(fogColor, transmittance);
}

vec3 UnderwaterVolumetricLight(in vec3 worldPos, in vec3 worldDir, in float dither) {
	float rayLength = min(24.0, length(worldPos));

	uint steps = uint(12.0 + 0.5 * rayLength);
	     steps = min(steps, 22u);

	float rSteps = 1.0 / float(steps);

	float stepLength = rayLength * rSteps;

	vec3 shadowStart = WorldPosToShadowPos(gbufferModelViewInverse[3].xyz),
		 shadowEnd = WorldPosToShadowPos(worldDir * stepLength + gbufferModelViewInverse[3].xyz);

	vec3 shadowStep = shadowEnd - shadowStart,
		 shadowPosition = shadowStep * dither + shadowStart;

	const vec3 coeff = waterAbsorption + 0.02;
	vec3 stepTransmittance = expf(-coeff * stepLength);
	vec3 transmittance = vec3(1.0);

	vec3 scattering = vec3(0.0);

    uint i = 0u;
	while (++i < steps) {
		shadowPosition += shadowStep;

		vec2 shadowProjPos = DistortShadowSpace(shadowPosition.xy);
		if (saturate(shadowProjPos) != shadowProjPos) continue;
		ivec2 shadowTexel = ivec2(shadowProjPos * realShadowMapRes);
	
        float translucentShadow = step(shadowPosition.z, texelFetch(shadowtex0, shadowTexel, 0).x);
        vec3 sampleShadow = vec3(1.0);

		if (translucentShadow < 1.0) {
			sampleShadow = step(shadowPosition.z, texelFetch(shadowtex1, shadowTexel, 0).xxx);

            if (sampleShadow.x != translucentShadow) {
				float waterDepth = abs(texelFetch(shadowcolor1, shadowTexel, 0).w * 512.0 - 128.0 - shadowPosition.y - eyeAltitude);
				if (waterDepth > 0.1) {
					sampleShadow = sqr(cube(texelFetch(shadowcolor0, shadowTexel, 0).rgb));
				} else {
					vec3 shadowColorSample = pow4(texelFetch(shadowcolor0, shadowTexel, 0).rgb);
					sampleShadow = shadowColorSample * (sampleShadow - translucentShadow) + vec3(translucentShadow);
				}

				sampleShadow *= expf(-coeff * 0.4 * max(waterDepth, 8.0));
			}
		}

		scattering += sampleShadow * transmittance * oneMinus(stepTransmittance);

		transmittance *= stepTransmittance;
	}

	vec3 lightVector = refract(worldLightVector, vec3(0.0, -1.0, 0.0), 1.0 / WATER_REFRACT_IOR);
	float LdotV = dot(lightVector, worldDir);
	float phase = HenyeyGreensteinPhase(LdotV, 0.8) + HenyeyGreensteinPhase(LdotV, 0.6);

	vec3 fogColor = 8.0 / coeff// * oneMinus(stepTransmittance)
	;
	fogColor *= scattering * phase * UW_VOLUMETRIC_LIGHT_STRENGTH;

	return fogColor;
}