// Rainbow — портировано с донорского пака. Упрощено: убрана зависимость
// от donor-специфичных вещей, которых нет в этом паке (per-pixel облачная
// линейная глубина в colortex5 — тут в colortex5 лежит sky capture map,
// а не то же самое; cave factor; translucentMult для стекла). Радуга рисуется
// как атмосферный эффект по направлению взгляда, видна только по небу/дальним
// объектам (проверяется через depth снаружи, см. composite1.fsh).
#if !defined RAINBOW_GLSL
#define RAINBOW_GLSL

#include "/lib/Atmosphere/SkyEffectsCommon.glsl"

#define RAINBOW_DIAMETER 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00 2.05 2.10 2.15 2.20 2.25 2.30 2.35 2.40 2.45 2.50 2.55 2.60 2.65 2.70 2.75 2.80 2.85 2.90 2.95 3.00 3.05 3.10 3.15 3.20 3.25 3.30 3.35 3.40 3.45 3.50 3.55 3.60 3.65 3.70 3.75 3.80 3.85 3.90 3.95 4.00 4.25 4.50 4.75 5.00 5.25 5.50 5.75 6.00 6.25 6.50 6.75 7.00 7.50 8.00]
#define RAINBOW_INTENSITY 1.0 //[0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0]

// worldDir — направление взгляда в мировых координатах.
// VdotL — dot(worldDir, worldLightVector) (со знаком, как приходит от солнца).
// fragDist — расстояние в мировых единицах до фрагмента (far, если это небо).
vec3 GetRainbow(in vec3 worldDir, in float VdotL, in float fragDist, in float dither) {
	vec3 rainbow = vec3(0.0);

	// Радуга появляется только когда солнце невысоко и не в зените, и после/во время дождя.
	float rainbowTime = min1(max0(worldSunVector.y - 0.1) / 0.15);
	rainbowTime = clamp(rainbowTime - pow2(pow2(pow2(timeNoon))) * 8.0, 0.0, 0.85);
	rainbowTime *= sqrt2(max0(wetness - 0.333) * 1.5);

	if (rainbowTime > 0.001) {
		float rainbowLength = far * 0.9;
		float lViewPos1 = min(fragDist, rainbowLength);

		float rainbowCoord = clamp01(1.0 - (VdotL + 0.75) / (0.0625 * RAINBOW_DIAMETER));
		float rainbowFactor = rainbowCoord * (1.0 - rainbowCoord);
		rainbowFactor = pow2(pow2(rainbowFactor * 3.7));
		rainbowFactor *= pow2(min1(lViewPos1 / rainbowLength));
		rainbowFactor *= rainbowTime;

		if (rainbowFactor > 0.0) {
			float rainbowCoordM = pow(rainbowCoord, 1.4 + max(rainbowCoord - 0.5, 0.0) * 1.6);
			rainbowCoordM = smoothstep(0.0, 1.0, rainbowCoordM) * 0.85;
			rainbowCoordM += (dither - 0.5) * 0.1;

			rainbow += clamp(abs(mod(rainbowCoordM * 6.0 + vec3(-0.55, 4.3, 2.2), 6.0) - 3.0) - 1.0, 0.0, 1.0);
			rainbowCoordM += 0.1;
			rainbow += clamp(abs(mod(rainbowCoordM * 6.0 + vec3(-0.55, 4.3, 2.2), 6.0) - 3.0) - 1.0, 0.0, 1.0);
			rainbowCoordM -= 0.2;
			rainbow += clamp(abs(mod(rainbowCoordM * 6.0 + vec3(-0.55, 4.3, 2.2), 6.0) - 3.0) - 1.0, 0.0, 1.0);
			rainbow /= 3.0;

			rainbow.r += pow2(max(rainbowCoord - 0.5, 0.0)) * (max(1.0 - rainbowCoord, 0.0)) * 26.0;
			rainbow = pow(rainbow, vec3(2.2)) * vec3(0.25, 0.075, 0.25) * 3.0;

			if (isEyeInWater != 0) rainbow *= sqrt1(max0(worldDir.y));

			rainbow *= rainbowFactor * RAINBOW_INTENSITY;
		}
	}

	return rainbow;
}

#endif
