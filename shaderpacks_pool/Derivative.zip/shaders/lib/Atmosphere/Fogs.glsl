
uniform float blindness;
uniform float darknessFactor;

void CommonFog(inout vec3 color, in float dist) {
	if (blindness + darknessFactor > 0.0) color *= expf(-dist * max(blindness, darknessFactor));

	if (isEyeInWater == 2) color = mix(color, vec3(3.96, 0.68, 0.02), saturate(dist));

	if (isEyeInWater == 3) {
		#if defined IS_OVERWORLD
			vec3 fogColor = skyIlluminance + directIlluminance;
			fogColor = 6.0 * mix(fogColor, directIlluminance * 0.1, wetnessCustom * 0.8);
		#else
			vec3 fogColor = vec3(1.76, 1.92, 2.0);
		#endif

		color = mix(fogColor * eyeSkylightFix, color, exp2(-dist * 2.0));
	}
}


#ifdef IS_END
	void EndFog(inout vec3 color, in vec3 viewPos, MaterialMask mask)
	{
		float dist = length(viewPos);

		float fogDensity = 0.02;
	#if MC_VERSION >= 11700
		fogDensity -= mask.sky * 0.018;
	#else
		fogDensity -= mask.sky * 0.015;
	#endif
		float fogFactor = sqr(1.0 - expf(-dist * fogDensity));

		vec3 fogColor = vec3(0.1, 0.03, 0.13) * 0.2;

		color = mix(color, fogColor, vec3(fogFactor));
	}
#endif


#if defined IS_NETHER
	//uniform vec3 fogColor;
	uniform float BiomeNetherWastesSmooth;
	uniform float BiomeWarpedForestSmooth;
	uniform float BiomeCrimsonForestSmooth;
	uniform float BiomeSoulSandValleySmooth;
	uniform float BiomeBasaltDeltasSmooth;

	vec3 NetherFogColor() {
		return vec3(0.99, 0.23, 0.03) 	* BiomeNetherWastesSmooth
			 + vec3(0.04, 0.24, 0.2) 	* BiomeWarpedForestSmooth
			 + vec3(0.3, 0.03, 0.01) 	* BiomeCrimsonForestSmooth
			 + vec3(0.012, 0.055, 0.06) * BiomeSoulSandValleySmooth
			 + vec3(0.5) 				* BiomeBasaltDeltasSmooth;
	}

	void NetherFog(inout vec3 color, in float dist) {
        vec3 transmittance = exp2(-NetherFogColor() * dist * 0.01);
        vec3 scattering = oneMinus(transmittance) * 0.6;
		//color = mix(color, GammaToLinear(fogColor), vec3(fogFactor));
		color = color * transmittance + scattering;
	}
#else
vec4 SpatialUpscale(in sampler2D tex, in vec2 coord, in float linearDepth) {
    // biasStrength: 0.0 = дизер выключен, offset всегда 0 (максимально
    //               заметные полосы, но самый чёткий/стабильный результат)
    //               1.0 = дизер работает на полную (как оригинальный
    //               чекерборд с шагом 2) — полосы усредняются по кадрам
    //               сильнее всего, но чуть больше шума/мерцания.
    // Промежуточные значения (например 0.3) смешивают "выключенный" и
    // "полный" bias через случайный порог по кадру/пикселю — так можно
    // подобрать компромисс между полосами и шумом.
    const float biasStrength = 0.3;

    float noise = fract(sin(dot(coord + float(frameCounter), vec2(12.9898, 78.233))) * 43758.5453);
    ivec2 fullBias = ivec2(coord + frameCounter) % 1; // оригинальная логика чекерборда, шаг 1 в half-res, диапазон 0..1
    ivec2 bias = (noise < biasStrength) ? fullBias : ivec2(0);

    ivec2 texel = ivec2(coord * 0.5) + bias;

    ivec2 offset[4] = ivec2[4](
        ivec2(-1,-1), ivec2(-1, 0),
        ivec2( 0, 0), ivec2( 0,-1)
    );

    float sigmaZ = 64.0 / linearDepth;

    vec4 total = vec4(0.0);
    float sumWeight = 0.0;

    for (uint i = 0u; i < 4u; ++i) {
        ivec2 sampleTexel = texel + offset[i];

        float sampleDepth = GetDepthLinear(GetDepth(sampleTexel * 1));

        float weight = max(exp2(-abs(sampleDepth - linearDepth) * sigmaZ), 1e-6);
        total += texelFetch(tex, sampleTexel, 0) * weight;

        sumWeight += weight;
    }

    return total / sumWeight;
}

#if defined DISTANT_HORIZONS || defined VOXY
    vec4 SpatialUpscaleDH(in sampler2D tex, in vec2 coord, in float linearDepth) {
        // Тот же дизер-фикс, что и в SpatialUpscale выше.
        const float biasStrength = 0.3;

        float noise = fract(sin(dot(coord + float(frameCounter), vec2(12.9898, 78.233))) * 43758.5453);
        ivec2 fullBias = ivec2(coord + frameCounter) % 1;
        ivec2 bias = (noise < biasStrength) ? fullBias : ivec2(0);

        ivec2 texel = ivec2(coord * 0.5) + bias;

        ivec2 offset[4] = ivec2[4](
            ivec2(-1,-1), ivec2(-1, 0),
            ivec2( 0, 0), ivec2( 0,-1)
        );

        float sigmaZ = 64.0 / linearDepth;

        vec4 total = vec4(0.0);
        float sumWeight = 0.0;

        for (uint i = 0u; i < 4u; ++i) {
            ivec2 sampleTexel = texel + offset[i];

            float sampleDepth = GetDepthLinearDH(GetDepthDH(sampleTexel * 1));

            float weight = max(exp2(-abs(sampleDepth - linearDepth) * sigmaZ), 1e-6);
            total += texelFetch(tex, sampleTexel, 0) * weight;

            sumWeight += weight;
        }

        return total / sumWeight;
    }
#endif
	#endif
#endif

void TransparentAbsorption(inout vec3 color, in vec4 stainedGlassAlbedo) {
	vec3 stainedGlassColor = normalize(stainedGlassAlbedo.rgb) * pow(dotSelf(stainedGlassAlbedo.rgb), GLASS_TEXTURE_ALPHA * 0.25);

	color *= pow4(mix(vec3(1.0), saturate(stainedGlassColor), pow(stainedGlassAlbedo.a, 0.2 * GLASS_TEXTURE_ALPHA)));
}
