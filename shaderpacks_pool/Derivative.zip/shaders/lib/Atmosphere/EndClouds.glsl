// EndClouds.glsl
//
// Слои "полноценных облаков" в Энде.
// Плотность считается ТОЙ ЖЕ формулой, что и в CalculateFogDensity()
// из VolumetricFogEnd.glsl (тот же 3D-нойз, та же схема октав 0.5/0.25/0.125/0.0625,
// та же маска по высоте, тот же coverage/sharpness) — логика 1в1, ничего в самой
// математике не поменяно.
//
// Слои 1-7 — полностью независимы друг от друга (свои дефайны,
// свой марш, свой toggle). У каждого СВОЙ toggle — можно включить любой
// набор слоёв: только один, несколько, все семь, или ни одного.
//
// Этот файл должен инклудиться СРАЗУ ПОСЛЕ "/lib/Atmosphere/VolumetricFogEnd.glsl",
// т.к. переиспользует уже объявленные там: WorldPosToShadowPos, DistortShadowSpace,
// realShadowMapRes, darkEnd, endWorldLightVector (свой sunPathRotation Энда),
// а также общие HenyeyGreensteinPhase/RayleighPhase/Get3DNoiseSmooth из
// Common/Functions.inc (они уже заинклюжены выше по цепочке).

//----// СЛОЙ 1 //--------------------------------------------------------------------------------//

#define END_CLOUDS // Включить 1й слой облаков в Энде поверх основного тумана

#ifdef END_CLOUDS
#define END_FOG_SAMPLES 112
// Цвет и яркость god-ray составляющей облаков (свет, проходящий через тени).
#define END_CLOUDS_LIGHT_COLOR_R 91 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS_LIGHT_COLOR_G 92 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS_LIGHT_COLOR_B 222 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS_LIGHT_BRIGHTNESS 100.0 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.25 2.50 2.75 3.00 3.50 4.00 4.50 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]
#define END_CLOUDS_LIGHT_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Жёсткий потолок яркости слоя облаков.
#define END_CLOUDS_MAX_BRIGHTNESS 3.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00 3.50 4.00 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]

// Цвет и плотность самих "телес" облаков.
#define END_CLOUDS_COLOR_R 91 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS_COLOR_G 92 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS_COLOR_B 222 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS_DENSITY 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00 4.00 5.00]
#define END_CLOUDS_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Насколько skylight (фоновый цвет неба, восход/закат) подмешивается в цвет облака.
// 0.0 = облако НЕ перекрашивается небом — на фоне неба видны только годреи/тени (без розового/цветного оттенка).
// 1.0 = как раньше, полный вклад неба.
#define END_CLOUDS_SKY_TINT_STRENGTH 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0]

// --- Усиление цвета (boost) ---
#define END_CLOUDS_COLOR_BRIGHTNESS_BOOST 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0]
#define END_CLOUDS_COLOR_SATURATION_BOOST 1.0 //[0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0]

// --- Вспышки в облаке ---
#define END_CLOUDS_FLASHES // Включить случайные цветные вспышки в этом слое облаков

#ifdef END_CLOUDS_FLASHES
	#define END_CLOUDS_FLASH_COLOR_R 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS_FLASH_COLOR_G 40 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS_FLASH_COLOR_B 220 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]

	#define END_CLOUDS_FLASH_BRIGHTNESS 4.0 //[0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0 12.0 15.0 20.0]
	#define END_CLOUDS_FLASH_FREQUENCY 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50]
	#define END_CLOUDS_FLASH_SHARPNESS 8.0 //[1.0 2.0 3.0 4.0 5.0 6.0 8.0 10.0 15.0 20.0 30.0 50.0]
	#define END_CLOUDS_FLASH_SPEED 0.15 //[0.00 0.02 0.05 0.08 0.10 0.15 0.20 0.30 0.40 0.50 0.70 1.00]
	#define END_CLOUDS_FLASH_SCALE 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.15 0.20 0.30 0.40]
#endif


// Вертикальный диапазон, в котором "живёт" слой 1.
#define END_CLOUDS_HEIGHT_START 40 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200]
#define END_CLOUDS_HEIGHT_END 160 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500]
#define END_CLOUDS_HEIGHT_EDGE 20.0 //[0.0 5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0 60.0 80.0 100.0]

// Покрытие/резкость клочков слоя 1.
#define END_CLOUDS_COVERAGE 0.46 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80]
#define END_CLOUDS_SHARPNESS 50.0 //[10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 60.0 70.0 80.0 90.0 100.0 120.0 150.0]

// Масштаб нойза слоя 1.
#define END_CLOUDS_SCALE 0.015 //[0.005 0.008 0.010 0.012 0.015 0.020 0.025 0.030 0.040 0.050]

// Скорость ветра слоя 1.
#define END_CLOUDS_WIND_SPEED 0.006 //[0.000 0.002 0.004 0.006 0.008 0.010 0.015 0.020 0.030 0.040 0.060 0.080 0.100]

// Дальность марша и затухание с расстоянием слоя 1.
#define END_CLOUDS_MAX_DISTANCE 250.0 //[50.0 75.0 100.0 125.0 150.0 175.0 200.0 250.0 300.0 350.0 400.0 500.0 600.0 700.0 800.0 1000.0 1200.0 1500.0 2000.0 2500.0 3000.0 4000.0 5000.0 6000.0 8000.0 10000.0]
#define END_CLOUDS_DISTANCE_FALLOFF 1.00 //[0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00 6.00 8.00 10.00]


// Маска вокруг центрального острова — то же самое, что END_FOG_ISLAND_MASK
// у тумана, но отдельно для слоя 1 облаков и с собственным тумблером.
#define END_CLOUDS_ISLAND_MASK

#ifdef END_CLOUDS_ISLAND_MASK
	#define END_CLOUDS_ISLAND_CENTER_X 0.0
	#define END_CLOUDS_ISLAND_CENTER_Z 0.0
	#define END_CLOUDS_ISLAND_RADIUS 120.0 //[20.0 40.0 60.0 80.0 100.0 120.0 140.0 160.0 180.0 200.0 250.0 300.0 350.0 400.0 500.0]
	#define END_CLOUDS_ISLAND_EDGE 60.0 //[0.0 10.0 20.0 30.0 40.0 50.0 60.0 80.0 100.0 120.0 150.0 200.0]
#endif

vec3 endCloudsWind = vec3(1.0, 0.3, 0.6) * worldTimeCounter * (END_CLOUDS_WIND_SPEED + darkEnd * 0.02);

// 1в1 та же формула, что CalculateFogDensity() в VolumetricFogEnd.glsl,
// только на независимых END_CLOUDS_* константах и с собственным ветром/масштабом.
float CalculateCloudDensity(in vec3 rayPosition) {
	float lowerFade = smoothstep(float(END_CLOUDS_HEIGHT_START) - END_CLOUDS_HEIGHT_EDGE, float(END_CLOUDS_HEIGHT_START), rayPosition.y);
	float upperFade = 1.0 - smoothstep(float(END_CLOUDS_HEIGHT_END), float(END_CLOUDS_HEIGHT_END) + END_CLOUDS_HEIGHT_EDGE, rayPosition.y);
	float falloff = lowerFade * upperFade;

	#ifdef END_CLOUDS_ISLAND_MASK
		float islandDist = length(rayPosition.xz - vec2(END_CLOUDS_ISLAND_CENTER_X, END_CLOUDS_ISLAND_CENTER_Z));
		float islandMask = 1.0 - smoothstep(END_CLOUDS_ISLAND_RADIUS, END_CLOUDS_ISLAND_RADIUS + max(END_CLOUDS_ISLAND_EDGE, 0.001), islandDist);
		falloff *= islandMask;
	#endif

	rayPosition *= END_CLOUDS_SCALE;
	rayPosition += endCloudsWind;
	float noise = Get3DNoiseSmooth(rayPosition) * 0.5;
		rayPosition += endCloudsWind;
	noise += Get3DNoiseSmooth(rayPosition * 3.6) * 0.25;
		rayPosition += endCloudsWind;
	noise += Get3DNoiseSmooth(rayPosition * 12.0) * 0.125;
		rayPosition += endCloudsWind;
	noise += Get3DNoiseSmooth(rayPosition * 56.0) * 0.0625;

	return saturate(falloff * (noise - END_CLOUDS_COVERAGE + darkEnd) * END_CLOUDS_SHARPNESS) * 0.2 * END_CLOUDS_DENSITY;
}

#ifdef END_CLOUDS_FLASHES
float CalculateCloudFlash(in vec3 rayPosition, in float density) {
	if (density < 1e-4) return 0.0;

	vec3 flashPos = rayPosition * END_CLOUDS_FLASH_SCALE;
	flashPos += vec3(3.17, -1.41, 2.63) * worldTimeCounter * END_CLOUDS_FLASH_SPEED;

	float flashNoise = Get3DNoiseSmooth(flashPos);
	float flash = saturate((flashNoise - (1.0 - END_CLOUDS_FLASH_FREQUENCY)) * END_CLOUDS_FLASH_SHARPNESS);

	return flash * END_CLOUDS_FLASH_BRIGHTNESS;
}
#endif

vec4 CalculateEndClouds(in vec3 worldPos, in vec3 worldDir, in float dither) {
	float rayLength = min(END_CLOUDS_MAX_DISTANCE, length(worldPos));

	#if defined DISTANT_HORIZONS || defined VOXY
		uint steps = END_FOG_SAMPLES;
	#else
		uint steps = uint(END_FOG_SAMPLES * 0.4 + rayLength * 0.1);
		     steps = min(steps, END_FOG_SAMPLES);
	#endif

	float rSteps = 1.0 / float(steps);
	float stepLength = rayLength * rSteps;

	float transmittance = 1.0;
	float LdotV = dot(endWorldLightVector, worldDir);
	float LdotV01 = LdotV * 0.5 + 0.5;
	float skylightSample = 0.0;
	#ifdef END_CLOUDS_FLASHES
		float flashSample = 0.0;
	#endif

	vec3 rayStep = worldDir * stepLength,
		 rayPosition = rayStep * dither + gbufferModelViewInverse[3].xyz + cameraPosition;

	vec3 shadowStart = WorldPosToShadowPos(gbufferModelViewInverse[3].xyz),
		 shadowEnd = WorldPosToShadowPos(rayStep + gbufferModelViewInverse[3].xyz);

	vec3 shadowStep = shadowEnd - shadowStart,
		 shadowPosition = shadowStep * dither + shadowStart;
	vec3 sunlightSample = vec3(0.0);

	float phases1 = (HenyeyGreensteinPhase(LdotV, 0.5) 		   + HenyeyGreensteinPhase(LdotV, -0.3))		 * 0.5,
		  phases2 = (HenyeyGreensteinPhase(LdotV * 0.5, 0.5)   + HenyeyGreensteinPhase(LdotV * 0.5, -0.3))   * 0.25,
		  phases3 = (HenyeyGreensteinPhase(LdotV * 0.25, 0.5)  + HenyeyGreensteinPhase(LdotV * 0.25, -0.3))  * 0.125,
		  phases4 = (HenyeyGreensteinPhase(LdotV * 0.125, 0.5) + HenyeyGreensteinPhase(LdotV * 0.125, -0.3)) * 0.0625;

	uint i = 0u;
	while (++i < steps) {
		rayPosition += rayStep, shadowPosition += shadowStep;

		vec2 shadowProjPos = DistortShadowSpace(shadowPosition.xy);
		if (saturate(shadowProjPos) != shadowProjPos) continue;
		ivec2 shadowTexel = ivec2(shadowProjPos * realShadowMapRes);

		float density = CalculateCloudDensity(rayPosition);
		density *= exp2(-distance(rayPosition, cameraPosition) * END_CLOUDS_DISTANCE_FALLOFF * 0.001);

		if (density < 1e-5) continue;
		float fogDensity = density * stepLength;

		#ifdef END_CLOUDS_FLASHES
			flashSample += CalculateCloudFlash(rayPosition, density) * fogDensity * transmittance;
		#endif

		vec3 shadow = texelFetch(shadowtex1, shadowTexel, 0).xxx;
		shadow = step(shadowPosition.z, shadow);
		#ifdef RAY_STAINED_GLASS_TINT
			float translucentShadow = step(shadowPosition.z, texelFetch(shadowtex0, shadowTexel, 0).x);
			if (shadow.x != translucentShadow) {
				vec3 shadowColorSample = pow4(texelFetch(shadowcolor0, shadowTexel, 0).rgb);
				shadow = shadowColorSample * (shadow - translucentShadow) + vec3(translucentShadow);
			}
		#endif

		float stepLengthSun = 5.0, sunlightOD = 0.0;
		vec3 checkPos = rayPosition;
		for (uint j = 0u; j < 4u; ++j, checkPos += endWorldLightVector * stepLengthSun) {
			float densityCheck = CalculateCloudDensity(checkPos);
			if (densityCheck < 1e-5) continue;
			sunlightOD += densityCheck * stepLengthSun;
			stepLengthSun *= 1.5;
		}

		float scatteringSun = oneMinus(expf(-sunlightOD * 3.0)) * oneMinus(LdotV01) + LdotV01;
		scatteringSun *= expf(-sunlightOD * 4.0) * phases1
					+ expf(-sunlightOD * 2.0)  	* phases2
					+ expf(-sunlightOD * 1.0)  	* phases3
					+ expf(-sunlightOD * 0.5) 	* phases4;

		shadow *= scatteringSun * 4.0;

		float stepTransmittance = expf(-fogDensity);

		float powder = rcp(fogDensity * 0.3 + 0.15) * fogDensity;
		powder = powder * oneMinus(LdotV01) + LdotV01;
		float fogSample = powder * transmittance * oneMinus(stepTransmittance);
		sunlightSample += shadow * fogSample;
		skylightSample += fogSample;

		transmittance *= stepTransmittance;

		if (transmittance < 1e-3) break;
	}

	vec3 cloudsLightColor = vec3(END_CLOUDS_LIGHT_COLOR_R, END_CLOUDS_LIGHT_COLOR_G, END_CLOUDS_LIGHT_COLOR_B) / 255.0;
	vec3 cloudsBaseColor = vec3(END_CLOUDS_COLOR_R, END_CLOUDS_COLOR_G, END_CLOUDS_COLOR_B) / 255.0;

	// Boost: сатурейшн относительно luma цвета, затем яркость
	float cloudsLightLuma = dot(cloudsLightColor, vec3(0.2126, 0.7152, 0.0722));
	cloudsLightColor = mix(vec3(cloudsLightLuma), cloudsLightColor, END_CLOUDS_COLOR_SATURATION_BOOST) * END_CLOUDS_COLOR_BRIGHTNESS_BOOST;

	float cloudsBaseLuma = dot(cloudsBaseColor, vec3(0.2126, 0.7152, 0.0722));
	cloudsBaseColor = mix(vec3(cloudsBaseLuma), cloudsBaseColor, END_CLOUDS_COLOR_SATURATION_BOOST) * END_CLOUDS_COLOR_BRIGHTNESS_BOOST;

	vec3 cloudsSunColor = cloudsLightColor * (1.0 - darkEnd * END_CLOUDS_LIGHT_DARK_END_FADE) * sunlightSample * END_CLOUDS_LIGHT_BRIGHTNESS;
	vec3 cloudsSkyColor = cloudsBaseColor * (1.0 - darkEnd * END_CLOUDS_DARK_END_FADE) * 0.04 * skylightSample * END_CLOUDS_SKY_TINT_STRENGTH;

	vec3 cloudsColor = cloudsSunColor + cloudsSkyColor;

	#ifdef END_CLOUDS_FLASHES
		vec3 cloudsFlashColor = vec3(END_CLOUDS_FLASH_COLOR_R, END_CLOUDS_FLASH_COLOR_G, END_CLOUDS_FLASH_COLOR_B) / 255.0;
		cloudsColor += cloudsFlashColor * flashSample;
	#endif

	cloudsColor = clamp(cloudsColor, vec3(0.0), vec3(END_CLOUDS_MAX_BRIGHTNESS));

	return vec4(cloudsColor, transmittance);
}

#endif // END_CLOUDS

//----// СЛОЙ 2 //--------------------------------------------------------------------------------//
// Полностью независимый от слоя 1: свой toggle, свои дефайны (END_CLOUDS2_*),
// своя функция плотности, свой марш. Цвет по умолчанию такой же, как у слоя 1
// (можно менять отдельно), высота по умолчанию выше слоя 1 (100-220 против 40-160).

#define END_CLOUDS_LAYER2 // Включить 2й слой облаков (независимо от 1го)

#ifdef END_CLOUDS_LAYER2

#define END_CLOUDS2_LIGHT_COLOR_R 110 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS2_LIGHT_COLOR_G 65 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS2_LIGHT_COLOR_B 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS2_LIGHT_BRIGHTNESS 100.0 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.25 2.50 2.75 3.00 3.50 4.00 4.50 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]
#define END_CLOUDS2_LIGHT_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#define END_CLOUDS2_MAX_BRIGHTNESS 3.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00 3.50 4.00 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]

// Цвет тот же, что у слоя 1 (можешь развести по-разному).
#define END_CLOUDS2_COLOR_R 100 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS2_COLOR_G 60 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS2_COLOR_B 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS2_DENSITY 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00 4.00 5.00]
#define END_CLOUDS2_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Насколько skylight (фоновый цвет неба, восход/закат) подмешивается в цвет облака.
// 0.0 = облако НЕ перекрашивается небом. 1.0 = как раньше.
#define END_CLOUDS2_SKY_TINT_STRENGTH 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0]

// --- Усиление цвета (boost) ---
#define END_CLOUDS2_COLOR_BRIGHTNESS_BOOST 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0]
#define END_CLOUDS2_COLOR_SATURATION_BOOST 1.0 //[0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0]

// --- Вспышки в облаке ---
#define END_CLOUDS2_FLASHES // Включить случайные цветные вспышки в этом слое облаков

#ifdef END_CLOUDS2_FLASHES
	#define END_CLOUDS2_FLASH_COLOR_R 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS2_FLASH_COLOR_G 40 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS2_FLASH_COLOR_B 220 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]

	#define END_CLOUDS2_FLASH_BRIGHTNESS 4.0 //[0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0 12.0 15.0 20.0]
	#define END_CLOUDS2_FLASH_FREQUENCY 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50]
	#define END_CLOUDS2_FLASH_SHARPNESS 8.0 //[1.0 2.0 3.0 4.0 5.0 6.0 8.0 10.0 15.0 20.0 30.0 50.0]
	#define END_CLOUDS2_FLASH_SPEED 0.15 //[0.00 0.02 0.05 0.08 0.10 0.15 0.20 0.30 0.40 0.50 0.70 1.00]
	#define END_CLOUDS2_FLASH_SCALE 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.15 0.20 0.30 0.40]
#endif


// Высота слоя 2 — по умолчанию повыше слоя 1 (100-220 против 40-160 у слоя 1).
#define END_CLOUDS2_HEIGHT_START 100 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200]
#define END_CLOUDS2_HEIGHT_END 220 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500]
#define END_CLOUDS2_HEIGHT_EDGE 20.0 //[0.0 5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0 60.0 80.0 100.0]

#define END_CLOUDS2_COVERAGE 0.46 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80]
#define END_CLOUDS2_SHARPNESS 50.0 //[10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 60.0 70.0 80.0 90.0 100.0 120.0 150.0]

#define END_CLOUDS2_SCALE 0.015 //[0.005 0.008 0.010 0.012 0.015 0.020 0.025 0.030 0.040 0.050]

#define END_CLOUDS2_WIND_SPEED 0.006 //[0.000 0.002 0.004 0.006 0.008 0.010 0.015 0.020 0.030 0.040 0.060 0.080 0.100]

#define END_CLOUDS2_MAX_DISTANCE 250.0 //[50.0 75.0 100.0 125.0 150.0 175.0 200.0 250.0 300.0 350.0 400.0 500.0 600.0 700.0 800.0 1000.0 1200.0 1500.0 2000.0 2500.0 3000.0 4000.0 5000.0 6000.0 8000.0 10000.0]
#define END_CLOUDS2_DISTANCE_FALLOFF 1.00 //[0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00 6.00 8.00 10.00]


// Маска вокруг центрального острова для слоя 2 — независимо от слоя 1.
#define END_CLOUDS2_ISLAND_MASK

#ifdef END_CLOUDS2_ISLAND_MASK
	#define END_CLOUDS2_ISLAND_CENTER_X 0.0
	#define END_CLOUDS2_ISLAND_CENTER_Z 0.0
	#define END_CLOUDS2_ISLAND_RADIUS 120.0 //[20.0 40.0 60.0 80.0 100.0 120.0 140.0 160.0 180.0 200.0 250.0 300.0 350.0 400.0 500.0]
	#define END_CLOUDS2_ISLAND_EDGE 60.0 //[0.0 10.0 20.0 30.0 40.0 50.0 60.0 80.0 100.0 120.0 150.0 200.0]
#endif

vec3 endClouds2Wind = vec3(1.0, 0.3, 0.6) * worldTimeCounter * (END_CLOUDS2_WIND_SPEED + darkEnd * 0.02);

float CalculateCloudDensity2(in vec3 rayPosition) {
	float lowerFade = smoothstep(float(END_CLOUDS2_HEIGHT_START) - END_CLOUDS2_HEIGHT_EDGE, float(END_CLOUDS2_HEIGHT_START), rayPosition.y);
	float upperFade = 1.0 - smoothstep(float(END_CLOUDS2_HEIGHT_END), float(END_CLOUDS2_HEIGHT_END) + END_CLOUDS2_HEIGHT_EDGE, rayPosition.y);
	float falloff = lowerFade * upperFade;

	#ifdef END_CLOUDS2_ISLAND_MASK
		float islandDist = length(rayPosition.xz - vec2(END_CLOUDS2_ISLAND_CENTER_X, END_CLOUDS2_ISLAND_CENTER_Z));
		float islandMask = 1.0 - smoothstep(END_CLOUDS2_ISLAND_RADIUS, END_CLOUDS2_ISLAND_RADIUS + max(END_CLOUDS2_ISLAND_EDGE, 0.001), islandDist);
		falloff *= islandMask;
	#endif

	rayPosition *= END_CLOUDS2_SCALE;
	rayPosition += endClouds2Wind;
	float noise = Get3DNoiseSmooth(rayPosition) * 0.5;
		rayPosition += endClouds2Wind;
	noise += Get3DNoiseSmooth(rayPosition * 3.6) * 0.25;
		rayPosition += endClouds2Wind;
	noise += Get3DNoiseSmooth(rayPosition * 12.0) * 0.125;
		rayPosition += endClouds2Wind;
	noise += Get3DNoiseSmooth(rayPosition * 56.0) * 0.0625;

	return saturate(falloff * (noise - END_CLOUDS2_COVERAGE + darkEnd) * END_CLOUDS2_SHARPNESS) * 0.2 * END_CLOUDS2_DENSITY;
}

#ifdef END_CLOUDS2_FLASHES
float CalculateCloudFlash2(in vec3 rayPosition, in float density) {
	if (density < 1e-4) return 0.0;

	vec3 flashPos = rayPosition * END_CLOUDS2_FLASH_SCALE;
	flashPos += vec3(3.17, -1.41, 2.63) * worldTimeCounter * END_CLOUDS2_FLASH_SPEED;

	float flashNoise = Get3DNoiseSmooth(flashPos);
	float flash = saturate((flashNoise - (1.0 - END_CLOUDS2_FLASH_FREQUENCY)) * END_CLOUDS2_FLASH_SHARPNESS);

	return flash * END_CLOUDS2_FLASH_BRIGHTNESS;
}
#endif

vec4 CalculateEndClouds2(in vec3 worldPos, in vec3 worldDir, in float dither) {
	float rayLength = min(END_CLOUDS2_MAX_DISTANCE, length(worldPos));

	#if defined DISTANT_HORIZONS || defined VOXY
		uint steps = END_FOG_SAMPLES;
	#else
		uint steps = uint(END_FOG_SAMPLES * 0.4 + rayLength * 0.1);
		     steps = min(steps, END_FOG_SAMPLES);
	#endif

	float rSteps = 1.0 / float(steps);
	float stepLength = rayLength * rSteps;

	float transmittance = 1.0;
	float LdotV = dot(endWorldLightVector, worldDir);
	float LdotV01 = LdotV * 0.5 + 0.5;
	float skylightSample = 0.0;
	#ifdef END_CLOUDS2_FLASHES
		float flashSample = 0.0;
	#endif

	vec3 rayStep = worldDir * stepLength,
		 rayPosition = rayStep * dither + gbufferModelViewInverse[3].xyz + cameraPosition;

	vec3 shadowStart = WorldPosToShadowPos(gbufferModelViewInverse[3].xyz),
		 shadowEnd = WorldPosToShadowPos(rayStep + gbufferModelViewInverse[3].xyz);

	vec3 shadowStep = shadowEnd - shadowStart,
		 shadowPosition = shadowStep * dither + shadowStart;
	vec3 sunlightSample = vec3(0.0);

	float phases1 = (HenyeyGreensteinPhase(LdotV, 0.5) 		   + HenyeyGreensteinPhase(LdotV, -0.3))		 * 0.5,
		  phases2 = (HenyeyGreensteinPhase(LdotV * 0.5, 0.5)   + HenyeyGreensteinPhase(LdotV * 0.5, -0.3))   * 0.25,
		  phases3 = (HenyeyGreensteinPhase(LdotV * 0.25, 0.5)  + HenyeyGreensteinPhase(LdotV * 0.25, -0.3))  * 0.125,
		  phases4 = (HenyeyGreensteinPhase(LdotV * 0.125, 0.5) + HenyeyGreensteinPhase(LdotV * 0.125, -0.3)) * 0.0625;

	uint i = 0u;
	while (++i < steps) {
		rayPosition += rayStep, shadowPosition += shadowStep;

		vec2 shadowProjPos = DistortShadowSpace(shadowPosition.xy);
		if (saturate(shadowProjPos) != shadowProjPos) continue;
		ivec2 shadowTexel = ivec2(shadowProjPos * realShadowMapRes);

		float density = CalculateCloudDensity2(rayPosition);
		density *= exp2(-distance(rayPosition, cameraPosition) * END_CLOUDS2_DISTANCE_FALLOFF * 0.001);

		if (density < 1e-5) continue;
		float fogDensity = density * stepLength;

		#ifdef END_CLOUDS2_FLASHES
			flashSample += CalculateCloudFlash2(rayPosition, density) * fogDensity * transmittance;
		#endif

		vec3 shadow = texelFetch(shadowtex1, shadowTexel, 0).xxx;
		shadow = step(shadowPosition.z, shadow);
		#ifdef RAY_STAINED_GLASS_TINT
			float translucentShadow = step(shadowPosition.z, texelFetch(shadowtex0, shadowTexel, 0).x);
			if (shadow.x != translucentShadow) {
				vec3 shadowColorSample = pow4(texelFetch(shadowcolor0, shadowTexel, 0).rgb);
				shadow = shadowColorSample * (shadow - translucentShadow) + vec3(translucentShadow);
			}
		#endif

		float stepLengthSun = 5.0, sunlightOD = 0.0;
		vec3 checkPos = rayPosition;
		for (uint j = 0u; j < 4u; ++j, checkPos += endWorldLightVector * stepLengthSun) {
			float densityCheck = CalculateCloudDensity2(checkPos);
			if (densityCheck < 1e-5) continue;
			sunlightOD += densityCheck * stepLengthSun;
			stepLengthSun *= 1.5;
		}

		float scatteringSun = oneMinus(expf(-sunlightOD * 3.0)) * oneMinus(LdotV01) + LdotV01;
		scatteringSun *= expf(-sunlightOD * 4.0) * phases1
					+ expf(-sunlightOD * 2.0)  	* phases2
					+ expf(-sunlightOD * 1.0)  	* phases3
					+ expf(-sunlightOD * 0.5) 	* phases4;

		shadow *= scatteringSun * 4.0;

		float stepTransmittance = expf(-fogDensity);

		float powder = rcp(fogDensity * 0.3 + 0.15) * fogDensity;
		powder = powder * oneMinus(LdotV01) + LdotV01;
		float fogSample = powder * transmittance * oneMinus(stepTransmittance);
		sunlightSample += shadow * fogSample;
		skylightSample += fogSample;

		transmittance *= stepTransmittance;

		if (transmittance < 1e-3) break;
	}

	vec3 clouds2LightColor = vec3(END_CLOUDS2_LIGHT_COLOR_R, END_CLOUDS2_LIGHT_COLOR_G, END_CLOUDS2_LIGHT_COLOR_B) / 255.0;
	vec3 clouds2BaseColor = vec3(END_CLOUDS2_COLOR_R, END_CLOUDS2_COLOR_G, END_CLOUDS2_COLOR_B) / 255.0;

	// Boost: сатурейшн относительно luma цвета, затем яркость
	float clouds2LightLuma = dot(clouds2LightColor, vec3(0.2126, 0.7152, 0.0722));
	clouds2LightColor = mix(vec3(clouds2LightLuma), clouds2LightColor, END_CLOUDS2_COLOR_SATURATION_BOOST) * END_CLOUDS2_COLOR_BRIGHTNESS_BOOST;

	float clouds2BaseLuma = dot(clouds2BaseColor, vec3(0.2126, 0.7152, 0.0722));
	clouds2BaseColor = mix(vec3(clouds2BaseLuma), clouds2BaseColor, END_CLOUDS2_COLOR_SATURATION_BOOST) * END_CLOUDS2_COLOR_BRIGHTNESS_BOOST;

	vec3 clouds2SunColor = clouds2LightColor * (1.0 - darkEnd * END_CLOUDS2_LIGHT_DARK_END_FADE) * sunlightSample * END_CLOUDS2_LIGHT_BRIGHTNESS;
	vec3 clouds2SkyColor = clouds2BaseColor * (1.0 - darkEnd * END_CLOUDS2_DARK_END_FADE) * 0.04 * skylightSample * END_CLOUDS2_SKY_TINT_STRENGTH;

	vec3 clouds2Color = clouds2SunColor + clouds2SkyColor;

	#ifdef END_CLOUDS2_FLASHES
		vec3 clouds2FlashColor = vec3(END_CLOUDS2_FLASH_COLOR_R, END_CLOUDS2_FLASH_COLOR_G, END_CLOUDS2_FLASH_COLOR_B) / 255.0;
		clouds2Color += clouds2FlashColor * flashSample;
	#endif

	clouds2Color = clamp(clouds2Color, vec3(0.0), vec3(END_CLOUDS2_MAX_BRIGHTNESS));

	return vec4(clouds2Color, transmittance);
}

#endif // END_CLOUDS_LAYER2

//----// СЛОЙ 3 //--------------------------------------------------------------------------------//
// Полностью независимый от слоёв 1 и 2: свой toggle, свои дефайны (END_CLOUDS3_*),
// своя функция плотности, свой марш. Высота по умолчанию выше слоя 2 (160-280).

//#define END_CLOUDS_LAYER3 // Включить 3й слой облаков (независимо от остальных)

#ifdef END_CLOUDS_LAYER3

#define END_CLOUDS3_LIGHT_COLOR_R 110 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS3_LIGHT_COLOR_G 65 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS3_LIGHT_COLOR_B 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS3_LIGHT_BRIGHTNESS 100.0 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.25 2.50 2.75 3.00 3.50 4.00 4.50 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]
#define END_CLOUDS3_LIGHT_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#define END_CLOUDS3_MAX_BRIGHTNESS 3.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00 3.50 4.00 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]

#define END_CLOUDS3_COLOR_R 100 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS3_COLOR_G 60 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS3_COLOR_B 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS3_DENSITY 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00 4.00 5.00]
#define END_CLOUDS3_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Насколько skylight (фоновый цвет неба, восход/закат) подмешивается в цвет облака.
// 0.0 = облако НЕ перекрашивается небом. 1.0 = как раньше.
#define END_CLOUDS3_SKY_TINT_STRENGTH 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0]

// --- Усиление цвета (boost) ---
#define END_CLOUDS3_COLOR_BRIGHTNESS_BOOST 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0]
#define END_CLOUDS3_COLOR_SATURATION_BOOST 1.0 //[0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0]

// --- Вспышки в облаке ---
#define END_CLOUDS3_FLASHES // Включить случайные цветные вспышки в этом слое облаков

#ifdef END_CLOUDS3_FLASHES
	#define END_CLOUDS3_FLASH_COLOR_R 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS3_FLASH_COLOR_G 40 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS3_FLASH_COLOR_B 220 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]

	#define END_CLOUDS3_FLASH_BRIGHTNESS 4.0 //[0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0 12.0 15.0 20.0]
	#define END_CLOUDS3_FLASH_FREQUENCY 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50]
	#define END_CLOUDS3_FLASH_SHARPNESS 8.0 //[1.0 2.0 3.0 4.0 5.0 6.0 8.0 10.0 15.0 20.0 30.0 50.0]
	#define END_CLOUDS3_FLASH_SPEED 0.15 //[0.00 0.02 0.05 0.08 0.10 0.15 0.20 0.30 0.40 0.50 0.70 1.00]
	#define END_CLOUDS3_FLASH_SCALE 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.15 0.20 0.30 0.40]
#endif


// Высота слоя 3 — по умолчанию повыше слоя 2 (160-280 против 100-220 у слоя 2).
#define END_CLOUDS3_HEIGHT_START 160 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200]
#define END_CLOUDS3_HEIGHT_END 280 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500]
#define END_CLOUDS3_HEIGHT_EDGE 20.0 //[0.0 5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0 60.0 80.0 100.0]

#define END_CLOUDS3_COVERAGE 0.50 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80]
#define END_CLOUDS3_SHARPNESS 50.0 //[10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 60.0 70.0 80.0 90.0 100.0 120.0 150.0]

#define END_CLOUDS3_SCALE 0.015 //[0.005 0.008 0.010 0.012 0.015 0.020 0.025 0.030 0.040 0.050]

#define END_CLOUDS3_WIND_SPEED 0.007 //[0.000 0.002 0.004 0.006 0.008 0.010 0.015 0.020 0.030 0.040 0.060 0.080 0.100]

#define END_CLOUDS3_MAX_DISTANCE 250.0 //[50.0 75.0 100.0 125.0 150.0 175.0 200.0 250.0 300.0 350.0 400.0 500.0 600.0 700.0 800.0 1000.0 1200.0 1500.0 2000.0 2500.0 3000.0 4000.0 5000.0 6000.0 8000.0 10000.0]
#define END_CLOUDS3_DISTANCE_FALLOFF 1.00 //[0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00 6.00 8.00 10.00]


// Маска вокруг центрального острова для слоя 3 — независимо от остальных слоёв.
#define END_CLOUDS3_ISLAND_MASK

#ifdef END_CLOUDS3_ISLAND_MASK
	#define END_CLOUDS3_ISLAND_CENTER_X 0.0
	#define END_CLOUDS3_ISLAND_CENTER_Z 0.0
	#define END_CLOUDS3_ISLAND_RADIUS 120.0 //[20.0 40.0 60.0 80.0 100.0 120.0 140.0 160.0 180.0 200.0 250.0 300.0 350.0 400.0 500.0]
	#define END_CLOUDS3_ISLAND_EDGE 60.0 //[0.0 10.0 20.0 30.0 40.0 50.0 60.0 80.0 100.0 120.0 150.0 200.0]
#endif

vec3 endClouds3Wind = vec3(1.0, 0.3, 0.6) * worldTimeCounter * (END_CLOUDS3_WIND_SPEED + darkEnd * 0.02);

float CalculateCloudDensity3(in vec3 rayPosition) {
	float lowerFade = smoothstep(float(END_CLOUDS3_HEIGHT_START) - END_CLOUDS3_HEIGHT_EDGE, float(END_CLOUDS3_HEIGHT_START), rayPosition.y);
	float upperFade = 1.0 - smoothstep(float(END_CLOUDS3_HEIGHT_END), float(END_CLOUDS3_HEIGHT_END) + END_CLOUDS3_HEIGHT_EDGE, rayPosition.y);
	float falloff = lowerFade * upperFade;

	#ifdef END_CLOUDS3_ISLAND_MASK
		float islandDist = length(rayPosition.xz - vec2(END_CLOUDS3_ISLAND_CENTER_X, END_CLOUDS3_ISLAND_CENTER_Z));
		float islandMask = 1.0 - smoothstep(END_CLOUDS3_ISLAND_RADIUS, END_CLOUDS3_ISLAND_RADIUS + max(END_CLOUDS3_ISLAND_EDGE, 0.001), islandDist);
		falloff *= islandMask;
	#endif

	rayPosition *= END_CLOUDS3_SCALE;
	rayPosition += endClouds3Wind;
	float noise = Get3DNoiseSmooth(rayPosition) * 0.5;
		rayPosition += endClouds3Wind;
	noise += Get3DNoiseSmooth(rayPosition * 3.6) * 0.25;
		rayPosition += endClouds3Wind;
	noise += Get3DNoiseSmooth(rayPosition * 12.0) * 0.125;
		rayPosition += endClouds3Wind;
	noise += Get3DNoiseSmooth(rayPosition * 56.0) * 0.0625;

	return saturate(falloff * (noise - END_CLOUDS3_COVERAGE + darkEnd) * END_CLOUDS3_SHARPNESS) * 0.2 * END_CLOUDS3_DENSITY;
}

#ifdef END_CLOUDS3_FLASHES
float CalculateCloudFlash3(in vec3 rayPosition, in float density) {
	if (density < 1e-4) return 0.0;

	vec3 flashPos = rayPosition * END_CLOUDS3_FLASH_SCALE;
	flashPos += vec3(3.17, -1.41, 2.63) * worldTimeCounter * END_CLOUDS3_FLASH_SPEED;

	float flashNoise = Get3DNoiseSmooth(flashPos);
	float flash = saturate((flashNoise - (1.0 - END_CLOUDS3_FLASH_FREQUENCY)) * END_CLOUDS3_FLASH_SHARPNESS);

	return flash * END_CLOUDS3_FLASH_BRIGHTNESS;
}
#endif

vec4 CalculateEndClouds3(in vec3 worldPos, in vec3 worldDir, in float dither) {
	float rayLength = min(END_CLOUDS3_MAX_DISTANCE, length(worldPos));

	#if defined DISTANT_HORIZONS || defined VOXY
		uint steps = END_FOG_SAMPLES;
	#else
		uint steps = uint(END_FOG_SAMPLES * 0.4 + rayLength * 0.1);
		     steps = min(steps, END_FOG_SAMPLES);
	#endif

	float rSteps = 1.0 / float(steps);
	float stepLength = rayLength * rSteps;

	float transmittance = 1.0;
	float LdotV = dot(endWorldLightVector, worldDir);
	float LdotV01 = LdotV * 0.5 + 0.5;
	float skylightSample = 0.0;
	#ifdef END_CLOUDS3_FLASHES
		float flashSample = 0.0;
	#endif

	vec3 rayStep = worldDir * stepLength,
		 rayPosition = rayStep * dither + gbufferModelViewInverse[3].xyz + cameraPosition;

	vec3 shadowStart = WorldPosToShadowPos(gbufferModelViewInverse[3].xyz),
		 shadowEnd = WorldPosToShadowPos(rayStep + gbufferModelViewInverse[3].xyz);

	vec3 shadowStep = shadowEnd - shadowStart,
		 shadowPosition = shadowStep * dither + shadowStart;
	vec3 sunlightSample = vec3(0.0);

	float phases1 = (HenyeyGreensteinPhase(LdotV, 0.5) 		   + HenyeyGreensteinPhase(LdotV, -0.3))		 * 0.5,
		  phases2 = (HenyeyGreensteinPhase(LdotV * 0.5, 0.5)   + HenyeyGreensteinPhase(LdotV * 0.5, -0.3))   * 0.25,
		  phases3 = (HenyeyGreensteinPhase(LdotV * 0.25, 0.5)  + HenyeyGreensteinPhase(LdotV * 0.25, -0.3))  * 0.125,
		  phases4 = (HenyeyGreensteinPhase(LdotV * 0.125, 0.5) + HenyeyGreensteinPhase(LdotV * 0.125, -0.3)) * 0.0625;

	uint i = 0u;
	while (++i < steps) {
		rayPosition += rayStep, shadowPosition += shadowStep;

		vec2 shadowProjPos = DistortShadowSpace(shadowPosition.xy);
		if (saturate(shadowProjPos) != shadowProjPos) continue;
		ivec2 shadowTexel = ivec2(shadowProjPos * realShadowMapRes);

		float density = CalculateCloudDensity3(rayPosition);
		density *= exp2(-distance(rayPosition, cameraPosition) * END_CLOUDS3_DISTANCE_FALLOFF * 0.001);

		if (density < 1e-5) continue;
		float fogDensity = density * stepLength;

		#ifdef END_CLOUDS3_FLASHES
			flashSample += CalculateCloudFlash3(rayPosition, density) * fogDensity * transmittance;
		#endif

		vec3 shadow = texelFetch(shadowtex1, shadowTexel, 0).xxx;
		shadow = step(shadowPosition.z, shadow);
		#ifdef RAY_STAINED_GLASS_TINT
			float translucentShadow = step(shadowPosition.z, texelFetch(shadowtex0, shadowTexel, 0).x);
			if (shadow.x != translucentShadow) {
				vec3 shadowColorSample = pow4(texelFetch(shadowcolor0, shadowTexel, 0).rgb);
				shadow = shadowColorSample * (shadow - translucentShadow) + vec3(translucentShadow);
			}
		#endif

		float stepLengthSun = 5.0, sunlightOD = 0.0;
		vec3 checkPos = rayPosition;
		for (uint j = 0u; j < 4u; ++j, checkPos += endWorldLightVector * stepLengthSun) {
			float densityCheck = CalculateCloudDensity3(checkPos);
			if (densityCheck < 1e-5) continue;
			sunlightOD += densityCheck * stepLengthSun;
			stepLengthSun *= 1.5;
		}

		float scatteringSun = oneMinus(expf(-sunlightOD * 3.0)) * oneMinus(LdotV01) + LdotV01;
		scatteringSun *= expf(-sunlightOD * 4.0) * phases1
					+ expf(-sunlightOD * 2.0)  	* phases2
					+ expf(-sunlightOD * 1.0)  	* phases3
					+ expf(-sunlightOD * 0.5) 	* phases4;

		shadow *= scatteringSun * 4.0;

		float stepTransmittance = expf(-fogDensity);

		float powder = rcp(fogDensity * 0.3 + 0.15) * fogDensity;
		powder = powder * oneMinus(LdotV01) + LdotV01;
		float fogSample = powder * transmittance * oneMinus(stepTransmittance);
		sunlightSample += shadow * fogSample;
		skylightSample += fogSample;

		transmittance *= stepTransmittance;

		if (transmittance < 1e-3) break;
	}

	vec3 clouds3LightColor = vec3(END_CLOUDS3_LIGHT_COLOR_R, END_CLOUDS3_LIGHT_COLOR_G, END_CLOUDS3_LIGHT_COLOR_B) / 255.0;
	vec3 clouds3BaseColor = vec3(END_CLOUDS3_COLOR_R, END_CLOUDS3_COLOR_G, END_CLOUDS3_COLOR_B) / 255.0;

	// Boost: сатурейшн относительно luma цвета, затем яркость
	float clouds3LightLuma = dot(clouds3LightColor, vec3(0.2126, 0.7152, 0.0722));
	clouds3LightColor = mix(vec3(clouds3LightLuma), clouds3LightColor, END_CLOUDS3_COLOR_SATURATION_BOOST) * END_CLOUDS3_COLOR_BRIGHTNESS_BOOST;

	float clouds3BaseLuma = dot(clouds3BaseColor, vec3(0.2126, 0.7152, 0.0722));
	clouds3BaseColor = mix(vec3(clouds3BaseLuma), clouds3BaseColor, END_CLOUDS3_COLOR_SATURATION_BOOST) * END_CLOUDS3_COLOR_BRIGHTNESS_BOOST;

	vec3 clouds3SunColor = clouds3LightColor * (1.0 - darkEnd * END_CLOUDS3_LIGHT_DARK_END_FADE) * sunlightSample * END_CLOUDS3_LIGHT_BRIGHTNESS;
	vec3 clouds3SkyColor = clouds3BaseColor * (1.0 - darkEnd * END_CLOUDS3_DARK_END_FADE) * 0.04 * skylightSample * END_CLOUDS3_SKY_TINT_STRENGTH;

	vec3 clouds3Color = clouds3SunColor + clouds3SkyColor;

	#ifdef END_CLOUDS3_FLASHES
		vec3 clouds3FlashColor = vec3(END_CLOUDS3_FLASH_COLOR_R, END_CLOUDS3_FLASH_COLOR_G, END_CLOUDS3_FLASH_COLOR_B) / 255.0;
		clouds3Color += clouds3FlashColor * flashSample;
	#endif

	clouds3Color = clamp(clouds3Color, vec3(0.0), vec3(END_CLOUDS3_MAX_BRIGHTNESS));

	return vec4(clouds3Color, transmittance);
}

#endif // END_CLOUDS_LAYER3

//----// СЛОЙ 4 //--------------------------------------------------------------------------------//
// Полностью независимый от остальных слоёв: свой toggle, свои дефайны (END_CLOUDS4_*),
// своя функция плотности, свой марш. Высота по умолчанию выше слоя 3 (220-340).

//#define END_CLOUDS_LAYER4 // Включить 4й слой облаков (независимо от остальных)

#ifdef END_CLOUDS_LAYER4

#define END_CLOUDS4_LIGHT_COLOR_R 110 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS4_LIGHT_COLOR_G 65 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS4_LIGHT_COLOR_B 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS4_LIGHT_BRIGHTNESS 100.0 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.25 2.50 2.75 3.00 3.50 4.00 4.50 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]
#define END_CLOUDS4_LIGHT_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#define END_CLOUDS4_MAX_BRIGHTNESS 3.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00 3.50 4.00 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]

#define END_CLOUDS4_COLOR_R 100 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS4_COLOR_G 60 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS4_COLOR_B 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS4_DENSITY 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00 4.00 5.00]
#define END_CLOUDS4_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Насколько skylight (фоновый цвет неба, восход/закат) подмешивается в цвет облака.
// 0.0 = облако НЕ перекрашивается небом. 1.0 = как раньше.
#define END_CLOUDS4_SKY_TINT_STRENGTH 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0]

// --- Усиление цвета (boost) ---
#define END_CLOUDS4_COLOR_BRIGHTNESS_BOOST 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0]
#define END_CLOUDS4_COLOR_SATURATION_BOOST 1.0 //[0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0]

// --- Вспышки в облаке ---
#define END_CLOUDS4_FLASHES // Включить случайные цветные вспышки в этом слое облаков

#ifdef END_CLOUDS4_FLASHES
	#define END_CLOUDS4_FLASH_COLOR_R 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS4_FLASH_COLOR_G 40 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS4_FLASH_COLOR_B 220 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]

	#define END_CLOUDS4_FLASH_BRIGHTNESS 4.0 //[0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0 12.0 15.0 20.0]
	#define END_CLOUDS4_FLASH_FREQUENCY 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50]
	#define END_CLOUDS4_FLASH_SHARPNESS 8.0 //[1.0 2.0 3.0 4.0 5.0 6.0 8.0 10.0 15.0 20.0 30.0 50.0]
	#define END_CLOUDS4_FLASH_SPEED 0.15 //[0.00 0.02 0.05 0.08 0.10 0.15 0.20 0.30 0.40 0.50 0.70 1.00]
	#define END_CLOUDS4_FLASH_SCALE 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.15 0.20 0.30 0.40]
#endif


// Высота слоя 4 — по умолчанию повыше слоя 3 (220-340 против 160-280 у слоя 3).
#define END_CLOUDS4_HEIGHT_START 20 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200]
#define END_CLOUDS4_HEIGHT_END 100 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500]
#define END_CLOUDS4_HEIGHT_EDGE 20.0 //[0.0 5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0 60.0 80.0 100.0]

#define END_CLOUDS4_COVERAGE 0.49 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80]
#define END_CLOUDS4_SHARPNESS 50.0 //[10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 60.0 70.0 80.0 90.0 100.0 120.0 150.0]

#define END_CLOUDS4_SCALE 0.015 //[0.005 0.008 0.010 0.012 0.015 0.020 0.025 0.030 0.040 0.050]

#define END_CLOUDS4_WIND_SPEED 0.008 //[0.000 0.002 0.004 0.006 0.008 0.010 0.015 0.020 0.030 0.040 0.060 0.080 0.100]

#define END_CLOUDS4_MAX_DISTANCE 250.0 //[50.0 75.0 100.0 125.0 150.0 175.0 200.0 250.0 300.0 350.0 400.0 500.0 600.0 700.0 800.0 1000.0 1200.0 1500.0 2000.0 2500.0 3000.0 4000.0 5000.0 6000.0 8000.0 10000.0]
#define END_CLOUDS4_DISTANCE_FALLOFF 1.00 //[0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00 6.00 8.00 10.00]


// Маска вокруг центрального острова для слоя 4 — независимо от остальных слоёв.
#define END_CLOUDS4_ISLAND_MASK

#ifdef END_CLOUDS4_ISLAND_MASK
	#define END_CLOUDS4_ISLAND_CENTER_X 0.0
	#define END_CLOUDS4_ISLAND_CENTER_Z 0.0
	#define END_CLOUDS4_ISLAND_RADIUS 120.0 //[20.0 40.0 60.0 80.0 100.0 120.0 140.0 160.0 180.0 200.0 250.0 300.0 350.0 400.0 500.0]
	#define END_CLOUDS4_ISLAND_EDGE 60.0 //[0.0 10.0 20.0 30.0 40.0 50.0 60.0 80.0 100.0 120.0 150.0 200.0]
#endif

vec3 endClouds4Wind = vec3(1.0, 0.3, 0.6) * worldTimeCounter * (END_CLOUDS4_WIND_SPEED + darkEnd * 0.02);

float CalculateCloudDensity4(in vec3 rayPosition) {
	float lowerFade = smoothstep(float(END_CLOUDS4_HEIGHT_START) - END_CLOUDS4_HEIGHT_EDGE, float(END_CLOUDS4_HEIGHT_START), rayPosition.y);
	float upperFade = 1.0 - smoothstep(float(END_CLOUDS4_HEIGHT_END), float(END_CLOUDS4_HEIGHT_END) + END_CLOUDS4_HEIGHT_EDGE, rayPosition.y);
	float falloff = lowerFade * upperFade;

	#ifdef END_CLOUDS4_ISLAND_MASK
		float islandDist = length(rayPosition.xz - vec2(END_CLOUDS4_ISLAND_CENTER_X, END_CLOUDS4_ISLAND_CENTER_Z));
		float islandMask = 1.0 - smoothstep(END_CLOUDS4_ISLAND_RADIUS, END_CLOUDS4_ISLAND_RADIUS + max(END_CLOUDS4_ISLAND_EDGE, 0.001), islandDist);
		falloff *= islandMask;
	#endif

	rayPosition *= END_CLOUDS4_SCALE;
	rayPosition += endClouds4Wind;
	float noise = Get3DNoiseSmooth(rayPosition) * 0.5;
		rayPosition += endClouds4Wind;
	noise += Get3DNoiseSmooth(rayPosition * 3.6) * 0.25;
		rayPosition += endClouds4Wind;
	noise += Get3DNoiseSmooth(rayPosition * 12.0) * 0.125;
		rayPosition += endClouds4Wind;
	noise += Get3DNoiseSmooth(rayPosition * 56.0) * 0.0625;

	return saturate(falloff * (noise - END_CLOUDS4_COVERAGE + darkEnd) * END_CLOUDS4_SHARPNESS) * 0.2 * END_CLOUDS4_DENSITY;
}

#ifdef END_CLOUDS4_FLASHES
float CalculateCloudFlash4(in vec3 rayPosition, in float density) {
	if (density < 1e-4) return 0.0;

	vec3 flashPos = rayPosition * END_CLOUDS4_FLASH_SCALE;
	flashPos += vec3(3.17, -1.41, 2.63) * worldTimeCounter * END_CLOUDS4_FLASH_SPEED;

	float flashNoise = Get3DNoiseSmooth(flashPos);
	float flash = saturate((flashNoise - (1.0 - END_CLOUDS4_FLASH_FREQUENCY)) * END_CLOUDS4_FLASH_SHARPNESS);

	return flash * END_CLOUDS4_FLASH_BRIGHTNESS;
}
#endif

vec4 CalculateEndClouds4(in vec3 worldPos, in vec3 worldDir, in float dither) {
	float rayLength = min(END_CLOUDS4_MAX_DISTANCE, length(worldPos));

	#if defined DISTANT_HORIZONS || defined VOXY
		uint steps = END_FOG_SAMPLES;
	#else
		uint steps = uint(END_FOG_SAMPLES * 0.4 + rayLength * 0.1);
		     steps = min(steps, END_FOG_SAMPLES);
	#endif

	float rSteps = 1.0 / float(steps);
	float stepLength = rayLength * rSteps;

	float transmittance = 1.0;
	float LdotV = dot(endWorldLightVector, worldDir);
	float LdotV01 = LdotV * 0.5 + 0.5;
	float skylightSample = 0.0;
	#ifdef END_CLOUDS4_FLASHES
		float flashSample = 0.0;
	#endif

	vec3 rayStep = worldDir * stepLength,
		 rayPosition = rayStep * dither + gbufferModelViewInverse[3].xyz + cameraPosition;

	vec3 shadowStart = WorldPosToShadowPos(gbufferModelViewInverse[3].xyz),
		 shadowEnd = WorldPosToShadowPos(rayStep + gbufferModelViewInverse[3].xyz);

	vec3 shadowStep = shadowEnd - shadowStart,
		 shadowPosition = shadowStep * dither + shadowStart;
	vec3 sunlightSample = vec3(0.0);

	float phases1 = (HenyeyGreensteinPhase(LdotV, 0.5) 		   + HenyeyGreensteinPhase(LdotV, -0.3))		 * 0.5,
		  phases2 = (HenyeyGreensteinPhase(LdotV * 0.5, 0.5)   + HenyeyGreensteinPhase(LdotV * 0.5, -0.3))   * 0.25,
		  phases3 = (HenyeyGreensteinPhase(LdotV * 0.25, 0.5)  + HenyeyGreensteinPhase(LdotV * 0.25, -0.3))  * 0.125,
		  phases4 = (HenyeyGreensteinPhase(LdotV * 0.125, 0.5) + HenyeyGreensteinPhase(LdotV * 0.125, -0.3)) * 0.0625;

	uint i = 0u;
	while (++i < steps) {
		rayPosition += rayStep, shadowPosition += shadowStep;

		vec2 shadowProjPos = DistortShadowSpace(shadowPosition.xy);
		if (saturate(shadowProjPos) != shadowProjPos) continue;
		ivec2 shadowTexel = ivec2(shadowProjPos * realShadowMapRes);

		float density = CalculateCloudDensity4(rayPosition);
		density *= exp2(-distance(rayPosition, cameraPosition) * END_CLOUDS4_DISTANCE_FALLOFF * 0.001);

		if (density < 1e-5) continue;
		float fogDensity = density * stepLength;

		#ifdef END_CLOUDS4_FLASHES
			flashSample += CalculateCloudFlash4(rayPosition, density) * fogDensity * transmittance;
		#endif

		vec3 shadow = texelFetch(shadowtex1, shadowTexel, 0).xxx;
		shadow = step(shadowPosition.z, shadow);
		#ifdef RAY_STAINED_GLASS_TINT
			float translucentShadow = step(shadowPosition.z, texelFetch(shadowtex0, shadowTexel, 0).x);
			if (shadow.x != translucentShadow) {
				vec3 shadowColorSample = pow4(texelFetch(shadowcolor0, shadowTexel, 0).rgb);
				shadow = shadowColorSample * (shadow - translucentShadow) + vec3(translucentShadow);
			}
		#endif

		float stepLengthSun = 5.0, sunlightOD = 0.0;
		vec3 checkPos = rayPosition;
		for (uint j = 0u; j < 4u; ++j, checkPos += endWorldLightVector * stepLengthSun) {
			float densityCheck = CalculateCloudDensity4(checkPos);
			if (densityCheck < 1e-5) continue;
			sunlightOD += densityCheck * stepLengthSun;
			stepLengthSun *= 1.5;
		}

		float scatteringSun = oneMinus(expf(-sunlightOD * 3.0)) * oneMinus(LdotV01) + LdotV01;
		scatteringSun *= expf(-sunlightOD * 4.0) * phases1
					+ expf(-sunlightOD * 2.0)  	* phases2
					+ expf(-sunlightOD * 1.0)  	* phases3
					+ expf(-sunlightOD * 0.5) 	* phases4;

		shadow *= scatteringSun * 4.0;

		float stepTransmittance = expf(-fogDensity);

		float powder = rcp(fogDensity * 0.3 + 0.15) * fogDensity;
		powder = powder * oneMinus(LdotV01) + LdotV01;
		float fogSample = powder * transmittance * oneMinus(stepTransmittance);
		sunlightSample += shadow * fogSample;
		skylightSample += fogSample;

		transmittance *= stepTransmittance;

		if (transmittance < 1e-3) break;
	}

	vec3 clouds4LightColor = vec3(END_CLOUDS4_LIGHT_COLOR_R, END_CLOUDS4_LIGHT_COLOR_G, END_CLOUDS4_LIGHT_COLOR_B) / 255.0;
	vec3 clouds4BaseColor = vec3(END_CLOUDS4_COLOR_R, END_CLOUDS4_COLOR_G, END_CLOUDS4_COLOR_B) / 255.0;

	// Boost: сатурейшн относительно luma цвета, затем яркость
	float clouds4LightLuma = dot(clouds4LightColor, vec3(0.2126, 0.7152, 0.0722));
	clouds4LightColor = mix(vec3(clouds4LightLuma), clouds4LightColor, END_CLOUDS4_COLOR_SATURATION_BOOST) * END_CLOUDS4_COLOR_BRIGHTNESS_BOOST;

	float clouds4BaseLuma = dot(clouds4BaseColor, vec3(0.2126, 0.7152, 0.0722));
	clouds4BaseColor = mix(vec3(clouds4BaseLuma), clouds4BaseColor, END_CLOUDS4_COLOR_SATURATION_BOOST) * END_CLOUDS4_COLOR_BRIGHTNESS_BOOST;

	vec3 clouds4SunColor = clouds4LightColor * (1.0 - darkEnd * END_CLOUDS4_LIGHT_DARK_END_FADE) * sunlightSample * END_CLOUDS4_LIGHT_BRIGHTNESS;
	vec3 clouds4SkyColor = clouds4BaseColor * (1.0 - darkEnd * END_CLOUDS4_DARK_END_FADE) * 0.04 * skylightSample * END_CLOUDS4_SKY_TINT_STRENGTH;

	vec3 clouds4Color = clouds4SunColor + clouds4SkyColor;

	#ifdef END_CLOUDS4_FLASHES
		vec3 clouds4FlashColor = vec3(END_CLOUDS4_FLASH_COLOR_R, END_CLOUDS4_FLASH_COLOR_G, END_CLOUDS4_FLASH_COLOR_B) / 255.0;
		clouds4Color += clouds4FlashColor * flashSample;
	#endif

	clouds4Color = clamp(clouds4Color, vec3(0.0), vec3(END_CLOUDS4_MAX_BRIGHTNESS));

	return vec4(clouds4Color, transmittance);
}

#endif // END_CLOUDS_LAYER4

//----// СЛОЙ 5 //--------------------------------------------------------------------------------//
// Полностью независимый от остальных слоёв: свой toggle, свои дефайны (END_CLOUDS5_*),
// своя функция плотности, свой марш. Высота по умолчанию выше слоя 4 (280-400).

//#define END_CLOUDS_LAYER5 // Включить 5й слой облаков (независимо от остальных)

#ifdef END_CLOUDS_LAYER5

#define END_CLOUDS5_LIGHT_COLOR_R 110 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS5_LIGHT_COLOR_G 65 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS5_LIGHT_COLOR_B 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS5_LIGHT_BRIGHTNESS 100.0 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.25 2.50 2.75 3.00 3.50 4.00 4.50 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]
#define END_CLOUDS5_LIGHT_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#define END_CLOUDS5_MAX_BRIGHTNESS 3.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00 3.50 4.00 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]

#define END_CLOUDS5_COLOR_R 100 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS5_COLOR_G 60 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS5_COLOR_B 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS5_DENSITY 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00 4.00 5.00]
#define END_CLOUDS5_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Насколько skylight (фоновый цвет неба, восход/закат) подмешивается в цвет облака.
// 0.0 = облако НЕ перекрашивается небом. 1.0 = как раньше.
#define END_CLOUDS5_SKY_TINT_STRENGTH 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0]

// --- Усиление цвета (boost) ---
#define END_CLOUDS5_COLOR_BRIGHTNESS_BOOST 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0]
#define END_CLOUDS5_COLOR_SATURATION_BOOST 1.0 //[0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0]

// --- Вспышки в облаке ---
#define END_CLOUDS5_FLASHES // Включить случайные цветные вспышки в этом слое облаков

#ifdef END_CLOUDS5_FLASHES
	#define END_CLOUDS5_FLASH_COLOR_R 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS5_FLASH_COLOR_G 40 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS5_FLASH_COLOR_B 220 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]

	#define END_CLOUDS5_FLASH_BRIGHTNESS 4.0 //[0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0 12.0 15.0 20.0]
	#define END_CLOUDS5_FLASH_FREQUENCY 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50]
	#define END_CLOUDS5_FLASH_SHARPNESS 8.0 //[1.0 2.0 3.0 4.0 5.0 6.0 8.0 10.0 15.0 20.0 30.0 50.0]
	#define END_CLOUDS5_FLASH_SPEED 0.15 //[0.00 0.02 0.05 0.08 0.10 0.15 0.20 0.30 0.40 0.50 0.70 1.00]
	#define END_CLOUDS5_FLASH_SCALE 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.15 0.20 0.30 0.40]
#endif


// Высота слоя 5 — по умолчанию повыше слоя 4 (280-400 против 220-340 у слоя 4).
#define END_CLOUDS5_HEIGHT_START 30 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200]
#define END_CLOUDS5_HEIGHT_END 400 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500]
#define END_CLOUDS5_HEIGHT_EDGE 20.0 //[0.0 5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0 60.0 80.0 100.0]

#define END_CLOUDS5_COVERAGE 0.50 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80]
#define END_CLOUDS5_SHARPNESS 50.0 //[10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 60.0 70.0 80.0 90.0 100.0 120.0 150.0]

#define END_CLOUDS5_SCALE 0.015 //[0.005 0.008 0.010 0.012 0.015 0.020 0.025 0.030 0.040 0.050]

#define END_CLOUDS5_WIND_SPEED 0.009 //[0.000 0.002 0.004 0.006 0.008 0.010 0.015 0.020 0.030 0.040 0.060 0.080 0.100]

#define END_CLOUDS5_MAX_DISTANCE 250.0 //[50.0 75.0 100.0 125.0 150.0 175.0 200.0 250.0 300.0 350.0 400.0 500.0 600.0 700.0 800.0 1000.0 1200.0 1500.0 2000.0 2500.0 3000.0 4000.0 5000.0 6000.0 8000.0 10000.0]
#define END_CLOUDS5_DISTANCE_FALLOFF 1.00 //[0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00 6.00 8.00 10.00]


// Маска вокруг центрального острова для слоя 5 — независимо от остальных слоёв.
#define END_CLOUDS5_ISLAND_MASK

#ifdef END_CLOUDS5_ISLAND_MASK
	#define END_CLOUDS5_ISLAND_CENTER_X 0.0
	#define END_CLOUDS5_ISLAND_CENTER_Z 0.0
	#define END_CLOUDS5_ISLAND_RADIUS 120.0 //[20.0 40.0 60.0 80.0 100.0 120.0 140.0 160.0 180.0 200.0 250.0 300.0 350.0 400.0 500.0]
	#define END_CLOUDS5_ISLAND_EDGE 60.0 //[0.0 10.0 20.0 30.0 40.0 50.0 60.0 80.0 100.0 120.0 150.0 200.0]
#endif

vec3 endClouds5Wind = vec3(1.0, 0.3, 0.6) * worldTimeCounter * (END_CLOUDS5_WIND_SPEED + darkEnd * 0.02);

float CalculateCloudDensity5(in vec3 rayPosition) {
	float lowerFade = smoothstep(float(END_CLOUDS5_HEIGHT_START) - END_CLOUDS5_HEIGHT_EDGE, float(END_CLOUDS5_HEIGHT_START), rayPosition.y);
	float upperFade = 1.0 - smoothstep(float(END_CLOUDS5_HEIGHT_END), float(END_CLOUDS5_HEIGHT_END) + END_CLOUDS5_HEIGHT_EDGE, rayPosition.y);
	float falloff = lowerFade * upperFade;

	#ifdef END_CLOUDS5_ISLAND_MASK
		float islandDist = length(rayPosition.xz - vec2(END_CLOUDS5_ISLAND_CENTER_X, END_CLOUDS5_ISLAND_CENTER_Z));
		float islandMask = 1.0 - smoothstep(END_CLOUDS5_ISLAND_RADIUS, END_CLOUDS5_ISLAND_RADIUS + max(END_CLOUDS5_ISLAND_EDGE, 0.001), islandDist);
		falloff *= islandMask;
	#endif

	rayPosition *= END_CLOUDS5_SCALE;
	rayPosition += endClouds5Wind;
	float noise = Get3DNoiseSmooth(rayPosition) * 0.5;
		rayPosition += endClouds5Wind;
	noise += Get3DNoiseSmooth(rayPosition * 3.6) * 0.25;
		rayPosition += endClouds5Wind;
	noise += Get3DNoiseSmooth(rayPosition * 12.0) * 0.125;
		rayPosition += endClouds5Wind;
	noise += Get3DNoiseSmooth(rayPosition * 56.0) * 0.0625;

	return saturate(falloff * (noise - END_CLOUDS5_COVERAGE + darkEnd) * END_CLOUDS5_SHARPNESS) * 0.2 * END_CLOUDS5_DENSITY;
}

#ifdef END_CLOUDS5_FLASHES
float CalculateCloudFlash5(in vec3 rayPosition, in float density) {
	if (density < 1e-4) return 0.0;

	vec3 flashPos = rayPosition * END_CLOUDS5_FLASH_SCALE;
	flashPos += vec3(3.17, -1.41, 2.63) * worldTimeCounter * END_CLOUDS5_FLASH_SPEED;

	float flashNoise = Get3DNoiseSmooth(flashPos);
	float flash = saturate((flashNoise - (1.0 - END_CLOUDS5_FLASH_FREQUENCY)) * END_CLOUDS5_FLASH_SHARPNESS);

	return flash * END_CLOUDS5_FLASH_BRIGHTNESS;
}
#endif

vec4 CalculateEndClouds5(in vec3 worldPos, in vec3 worldDir, in float dither) {
	float rayLength = min(END_CLOUDS5_MAX_DISTANCE, length(worldPos));

	#if defined DISTANT_HORIZONS || defined VOXY
		uint steps = END_FOG_SAMPLES;
	#else
		uint steps = uint(END_FOG_SAMPLES * 0.4 + rayLength * 0.1);
		     steps = min(steps, END_FOG_SAMPLES);
	#endif

	float rSteps = 1.0 / float(steps);
	float stepLength = rayLength * rSteps;

	float transmittance = 1.0;
	float LdotV = dot(endWorldLightVector, worldDir);
	float LdotV01 = LdotV * 0.5 + 0.5;
	float skylightSample = 0.0;
	#ifdef END_CLOUDS5_FLASHES
		float flashSample = 0.0;
	#endif

	vec3 rayStep = worldDir * stepLength,
		 rayPosition = rayStep * dither + gbufferModelViewInverse[3].xyz + cameraPosition;

	vec3 shadowStart = WorldPosToShadowPos(gbufferModelViewInverse[3].xyz),
		 shadowEnd = WorldPosToShadowPos(rayStep + gbufferModelViewInverse[3].xyz);

	vec3 shadowStep = shadowEnd - shadowStart,
		 shadowPosition = shadowStep * dither + shadowStart;
	vec3 sunlightSample = vec3(0.0);

	float phases1 = (HenyeyGreensteinPhase(LdotV, 0.5) 		   + HenyeyGreensteinPhase(LdotV, -0.3))		 * 0.5,
		  phases2 = (HenyeyGreensteinPhase(LdotV * 0.5, 0.5)   + HenyeyGreensteinPhase(LdotV * 0.5, -0.3))   * 0.25,
		  phases3 = (HenyeyGreensteinPhase(LdotV * 0.25, 0.5)  + HenyeyGreensteinPhase(LdotV * 0.25, -0.3))  * 0.125,
		  phases4 = (HenyeyGreensteinPhase(LdotV * 0.125, 0.5) + HenyeyGreensteinPhase(LdotV * 0.125, -0.3)) * 0.0625;

	uint i = 0u;
	while (++i < steps) {
		rayPosition += rayStep, shadowPosition += shadowStep;

		vec2 shadowProjPos = DistortShadowSpace(shadowPosition.xy);
		if (saturate(shadowProjPos) != shadowProjPos) continue;
		ivec2 shadowTexel = ivec2(shadowProjPos * realShadowMapRes);

		float density = CalculateCloudDensity5(rayPosition);
		density *= exp2(-distance(rayPosition, cameraPosition) * END_CLOUDS5_DISTANCE_FALLOFF * 0.001);

		if (density < 1e-5) continue;
		float fogDensity = density * stepLength;

		#ifdef END_CLOUDS5_FLASHES
			flashSample += CalculateCloudFlash5(rayPosition, density) * fogDensity * transmittance;
		#endif

		vec3 shadow = texelFetch(shadowtex1, shadowTexel, 0).xxx;
		shadow = step(shadowPosition.z, shadow);
		#ifdef RAY_STAINED_GLASS_TINT
			float translucentShadow = step(shadowPosition.z, texelFetch(shadowtex0, shadowTexel, 0).x);
			if (shadow.x != translucentShadow) {
				vec3 shadowColorSample = pow4(texelFetch(shadowcolor0, shadowTexel, 0).rgb);
				shadow = shadowColorSample * (shadow - translucentShadow) + vec3(translucentShadow);
			}
		#endif

		float stepLengthSun = 5.0, sunlightOD = 0.0;
		vec3 checkPos = rayPosition;
		for (uint j = 0u; j < 4u; ++j, checkPos += endWorldLightVector * stepLengthSun) {
			float densityCheck = CalculateCloudDensity5(checkPos);
			if (densityCheck < 1e-5) continue;
			sunlightOD += densityCheck * stepLengthSun;
			stepLengthSun *= 1.5;
		}

		float scatteringSun = oneMinus(expf(-sunlightOD * 3.0)) * oneMinus(LdotV01) + LdotV01;
		scatteringSun *= expf(-sunlightOD * 4.0) * phases1
					+ expf(-sunlightOD * 2.0)  	* phases2
					+ expf(-sunlightOD * 1.0)  	* phases3
					+ expf(-sunlightOD * 0.5) 	* phases4;

		shadow *= scatteringSun * 4.0;

		float stepTransmittance = expf(-fogDensity);

		float powder = rcp(fogDensity * 0.3 + 0.15) * fogDensity;
		powder = powder * oneMinus(LdotV01) + LdotV01;
		float fogSample = powder * transmittance * oneMinus(stepTransmittance);
		sunlightSample += shadow * fogSample;
		skylightSample += fogSample;

		transmittance *= stepTransmittance;

		if (transmittance < 1e-3) break;
	}

	vec3 clouds5LightColor = vec3(END_CLOUDS5_LIGHT_COLOR_R, END_CLOUDS5_LIGHT_COLOR_G, END_CLOUDS5_LIGHT_COLOR_B) / 255.0;
	vec3 clouds5BaseColor = vec3(END_CLOUDS5_COLOR_R, END_CLOUDS5_COLOR_G, END_CLOUDS5_COLOR_B) / 255.0;

	// Boost: сатурейшн относительно luma цвета, затем яркость
	float clouds5LightLuma = dot(clouds5LightColor, vec3(0.2126, 0.7152, 0.0722));
	clouds5LightColor = mix(vec3(clouds5LightLuma), clouds5LightColor, END_CLOUDS5_COLOR_SATURATION_BOOST) * END_CLOUDS5_COLOR_BRIGHTNESS_BOOST;

	float clouds5BaseLuma = dot(clouds5BaseColor, vec3(0.2126, 0.7152, 0.0722));
	clouds5BaseColor = mix(vec3(clouds5BaseLuma), clouds5BaseColor, END_CLOUDS5_COLOR_SATURATION_BOOST) * END_CLOUDS5_COLOR_BRIGHTNESS_BOOST;

	vec3 clouds5SunColor = clouds5LightColor * (1.0 - darkEnd * END_CLOUDS5_LIGHT_DARK_END_FADE) * sunlightSample * END_CLOUDS5_LIGHT_BRIGHTNESS;
	vec3 clouds5SkyColor = clouds5BaseColor * (1.0 - darkEnd * END_CLOUDS5_DARK_END_FADE) * 0.04 * skylightSample * END_CLOUDS5_SKY_TINT_STRENGTH;

	vec3 clouds5Color = clouds5SunColor + clouds5SkyColor;

	#ifdef END_CLOUDS5_FLASHES
		vec3 clouds5FlashColor = vec3(END_CLOUDS5_FLASH_COLOR_R, END_CLOUDS5_FLASH_COLOR_G, END_CLOUDS5_FLASH_COLOR_B) / 255.0;
		clouds5Color += clouds5FlashColor * flashSample;
	#endif

	clouds5Color = clamp(clouds5Color, vec3(0.0), vec3(END_CLOUDS5_MAX_BRIGHTNESS));

	return vec4(clouds5Color, transmittance);
}

#endif // END_CLOUDS_LAYER5

//----// СЛОЙ 6 //--------------------------------------------------------------------------------//
// Полностью независимый от остальных слоёв: свой toggle, свои дефайны (END_CLOUDS6_*),
// своя функция плотности, свой марш. Высота по умолчанию выше слоя 5 (340-460).

#define END_CLOUDS_LAYER6 // Включить 6й слой облаков (независимо от остальных)

#ifdef END_CLOUDS_LAYER6

#define END_CLOUDS6_LIGHT_COLOR_R 50 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS6_LIGHT_COLOR_G 19 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS6_LIGHT_COLOR_B 30 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS6_LIGHT_BRIGHTNESS 100.0 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.25 2.50 2.75 3.00 3.50 4.00 4.50 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]
#define END_CLOUDS6_LIGHT_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#define END_CLOUDS6_MAX_BRIGHTNESS 3.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00 3.50 4.00 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]

#define END_CLOUDS6_COLOR_R 50 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS6_COLOR_G 19 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS6_COLOR_B 40 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS6_DENSITY 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00 4.00 5.00]
#define END_CLOUDS6_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Насколько skylight (фоновый цвет неба, восход/закат) подмешивается в цвет облака.
// 0.0 = облако НЕ перекрашивается небом. 1.0 = как раньше.
#define END_CLOUDS6_SKY_TINT_STRENGTH 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0]

// --- Усиление цвета (boost) ---
#define END_CLOUDS6_COLOR_BRIGHTNESS_BOOST 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0]
#define END_CLOUDS6_COLOR_SATURATION_BOOST 1.0 //[0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0]

// --- Вспышки в облаке ---
#define END_CLOUDS6_FLASHES // Включить случайные цветные вспышки в этом слое облаков

#ifdef END_CLOUDS6_FLASHES
	#define END_CLOUDS6_FLASH_COLOR_R 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS6_FLASH_COLOR_G 40 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS6_FLASH_COLOR_B 220 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]

	#define END_CLOUDS6_FLASH_BRIGHTNESS 4.0 //[0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0 12.0 15.0 20.0]
	#define END_CLOUDS6_FLASH_FREQUENCY 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50]
	#define END_CLOUDS6_FLASH_SHARPNESS 8.0 //[1.0 2.0 3.0 4.0 5.0 6.0 8.0 10.0 15.0 20.0 30.0 50.0]
	#define END_CLOUDS6_FLASH_SPEED 0.15 //[0.00 0.02 0.05 0.08 0.10 0.15 0.20 0.30 0.40 0.50 0.70 1.00]
	#define END_CLOUDS6_FLASH_SCALE 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.15 0.20 0.30 0.40]
#endif


// Высота слоя 6 — по умолчанию повыше слоя 5 (340-460 против 280-400 у слоя 5).
#define END_CLOUDS6_HEIGHT_START 40 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200]
#define END_CLOUDS6_HEIGHT_END 260 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500]
#define END_CLOUDS6_HEIGHT_EDGE 20.0 //[0.0 5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0 60.0 80.0 100.0]

#define END_CLOUDS6_COVERAGE 0.54 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80]
#define END_CLOUDS6_SHARPNESS 50.0 //[10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 60.0 70.0 80.0 90.0 100.0 120.0 150.0]

#define END_CLOUDS6_SCALE 0.015 //[0.005 0.008 0.010 0.012 0.015 0.020 0.025 0.030 0.040 0.050]

#define END_CLOUDS6_WIND_SPEED 0.010 //[0.000 0.002 0.004 0.006 0.008 0.010 0.015 0.020 0.030 0.040 0.060 0.080 0.100]

#define END_CLOUDS6_MAX_DISTANCE 250.0 //[50.0 75.0 100.0 125.0 150.0 175.0 200.0 250.0 300.0 350.0 400.0 500.0 600.0 700.0 800.0 1000.0 1200.0 1500.0 2000.0 2500.0 3000.0 4000.0 5000.0 6000.0 8000.0 10000.0]
#define END_CLOUDS6_DISTANCE_FALLOFF 1.00 //[0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00 6.00 8.00 10.00]


// Маска вокруг центрального острова для слоя 6 — независимо от остальных слоёв.
//#define END_CLOUDS6_ISLAND_MASK

#ifdef END_CLOUDS6_ISLAND_MASK
	#define END_CLOUDS6_ISLAND_CENTER_X 0.0
	#define END_CLOUDS6_ISLAND_CENTER_Z 0.0
	#define END_CLOUDS6_ISLAND_RADIUS 120.0 //[20.0 40.0 60.0 80.0 100.0 120.0 140.0 160.0 180.0 200.0 250.0 300.0 350.0 400.0 500.0]
	#define END_CLOUDS6_ISLAND_EDGE 60.0 //[0.0 10.0 20.0 30.0 40.0 50.0 60.0 80.0 100.0 120.0 150.0 200.0]
#endif

vec3 endClouds6Wind = vec3(1.0, 0.3, 0.6) * worldTimeCounter * (END_CLOUDS6_WIND_SPEED + darkEnd * 0.02);

float CalculateCloudDensity6(in vec3 rayPosition) {
	float lowerFade = smoothstep(float(END_CLOUDS6_HEIGHT_START) - END_CLOUDS6_HEIGHT_EDGE, float(END_CLOUDS6_HEIGHT_START), rayPosition.y);
	float upperFade = 1.0 - smoothstep(float(END_CLOUDS6_HEIGHT_END), float(END_CLOUDS6_HEIGHT_END) + END_CLOUDS6_HEIGHT_EDGE, rayPosition.y);
	float falloff = lowerFade * upperFade;

	#ifdef END_CLOUDS6_ISLAND_MASK
		float islandDist = length(rayPosition.xz - vec2(END_CLOUDS6_ISLAND_CENTER_X, END_CLOUDS6_ISLAND_CENTER_Z));
		float islandMask = 1.0 - smoothstep(END_CLOUDS6_ISLAND_RADIUS, END_CLOUDS6_ISLAND_RADIUS + max(END_CLOUDS6_ISLAND_EDGE, 0.001), islandDist);
		falloff *= islandMask;
	#endif

	rayPosition *= END_CLOUDS6_SCALE;
	rayPosition += endClouds6Wind;
	float noise = Get3DNoiseSmooth(rayPosition) * 0.5;
		rayPosition += endClouds6Wind;
	noise += Get3DNoiseSmooth(rayPosition * 3.6) * 0.25;
		rayPosition += endClouds6Wind;
	noise += Get3DNoiseSmooth(rayPosition * 12.0) * 0.125;
		rayPosition += endClouds6Wind;
	noise += Get3DNoiseSmooth(rayPosition * 56.0) * 0.0625;

	return saturate(falloff * (noise - END_CLOUDS6_COVERAGE + darkEnd) * END_CLOUDS6_SHARPNESS) * 0.2 * END_CLOUDS6_DENSITY;
}

#ifdef END_CLOUDS6_FLASHES
float CalculateCloudFlash6(in vec3 rayPosition, in float density) {
	if (density < 1e-4) return 0.0;

	vec3 flashPos = rayPosition * END_CLOUDS6_FLASH_SCALE;
	flashPos += vec3(3.17, -1.41, 2.63) * worldTimeCounter * END_CLOUDS6_FLASH_SPEED;

	float flashNoise = Get3DNoiseSmooth(flashPos);
	float flash = saturate((flashNoise - (1.0 - END_CLOUDS6_FLASH_FREQUENCY)) * END_CLOUDS6_FLASH_SHARPNESS);

	return flash * END_CLOUDS6_FLASH_BRIGHTNESS;
}
#endif

vec4 CalculateEndClouds6(in vec3 worldPos, in vec3 worldDir, in float dither) {
	float rayLength = min(END_CLOUDS6_MAX_DISTANCE, length(worldPos));

	#if defined DISTANT_HORIZONS || defined VOXY
		uint steps = END_FOG_SAMPLES;
	#else
		uint steps = uint(END_FOG_SAMPLES * 0.4 + rayLength * 0.1);
		     steps = min(steps, END_FOG_SAMPLES);
	#endif

	float rSteps = 1.0 / float(steps);
	float stepLength = rayLength * rSteps;

	float transmittance = 1.0;
	float LdotV = dot(endWorldLightVector, worldDir);
	float LdotV01 = LdotV * 0.5 + 0.5;
	float skylightSample = 0.0;
	#ifdef END_CLOUDS6_FLASHES
		float flashSample = 0.0;
	#endif

	vec3 rayStep = worldDir * stepLength,
		 rayPosition = rayStep * dither + gbufferModelViewInverse[3].xyz + cameraPosition;

	vec3 shadowStart = WorldPosToShadowPos(gbufferModelViewInverse[3].xyz),
		 shadowEnd = WorldPosToShadowPos(rayStep + gbufferModelViewInverse[3].xyz);

	vec3 shadowStep = shadowEnd - shadowStart,
		 shadowPosition = shadowStep * dither + shadowStart;
	vec3 sunlightSample = vec3(0.0);

	float phases1 = (HenyeyGreensteinPhase(LdotV, 0.5) 		   + HenyeyGreensteinPhase(LdotV, -0.3))		 * 0.5,
		  phases2 = (HenyeyGreensteinPhase(LdotV * 0.5, 0.5)   + HenyeyGreensteinPhase(LdotV * 0.5, -0.3))   * 0.25,
		  phases3 = (HenyeyGreensteinPhase(LdotV * 0.25, 0.5)  + HenyeyGreensteinPhase(LdotV * 0.25, -0.3))  * 0.125,
		  phases4 = (HenyeyGreensteinPhase(LdotV * 0.125, 0.5) + HenyeyGreensteinPhase(LdotV * 0.125, -0.3)) * 0.0625;

	uint i = 0u;
	while (++i < steps) {
		rayPosition += rayStep, shadowPosition += shadowStep;

		vec2 shadowProjPos = DistortShadowSpace(shadowPosition.xy);
		if (saturate(shadowProjPos) != shadowProjPos) continue;
		ivec2 shadowTexel = ivec2(shadowProjPos * realShadowMapRes);

		float density = CalculateCloudDensity6(rayPosition);
		density *= exp2(-distance(rayPosition, cameraPosition) * END_CLOUDS6_DISTANCE_FALLOFF * 0.001);

		if (density < 1e-5) continue;
		float fogDensity = density * stepLength;

		#ifdef END_CLOUDS6_FLASHES
			flashSample += CalculateCloudFlash6(rayPosition, density) * fogDensity * transmittance;
		#endif

		vec3 shadow = texelFetch(shadowtex1, shadowTexel, 0).xxx;
		shadow = step(shadowPosition.z, shadow);
		#ifdef RAY_STAINED_GLASS_TINT
			float translucentShadow = step(shadowPosition.z, texelFetch(shadowtex0, shadowTexel, 0).x);
			if (shadow.x != translucentShadow) {
				vec3 shadowColorSample = pow4(texelFetch(shadowcolor0, shadowTexel, 0).rgb);
				shadow = shadowColorSample * (shadow - translucentShadow) + vec3(translucentShadow);
			}
		#endif

		float stepLengthSun = 5.0, sunlightOD = 0.0;
		vec3 checkPos = rayPosition;
		for (uint j = 0u; j < 4u; ++j, checkPos += endWorldLightVector * stepLengthSun) {
			float densityCheck = CalculateCloudDensity6(checkPos);
			if (densityCheck < 1e-5) continue;
			sunlightOD += densityCheck * stepLengthSun;
			stepLengthSun *= 1.5;
		}

		float scatteringSun = oneMinus(expf(-sunlightOD * 3.0)) * oneMinus(LdotV01) + LdotV01;
		scatteringSun *= expf(-sunlightOD * 4.0) * phases1
					+ expf(-sunlightOD * 2.0)  	* phases2
					+ expf(-sunlightOD * 1.0)  	* phases3
					+ expf(-sunlightOD * 0.5) 	* phases4;

		shadow *= scatteringSun * 4.0;

		float stepTransmittance = expf(-fogDensity);

		float powder = rcp(fogDensity * 0.3 + 0.15) * fogDensity;
		powder = powder * oneMinus(LdotV01) + LdotV01;
		float fogSample = powder * transmittance * oneMinus(stepTransmittance);
		sunlightSample += shadow * fogSample;
		skylightSample += fogSample;

		transmittance *= stepTransmittance;

		if (transmittance < 1e-3) break;
	}

	vec3 clouds6LightColor = vec3(END_CLOUDS6_LIGHT_COLOR_R, END_CLOUDS6_LIGHT_COLOR_G, END_CLOUDS6_LIGHT_COLOR_B) / 255.0;
	vec3 clouds6BaseColor = vec3(END_CLOUDS6_COLOR_R, END_CLOUDS6_COLOR_G, END_CLOUDS6_COLOR_B) / 255.0;

	// Boost: сатурейшн относительно luma цвета, затем яркость
	float clouds6LightLuma = dot(clouds6LightColor, vec3(0.2126, 0.7152, 0.0722));
	clouds6LightColor = mix(vec3(clouds6LightLuma), clouds6LightColor, END_CLOUDS6_COLOR_SATURATION_BOOST) * END_CLOUDS6_COLOR_BRIGHTNESS_BOOST;

	float clouds6BaseLuma = dot(clouds6BaseColor, vec3(0.2126, 0.7152, 0.0722));
	clouds6BaseColor = mix(vec3(clouds6BaseLuma), clouds6BaseColor, END_CLOUDS6_COLOR_SATURATION_BOOST) * END_CLOUDS6_COLOR_BRIGHTNESS_BOOST;

	vec3 clouds6SunColor = clouds6LightColor * (1.0 - darkEnd * END_CLOUDS6_LIGHT_DARK_END_FADE) * sunlightSample * END_CLOUDS6_LIGHT_BRIGHTNESS;
	vec3 clouds6SkyColor = clouds6BaseColor * (1.0 - darkEnd * END_CLOUDS6_DARK_END_FADE) * 0.04 * skylightSample * END_CLOUDS6_SKY_TINT_STRENGTH;

	vec3 clouds6Color = clouds6SunColor + clouds6SkyColor;

	#ifdef END_CLOUDS6_FLASHES
		vec3 clouds6FlashColor = vec3(END_CLOUDS6_FLASH_COLOR_R, END_CLOUDS6_FLASH_COLOR_G, END_CLOUDS6_FLASH_COLOR_B) / 255.0;
		clouds6Color += clouds6FlashColor * flashSample;
	#endif

	clouds6Color = clamp(clouds6Color, vec3(0.0), vec3(END_CLOUDS6_MAX_BRIGHTNESS));

	return vec4(clouds6Color, transmittance);
}

#endif // END_CLOUDS_LAYER6

//----// СЛОЙ 7 //--------------------------------------------------------------------------------//
// Полностью независимый от остальных слоёв: свой toggle, свои дефайны (END_CLOUDS7_*),
// своя функция плотности, свой марш. Высота по умолчанию выше слоя 6 (400-520).

#define END_CLOUDS_LAYER7 // Включить 7й слой облаков (независимо от остальных)

#ifdef END_CLOUDS_LAYER7


#define END_CLOUDS7_LIGHT_COLOR_R 19 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS7_LIGHT_COLOR_G 19 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS7_LIGHT_COLOR_B 30 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS7_LIGHT_BRIGHTNESS 100.0 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.25 2.50 2.75 3.00 3.50 4.00 4.50 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]
#define END_CLOUDS7_LIGHT_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#define END_CLOUDS7_MAX_BRIGHTNESS 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00 3.50 4.00 5.00 6.00 7.00 8.00 9.00 10.00 12.00 14.00 16.00 18.00 20.00]

#define END_CLOUDS7_COLOR_R 19 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS7_COLOR_G 19 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS7_COLOR_B 30 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define END_CLOUDS7_DENSITY 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00 4.00 5.00]
#define END_CLOUDS7_DARK_END_FADE 0.96 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Насколько skylight (фоновый цвет неба, восход/закат) подмешивается в цвет облака.
// 0.0 = облако НЕ перекрашивается небом — именно это тебе и нужно, чтобы 255-й
// (максимально насыщенный) 7й слой не подсвечивался розовым закатом на фоне неба.
// 1.0 = как раньше, полный вклад неба.
#define END_CLOUDS7_SKY_TINT_STRENGTH 0.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0]

// --- Усиление цвета (boost) ---
#define END_CLOUDS7_COLOR_BRIGHTNESS_BOOST 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0]
#define END_CLOUDS7_COLOR_SATURATION_BOOST 1.0 //[0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0]

// --- Вспышки в облаке ---
#define END_CLOUDS7_FLASHES // Включить случайные цветные вспышки в этом слое облаков

#ifdef END_CLOUDS7_FLASHES
	#define END_CLOUDS7_FLASH_COLOR_R 140 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS7_FLASH_COLOR_G 40 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
	#define END_CLOUDS7_FLASH_COLOR_B 220 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]

	#define END_CLOUDS7_FLASH_BRIGHTNESS 4.0 //[0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0 12.0 15.0 20.0]
	#define END_CLOUDS7_FLASH_FREQUENCY 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50]
	#define END_CLOUDS7_FLASH_SHARPNESS 8.0 //[1.0 2.0 3.0 4.0 5.0 6.0 8.0 10.0 15.0 20.0 30.0 50.0]
	#define END_CLOUDS7_FLASH_SPEED 0.15 //[0.00 0.02 0.05 0.08 0.10 0.15 0.20 0.30 0.40 0.50 0.70 1.00]
	#define END_CLOUDS7_FLASH_SCALE 0.08 //[0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.15 0.20 0.30 0.40]
#endif


// Высота слоя 7 — по умолчанию повыше слоя 6 (400-520 против 340-460 у слоя 6).
#define END_CLOUDS7_HEIGHT_START 30 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200]
#define END_CLOUDS7_HEIGHT_END 201 //[-200 -180 -160 -140 -120 -100 -80 -60 -40 -20 0 20 40 60 80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500]
#define END_CLOUDS7_HEIGHT_EDGE 20.0 //[0.0 5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0 60.0 80.0 100.0]

#define END_CLOUDS7_COVERAGE 0.53 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80]
#define END_CLOUDS7_SHARPNESS 50.0 //[10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 60.0 70.0 80.0 90.0 100.0 120.0 150.0]

#define END_CLOUDS7_SCALE 0.015 //[0.005 0.008 0.010 0.012 0.015 0.020 0.025 0.030 0.040 0.050]

#define END_CLOUDS7_WIND_SPEED 0.011 //[0.000 0.002 0.004 0.006 0.008 0.010 0.015 0.020 0.030 0.040 0.060 0.080 0.100]

#define END_CLOUDS7_MAX_DISTANCE 250.0 //[50.0 75.0 100.0 125.0 150.0 175.0 200.0 250.0 300.0 350.0 400.0 500.0 600.0 700.0 800.0 1000.0 1200.0 1500.0 2000.0 2500.0 3000.0 4000.0 5000.0 6000.0 8000.0 10000.0]
#define END_CLOUDS7_DISTANCE_FALLOFF 1.00 //[0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00 6.00 8.00 10.00]


// Маска вокруг центрального острова для слоя 7 — независимо от остальных слоёв.
//#define END_CLOUDS7_ISLAND_MASK

#ifdef END_CLOUDS7_ISLAND_MASK
	#define END_CLOUDS7_ISLAND_CENTER_X 0.0
	#define END_CLOUDS7_ISLAND_CENTER_Z 0.0
	#define END_CLOUDS7_ISLAND_RADIUS 120.0 //[20.0 40.0 60.0 80.0 100.0 120.0 140.0 160.0 180.0 200.0 250.0 300.0 350.0 400.0 500.0]
	#define END_CLOUDS7_ISLAND_EDGE 60.0 //[0.0 10.0 20.0 30.0 40.0 50.0 60.0 80.0 100.0 120.0 150.0 200.0]
#endif

vec3 endClouds7Wind = vec3(1.0, 0.3, 0.6) * worldTimeCounter * (END_CLOUDS7_WIND_SPEED + darkEnd * 0.02);

float CalculateCloudDensity7(in vec3 rayPosition) {
	float lowerFade = smoothstep(float(END_CLOUDS7_HEIGHT_START) - END_CLOUDS7_HEIGHT_EDGE, float(END_CLOUDS7_HEIGHT_START), rayPosition.y);
	float upperFade = 1.0 - smoothstep(float(END_CLOUDS7_HEIGHT_END), float(END_CLOUDS7_HEIGHT_END) + END_CLOUDS7_HEIGHT_EDGE, rayPosition.y);
	float falloff = lowerFade * upperFade;

	#ifdef END_CLOUDS7_ISLAND_MASK
		float islandDist = length(rayPosition.xz - vec2(END_CLOUDS7_ISLAND_CENTER_X, END_CLOUDS7_ISLAND_CENTER_Z));
		float islandMask = 1.0 - smoothstep(END_CLOUDS7_ISLAND_RADIUS, END_CLOUDS7_ISLAND_RADIUS + max(END_CLOUDS7_ISLAND_EDGE, 0.001), islandDist);
		falloff *= islandMask;
	#endif

	rayPosition *= END_CLOUDS7_SCALE;
	rayPosition += endClouds7Wind;
	float noise = Get3DNoiseSmooth(rayPosition) * 0.5;
		rayPosition += endClouds7Wind;
	noise += Get3DNoiseSmooth(rayPosition * 3.6) * 0.25;
		rayPosition += endClouds7Wind;
	noise += Get3DNoiseSmooth(rayPosition * 12.0) * 0.125;
		rayPosition += endClouds7Wind;
	noise += Get3DNoiseSmooth(rayPosition * 56.0) * 0.0625;

	return saturate(falloff * (noise - END_CLOUDS7_COVERAGE + darkEnd) * END_CLOUDS7_SHARPNESS) * 0.2 * END_CLOUDS7_DENSITY;
}

#ifdef END_CLOUDS7_FLASHES
float CalculateCloudFlash7(in vec3 rayPosition, in float density) {
	if (density < 1e-4) return 0.0;

	vec3 flashPos = rayPosition * END_CLOUDS7_FLASH_SCALE;
	flashPos += vec3(3.17, -1.41, 2.63) * worldTimeCounter * END_CLOUDS7_FLASH_SPEED;

	float flashNoise = Get3DNoiseSmooth(flashPos);
	float flash = saturate((flashNoise - (1.0 - END_CLOUDS7_FLASH_FREQUENCY)) * END_CLOUDS7_FLASH_SHARPNESS);

	return flash * END_CLOUDS7_FLASH_BRIGHTNESS;
}
#endif

vec4 CalculateEndClouds7(in vec3 worldPos, in vec3 worldDir, in float dither) {
	float rayLength = min(END_CLOUDS7_MAX_DISTANCE, length(worldPos));

	#if defined DISTANT_HORIZONS || defined VOXY
		uint steps = END_FOG_SAMPLES;
	#else
		uint steps = uint(END_FOG_SAMPLES * 0.4 + rayLength * 0.1);
		     steps = min(steps, END_FOG_SAMPLES);
	#endif

	float rSteps = 1.0 / float(steps);
	float stepLength = rayLength * rSteps;

	float transmittance = 1.0;
	float LdotV = dot(endWorldLightVector, worldDir);
	float LdotV01 = LdotV * 0.5 + 0.5;
	float skylightSample = 0.0;
	#ifdef END_CLOUDS7_FLASHES
		float flashSample = 0.0;
	#endif

	vec3 rayStep = worldDir * stepLength,
		 rayPosition = rayStep * dither + gbufferModelViewInverse[3].xyz + cameraPosition;

	vec3 shadowStart = WorldPosToShadowPos(gbufferModelViewInverse[3].xyz),
		 shadowEnd = WorldPosToShadowPos(rayStep + gbufferModelViewInverse[3].xyz);

	vec3 shadowStep = shadowEnd - shadowStart,
		 shadowPosition = shadowStep * dither + shadowStart;
	vec3 sunlightSample = vec3(0.0);

	float phases1 = (HenyeyGreensteinPhase(LdotV, 0.5) 		   + HenyeyGreensteinPhase(LdotV, -0.3))		 * 0.5,
		  phases2 = (HenyeyGreensteinPhase(LdotV * 0.5, 0.5)   + HenyeyGreensteinPhase(LdotV * 0.5, -0.3))   * 0.25,
		  phases3 = (HenyeyGreensteinPhase(LdotV * 0.25, 0.5)  + HenyeyGreensteinPhase(LdotV * 0.25, -0.3))  * 0.125,
		  phases4 = (HenyeyGreensteinPhase(LdotV * 0.125, 0.5) + HenyeyGreensteinPhase(LdotV * 0.125, -0.3)) * 0.0625;

	uint i = 0u;
	while (++i < steps) {
		rayPosition += rayStep, shadowPosition += shadowStep;

		vec2 shadowProjPos = DistortShadowSpace(shadowPosition.xy);
		if (saturate(shadowProjPos) != shadowProjPos) continue;
		ivec2 shadowTexel = ivec2(shadowProjPos * realShadowMapRes);

		float density = CalculateCloudDensity7(rayPosition);
		density *= exp2(-distance(rayPosition, cameraPosition) * END_CLOUDS7_DISTANCE_FALLOFF * 0.001);

		if (density < 1e-5) continue;
		float fogDensity = density * stepLength;

		#ifdef END_CLOUDS7_FLASHES
			flashSample += CalculateCloudFlash7(rayPosition, density) * fogDensity * transmittance;
		#endif

		vec3 shadow = texelFetch(shadowtex1, shadowTexel, 0).xxx;
		shadow = step(shadowPosition.z, shadow);
		#ifdef RAY_STAINED_GLASS_TINT
			float translucentShadow = step(shadowPosition.z, texelFetch(shadowtex0, shadowTexel, 0).x);
			if (shadow.x != translucentShadow) {
				vec3 shadowColorSample = pow4(texelFetch(shadowcolor0, shadowTexel, 0).rgb);
				shadow = shadowColorSample * (shadow - translucentShadow) + vec3(translucentShadow);
			}
		#endif

		float stepLengthSun = 5.0, sunlightOD = 0.0;
		vec3 checkPos = rayPosition;
		for (uint j = 0u; j < 4u; ++j, checkPos += endWorldLightVector * stepLengthSun) {
			float densityCheck = CalculateCloudDensity7(checkPos);
			if (densityCheck < 1e-5) continue;
			sunlightOD += densityCheck * stepLengthSun;
			stepLengthSun *= 1.5;
		}

		float scatteringSun = oneMinus(expf(-sunlightOD * 3.0)) * oneMinus(LdotV01) + LdotV01;
		scatteringSun *= expf(-sunlightOD * 4.0) * phases1
					+ expf(-sunlightOD * 2.0)  	* phases2
					+ expf(-sunlightOD * 1.0)  	* phases3
					+ expf(-sunlightOD * 0.5) 	* phases4;

		shadow *= scatteringSun * 4.0;

		float stepTransmittance = expf(-fogDensity);

		float powder = rcp(fogDensity * 0.3 + 0.15) * fogDensity;
		powder = powder * oneMinus(LdotV01) + LdotV01;
		float fogSample = powder * transmittance * oneMinus(stepTransmittance);
		sunlightSample += shadow * fogSample;
		skylightSample += fogSample;

		transmittance *= stepTransmittance;

		if (transmittance < 1e-3) break;
	}

	vec3 clouds7LightColor = vec3(END_CLOUDS7_LIGHT_COLOR_R, END_CLOUDS7_LIGHT_COLOR_G, END_CLOUDS7_LIGHT_COLOR_B) / 255.0;
	vec3 clouds7BaseColor = vec3(END_CLOUDS7_COLOR_R, END_CLOUDS7_COLOR_G, END_CLOUDS7_COLOR_B) / 255.0;

	// Boost: сатурейшн относительно luma цвета, затем яркость
	float clouds7LightLuma = dot(clouds7LightColor, vec3(0.2126, 0.7152, 0.0722));
	clouds7LightColor = mix(vec3(clouds7LightLuma), clouds7LightColor, END_CLOUDS7_COLOR_SATURATION_BOOST) * END_CLOUDS7_COLOR_BRIGHTNESS_BOOST;

	float clouds7BaseLuma = dot(clouds7BaseColor, vec3(0.2126, 0.7152, 0.0722));
	clouds7BaseColor = mix(vec3(clouds7BaseLuma), clouds7BaseColor, END_CLOUDS7_COLOR_SATURATION_BOOST) * END_CLOUDS7_COLOR_BRIGHTNESS_BOOST;

	vec3 clouds7SunColor = clouds7LightColor * (1.0 - darkEnd * END_CLOUDS7_LIGHT_DARK_END_FADE) * sunlightSample * END_CLOUDS7_LIGHT_BRIGHTNESS;
	vec3 clouds7SkyColor = clouds7BaseColor * (1.0 - darkEnd * END_CLOUDS7_DARK_END_FADE) * 0.04 * skylightSample * END_CLOUDS7_SKY_TINT_STRENGTH;

	vec3 clouds7Color = clouds7SunColor + clouds7SkyColor;

	#ifdef END_CLOUDS7_FLASHES
		vec3 clouds7FlashColor = vec3(END_CLOUDS7_FLASH_COLOR_R, END_CLOUDS7_FLASH_COLOR_G, END_CLOUDS7_FLASH_COLOR_B) / 255.0;
		clouds7Color += clouds7FlashColor * flashSample;
	#endif

	clouds7Color = clamp(clouds7Color, vec3(0.0), vec3(END_CLOUDS7_MAX_BRIGHTNESS));

	return vec4(clouds7Color, transmittance);
}

#endif // END_CLOUDS_LAYER7
