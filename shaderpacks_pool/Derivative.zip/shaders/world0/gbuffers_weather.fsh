#version 450 compatibility

#include "/program/Gbuffers/WeatherDef.glsl"
#include "/lib/Head/ParticleBloomSettings.inc"

layout(location = 0) out vec4 albedoData; // fix Mesa/AMD : alpha sinon indefini avec blend ONE ONE
layout(location = 1) out vec4 colortex31Out;

/* RENDERTARGETS: 0,31 */

uniform sampler2D tex;
uniform float rainStrength;  // 0..1, сила дождя от Minecraft
uniform float frameTimeCounter;

in vec2  texcoord;
in float tint;
in float dropHeight;
in vec2  fallDirScreen;
in float dropRandom;   // уникальное значение на каплю [0..1]
in float nearFade;     // fade вблизи камеры

void main() {
    vec2  tileUV     = texcoord * vec2(RAIN_UV_TILE_X, RAIN_UV_TILE_Y);
    float albedoAlpha = texture(tex, tileUV).a;
    if (albedoAlpha < 0.1) discard;

    // ── Базовый цвет (днём) ─────────────────────────────────────────────────
    vec3 dayColor   = vec3(RAIN_COLOR_R,       RAIN_COLOR_G,       RAIN_COLOR_B)       * RAIN_ALBEDO;

    // ── Ночной цвет (новая настройка) ───────────────────────────────────────
    // Ночью дождь темнее и чуть синее. Смешиваем по rainStrength как косвенному
    // признаку: можно заменить на реальный daylight если есть uniform.
    vec3 nightColor = vec3(RAIN_NIGHT_COLOR_R, RAIN_NIGHT_COLOR_G, RAIN_NIGHT_COLOR_B) * RAIN_ALBEDO * 0.35;

    // Простой способ: lerp по dropRandom — часть капель чуть темнее/светлее,
    // имитируя неоднородность. RAIN_COLOR_VARIANCE — новая настройка.
    float colorJitter = (dropRandom - 0.5) * RAIN_COLOR_VARIANCE;
    vec3 baseColor = mix(dayColor, nightColor, 1.0 - rainStrength);
    baseColor = clamp(baseColor + colorJitter, 0.0, 1.0);

    // ── UV в пространстве капли (-1..+1) ────────────────────────────────────
    vec2 dropUV = fract(tileUV) * 2.0 - 1.0;

    // ── Анизотропная форма (капля вытянута по вертикали) ────────────────────
    vec2  anisoDrop     = dropUV * vec2(0.45, 1.0);
    float distFromCenter = dot(anisoDrop, anisoDrop);
    float lensEffect     = (1.0 - distFromCenter) * RAIN_DROP_SHADE;

    // ── Яркий центр (новая настройка RAIN_CORE_BRIGHTNESS) ──────────────────
    // Центр капли — сильнее освещён (как капля воды на свету).
    float coreMask       = max(0.0, 1.0 - distFromCenter * 3.0); // маленькое светлое пятно
    coreMask             = coreMask * coreMask;

    // ── Боковой блик (преломление) ───────────────────────────────────────────
    float sideGlint = max(0.0, 1.0 - abs(dropUV.x) * 5.0)
                    * max(0.0, 1.0 - abs(dropUV.y + 0.25) * 4.0);
    sideGlint = sideGlint * sideGlint;

    // ── Мерцание (новая настройка RAIN_FLICKER) ──────────────────────────────
    // Каждая капля мерцает в своей фазе — имитация переливов дождя на свету.
    float flickerPhase = dropRandom * 6.2831;
    float flickerSpeed = 3.0 + dropRandom * 4.0;
    float flicker      = 1.0 + sin(frameTimeCounter * flickerSpeed + flickerPhase) * RAIN_FLICKER;

    // ── Яркость по высоте: у земли темнее ────────────────────────────────────
    float heightBrightness = mix(0.55, 1.0, dropHeight);

    float refractionModifier = 1.0 + (RAIN_REFRACTION * 0.5);

    // ── Сборка ───────────────────────────────────────────────────────────────
    vec3 rainColor  = baseColor * max(lensEffect, 0.15);
    rainColor += baseColor * coreMask   * RAIN_CORE_BRIGHTNESS;
    rainColor += baseColor * sideGlint  * RAIN_GLINT_STRENGTH;
    rainColor *= albedoAlpha * tint * refractionModifier * heightBrightness * nearFade * flicker;
    albedoData = vec4(rainColor, 0.0);

    // ── Forward-буфер (independent shading + bloom в composite1.fsh) ─────────
    colortex31Out = vec4(rainColor, albedoAlpha > 0.1 ? 1.0 : 0.0);
}
