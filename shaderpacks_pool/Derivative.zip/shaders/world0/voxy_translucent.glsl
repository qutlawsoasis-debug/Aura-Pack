#define IS_OVERWORLD
#include "/program/voxy_translucent.glsl"
