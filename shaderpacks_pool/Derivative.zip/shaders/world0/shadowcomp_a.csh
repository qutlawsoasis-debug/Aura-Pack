#version 450 compatibility

#extension GL_ARB_shader_image_load_store : enable

#define CSH


#include "/lib/Head/Common.inc"
#include "/lib/Water/WaterTrail.glsl"


#if !defined(WATER_TRAIL) || WATER_TRAIL == 0
	layout (local_size_x = 1, local_size_y = 1) in;
	const ivec3 workGroups = ivec3(1, 1, 1);

	void main() {}
#endif