#version 450 compatibility

#extension GL_ARB_shader_image_load_store : enable

#define CSH

#include "/lib/Head/Common.inc"
#include "/lib/Lighting/FloodFill.glsl"


#if MULTICOLORED_BLOCKLIGHT != 1
	layout (local_size_x = 1, local_size_y = 1, local_size_z = 1) in;
	const ivec3 workGroups = ivec3(1, 1, 1);

	void main() {}
#endif
