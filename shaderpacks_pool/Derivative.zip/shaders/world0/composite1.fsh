#version 450 compatibility

//----// FLASHLIGHT SETTINGS //-------------------------------------------------------------------//
#define FLASHLIGHT_TOGGLE 0 // [0 1 2 3]
#define FLASHLIGHT_SHADOW 1 // [0 1]
#define FLASHLIGHT_SHADOW_INTENSITY 0.85 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.85 0.9 1.0] 
#define FLASHLIGHT_STYLE 0 // [0 1 2 3 4] Style: Tactical LED, Warm Halogen, Wide Flood, Blue Modern, Searchlight
#define FLASHLIGHT_INTENSITY 3.5 // [0.0 0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 5.0 10.0]
#define FLASHLIGHT_RANGE 40.0 // [10.0 20.0 30.0 40.0 50.0 60.0 80.0 100.0]
#define FLASHLIGHT_DELAY 1 // [0 1]
#define FLASHLIGHT_DELAY_INTENSITY 1.2 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0 5.0]

#ifndef HELD_LIGHT_POS_R_X
	#define HELD_LIGHT_POS_R_X  0.32
#endif
#ifndef HELD_LIGHT_POS_R_Y
	#define HELD_LIGHT_POS_R_Y -0.28
#endif


#define IS_OVERWORLD

#include "/lib/Head/Common.inc"

layout(location = 0) out vec3 sceneData;

#ifdef BLOOMY_FOG
	layout(location = 1) out float fogTransmittance;
	/* DRAWBUFFERS:46 */
#else
	/* DRAWBUFFERS:4 */
#endif


in vec2 screenCoord;

flat in vec3 directIlluminance;
flat in vec3 skyIlluminance;

#include "/lib/Head/Uniforms.inc"
#include "/lib/Atmosphere/Atmosphere.glsl"

//----// STRUCTS //-------------------------------------------------------------------------------//

#include "/lib/Head/Mask.inc"
#include "/lib/Head/Material.inc"

//----// FUNCTIONS //-----------------------------------------------------------------------------//

#include "/lib/Head/Functions.inc"
#include "/lib/Lighting/HeldLightShadow.glsl"

#include "/lib/Surface/Refraction.glsl"

// RAYTRACED_REFRACTION включён (см. Refraction.glsl), поэтому его #else-ветка
// (которая обычно тянет WaterWave.glsl) не компилируется. GetVoxyWaterNormal
// ниже нужен GetWavesNormal(), так что подключаем явно.
#include "/lib/Water/WaterWave.glsl"

#include "/lib/Surface/ReflectionFilter.glsl"
#include "/lib/Surface/BRDF.glsl"

#include "/lib/Atmosphere/Fogs.glsl"

#include "/lib/Water/WaterFog.glsl"

// ── Voxy: вода дальних чанков ──
// Voxy рендерит дальний рельеф (включая воду) как отдельный, заранее
// растеризованный слой (vxDepthTexOpaque/vxDepthTexTrans), а не через
// обычный gbuffers_water — то есть Water.frag для этих пикселей никогда не
// вызывается, и normalData/reflectionData из colortex2/colortex3 для них не
// посчитаны. Поэтому для воды в Voxy-диапазоне (voxyWater == true, см. main())
// нормаль и отражение считаются здесь, вручную, повторяя то, что делает
// Water.frag для обычной воды.
#if defined VOXY && !defined DISTANT_HORIZONS
	// Аналог GetWavesNormal(), но переводит волновую нормаль из
	// касательного пространства в view-space вручную (у Voxy-воды нет
	// готового tbnMatrix, есть только worldNormal из gbuffer).
	vec3 GetVoxyWaterNormal(in vec3 position, in vec3 baseNormal) {
		vec3 worldNormal = mat3(gbufferModelViewInverse) * baseNormal;
		if (abs(worldNormal.y) < 0.5) return baseNormal; // не горизонтальная поверхность — не вода, нормаль не трогаем
		vec3 waveNormal = GetWavesNormal(position.xz - position.y);
		vec3 waveWorld = normalize(vec3(waveNormal.x, waveNormal.z * sign(worldNormal.y), waveNormal.y));
		vec3 waveView = normalize(mat3(gbufferModelView) * waveWorld);
		return isEyeInWater == 1 ? -waveView : waveView;
	}

	// Свой, самодостаточный SSR-трейс против vxDepthTexOpaque (буфер Voxy),
	// а не depthtex1/dhDepthTex1 — чтобы отражение видело именно Voxy-рельеф.
	bool VoxyScreenSpaceRayTrace(in vec3 viewPos, in vec3 viewDir, in float dither, inout vec3 rayPos) {
		const uint steps = 16u;
		const float maxLength = 1.0 / 16.0;
		const float minLength = length(screenPixelSize);

		vec3 position = ViewToScreenSpaceDH(viewDir * abs(viewPos.z) + viewPos);
		vec3 screenDir = normalize(position - rayPos);
		float stepWeight = 1.0 / max(abs(screenDir.z), 1e-6);

		float stepLength = minOf((step(vec3(0.0), screenDir) - rayPos) / screenDir) / 16.0;

		screenDir.xy *= screenSize;
		rayPos.xy *= screenSize;

		vec3 rayStep = screenDir * stepLength;
		rayPos += rayStep * dither + screenDir * minLength;

		float depthTolerance = max(abs(rayStep.z) * 3.0, 0.02 / max(sqr(viewPos.z), 1e-6));

		float depth = texelFetch(vxDepthTexOpaque, ivec2(rayPos.xy), 0).x;

		for (uint i = 0u; i < steps; ++i) {
			if (clamp(rayPos.xy, vec2(0.0), screenSize) != rayPos.xy || rayPos.z >= 1.0) return false;

			stepLength = abs(depth - rayPos.z) * stepWeight;
			rayPos += screenDir * clamp(stepLength, minLength, maxLength);

			depth = texelFetch(vxDepthTexOpaque, ivec2(rayPos.xy), 0).x;

			if (depth < rayPos.z && abs(depthTolerance - (rayPos.z - depth)) < depthTolerance) return true;
		}

		return false;
	}

	// Повторяет CalculateSpecularReflections() из Water.frag (небо/солнце/луна
	// + SSR-хит), но с VoxyScreenSpaceRayTrace вместо обычного трейса.
	vec4 GetVoxyWaterReflection(in vec3 normal, in float skylight, in vec3 viewPos, in float surfaceDepth) {
		skylight = smoothstep(0.3, 0.8, skylight);
		vec3 viewDir = normalize(viewPos);
		vec3 rayDir = reflect(viewDir, normal);
		if (dot(normal, rayDir) < 1e-6) return vec4(0.0, 0.0, 0.0, 1.0);

		vec3 rayPos = vec3(gl_FragCoord.xy * screenPixelSize, surfaceDepth);
		float dither = InterleavedGradientNoiseTemporal(gl_FragCoord.xy);
		bool hit = VoxyScreenSpaceRayTrace(viewPos, rayDir, dither, rayPos);

		vec3 reflection = vec3(0.0);
		#ifdef REAL_SKY_REFLECTION
			if (isEyeInWater == 0) {
				if (skylight > 1e-3) {
					vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
					float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
					vec4 skyboxData = textureBicubic(colortex5, ProjectSky(rayDirWorld) + vec2(0.0, skyCaptureRes.y * screenPixelSize.y));
					vec3 sunmoon = RenderSunReflection(rayDirWorld, worldSunVector) + RenderMoonReflection(rayDirWorld, worldSunVector);
					reflection = hit ? texelFetch(colortex4, ivec2(rayPos.xy), 0).rgb : skyboxData.rgb * skylight * NdotU;
					reflection += sunmoon * skyboxData.a * skylight * AtmosphereAbsorption(rayDirWorld, AtmosphereExtent);
				}
			} else {
				reflection = hit ? texelFetch(colortex4, ivec2(rayPos.xy), 0).rgb : vec3(0.05, 0.7, 1.0) * 0.3;
			}
		#else
			if (hit) {
				reflection = texelFetch(colortex4, ivec2(rayPos.xy), 0).rgb;
			} else if (skylight > 1e-3) {
				if (isEyeInWater == 0) {
					vec3 rayDirWorld = mat3(gbufferModelViewInverse) * rayDir;
					float NdotU = saturate((dot(normal, gbufferModelView[1].xyz) + 0.7) * 2.0) * 0.75 + 0.25;
					vec4 skyboxData = textureBicubic(colortex5, ProjectSky(rayDirWorld) + vec2(0.0, skyCaptureRes.y * screenPixelSize.y));
					reflection = skyboxData.rgb * skylight * NdotU;
				} else {
					reflection = vec3(0.05, 0.7, 1.0) * 0.25 * (timeNoon + timeMidnight * NIGHT_BRIGHTNESS);
				}
			}
		#endif

		float NdotV = max(1e-6, dot(normal, -viewDir));
		float specular = FresnelDielectricN(NdotV, isEyeInWater == 1 ? 1.0 / WATER_REFRACT_IOR : WATER_REFRACT_IOR);
		return clamp16F(vec4(reflection * specular, 1.0 - specular));
	}
#endif

//----// MAIN //----------------------------------------------------------------------------------//
void main() {
	ivec2 texel 		= ivec2(gl_FragCoord.xy);

	vec4 gbuffer3 		= texelFetch(colortex3, texel, 0);
	vec4 albedoT 		= vec4(UnpackUnorm2x8(gbuffer3.z), UnpackUnorm2x8(gbuffer3.w));

	vec3 normal 		= DecodeNormal(gbuffer3.xy);

	int materialIDT 	= int(texelFetch(colortex7, texel, 0).z * 255.0);
	TranslucentMask materialMaskT = CalculateMasksT(materialIDT);

	float depthSoild 	= GetDepthSoild(texel);
	// depthSoild += 0.38 * step(depthSoild, 0.56);
	float depth 		= GetDepthFix(texel);

	#if defined VOXY && !defined DISTANT_HORIZONS
		bool voxyWater = false;
	#endif

	vec3 viewPos 		= ScreenToViewSpace(vec3(screenCoord, depth));

	#if defined DISTANT_HORIZONS || defined VOXY
		bool dhRange = depth >= 1.0;
		if (dhRange) {
			depth = GetDepthDH(texel);
			depthSoild = GetDepthSoildDH(texel);
			viewPos = ScreenToViewSpaceDH(vec3(screenCoord, depth));
			#if defined VOXY && !defined DISTANT_HORIZONS
				// Voxy хранит непрозрачную и прозрачную (вода/стекло) глубину
				// в двух разных буферах — если на этом пикселе есть вода И её
				// глубина совпадает с "непрозрачной" (т.е. вода — верхний
				// видимый слой, а не что-то под ней), значит здесь настоящая
				// поверхность Voxy-воды, для которой нужно посчитать свою
				// нормаль/отражение (см. ниже).
				float voxyTransDepth = texelFetch(vxDepthTexTrans, texel, 0).x;
				float voxyOpaqueDepth = texelFetch(vxDepthTexOpaque, texel, 0).x;
				voxyWater = materialMaskT.water && voxyTransDepth < 1.0 && voxyTransDepth <= voxyOpaqueDepth + 1e-6;
			#endif
		}
	#endif

	vec3 viewDir 		= normalize(viewPos);
	vec3 worldPos 		= mat3(gbufferModelViewInverse) * viewPos;
	// gbufferModelViewInverse's 3x3 part is a pure rotation (orthonormal),
	// so normalize(M*v) == M*normalize(v). Reuses viewDir's normalize,
	// saving one inversesqrt+dot per pixel across the whole screen.
	vec3 worldDir 		= mat3(gbufferModelViewInverse) * viewDir;
	worldPos 			+= gbufferModelViewInverse[3].xyz;

	#if defined VOXY && !defined DISTANT_HORIZONS
		if (voxyWater) normal = GetVoxyWaterNormal(worldPos + cameraPosition, normal);
	#endif

	if (depth < 1.0) {
		#ifdef RAYTRACED_REFRACTION
			#ifdef REFRACTIVE_DISPERSION
				vec2 refractCoord  	= CalculateRefractCoord(materialMaskT, normal, viewDir, viewPos, depth, 1.5);
				vec2 refractCoordR  = CalculateRefractCoord(materialMaskT, normal, viewDir, viewPos, depth, 1.45);
				vec2 refractCoordB  = CalculateRefractCoord(materialMaskT, normal, viewDir, viewPos, depth, 1.55);
				ivec2 refractTexel 	= ivec2(refractCoord * screenSize);
				ivec2 refractTexelR = ivec2(refractCoordR * screenSize);
				ivec2 refractTexelB = ivec2(refractCoordB * screenSize);

				sceneData.g 		= texelFetch(colortex4, refractTexel, 0).g;
				sceneData.r 		= texelFetch(colortex4, refractTexelR, 0).r;
				sceneData.b 		= texelFetch(colortex4, refractTexelB, 0).b;
			#else
				vec2 refractCoord  	= CalculateRefractCoord(materialMaskT, normal, viewDir, viewPos, depth, 1.5);
				ivec2 refractTexel 	= ivec2(refractCoord * screenSize);

				sceneData 			= texelFetch(colortex4, refractTexel, 0).rgb;
			#endif
		#else
			#if defined DISTANT_HORIZONS || defined VOXY
				vec2 refractCoord;
				if (dhRange) refractCoord = CalculateRefractCoordDH(materialMaskT, normal, worldPos, viewPos, depthSoild, depth);
				else refractCoord = CalculateRefractCoord(materialMaskT, normal, worldPos, viewPos, depthSoild, depth);
			#else
				vec2 refractCoord = CalculateRefractCoord(materialMaskT, normal, worldPos, viewPos, depthSoild, depth);
			#endif

			ivec2 refractTexel 	= ivec2(refractCoord * screenSize);

			sceneData 			= texelFetch(colortex4, refractTexel, 0).rgb;
		#endif

		vec3 albedoRaw 		= texelFetch(colortex6, refractTexel, 0).rgb;
		vec3 albedo 		= SRGBtoLinear(albedoRaw);

		Material material 	= GetMaterialData(texelFetch(colortex0, refractTexel, 0).xy);

		//----// FLASHLIGHT EFFECT //---------------------------------------------------------------------//
		#if FLASHLIGHT_TOGGLE > 0
			bool isNight = (worldTime > 13000 && worldTime < 23000);
			bool shouldBeOn = true;

			#if FLASHLIGHT_TOGGLE == 2
				if (!isNight) shouldBeOn = false;
			#elif FLASHLIGHT_TOGGLE == 3
				if (max(heldBlockLightValue, heldBlockLightValue2) <= 0) shouldBeOn = false;
			#endif

			if (shouldBeOn) {
				float f_dist = length(viewPos);

				if (f_dist < FLASHLIGHT_RANGE) {
					vec3 flashlightDir = vec3(0.0, 0.0, -1.0);

					#if FLASHLIGHT_DELAY == 1
						vec2 mouseVelocity = (gbufferPreviousModelView[0].xy - gbufferModelView[0].xy) + (gbufferPreviousModelView[1].xy - gbufferModelView[1].xy);
						flashlightDir.xy += mouseVelocity * FLASHLIGHT_DELAY_INTENSITY;
						flashlightDir = normalize(flashlightDir);
					#endif

					float f_dot = dot(viewDir, flashlightDir);
					float f_hotspot = 0.0;
					float f_spill = 0.0;
					vec3 f_color = vec3(1.0);
					float f_falloffMult = 0.15;

					#if FLASHLIGHT_STYLE == 0 // TACTICAL LED
						f_hotspot = smoothstep(0.975, 0.985, f_dot);
						f_spill = smoothstep(0.94, 0.975, f_dot) * 0.2;
						f_color = mix(vec3(0.9, 0.95, 1.0), vec3(1.0), f_hotspot);
						f_falloffMult = 0.12;
					#elif FLASHLIGHT_STYLE == 1 // WARM HALOGEN
						f_hotspot = smoothstep(0.95, 0.98, f_dot);
						f_spill = smoothstep(0.88, 0.95, f_dot) * 0.3;
						f_color = vec3(1.0, 0.85, 0.6);
						f_falloffMult = 0.22;
					#elif FLASHLIGHT_STYLE == 2 // WIDE FLOOD
						f_hotspot = smoothstep(0.85, 0.95, f_dot);
						f_spill = smoothstep(0.65, 0.85, f_dot) * 0.4;
						f_color = vec3(1.0, 0.98, 0.95);
						f_falloffMult = 0.35;
					#elif FLASHLIGHT_STYLE == 3 // BLUE MODERN
						f_hotspot = smoothstep(0.98, 0.988, f_dot);
						f_spill = smoothstep(0.95, 0.98, f_dot) * 0.15;
						f_color = vec3(0.7, 0.85, 1.0);
						f_falloffMult = 0.1;
					#elif FLASHLIGHT_STYLE == 4 // SEARCHLIGHT
						f_hotspot = smoothstep(0.992, 0.997, f_dot);
						f_spill = smoothstep(0.985, 0.992, f_dot) * 0.1;
						f_color = vec3(1.0, 1.0, 1.0);
						f_falloffMult = 0.05;
					#endif

					float f_finalMask = clamp(f_hotspot + f_spill, 0.0, 1.0);

					if (f_finalMask > 0.0) {
						float f_atten = exp(-f_dist * f_falloffMult);
						f_atten *= smoothstep(FLASHLIGHT_RANGE, FLASHLIGHT_RANGE * 0.5, f_dist);

						float f_ndotl = max(0.0, dot(normal, -viewDir));
						float f_strength = f_finalMask * f_atten * f_ndotl;

						#if FLASHLIGHT_SHADOW == 1
							if (f_strength > 1e-4) {
								vec3 flashlightShadowPos = vec3(HELD_LIGHT_POS_R_X, HELD_LIGHT_POS_R_Y, 0.0);
								vec3 toSurfaceFL = viewPos - flashlightShadowPos;
								vec3 shadowDirFL = toSurfaceFL / max(length(toSurfaceFL), 1e-4);

								f_strength *= HeldLightScreenSpaceShadow(viewPos, viewDir, normal, -shadowDirFL, InterleavedGradientNoiseTemporal(gl_FragCoord.xy), FLASHLIGHT_SHADOW_INTENSITY, FLASHLIGHT_RANGE);
							}
						#endif

						sceneData += albedo * f_color * f_strength * (FLASHLIGHT_INTENSITY);
					}
				}
			}
		#endif
		//------------------------------------------------------------------------------------------------//

		if (materialMaskT.stainedGlass) TransparentAbsorption(sceneData, albedoT);
		if (materialMaskT.ice) sceneData *= sqr(albedoT.rgb);

		if (materialMaskT.translucent) {
			vec4 reflectionData = texelFetch(colortex2, texel, 0);
			#if defined VOXY && !defined DISTANT_HORIZONS
				// colortex2 тут не посчитан для Voxy-воды (Water.frag для неё
				// не вызывался) — считаем отражение вручную.
				if (voxyWater) reflectionData = GetVoxyWaterReflection(normal, cube(texelFetch(colortex7, texel, 0).g), viewPos, depth);
			#endif
			sceneData = sceneData * reflectionData.a + reflectionData.rgb;
		} else if (material.hasReflections) {
			vec4 reflectionData = texelFetch(colortex2, texel, 0);
			#ifdef REFLECTION_FILTER
				if (material.isRough) reflectionData.rgb = ReflectionFilter(texel, reflectionData, material.roughness, normal, viewDir, 1.0, RandNext2F() - 0.5).rgb;
			#endif
			sceneData += reflectionData.rgb * mix(vec3(1.0), albedo, material.isMetal);
		}
	} else {
		sceneData = texelFetch(colortex4, texel, 0).rgb;
	}

	// float fogDist = depthT >= 1.0 ? far : length(viewPos);
	float fogDist = length(viewPos);
	//float fogDist = length(ScreenToViewSpace(vec3(refractCoord, GetDepthFix(refractTexel))));

	if (isEyeInWater == 1) UnderwaterFog(sceneData, materialMaskT, fogDist);
	if (isEyeInWater == 0 && depth < 1.0) {
		#if defined DISTANT_HORIZONS || defined VOXY
			#define far float(dhRenderDistance)
		#endif

		#ifdef LAND_ATMOSPHERIC_SCATTERING
			const float airNumberDensity       = 2.5035422e25; // m^3
			const float ozoneConcentrationPeak = 4e-6; // unitless
			const float ozoneNumberDensity     = airNumberDensity * exp(-35e3 / 8e3) * (134.628 / 48.0) * ozoneConcentrationPeak; // m^3 | airNumberDensity ASL * approximate relative density at altitude of peak ozone concentration * peak ozone concentration
			const vec3  ozoneCrossSection      = vec3(4.51103766177301E-21, 3.2854797958699E-21, 1.96774621921165E-22) * 0.0001; // mul by 0.0001 to convert from cm^2 to m^2 | single-wavelength values.

			const vec3  rayleighColor = vec3(6.433377384678407e+24, 1.0873673940138444e+25, 2.4861429602679963e+25);
			const float rayleighK     = 9.993284137187039e-31; // Set for an earth-like atmosphere.

			// m^3 coefficients
			const vec3 atmosphere_coefficientRayleigh = rayleighK * rayleighColor;
			const vec3 atmosphere_coefficientOzone    = ozoneCrossSection * ozoneNumberDensity;
			const vec3 atmosphere_coefficientMie      = vec3(4e-6); // Should usually be >= 2e-6, depends heavily on conditions. Current value is just one that looks good.

			const vec3 baseAttenuationCoefficient = atmosphere_coefficientRayleigh + atmosphere_coefficientMie + atmosphere_coefficientOzone;
			const mat2x3 atmosphere_coefficientsScattering = mat2x3(atmosphere_coefficientRayleigh, atmosphere_coefficientMie * 0.9);

			float dist = fogDist * eyeSkylightFix * 20.0;

			vec3 opticalDepth = baseAttenuationCoefficient * dist;

			vec3 transmittance   = exp(-opticalDepth);
			vec3 visibleFraction = min(oneMinus(transmittance) / opticalDepth, 1.0);

			float LdotV = dot(worldLightVector, worldDir);

			vec3 scattering = atmosphere_coefficientsScattering * vec2(RayleighPhase(LdotV), HenyeyGreensteinPhase(LdotV, mie_phase_g)) * directIlluminance;
			scattering += atmosphere_coefficientsScattering * vec2(0.25 * rPI) * skyIlluminance;
			scattering *= dist * visibleFraction;

			sceneData = sceneData * transmittance + scattering * 20.0 * oneMinus(wetness * 0.6);
		#elif !defined BORDER_FOG
			float density = eyeSkylightFix * 0.4 * (1.0 + wetness);
			float transmittance = expf(-fogDist / far * density);

			sceneData *= transmittance;
			sceneData += skyIlluminance * oneMinus(wetness * 0.8) * oneMinus(transmittance);
		#endif

		#ifdef BORDER_FOG
			float density = 1.0 - exp2(-sqr(pow4(length(worldPos.xz) * eyeSkylightFix / far)) * 8.0);

			density *= oneMinus(saturate(worldDir.y * 3.0));

			vec3 skyRadiance = textureBicubic(colortex5, ProjectSky(worldDir)).rgb;
			sceneData = mix(sceneData, skyRadiance, density);
		#endif
	}

	#if defined VOLUMETRIC_FOG || defined VOLUMETRIC_LIGHT || defined UW_VOLUMETRIC_LIGHT
		#if defined DISTANT_HORIZONS || defined VOXY
			vec4 VFData;
			if (dhRange) VFData = SpatialUpscaleDH(colortex1, gl_FragCoord.xy, GetDepthLinearDH(depth));
			else VFData = SpatialUpscale(colortex1, gl_FragCoord.xy, GetDepthLinear(depth));
		#else
			vec4 VFData = SpatialUpscale(colortex1, gl_FragCoord.xy, GetDepthLinear(depth));
		#endif

		sceneData *= VFData.a;
		sceneData += VFData.rgb;

		#ifdef BLOOMY_FOG
			fogTransmittance = VFData.a;
			#if FOG_TYPE == 3
				fogTransmittance = fogTransmittance * 0.3 + 0.7;
			#endif
		#endif
	#elif defined BLOOMY_FOG
		fogTransmittance = 1.0;
	#endif

	CommonFog(sceneData, fogDist);

	#ifdef BLOOMY_FOG
		float fogDensity = wetness * eyeSkylightFix * 2e-3;

		if (isEyeInWater == 1) fogDensity = 0.06 * WATER_FOG_DENSITY;
		if (isEyeInWater > 1) fogDensity = 1.0;

		fogTransmittance = min(expf(-fogDensity * fogDist), fogTransmittance);
	#endif

	#if DEBUG_NORMAL == 0
		sceneData = clamp16F(sceneData);
	#elif DEBUG_NORMAL == 1
		sceneData = normal;
	#else
		sceneData = mat3(gbufferModelViewInverse) * normal;
	#endif
}
